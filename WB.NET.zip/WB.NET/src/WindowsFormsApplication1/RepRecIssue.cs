﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepRecIssue : Form
    {
        public bool isOk = false;
        public string tipe;
        public string kb;
        public string IO = "I";
        private WBTable tbl_Do;
        private WBTable tbl_TransType;
        private WBTable tbl_Comm;
        private WBTable tbl_CommDetail;
        private WBTable tbl_TransQC;
        private WBTable tbl_transDL;
        private WBTable tbl_Iscc;
        private WBTable tbl_Transport;
        private WBTable tblTransType;
        private DataRow qcTemp;
        private string rptName;
        private string Vendor;
        private int jlhQa = 0;
        private int no;
        private int minutes;
        private int hours;
        private int jlhKolom = 0;
        private int jlhKolomB = 0;
        private int jlhKlmDL = 0;
        private int nextcol = 0;
        private int jlhklmsDL = 0;
        private string commUnit = "KG";
        private string bulkpack = "B";
        private double weightIn = 0.0;
        private double[] weightIn2 = new double[4];
        private double eGross = 0.0;
        private double eTare = 0.0;
        private double eNet = 0.0;
        private double fBruto = 0.0;
        private double fTarra = 0.0;
        private double fNett = 0.0;
        private double fLoadingQty = 0.0;
        private double fLoadingQty_opw = 0.0;
        private double fLoadingNetW = 0.0;
        private float commNetW = 0f;
        private string commUOM = "";
        private double sfLoadingQty = 0.0;
        private double sfLoadingNetW = 0.0;
        private double sfLoadingQty_opw = 0.0;
        private double vfLoadingQty = 0.0;
        private double vfLoadingNetW = 0.0;
        private double vfLoadingQty_opw = 0.0;
        private double tfLoadingQty = 0.0;
        private double tfLoadingNetW = 0.0;
        private double tfLoadingQty_opw = 0.0;
        private double seGross = 0.0;
        private double seTare = 0.0;
        private double seNet = 0.0;
        private double sfBruto = 0.0;
        private double sfTarra = 0.0;
        private double sfNett = 0.0;
        private double sConv = 0.0;
        private double seReturInKg = 0.0;
        private double seReturInPack = 0.0;
        private double veReturInKg = 0.0;
        private double veReturInPack = 0.0;
        private double seLossInKg = 0.0;
        private double seLossInPack = 0.0;
        private double veLossInKg = 0.0;
        private double veLossInPack = 0.0;
        private double veGross = 0.0;
        private double veTare = 0.0;
        private double veNet = 0.0;
        private double vfBruto = 0.0;
        private double vfTarra = 0.0;
        private double vfNett = 0.0;
        private double vConv = 0.0;
        private double teGross = 0.0;
        private double teTare = 0.0;
        private double teNet = 0.0;
        private double tfBruto = 0.0;
        private double tfTarra = 0.0;
        private double tfNett = 0.0;
        private double tConv = 0.0;
        private double lossInKg = 0.0;
        private double lossInPack = 0.0;
        private double subDO = 0.0;
        private double vsubDO = 0.0;
        private double wDiff = 0.0;
        private double pwDiff = 0.0;
        private double party = 0.0;
        private double vparty = 0.0;
        private double uToday = 0.0;
        private double OS = 0.0;
        private double party_est = 0.0;
        private double party_fac = 0.0;
        private double vparty_fac = 0.0;
        private double vparty_est = 0.0;
        private double uToday_est = 0.0;
        private double uToday_fac = 0.0;
        private double uToday_loadQty = 0.0;
        private double OS_est = 0.0;
        private double OS_fac = 0.0;
        private double OS_loadQty = 0.0;
        private double subDO_est = 0.0;
        private double vsubDO_est = 0.0;
        private double subDO_fac = 0.0;
        private double vsubDO_fac = 0.0;
        private double subDO_loadQty = 0.0;
        private double vsubDO_loadQty = 0.0;
        private double tsubDO_fac = 0.0;
        private string deductedBy = "0";
        private double fgunny = 0.0;
        private double sfgunny = 0.0;
        private double vfgunny = 0.0;
        private double tfgunny = 0.0;
        private double fdeduc = 0.0;
        private double sfdeduc = 0.0;
        private double vfdeduc = 0.0;
        private double tfdeduc = 0.0;
        private double freceived = 0.0;
        private double sfreceived = 0.0;
        private double vfreceived = 0.0;
        private double tfreceived = 0.0;
        private double tQDeductKG = 0.0;
        private double todayDL = 0.0;
        private double tiltodayDL = 0.0;
        private double osDL = 0.0;
        private double sjgunny = 0.0;
        private double sjtgunny = 0.0;
        private double sjKG = 0.0;
        private double sjtKG = 0.0;
        private double vweightIn = 0.0;
        private double vweightIn_est = 0.0;
        private double vweightIn_fac = 0.0;
        private double vweightIn_loadQty = 0.0;
        private string mark_return = "";
        private DateTime time1;
        private DateTime time2;
        private TimeSpan ts;
        private string tmpDate;
        private DataRow commrow;
        private double netGunny = 0.0;
        private double JlhGunnyDO = 0.0;
        private double jlhGunnyToday = 0.0;
        private IContainer components = null;
        private Panel panel1;
        private CheckBox checkConv;
        private CheckBox checkSeal;
        private CheckBox checkRmkReport;
        private CheckBox checkRmkTicket;
        private CheckBox checkVariance;
        private CheckBox checkBrutoTarra;
        private CheckBox check3rdParty;
        private CheckBox checkTransporter;
        private CheckBox checkDeliNote;
        private CheckBox checkDriverName;
        private CheckBox checkLicenseNo;
        private CheckBox checkEstate;
        private CheckBox checkRelation;
        private CheckBox check1xDO;
        private CheckBox check1xSTO;
        private CheckBox checkPO;
        private CheckBox checkSTO;
        private CheckBox checkDO_No;
        private CheckBox checkDelivery;
        public GroupBox grType;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public GroupBox grKB;
        public RadioButton rboNonKB;
        public RadioButton rboKB;
        public DateTimePicker monthCalendar1;
        public Label labelDate;
        private Label labelTransTypeName;
        private Button buttonType;
        private TextBox textType;
        private Label label9;
        public Label label4;
        private Panel panel2;
        private CheckBox checkProcess;
        private CheckBox checkTank;
        private GroupBox groupBox1;
        public Button button2;
        public Button button1;
        private CheckBox checkParty;
        private CheckBox checkHour;
        public Label labelMinOS;
        public TextBox textMinOS;
        private CheckBox checkISO;
        private RadioButton radioPO;
        private RadioButton radioTank;
        private RadioButton radioEstate;
        private RadioButton radioRelation;
        private RadioButton radioContract;
        private RadioButton radioDo;
        private RadioButton radioDaily;
        private CheckBox checkRegDate;
        private CheckBox checkFactQ;
        private CheckBox checkEstQ;
        private MaskedTextBox TimeTo;
        private MaskedTextBox TimeFrom;
        private CheckBox checkHourDiff;
        public Label labelProcess;
        public Label labelRecNo;
        private RadioButton radioDOReport;
        private RadioButton radioDailyCumulative;
        private RadioButton radioMonthlyCumulative;
        private CheckBox cbGunny;
        private CheckBox cbDeduction;
        private CheckBox checkContract;
        private CheckBox checkDeliveryLetter;
        private Label label1;
        public DateTimePicker monthCalendar2;
        private CheckBox checkRelationName;
        private RadioButton radioCommodity;
        private CheckBox checkChange;
        private CheckBox checkCreate;
        private CheckBox checkQSt;
        private CheckBox CbAddInfo;
        private CheckBox cBoxPISI;
        private CheckBox checkBoxMaterialStuffing;
        private CheckBox checkLoadingQty;
        private CheckBox cBoxCommName;
        private CheckBox cb_yellow;
        private CheckBox cBoxWBCode;
        private CheckBox cBoxAll;
        public Label label3;
        public TextBox txt_ref;
        public TextBox textTransport;
        public Button buttonTransporter;
        public Label label2;
        public Label labelQStandard;
        private ComboBox ComboIscc;
        public CheckBox chkNonQ;
        public CheckBox chkQstandard;
        public Button btnQstandard;
        public TextBox txtqstandard;
        private ComboBox comboDO;
        private ComboBox ComboComm;
        public Label labelTank;
        public TextBox textTanker;
        public Label label5;
        public Button buttonDoNo;
        public Label labelDoNo;
        public TextBox textDoNo;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        private CheckBox checkSourceDesc;
        private CheckBox checkSourceCode;
        private CheckBox checkTransporterName;
        private CheckBox chkShowOSUTDPerVendor;
        private CheckBox checkBoxGatepassNumber;
        private CheckBox checkGrade;
        private CheckBox checkOPRef;
        private CheckBox cb_interval34;
        private CheckBox cb_interval12;
        private CheckBox checkRegistrationInOut;
        private CheckBox checkOI;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxReturnInPack;
        private CheckBox cBoxLossInKG;
        private CheckBox cBoxReturnInKG;
        private CheckBox checkQDeductKG;
        private CheckBox checkBoxDOSAPItem;
        private CheckBox checkBoxDOSAP;

        public RepRecIssue()
        {
            this.InitializeComponent();
        }

        private void btnQstandard_Click(object sender, EventArgs e)
        {
            FormQStandard standard = new FormQStandard {
                pMode = "CHOOSE"
            };
            standard.ShowDialog();
            if (standard.countt != 0)
            {
                this.txtqstandard.Text = standard.arry[0].ToString();
                this.textCommodity.Focus();
                this.ComboIscc.Items.Clear();
                foreach (string str in standard.arry)
                {
                    if (str != null)
                    {
                        this.ComboIscc.Items.Add(str);
                    }
                }
            }
            standard.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.veGross = 0.0;
            this.veNet = 0.0;
            this.veTare = 0.0;
            this.vfBruto = 0.0;
            this.vfNett = 0.0;
            this.vfTarra = 0.0;
            this.vConv = 0.0;
            this.vfreceived = 0.0;
            this.vfdeduc = 0.0;
            this.vfgunny = 0.0;
            this.vsubDO = 0.0;
            this.vsubDO_est = 0.0;
            this.vsubDO_fac = 0.0;
            this.vsubDO_loadQty = 0.0;
            this.vparty = 0.0;
            this.vparty_fac = 0.0;
            this.vparty_est = 0.0;
            this.vweightIn = 0.0;
            this.vfLoadingQty = 0.0;
            this.vfLoadingQty_opw = 0.0;
            this.vfLoadingNetW = 0.0;
            if (this.radioDOReport.Checked && (this.textDoNo.Text.Trim() == ""))
            {
                MessageBox.Show(Resource.Mes_599, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textDoNo.Focus();
            }
            else
            {
                this.labelProcess.Visible = true;
                this.labelRecNo.Visible = true;
                this.labelProcess.Refresh();
                this.labelRecNo.Refresh();
                this.isOk = true;
                WBTable table = new WBTable();
                string sqltext = "";
                if (this.radioDaily.Checked || this.radioDailyCumulative.Checked)
                {
                    if (this.checkProcess.Checked)
                    {
                        string[] textArray1 = new string[] { " and (report_date = '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00' ) or ((WX = '4X' and _4th = 0) or (WX = '2X' and _2nd = 0)) " };
                        sqltext = "Select * from vw_Trans where " + WBData.CompanyLocation(string.Concat(textArray1));
                    }
                    else
                    {
                        string[] textArray2 = new string[] { " and (report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                        sqltext = "Select * from vw_Trans where " + WBData.CompanyLocation(string.Concat(textArray2));
                    }
                }
                else if (this.radioMonthlyCumulative.Checked)
                {
                    if (this.checkProcess.Checked)
                    {
                        string[] textArray3 = new string[] { " and (Month(report_date) = '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Month.ToString(), "' and Year(report_date) = '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Year.ToString(), "' and Report_Date <= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00') or ((WX = '4X' and _4th = 0) or (WX = '2X' and _2nd = 0)) " };
                        sqltext = "Select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray3));
                    }
                    else
                    {
                        string[] textArray4 = new string[] { " and (Month(report_date) = '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Month.ToString(), "' and Year(report_date) = '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Year.ToString(), "' and Report_Date <= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                        sqltext = "Select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray4));
                    }
                }
                if (this.radioDOReport.Checked)
                {
                    sqltext = "Select * from vw_Trans where " + WBData.CompanyLocation(" and ( report_Date is not null or report_date <> '') ");
                }
                if (this.textType.Text.Trim() != "")
                {
                    sqltext = sqltext + " and transaction_code = '" + this.textType.Text + "' ";
                }
                if (this.txt_ref.Text.Trim() != "")
                {
                    sqltext = sqltext + " and Ref = '" + this.txt_ref.Text.Trim() + "' ";
                }
                if (this.textTransport.Text.Trim() != "")
                {
                    sqltext = sqltext + " and Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                }
                if (this.textCommodity.Text.Trim() != "")
                {
                    sqltext = sqltext + " and (comm_code = '" + this.textCommodity.Text + "' ";
                    int num4 = 1;
                    while (true)
                    {
                        if (num4 >= this.ComboComm.Items.Count)
                        {
                            sqltext = sqltext + ") ";
                            break;
                        }
                        sqltext = sqltext + " or comm_code = '" + this.ComboComm.Items[num4].ToString() + "' ";
                        num4++;
                    }
                }
                if (this.textDoNo.Text.Trim() != "")
                {
                    sqltext = sqltext + " and (Do_No = '" + this.textDoNo.Text + "' ";
                    int num5 = 1;
                    while (true)
                    {
                        if (num5 >= this.comboDO.Items.Count)
                        {
                            sqltext = sqltext + ") ";
                            break;
                        }
                        sqltext = sqltext + " or Do_No = '" + this.comboDO.Items[num5].ToString() + "' ";
                        num5++;
                    }
                }
                if (this.textTanker.Text.Trim() != "")
                {
                    sqltext = sqltext + " and TankQC = '" + this.textTanker.Text + "' ";
                }
                if (!this.radioDOReport.Checked)
                {
                    sqltext = sqltext + " and IO = '" + this.IO + "' ";
                }
                this.kb = !this.rboKB.Checked ? "N" : "Y";
                sqltext = sqltext + " and berikat = '" + this.kb + "' ";
                if (this.chkQstandard.Checked && this.chkNonQ.Checked)
                {
                    sqltext = sqltext + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                    int num6 = 1;
                    while (true)
                    {
                        if (num6 >= this.ComboIscc.Items.Count)
                        {
                            sqltext = sqltext + " or qstandard = '' or qstandard is null) ";
                            break;
                        }
                        sqltext = sqltext + " or qstandard = '" + this.ComboIscc.Items[num6].ToString() + "' ";
                        num6++;
                    }
                }
                else if (this.chkQstandard.Checked || this.chkNonQ.Checked)
                {
                    if (!this.chkQstandard.Checked)
                    {
                        if (this.chkNonQ.Checked)
                        {
                            sqltext = sqltext + " and (qstandard = '' or qstandard is null) ";
                        }
                    }
                    else
                    {
                        sqltext = sqltext + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                        int num7 = 1;
                        while (true)
                        {
                            if (num7 >= this.ComboIscc.Items.Count)
                            {
                                sqltext = sqltext + ") ";
                                break;
                            }
                            sqltext = sqltext + " or qstandard = '" + this.ComboIscc.Items[num7].ToString() + "' ";
                            num7++;
                        }
                    }
                }
                if (this.chkNonQ.Checked)
                {
                }
                sqltext = ((sqltext + " and (deleted is null or deleted = 'N') ") + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))" + " order by Comm_code ";
                if (this.radioDo.Checked)
                {
                    sqltext = sqltext + " , Relation_code, DO_NO";
                }
                else if (this.radioContract.Checked)
                {
                    sqltext = sqltext + " , Relation_code, Contract";
                }
                else if (this.radioRelation.Checked)
                {
                    sqltext = sqltext + " , Relation_code";
                }
                else if (this.radioEstate.Checked)
                {
                    sqltext = sqltext + " , Relation_code, Estate_Code";
                }
                else if (this.radioTank.Checked)
                {
                    sqltext = sqltext + " , Relation_code, TankQC";
                }
                else if (this.radioPO.Checked)
                {
                    sqltext = sqltext + " , Relation_code, PO";
                }
                sqltext = sqltext + " , ref ";
                table.OpenTable("vw_trans", sqltext, WBData.conn);
                string comm = "";
                string doNo = "";
                int num = 0;
                double count = 0.0;
                count = table.DT.Rows.Count;
                if (!(count != 0.0))
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML rep = new HTML();
                    rep.File = rep.File + @"\" + WBUser.UserID + "_RecIssue.htm";
                    rep.Title = this.rptName;
                    rep.Open();
                    rep.Write(rep.Style());
                    if (this.radioDOReport.Checked)
                    {
                        rep.Write("<br><font size=5><b>WEIGHING LIST OF GOODS RECEIVE/GOODS ISSUE (DO DETAILS)</b></font><br>");
                    }
                    else if (this.rboGR.Checked)
                    {
                        rep.Write("<br><font size=5><b>WEIGHING LIST OF GOODS RECEIVE</b></font><br>");
                    }
                    else
                    {
                        rep.Write("<br><font size=5><b>WEIGHING LIST OF GOODS ISSUE</b></font><br>");
                    }
                    string[] textArray5 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    rep.Write(string.Concat(textArray5));
                    string[] textArray6 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                    rep.Write(string.Concat(textArray6));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    rep.Write("<br><br>");
                    rep.Write("<font size=3>");
                    if (this.radioDaily.Checked)
                    {
                        rep.Write("<br>DAILY REPORT");
                    }
                    else if (this.radioDailyCumulative.Checked)
                    {
                        rep.Write("<br>DAILY CUMULATIVE REPORT");
                    }
                    else if (this.radioMonthlyCumulative.Checked)
                    {
                        rep.Write("<br>MONTHLY CUMULATIVE REPORT");
                    }
                    rep.Write("</font></b><br/>");
                    rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    if (this.checkISO.Checked)
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>FormISO</td>");
                        rep.Write("<td>: <b>" + WBSetting.Field("FormISO").Trim() + "</b></td>");
                        rep.Write("</tr>");
                    }
                    if (this.textCommodity.Text.Trim() != "")
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Composite_004 + "</td>");
                        string[] textArray7 = new string[] { "<td>: <b>", this.textCommodity.Text, " - ", this.labelCommName.Text, "</b></td>" };
                        rep.Write(string.Concat(textArray7));
                        rep.Write("</tr>");
                    }
                    if (this.textDoNo.Text.Trim() != "")
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Contract_002 + "</td>");
                        rep.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                        rep.Write("</tr>");
                    }
                    if (this.textTanker.Text.Trim() != "")
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Main_082 + "</td>");
                        rep.Write("<td>: <b>" + this.textTanker.Text + "</b></td>");
                        rep.Write("</tr>");
                    }
                    if (this.textType.Text.Trim() != "")
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Gatepass_023 + "</td>");
                        rep.Write("<td>: <b>" + this.textType.Text + "</b></td>");
                        rep.Write("</tr>");
                    }
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>Report Date</td>");
                    rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br/><br/>");
                    foreach (DataRow row in table.DT.Rows)
                    {
                        num++;
                        this.labelRecNo.Text = num.ToString() + " / " + count.ToString();
                        this.labelRecNo.Refresh();
                        bool flag45 = row["Do_No"].ToString().Trim() != doNo;
                        if (flag45 && ((num != 1) & !this.radioCommodity.Checked))
                        {
                            this.subTotalDO(rep, doNo);
                        }
                        if (row["Relation_Code"].ToString().Trim() != this.Vendor)
                        {
                            if (this.Vendor == "")
                            {
                                break;
                            }
                            if ((num != 1) & !this.radioCommodity.Checked)
                            {
                                this.subTotalVendor(rep, this.Vendor);
                            }
                            this.veGross = 0.0;
                            this.veNet = 0.0;
                            this.veTare = 0.0;
                            this.vfBruto = 0.0;
                            this.vfNett = 0.0;
                            this.vfTarra = 0.0;
                            this.vConv = 0.0;
                            this.vfreceived = 0.0;
                            this.vfdeduc = 0.0;
                            this.vfgunny = 0.0;
                            this.vsubDO = 0.0;
                            this.vsubDO_est = 0.0;
                            this.vsubDO_fac = 0.0;
                            this.vsubDO_loadQty = 0.0;
                            this.vparty = 0.0;
                            this.vparty_est = 0.0;
                            this.vparty_fac = 0.0;
                            this.vweightIn = 0.0;
                            this.vweightIn_est = 0.0;
                            this.vweightIn_fac = 0.0;
                            this.vweightIn_loadQty = 0.0;
                            this.vfLoadingQty = 0.0;
                            this.vfLoadingQty_opw = 0.0;
                            this.vfLoadingNetW = 0.0;
                        }
                        if (row["comm_code"].ToString().Trim() != comm.Trim())
                        {
                            if (num != 1)
                            {
                                this.subTotalComm(rep, comm);
                                rep.Write("</table>");
                                this.tbl_CommDetail.Close();
                            }
                            this.teGross = 0.0;
                            this.teNet = 0.0;
                            this.teTare = 0.0;
                            this.tfBruto = 0.0;
                            this.tfNett = 0.0;
                            this.tfTarra = 0.0;
                            this.tConv = 0.0;
                            this.tfLoadingQty = 0.0;
                            this.tfLoadingQty_opw = 0.0;
                            this.tfLoadingNetW = 0.0;
                            this.tQDeductKG = 0.0;
                            this.tfreceived = 0.0;
                            this.tfdeduc = 0.0;
                            this.tfgunny = 0.0;
                            this.sjtgunny = 0.0;
                            this.sjtKG = 0.0;
                            comm = row["comm_code"].ToString().Trim();
                            string[] textArray8 = new string[] { "<br><b><font size=2>", Resource.CommE_001, " : ", comm, "</b>" };
                            rep.Write(string.Concat(textArray8));
                            this.tbl_CommDetail = new WBTable();
                            this.tbl_CommDetail.OpenTable("tbl_commodity_detail", "select * from wb_commodity_detail where " + WBData.CompanyLocation(" and comm_code ='" + comm + "'"), WBData.conn);
                            this.jlhQa = this.tbl_CommDetail.DT.Rows.Count;
                            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                            if (this.radioCommodity.Checked)
                            {
                                this.initHeader(rep, "", this.Vendor);
                                this.no = 0;
                            }
                        }
                        if ((row["Do_No"].ToString().Trim() != doNo) & !this.radioCommodity.Checked)
                        {
                            this.seGross = 0.0;
                            this.seTare = 0.0;
                            this.seNet = 0.0;
                            this.sfBruto = 0.0;
                            this.sfNett = 0.0;
                            this.sfTarra = 0.0;
                            this.subDO = 0.0;
                            this.subDO_est = 0.0;
                            this.subDO_fac = 0.0;
                            this.subDO_loadQty = 0.0;
                            this.sConv = 0.0;
                            this.no = 0;
                            this.seReturInKg = 0.0;
                            this.seReturInPack = 0.0;
                            this.veReturInKg = 0.0;
                            this.veReturInPack = 0.0;
                            this.seLossInKg = 0.0;
                            this.seLossInPack = 0.0;
                            this.veLossInKg = 0.0;
                            this.veLossInPack = 0.0;
                            this.sfreceived = 0.0;
                            this.sfdeduc = 0.0;
                            this.sfgunny = 0.0;
                            this.sjgunny = 0.0;
                            this.sjKG = 0.0;
                            this.sfLoadingQty = 0.0;
                            this.sfLoadingNetW = 0.0;
                            this.sfLoadingQty_opw = 0.0;
                            double num1 = this.party = Program.StrToDouble(row["Quantity"].ToString().Trim(), 0);
                            this.party_est = this.party_fac = num1;
                            this.deductedBy = row["deductedBy"].ToString();
                            if (row["Entry_Fact"].ToString().Trim() != "0")
                            {
                                this.party_fac = Program.StrToDouble(row["Entry_Fact"].ToString().Trim(), 0);
                            }
                            if (row["Entry_Est"].ToString().Trim() != "0")
                            {
                                this.party_est = Program.StrToDouble(row["Entry_Est"].ToString().Trim(), 0);
                            }
                            if (this.deductedBy == "0")
                            {
                                if (row["Entry_Fact"].ToString().Trim() != "0")
                                {
                                    this.party = Program.StrToDouble(row["Entry_Fact"].ToString().Trim(), 0);
                                }
                            }
                            else if ((this.deductedBy == "1") && (row["Entry_Est"].ToString().Trim() != "0"))
                            {
                                this.party = Program.StrToDouble(row["Entry_Est"].ToString().Trim(), 0);
                            }
                            this.vparty += this.party;
                            this.vparty_est += this.party_est;
                            this.vparty_fac += this.party_fac;
                            doNo = row["Do_No"].ToString().Trim();
                            if (!this.radioDOReport.Checked)
                            {
                                this.weightIn2 = Enumerable.Empty<double>().ToArray<double>();
                                this.weightIn2 = this.cekSDHI(doNo);
                                this.weightIn = this.weightIn2[3];
                            }
                            else
                            {
                                this.weightIn = 0.0;
                                this.weightIn2[0] = 0.0;
                                this.weightIn2[1] = 0.0;
                                this.weightIn2[2] = 0.0;
                            }
                            this.vweightIn += this.weightIn;
                            this.vweightIn_fac += this.weightIn2[1];
                            this.vweightIn_est += this.weightIn2[0];
                            this.vweightIn_loadQty += this.weightIn2[2];
                            if (this.Vendor == row["Relation_Code"].ToString().Trim())
                            {
                                this.initHeader(rep, doNo, "");
                            }
                            else
                            {
                                this.Vendor = row["Relation_Code"].ToString().Trim();
                                this.initHeader(rep, doNo, this.Vendor);
                            }
                        }
                        this.tbl_TransQC = new WBTable();
                        this.tbl_TransQC.OpenTable("wb_transQC", "Select * from wb_transQC where ref = '" + rep.strq(row["ref"].ToString()) + "'", WBData.conn);
                        this.tbl_transDL = new WBTable();
                        string[] textArray9 = new string[] { "Select * from wb_transBatch where (ref = '", row["ref"].ToString().Trim(), "' or ref like '", row["ref"].ToString().Trim(), "-%') and SO_no = '", row["Do_No"].ToString().Trim(), "'" };
                        this.tbl_transDL.OpenTable("wb_transBatch", string.Concat(textArray9), WBData.conn);
                        this.tbl_Comm.ReOpen();
                        string[] aField = new string[] { "comm_code" };
                        string[] aFind = new string[] { comm };
                        this.commrow = this.tbl_Comm.GetData(aField, aFind);
                        this.commNetW = float.Parse((this.commrow["Netto_Weight"].ToString().Trim() == "") ? "0" : this.commrow["Netto_Weight"].ToString().Trim());
                        this.commUOM = this.commrow["Unit"].ToString();
                        this.bulkpack = this.commrow["bulkpack"].ToString();
                        try
                        {
                            this.netGunny = Convert.ToInt32(this.commrow["Netto_Gunny"]);
                            this.JlhGunnyDO = this.party / this.netGunny;
                        }
                        catch
                        {
                            this.netGunny = 0.0;
                            this.JlhGunnyDO = 0.0;
                        }
                        this.fillTable(rep, row);
                        this.tbl_TransQC.Close();
                        this.tbl_transDL.Close();
                    }
                    if (!this.radioCommodity.Checked)
                    {
                        this.subTotalDO(rep, doNo);
                    }
                    if (!this.radioCommodity.Checked)
                    {
                        this.subTotalVendor(rep, this.Vendor);
                    }
                    this.subTotalComm(rep, comm);
                    rep.Write("</table>");
                    rep.Write("<br><br><br>");
                    rep.writeSign();
                    rep.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                    };
                    report.ShowDialog();
                    rep.Dispose();
                    report.Dispose();
                    this.labelProcess.Visible = false;
                    this.labelRecNo.Visible = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransport.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransport.Focus();
            }
            transporter.Dispose();
        }

        private void buttonType_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textType.Text = type.ReturnRow["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = type.ReturnRow["Transaction_Name"].ToString();
            }
            type.Dispose();
        }

        private void cbGunny_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cBoxAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cBoxAll.Checked)
            {
                foreach (Control control in this.panel1.GetOffsprings())
                {
                    if (((control.GetType() == typeof(CheckBox)) && control.Visible) && ((control.Name != "chkQstandard") && (control.Name != "chkNonQ")))
                    {
                        ((CheckBox) control).Checked = true;
                    }
                }
            }
            else
            {
                foreach (Control control2 in this.panel1.GetOffsprings())
                {
                    if (((control2.GetType() == typeof(CheckBox)) && control2.Visible) && ((control2.Name != "chkQstandard") && (control2.Name != "chkNonQ")))
                    {
                        ((CheckBox) control2).Checked = false;
                    }
                }
            }
        }

        private unsafe double[] cekSDHI(string DoNo)
        {
            WBTable table2;
            WBTable table3;
            double num8;
            string str = "0";
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            string str2 = "";
            string str3 = "";
            string str4 = "KG";
            string str5 = "";
            double num7 = 0.0;
            double[] numArray = new double[4];
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DT.Rows[0]["check_qty"].ToString() == "Y")
            {
                str2 = table.DR["comm_code"].ToString();
                str = table.DR["deductedby"].ToString();
                num3 = (Program.StrToDouble(table.DR["Entry_Est"].ToString(), 0) <= 0.0) ? Program.StrToDouble(table.DR["Quantity"].ToString(), 0) : Program.StrToDouble(table.DR["Entry_Est"].ToString(), 0);
                num4 = (Program.StrToDouble(table.DR["Entry_Fact"].ToString(), 0) <= 0.0) ? Program.StrToDouble(table.DR["Quantity"].ToString(), 0) : Program.StrToDouble(table.DR["Entry_Fact"].ToString(), 0);
                num2 = (table.DR["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(table.DR["tolerance"].ToString());
                table2 = new WBTable();
                table2.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str2 + "'"), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                str3 = table2.DR["BulkPack"].ToString();
                str4 = table2.DR["Unit"].ToString();
                str5 = table2.DR["Type"].ToString();
                num7 = Program.StrToDouble(table2.DR["Netto_Weight"].ToString(), 0);
                table3 = new WBTable();
                string[] textArray1 = new string[] { "Select sum(NetFactory) as NetFactory,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty,  sum(case when loading_qty_opw = '0' then loading_qty else loading_qty_opw end) as loading_qty_opw,  sum(TotalGunny) as TotalGunny  from vw_outstanding  where ", WBData.CompanyLocation(" and DO_NO = '" + DoNo + "' "), " AND (mark_return = '' OR mark_return is null)  AND (mark_accident = '' OR mark_accident is null)  and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "'" };
                table3.OpenTable("vw_outstanding", string.Concat(textArray1), WBData.conn);
                if (table3.DT.Rows.Count <= 0)
                {
                    num8 = 0.0;
                    this.jlhGunnyToday = 0.0;
                }
                else
                {
                    table3.DR = table3.DT.Rows[0];
                    if (table3.DR["NetFactory"].ToString().Length > 0)
                    {
                        numArray[1] = Convert.ToDouble(table3.DR["NetFactory"].ToString());
                    }
                    if (table3.DR["NetOther"].ToString().Length > 0)
                    {
                        numArray[0] = Convert.ToDouble(table3.DR["NetOther"].ToString());
                    }
                    if (str == "1")
                    {
                        if ((str4 == "KG") || (str4 == ""))
                        {
                            if (table3.DR["NetOther"].ToString().Length > 0)
                            {
                                num8 = Convert.ToDouble(table3.DR["NetOther"].ToString());
                            }
                            else
                            {
                                num8 = 0.0;
                                numArray[0] = 0.0;
                            }
                        }
                        else if (str3 == "P")
                        {
                            num8 = Program.StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * num7;
                            numArray[2] = Program.StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * num7;
                        }
                        else
                        {
                            num8 = Program.StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 0);
                            numArray[2] = Program.StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 0);
                        }
                    }
                    else if ((str4 == "KG") || (str4 == ""))
                    {
                        if (table3.DR["NetFactory"].ToString().Length > 0)
                        {
                            num8 = Convert.ToDouble(table3.DR["NetFactory"].ToString());
                        }
                        else
                        {
                            num8 = 0.0;
                            numArray[1] = 0.0;
                        }
                    }
                    else if (str3 == "P")
                    {
                        num8 = Program.StrToDouble(table3.DT.Rows[0]["loading_qty"].ToString(), 0) * num7;
                        numArray[2] = Program.StrToDouble(table3.DT.Rows[0]["loading_qty"].ToString(), 0) * num7;
                    }
                    else
                    {
                        num8 = Program.StrToDouble(table3.DT.Rows[0]["loading_qty"].ToString(), 0);
                        numArray[2] = Program.StrToDouble(table3.DT.Rows[0]["loading_qty"].ToString(), 0);
                    }
                    try
                    {
                        this.jlhGunnyToday = Convert.ToDouble(table3.DR["NetGunny"].ToString());
                    }
                    catch
                    {
                        this.jlhGunnyToday = 0.0;
                    }
                }
            }
            else
            {
                table.Dispose();
                return numArray;
            }
            numArray[3] = num8;
            string[] textArray2 = new string[] { "Select sum(NetFactory) as NetFactory,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty,  sum(TotalGunny) as TotalGunny  from vw_outstanding  where ", WBData.CompanyLocation(" and DO_NO = '" + DoNo + "' "), " AND (mark_return = 'X')  and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "'" };
            table3.OpenTable("vw_outstanding", string.Concat(textArray2), WBData.conn);
            if (table3.DT.Rows.Count > 0)
            {
                num8 -= Program.StrToDouble(table3.DT.Rows[0]["netOther"].ToString(), 0);
                double* numPtr1 = numArray;
                numPtr1[0] -= Program.StrToDouble(table3.DT.Rows[0]["netOther"].ToString(), 0);
                double* numPtr2 = &(numArray[1]);
                numPtr2[0] -= Program.StrToDouble(table3.DT.Rows[0]["netOther"].ToString(), 0);
                double* numPtr3 = &(numArray[2]);
                numPtr3[0] -= Program.StrToDouble(table3.DT.Rows[0]["netOther"].ToString(), 0);
            }
            numArray[3] = num8;
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            return numArray;
        }

        private double cekSDHIOld(string DoNo)
        {
            double num;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation("and DO_NO = '" + DoNo + "'"), WBData.conn);
            table2.DR = table2.DT.Rows[0];
            if (WBSetting.locType == "1")
            {
                if (this.IO == "O")
                {
                    string[] textArray1 = new string[] { "Select sum(NETTO) as Net, sum(TotalGunny) as NetGunny from vw_trans where DO_NO = '", DoNo, "'and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "' and (deleted is null or deleted = 'N') and (report_date is not null)" };
                    table.OpenTable("vw_trans", string.Concat(textArray1), WBData.conn);
                }
                else
                {
                    string[] textArray2 = new string[] { "Select sum(NETTO) as Net, sum(TotalGunny) as NetGunny from vw_trans where DO_NO = '", DoNo, "'and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "' and (deleted is null or deleted = 'N') and (report_date is not null) " };
                    table.OpenTable("vw_trans", string.Concat(textArray2), WBData.conn);
                }
            }
            else if (table2.DR["deductedby"].ToString() == "0")
            {
                string[] textArray3 = new string[] { "Select sum(NETTO) as Net, sum(TotalGunny) as NetGunny from vw_trans where DO_NO = '", DoNo, "'and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "' and (deleted is null or deleted = 'N') and (report_date is not null)" };
                table.OpenTable("vw_trans", string.Concat(textArray3), WBData.conn);
            }
            else
            {
                string[] textArray4 = new string[] { "Select sum(Estate_qty) as Net, sum(TotalGunny) as NetGunny from vw_trans where DO_NO = '", DoNo, "'and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text)), "' and (deleted is null or deleted = 'N') and (report_date is not null)" };
                table.OpenTable("vw_trans", string.Concat(textArray4), WBData.conn);
            }
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
                this.jlhGunnyToday = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Net"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Net"].ToString());
                try
                {
                    this.jlhGunnyToday = Convert.ToDouble(table.DR["NetGunny"].ToString());
                }
                catch
                {
                    this.jlhGunnyToday = 0.0;
                }
            }
            return num;
        }

        private void checkBrutoTarra_CheckedChanged(object sender, EventArgs e)
        {
            this.cbDeduction.Enabled = true;
            this.cbGunny.Enabled = true;
            if (!this.checkBrutoTarra.Checked)
            {
                this.cbDeduction.Checked = false;
                this.cbGunny.Checked = false;
                this.cbDeduction.Enabled = false;
                this.cbGunny.Enabled = false;
            }
        }

        private void checkTank_CheckedChanged(object sender, EventArgs e)
        {
            this.textTanker.Enabled = this.checkTank.Checked;
        }

        private void chkQstandard_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkQstandard.Checked)
            {
                this.txtqstandard.Enabled = true;
                this.btnQstandard.Enabled = true;
            }
            else
            {
                this.txtqstandard.Text = "";
                this.ComboIscc.Items.Clear();
                this.txtqstandard.Enabled = false;
                this.btnQstandard.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillTable(HTML rep, DataRow aRow)
        {
            this.wDiff = 0.0;
            this.pwDiff = 0.0;
            if (this.radioDaily.Checked && ((this.TimeFrom.Text != "") && (this.TimeTo.Text != "")))
            {
                try
                {
                    if (aRow["Time2"].ToString().Trim() != "")
                    {
                        this.time1 = Convert.ToDateTime(this.monthCalendar1.Text.Substring(0, 10) + " " + this.TimeFrom.Text + ":00");
                        this.time2 = Convert.ToDateTime(this.monthCalendar2.Text.Substring(0, 10) + " " + this.TimeTo.Text + ":00");
                        this.tmpDate = aRow["Date2"].ToString().Substring(0, 10) + " " + aRow["Time2"].ToString();
                    }
                    else
                    {
                        this.time1 = Convert.ToDateTime(this.monthCalendar1.Text.Substring(0, 10) + " " + this.TimeFrom.Text + ":00");
                        this.time2 = Convert.ToDateTime(this.monthCalendar2.Text.Substring(0, 10) + " " + this.TimeTo.Text + ":00");
                        this.tmpDate = aRow["Date1"].ToString().Substring(0, 10) + " " + aRow["Time1"].ToString();
                    }
                    if ((Convert.ToDateTime(this.tmpDate) <= this.time1) || (Convert.ToDateTime(this.tmpDate) >= this.time2))
                    {
                        return;
                    }
                }
                catch
                {
                }
            }
            this.no++;
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap>" + this.no + "</td>");
            if (aRow["Report_date"].ToString().Trim() != "")
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Report_date"].ToString().Substring(0, 10)) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Ref_date"].ToString().Substring(0, 10)) + "</td>");
            }
            if (this.checkDelivery.Checked)
            {
                rep.Write("<td >" + rep.strq(aRow["Delivery_date"].ToString().Substring(0, 10)) + "</td>");
            }
            if (this.checkHour.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Time1"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["Time2"].ToString()) + "</td>");
            }
            if (this.cb_interval12.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate1_open"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate1_close"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["interval_1"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate2_open"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate2_close"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["interval_2"].ToString()) + "</td>");
            }
            if (this.cb_interval34.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate3_open"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate3_close"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["interval_3"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate4_open"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["time_bgate4_close"].ToString()) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(aRow["interval_4"].ToString()) + "</td>");
            }
            if (this.checkHourDiff.Checked)
            {
                if (aRow["report_date"].ToString() == "")
                {
                    rep.Write("<td nowrap>00:00</td>");
                }
                else
                {
                    this.tmpDate = aRow["date1"].ToString().Substring(0, 10) + " " + aRow["Time1"].ToString();
                    this.time1 = Convert.ToDateTime(this.tmpDate);
                    this.tmpDate = aRow["date2"].ToString().Substring(0, 10) + " " + aRow["Time2"].ToString();
                    this.time2 = Convert.ToDateTime(this.tmpDate);
                    this.ts = (TimeSpan) (this.time2 - this.time1);
                    rep.Write("<td nowrap>" + this.ts.ToString().Substring(0, 5) + "</td>");
                }
            }
            if (this.checkRegistrationInOut.Checked)
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_gatepass", "Select Create_By,Create_Date,Submit_Date,Submit_Time,Submit_By from wb_gatepass where " + WBData.CompanyLocation(" and ref = '" + aRow["ref"].ToString() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    rep.Write("<td nowrap align='center'> " + rep.strq("") + " </td>");
                    rep.Write("<td nowrap align='center'> " + rep.strq("") + " </td>");
                    rep.Write("<td nowrap align='center'> " + rep.strq("") + " </td>");
                    rep.Write("<td nowrap align='center'> " + rep.strq("") + " </td>");
                }
                else
                {
                    string str = (table.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Create_Date"].ToString().Substring(0, 10);
                    string str2 = (table.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Create_Date"].ToString().Substring(11, 5);
                    string[] textArray1 = new string[] { "<td nowrap align='center'>", str2, " ", str, "</td>" };
                    rep.Write(string.Concat(textArray1));
                    string pStr = (table.DT.Rows[0]["Create_By"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Create_By"].ToString();
                    rep.Write("<td nowrap align='center'>" + rep.strq(pStr) + "</td>");
                    string str4 = (table.DT.Rows[0]["Submit_Date"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Submit_Date"].ToString().Substring(0, 10);
                    string str5 = (table.DT.Rows[0]["Submit_Time"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Submit_Time"].ToString();
                    string[] textArray2 = new string[] { "<td nowrap align='center'>", str5, " ", str4, "</td>" };
                    rep.Write(string.Concat(textArray2));
                    string str6 = (table.DT.Rows[0]["Submit_By"].ToString() == "") ? "&nbsp;" : table.DT.Rows[0]["Submit_By"].ToString();
                    rep.Write("<td nowrap align='center'>" + rep.strq(str6) + "</td>");
                }
            }
            if (this.checkOI.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["IO"].ToString()) + "</td>");
            }
            rep.Write("<td nowrap>" + rep.strq(aRow["Ref"].ToString()) + "</td>");
            if (this.checkBoxGatepassNumber.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Gatepass_Number"].ToString()) + "</td>");
            }
            rep.Write("<td nowrap>" + rep.strq(aRow["Transaction_code"].ToString()) + "</td>");
            if (this.checkSTO.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["STO"].ToString()) + "</td>");
            }
            if (this.checkPO.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["PO"].ToString()) + "</td>");
            }
            if (this.check1xSTO.Checked)
            {
                rep.Write("<td nowrap>1xSTO</td>");
            }
            if (this.check1xDO.Checked)
            {
                rep.Write("<td nowrap>1XDO</td>");
            }
            rep.Write("<td nowrap>" + rep.strq(aRow["comm_code"].ToString()) + "</td>");
            if (this.checkEstate.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Estate_code"].ToString()) + "</td>");
            }
            if (this.checkGrade.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["FFB_Grade"].ToString()) + "</td>");
            }
            if (this.checkDriverName.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["name"].ToString()) + "</td>");
            }
            if (this.cb_yellow.Checked)
            {
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and truck_number = '" + rep.strq(aRow["truck_number"].ToString()) + "'"), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    string pStr = (table2.DT.Rows[0]["tipe"].ToString() == "K") ? "Y" : "N";
                    rep.Write("<td nowrap>" + rep.strq(pStr) + "</td>");
                }
            }
            if (this.checkLicenseNo.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["License_no"].ToString()) + "</td>");
            }
            if (this.checkRelation.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Relation_code"].ToString()) + "</td>");
            }
            if (this.checkRelationName.Checked)
            {
                string pStr = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", aRow["Relation_code"].ToString());
                rep.Write("<td nowrap>" + rep.strq(pStr) + "</td>");
            }
            if (this.checkDO_No.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Do_No"].ToString()) + "</td>");
            }
            if (this.checkBoxDOSAP.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Do_SAP"].ToString()) + "</td>");
            }
            if (this.checkBoxDOSAPItem.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Do_SAP_Item"].ToString()) + "</td>");
            }
            if (this.cBoxPISI.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["PI_No"].ToString()) + "</td>");
            }
            if (this.checkQSt.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Iscc_Text"].ToString()) + "</td>");
            }
            if (this.checkContract.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Contract"].ToString()) + "</td>");
            }
            if (this.cBoxCommName.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Comm_Name"].ToString()) + "</td>");
            }
            if (this.checkDeliNote.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Delivery_note"].ToString()) + "</td>");
            }
            if (this.checkTransporter.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Transporter_code"].ToString()) + "</td>");
            }
            if (this.checkTransporterName.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Transporter_Name"].ToString()) + "</td>");
            }
            rep.Write("<td nowrap >" + rep.strq(aRow["Truck_number"].ToString()) + "</td>");
            if (this.checkSourceCode.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Source_code"].ToString()) + "</td>");
            }
            if (this.checkSourceDesc.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq("") + "</td>");
            }
            if (this.CbAddInfo.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Addi_Info"].ToString()) + "</td>");
            }
            if (this.checkParty.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{Program.StrToDouble(aRow["Quantity"].ToString(), 0):N0}") + "</td>");
            }
            if (this.checkTank.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq(aRow["TankQC"].ToString()) + "</td>");
            }
            if (this.checkOPRef.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq(aRow["Ticket"].ToString()) + "</td>");
            }
            rep.Write("<td nowrap align=right>" + rep.strq($"{this.weightIn:N0}") + "</td>");
            if (this.checkEstQ.Checked)
            {
                foreach (DataRow row in this.tbl_CommDetail.DT.Rows)
                {
                    string[] aField = new string[] { "Ref", "Qcode" };
                    string[] aFind = new string[] { aRow["Ref"].ToString(), row["Qcode"].ToString() };
                    this.qcTemp = this.tbl_TransQC.GetData(aField, aFind);
                    if (this.qcTemp != null)
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq(this.qcTemp["Estate"].ToString()) + "</td>");
                        continue;
                    }
                    rep.Write("<td nowrap align=right>0</td>");
                }
            }
            if (aRow["Report_Date"].ToString().Trim() == "")
            {
                this.fBruto = Program.StrToDouble(aRow["Bruto"].ToString(), 0);
                this.fTarra = Program.StrToDouble(aRow["Tarra"].ToString(), 0);
                this.fNett = Program.StrToDouble(aRow["Netto"].ToString(), 0);
            }
            else
            {
                this.eGross = Program.StrToDouble(aRow["Gross_Estate"].ToString(), 0);
                this.eTare = Program.StrToDouble(aRow["Tare_Estate"].ToString(), 0);
                this.eNet = Program.StrToDouble(aRow["Estate_qty"].ToString(), 0);
                this.fLoadingQty_opw = Program.StrToDouble(aRow["loading_qty_opw"].ToString(), 0);
                this.fBruto = Program.StrToDouble(aRow["Bruto"].ToString(), 0);
                this.fTarra = Program.StrToDouble(aRow["Tarra"].ToString(), 0);
                this.fNett = Program.StrToDouble(aRow["Netto"].ToString(), 0);
                this.fLoadingQty = Program.StrToDouble(aRow["loading_qty"].ToString(), 0);
                this.fLoadingNetW = Program.StrToDouble(aRow["loading_qty"].ToString(), 0) * this.commNetW;
                this.lossInKg = 0.0;
                this.lossInPack = 0.0;
                this.seNet += this.eNet;
                this.seGross += this.eGross;
                this.seTare += this.eTare;
                this.seReturInPack += Program.StrToDouble(aRow["return_qty_pack"].ToString(), 3);
                this.seReturInKg += Program.StrToDouble(aRow["return_qty_kg"].ToString(), 0);
                this.teGross += this.eGross;
                this.teTare += this.eTare;
                this.teNet += this.eNet;
                this.veGross += this.eGross;
                this.veTare += this.eTare;
                this.veNet += this.eNet;
                this.veReturInPack += Program.StrToDouble(aRow["return_qty_pack"].ToString(), 3);
                this.veReturInKg += Program.StrToDouble(aRow["return_qty_kg"].ToString(), 0);
                this.freceived = Program.StrToDouble(aRow["Received"].ToString(), 0);
                this.fdeduc = Program.StrToDouble(aRow["Deduction"].ToString(), 0);
                this.fgunny = Program.StrToDouble(aRow["TotalBunch"].ToString(), 0) * Program.StrToDouble(aRow["WeightPerUnitName"].ToString(), 2);
                this.fgunny = Program.StrToDouble($"{this.fgunny:N0}", 0);
                this.fdeduc -= this.cbGunny.Checked ? this.fgunny : 0.0;
                this.sfBruto += this.fBruto;
                this.sfTarra += this.fTarra;
                this.sfNett += this.fNett;
                this.sfgunny += this.fgunny;
                this.sfdeduc += this.fdeduc;
                this.sfreceived += this.freceived;
                this.tfBruto += this.fBruto;
                this.tfTarra += this.fTarra;
                this.tfNett += this.fNett;
                this.vfBruto += this.fBruto;
                this.vfTarra += this.fTarra;
                this.vfNett += this.fNett;
                this.vfgunny += this.fgunny;
                this.vfdeduc += this.fdeduc;
                this.vfreceived += this.freceived;
                this.tfgunny += this.fgunny;
                this.tfdeduc += this.fdeduc;
                this.tfreceived += this.freceived;
                this.sfLoadingQty += this.fLoadingQty;
                this.sfLoadingNetW += this.fLoadingNetW;
                this.vfLoadingQty += this.fLoadingQty;
                this.vfLoadingNetW += this.fLoadingNetW;
                this.tfLoadingQty += this.fLoadingQty;
                this.tfLoadingNetW += this.fLoadingNetW;
                this.sfLoadingQty_opw += this.fLoadingQty_opw;
                this.vfLoadingQty_opw += this.fLoadingQty_opw;
                this.tfLoadingQty_opw += this.fLoadingQty_opw;
                this.mark_return = aRow["mark_return"].ToString();
                if (this.mark_return != "X")
                {
                    this.subDO_fac -= this.eNet;
                    this.subDO_est -= this.eNet;
                    if (this.deductedBy == "1")
                    {
                        if ((this.bulkpack != "P") && ((this.commUOM == "KG") || (this.commUOM == "")))
                        {
                            this.subDO = (this.eNet <= 0.0) ? (this.subDO - this.fNett) : (this.subDO - this.eNet);
                        }
                        else
                        {
                            this.subDO_loadQty -= this.eNet;
                            this.subDO -= this.eNet;
                        }
                    }
                    else if ((this.bulkpack != "P") && ((this.commUOM == "KG") || (this.commUOM == "")))
                    {
                        this.subDO -= this.eNet;
                    }
                    else
                    {
                        this.subDO_loadQty -= this.eNet;
                        this.subDO -= this.eNet;
                    }
                }
                else if ((aRow["mark_return"].ToString() != "X") && (aRow["mark_accident"].ToString() != "X"))
                {
                    this.subDO_fac += this.fNett;
                    this.subDO_est = ((Program.StrToDouble(aRow["Estate_qty"].ToString(), 0) <= 0.0) && (Program.StrToDouble(aRow["return_qty_kg"].ToString(), 0) <= 0.0)) ? (this.subDO_est + this.fNett) : (this.subDO_est + this.eNet);
                    if (this.deductedBy != "1")
                    {
                        if ((this.bulkpack != "P") && ((this.commUOM == "KG") || (this.commUOM == "")))
                        {
                            this.subDO += this.fNett;
                        }
                        else if (this.bulkpack != "P")
                        {
                            this.subDO_loadQty += this.fLoadingQty;
                        }
                        else
                        {
                            this.subDO += this.fLoadingNetW;
                            this.subDO_loadQty += this.fLoadingNetW;
                        }
                    }
                    else if ((this.bulkpack != "P") && ((this.commUOM == "KG") || (this.commUOM == "")))
                    {
                        int result = 0;
                        if (aRow["return_qty_kg"] != null)
                        {
                            int.TryParse(aRow["return_qty_kg"].ToString(), out result);
                        }
                        this.lossInKg = (this.fNett - (this.eNet + result)) * -1.0;
                        this.seLossInKg += this.lossInKg;
                        this.veLossInKg += this.lossInKg;
                        this.subDO = (this.eNet <= 0.0) ? (((this.subDO + this.fNett) - (this.lossInKg * -1.0)) - result) : (((this.subDO + this.eNet) - (this.lossInKg * -1.0)) - result);
                    }
                    else
                    {
                        this.lossInPack = (this.fLoadingQty - (this.fLoadingQty_opw + Program.StrToDouble(aRow["return_qty_pack"].ToString(), 3))) * -1.0;
                        this.seLossInPack += this.lossInPack;
                        this.veLossInPack += this.lossInPack;
                        if ((Program.StrToDouble(aRow["return_qty_pack"].ToString(), 3) > 0.0) || (Program.StrToDouble(aRow["loading_qty_opw"].ToString(), 3) > 0.0))
                        {
                            this.subDO += Convert.ToDouble(aRow["loading_qty_opw"]) * this.commNetW;
                            this.subDO_loadQty += Convert.ToDouble(aRow["loading_qty_opw"]) * this.commNetW;
                        }
                        else
                        {
                            this.subDO += this.fLoadingNetW;
                            this.subDO_loadQty += this.fLoadingNetW;
                        }
                    }
                }
                this.vsubDO += this.subDO;
                this.vsubDO_est += this.subDO_est;
                this.vsubDO_fac += this.subDO_fac;
                this.vsubDO_loadQty += this.subDO_loadQty;
                if (!(this.eNet == 0.0))
                {
                    this.wDiff = this.fNett - this.eNet;
                    this.pwDiff = ((this.fNett - this.eNet) / this.eNet) * 100.0;
                }
                this.uToday = this.weightIn + this.subDO;
                this.uToday_est = this.weightIn2[0] + this.subDO_est;
                this.uToday_fac = this.weightIn2[1] + this.subDO_fac;
                this.uToday_loadQty = this.weightIn2[2] + this.subDO_loadQty;
                if ((aRow["mark_return"].ToString() != "X") && (aRow["mark_accident"].ToString() != "X"))
                {
                    this.OS = this.party - (this.weightIn + this.subDO);
                    this.OS_fac = this.party - (this.weightIn2[1] + this.subDO_fac);
                    this.OS_est = this.party - (this.weightIn2[0] + this.subDO_est);
                    this.OS_loadQty = this.party - (this.weightIn2[2] + this.subDO_loadQty);
                }
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.eGross:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.eTare:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.eNet:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.subDO_est:N0}") + "</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.uToday_est:N0}") + " </td>");
                    if ((aRow["mark_return"].ToString() == "X") || (aRow["mark_accident"].ToString() == "X"))
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq($"{this.OS_est:N0}") + "</td>");
                    }
                }
            }
            if (this.checkFactQ.Checked)
            {
                foreach (DataRow row2 in this.tbl_CommDetail.DT.Rows)
                {
                    string[] aField = new string[] { "Ref", "Qcode" };
                    string[] aFind = new string[] { aRow["Ref"].ToString(), row2["Qcode"].ToString() };
                    this.qcTemp = this.tbl_TransQC.GetData(aField, aFind);
                    if (this.qcTemp != null)
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq(this.qcTemp["Factory"].ToString()) + "</td>");
                        continue;
                    }
                    rep.Write("<td nowrap align=right>0</td>");
                }
            }
            if (this.checkQDeductKG.Checked)
            {
                foreach (DataRow row3 in this.tbl_CommDetail.DT.Rows)
                {
                    string[] aField = new string[] { "Ref", "Qcode" };
                    string[] aFind = new string[] { aRow["Ref"].ToString(), row3["Qcode"].ToString() };
                    this.qcTemp = this.tbl_TransQC.GetData(aField, aFind);
                    if (this.qcTemp != null)
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq(this.qcTemp["KgDeduc"].ToString()) + "</td>");
                        continue;
                    }
                    rep.Write("<td nowrap align=right>0</td>");
                }
            }
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fBruto:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fTarra:N0}") + "</td>");
                if (this.cbDeduction.Checked)
                {
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.freceived:N0}") + "</td>");
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.fdeduc:N0}") + "</td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.fgunny:N0}") + "</td>");
                }
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fNett:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.subDO_fac:N0}") + "</td>");
                this.tsubDO_fac += this.subDO_fac;
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.uToday_fac:N0}") + " </td>");
                    if ((aRow["mark_return"].ToString() == "X") || (aRow["mark_accident"].ToString() == "X"))
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq($"{this.OS_fac:N0}") + "</td>");
                    }
                }
            }
            if (this.checkConv.Checked)
            {
                this.sConv += Program.StrToDouble(aRow["ConvNett"].ToString(), 0);
                this.vConv += Program.StrToDouble(aRow["ConvNett"].ToString(), 0);
                this.tConv += Program.StrToDouble(aRow["ConvNett"].ToString(), 0);
                rep.Write("<td nowrap align=right>" + rep.strq($"{Program.StrToDouble(aRow["ConvNett"].ToString(), 0):N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq(aRow["ConvUnit"].ToString()) + "</td>");
            }
            if (this.checkVariance.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.wDiff:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.pwDiff:N3}") + "</td>");
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fLoadingQty:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fLoadingQty_opw:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq(this.commUOM) + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.fLoadingNetW:N0}") + "</td>");
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.subDO_loadQty:N0}") + "</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap align=right>" + rep.strq($"{this.uToday_loadQty:N0}") + " </td>");
                    if ((aRow["mark_return"].ToString() == "X") || (aRow["mark_accident"].ToString() == "X"))
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq($"{this.OS_loadQty:N0}") + "</td>");
                    }
                }
            }
            if (this.cBoxReturnInKG.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{Program.StrToDouble(aRow["Return_qty_Kg"].ToString(), 0):N0}") + "</td>");
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{Program.StrToDouble(aRow["Return_qty_Pack"].ToString(), 3):N0}") + "</td>");
            }
            if (this.cBoxLossInKG.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.lossInKg:N0}") + "</td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap align=right>" + rep.strq($"{this.lossInPack:N0}") + "</td>");
            }
            if (this.checkSeal.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["SEAL"].ToString()) + "</td>");
            }
            if (this.checkBoxMaterialStuffing.Checked)
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["materialStuffing"].ToString()) + "</td>");
            }
            if (!this.checkDeliveryLetter.Checked)
            {
                if (this.checkRmkReport.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Report"].ToString()) + "</td>");
                }
                if (this.checkRmkTicket.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Ticket"].ToString()) + "</td>");
                }
                if (this.checkCreate.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Create_By"].ToString()) + "</td>");
                }
                if (this.checkChange.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Change_By"].ToString()) + "</td>");
                }
                if (this.cBoxWBCode.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["WbCode1"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(aRow["WbCode2"].ToString()) + "</td>");
                    if (WBSetting.Container == "Y")
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode3"].ToString()) + "</td>");
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode4"].ToString()) + "</td>");
                    }
                }
                rep.Write("</tr>");
            }
            else if (this.tbl_transDL.DT.Rows.Count <= 0)
            {
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap>&nbsp</td>");
                rep.Write("<td nowrap align=right>0</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap align=right>0</td>");
                    rep.Write("<td nowrap align=right>0</td>");
                }
                if (this.checkRmkReport.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Report"].ToString()) + "</td>");
                }
                if (this.checkRmkTicket.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Ticket"].ToString()) + "</td>");
                }
                if (this.checkCreate.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Create_By"].ToString()) + "</td>");
                }
                if (this.checkChange.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["Change_By"].ToString()) + "</td>");
                }
                if (this.cBoxWBCode.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(aRow["WbCode1"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(aRow["WbCode2"].ToString()) + "</td>");
                    if (WBSetting.Container == "Y")
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode3"].ToString()) + "</td>");
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode4"].ToString()) + "</td>");
                    }
                }
                rep.Write("</tr>");
            }
            else
            {
                this.tbl_transDL.DR = this.tbl_transDL.DT.Rows[0];
                int num2 = 0;
                int num3 = 0;
                int num4 = 0;
                foreach (DataRow row4 in this.tbl_transDL.DT.Rows)
                {
                    num2 += Convert.ToInt32(row4["Num_Of_Gunny"].ToString());
                    num3 += Convert.ToInt32(row4["Netto"].ToString());
                    this.jlhGunnyToday += num2;
                    if (num4 > 0)
                    {
                        rep.Write("<tr class='bd'>");
                        rep.Write("<td colspan=" + this.jlhklmsDL.ToString() + ">&nbsp</td>");
                    }
                    rep.Write("<td nowrap>" + rep.strq(row4["Do_No"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(row4["Item_No"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(row4["Batch"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(row4["STO_No"].ToString()) + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(row4["STO_Batch"].ToString()) + "</td>");
                    rep.Write("<td nowrap align=right>" + rep.strq($"{num2:N0}") + "</td>");
                    rep.Write("<td nowrap align=right>" + rep.strq($"{num3:N0}") + "</td>");
                    if (!this.radioCommodity.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + rep.strq($"{this.jlhGunnyToday * this.netGunny:N0}") + "</td>");
                        rep.Write("<td nowrap align=right>" + rep.strq($"{this.party - (this.jlhGunnyToday * this.netGunny):N0}") + "</td>");
                    }
                    if (this.checkRmkReport.Checked)
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Report"].ToString()) + "</td>");
                    }
                    if (this.checkRmkTicket.Checked)
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["Remark_Ticket"].ToString()) + "</td>");
                    }
                    if (this.checkCreate.Checked)
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["Create_By"].ToString()) + "</td>");
                    }
                    if (this.checkChange.Checked)
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["Change_By"].ToString()) + "</td>");
                    }
                    if (this.cBoxWBCode.Checked)
                    {
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode1"].ToString()) + "</td>");
                        rep.Write("<td nowrap>" + rep.strq(aRow["WbCode2"].ToString()) + "</td>");
                        if (WBSetting.Container == "Y")
                        {
                            rep.Write("<td nowrap>" + rep.strq(aRow["WbCode3"].ToString()) + "</td>");
                            rep.Write("<td nowrap>" + rep.strq(aRow["WbCode4"].ToString()) + "</td>");
                        }
                    }
                    rep.Write("</tr>");
                    num4++;
                }
                this.sjgunny += num2;
                this.sjtgunny += num2;
                this.sjKG += num3;
                this.sjtKG += num3;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void initHeader(HTML rep, string DoNo, string Vendor)
        {
            this.jlhKolom = 0;
            this.jlhKolomB = 0;
            this.nextcol = 0;
            this.jlhKlmDL = 0;
            rep.Write("<tr class='bd'>");
            this.jlhKolom++;
            this.jlhKolom++;
            if (this.checkDelivery.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkHour.Checked)
            {
                this.jlhKolom++;
                this.jlhKolom++;
            }
            if (this.cb_interval12.Checked)
            {
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
            }
            if (this.cb_interval34.Checked)
            {
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
            }
            if (this.checkHourDiff.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkRegistrationInOut.Checked)
            {
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
                this.jlhKolom++;
            }
            if (this.checkOI.Checked)
            {
                this.jlhKolom++;
            }
            this.jlhKolom++;
            if (this.checkBoxGatepassNumber.Checked)
            {
                this.jlhKolom++;
            }
            this.jlhKolom++;
            if (this.checkSTO.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkPO.Checked)
            {
                this.jlhKolom++;
            }
            if (this.check1xSTO.Checked)
            {
                this.jlhKolom++;
            }
            if (this.check1xDO.Checked)
            {
                this.jlhKolom++;
            }
            this.jlhKolom++;
            if (this.checkEstate.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkGrade.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkDriverName.Checked)
            {
                this.jlhKolom++;
            }
            if (this.cb_yellow.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkLicenseNo.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkRelation.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkRelationName.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkDO_No.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkBoxDOSAP.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkBoxDOSAPItem.Checked)
            {
                this.jlhKolom++;
            }
            if (this.cBoxPISI.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkQSt.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkContract.Checked)
            {
                this.jlhKolom++;
            }
            if (this.cBoxCommName.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkDeliNote.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkTransporter.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkTransporterName.Checked)
            {
                this.jlhKolom++;
            }
            this.jlhKolom++;
            if (this.checkSourceCode.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkSourceDesc.Checked)
            {
                this.jlhKolom++;
            }
            if (this.CbAddInfo.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkParty.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkTank.Checked)
            {
                this.jlhKolom++;
            }
            if (this.checkOPRef.Checked)
            {
                this.jlhKolom++;
            }
            this.jlhKolom++;
            int num = 0;
            if (this.checkEstQ.Checked)
            {
                num += this.jlhQa;
            }
            if (this.check3rdParty.Checked)
            {
                num += 4;
                if (!this.radioCommodity.Checked)
                {
                    num += 2;
                }
            }
            int num2 = 0;
            if (this.checkFactQ.Checked)
            {
                num2 += this.jlhQa;
            }
            if (this.checkQDeductKG.Checked)
            {
                num2 += this.jlhQa;
            }
            if (this.checkBrutoTarra.Checked)
            {
                num2 = ((((num2 + 2) + (this.cbDeduction.Checked ? 2 : 0)) + (this.cbGunny.Checked ? 1 : 0)) + 2) + (!this.radioCommodity.Checked ? 2 : 0);
            }
            this.jlhKolomB = 0;
            if (this.checkConv.Checked)
            {
                this.jlhKolomB++;
                this.jlhKolomB++;
            }
            if (this.checkVariance.Checked)
            {
                this.jlhKolomB++;
                this.jlhKolomB++;
            }
            if (this.checkLoadingQty.Checked)
            {
                this.jlhKolomB++;
                this.jlhKolomB++;
                this.jlhKolomB++;
                this.jlhKolomB++;
                this.jlhKolomB++;
                if (!this.radioCommodity.Checked)
                {
                    this.jlhKolomB++;
                    this.jlhKolomB++;
                }
            }
            if (this.cBoxReturnInKG.Checked)
            {
                this.jlhKolomB++;
            }
            if (this.cBoxReturnInPack.Checked)
            {
                this.jlhKolomB++;
            }
            if (this.cBoxLossInKG.Checked)
            {
                this.jlhKolomB++;
            }
            if (this.cBoxLossInPack.Checked)
            {
                this.jlhKolomB++;
            }
            if (this.checkSeal.Checked)
            {
                this.nextcol++;
            }
            if (this.checkDeliveryLetter.Checked)
            {
                this.jlhKlmDL = !this.radioCommodity.Checked ? 9 : 7;
            }
            if (this.checkRmkReport.Checked)
            {
                this.nextcol++;
            }
            if (this.checkRmkTicket.Checked)
            {
                this.nextcol++;
            }
            if (this.checkCreate.Checked)
            {
                this.nextcol++;
            }
            if (this.checkChange.Checked)
            {
                this.nextcol++;
            }
            if (this.cBoxWBCode.Checked)
            {
                this.nextcol++;
                this.nextcol++;
                if (WBSetting.Container == "Y")
                {
                    this.nextcol++;
                    this.nextcol++;
                }
            }
            this.jlhklmsDL = ((this.jlhKolom + this.jlhKolomB) + num) + num2;
            if ((Vendor != "") && !this.radioCommodity.Checked)
            {
                rep.Write("<tr class='bd'>");
                string[] textArray1 = new string[] { "<td colspan= ", (((((this.jlhKolom + num) + num2) + this.jlhKolomB) + this.jlhklmsDL) + this.nextcol).ToString(), " ><b> ", Resource.TruckE_021, " : ", Vendor, " </td>" };
                rep.Write(string.Concat(textArray1));
                rep.Write("</tr>");
            }
            rep.Write("<tr class='bd'>");
            if (DoNo != "")
            {
                string[] textArray2 = new string[] { "<td colspan= ", (((((this.jlhKolom + num) + num2) + this.jlhKolomB) + this.jlhklmsDL) + this.nextcol).ToString(), " ><b> ", Resource.Contract_002, " : ", DoNo, " </td>" };
                rep.Write(string.Concat(textArray2));
            }
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap rowspan='3' align=center>No.</td>");
            if (this.rboGI.Checked)
            {
                rep.Write("<td rowspan='3' align=center><b>" + Resource.Main_036 + " </b></td>");
            }
            else if (this.rboGR.Checked)
            {
                rep.Write("<td rowspan='3' align=center><b>" + Resource.Main_036a + " </b></td>");
            }
            if (this.checkDelivery.Checked)
            {
                if (this.rboGI.Checked)
                {
                    rep.Write("<td rowspan='3' align=center><b>" + Resource.Main_108 + " </b></td>");
                }
                else if (this.rboGR.Checked)
                {
                    rep.Write("<td rowspan='3' align=center><b>" + Resource.Main_108a + " </b></td>");
                }
            }
            if (this.cb_interval12.Checked)
            {
                rep.Write("<td align=center colspan=3><b>Barrier Gate 1st Weight</b></td>");
                rep.Write("<td align=center colspan=3><b>Barrier Gate 2nd Weight</b></td>");
            }
            if (this.cb_interval34.Checked)
            {
                rep.Write("<td align=center colspan=3><b>Barrier Gate 3rd Weight</b></td>");
                rep.Write("<td align=center colspan=3><b>Barrier Gate 4th Weight</b></td>");
            }
            if (this.checkHour.Checked || this.checkHourDiff.Checked)
            {
                int num4 = 0;
                if (this.checkHour.Checked)
                {
                    num4 += 2;
                }
                if (this.checkHourDiff.Checked)
                {
                    num4++;
                }
                rep.Write("<td colspan='" + num4 + "' nowrap align=center><b>Weighing In & Out</b></td>");
            }
            if (this.checkRegistrationInOut.Checked)
            {
                rep.Write("<td colspan='4' nowrap align=center><b>Registration In & Out</b></td>");
            }
            if (this.checkOI.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>I/O</b></td>");
            }
            rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Trans_005 + "</b></td>");
            if (this.checkBoxGatepassNumber.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Gatepass_001 + "</b></td>");
            }
            rep.Write("<td rowspan='3' nowrap align=center><b>Tx.</b></td>");
            if (this.checkSTO.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>STO</b></td>");
            }
            if (this.checkPO.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>PO</b></td>");
            }
            if (this.check1xSTO.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>1xSTO</b></td>");
            }
            if (this.check1xDO.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>1xDO</b></td>");
            }
            rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Composite_004 + "</b></td>");
            if (this.checkEstate.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Block_001 + "</b></td>");
            }
            if (this.checkGrade.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>FFB Grade</b></td>");
            }
            if (this.checkDriverName.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.DriverE_002 + "</b></td>");
            }
            if (this.cb_yellow.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>YELLOW PLATE</b></td>");
            }
            if (this.checkLicenseNo.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.DriverE_001 + "</b></td>");
            }
            if (this.checkRelation.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Contract_006 + "</b></td>");
            }
            if (this.checkRelationName.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Rep01_027 + "</b></td>");
            }
            if (this.checkDO_No.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Contract_002 + "</b></td>");
            }
            if (this.checkBoxDOSAP.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Contract_071 + "</b></td>");
            }
            if (this.checkBoxDOSAPItem.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Contract_072 + "</b></td>");
            }
            if (this.cBoxPISI.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>PI/SI No.</b></td>");
            }
            if (this.checkQSt.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>Q.Standard</b></td>");
            }
            if (this.checkContract.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.Rep01_019 + "</b></td>");
            }
            if (this.cBoxCommName.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.CommE_003 + "</b></td>");
            }
            if (this.checkDeliNote.Checked)
            {
                rep.Write("<td rowspan='3' nowrap align=center><b>" + Resource.DoE_009 + "</b></td>");
            }
            if (this.checkTransporter.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Contract_017 + "</b></td>");
            }
            if (this.checkTransporterName.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Transporter_002 + "</b></td>");
            }
            rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.DriverE_003 + "</b></td>");
            if (this.checkSourceCode.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Trans_059 + "</b></td>");
            }
            if (this.checkSourceDesc.Checked)
            {
                string[] textArray3 = new string[] { "<td nowrap rowspan='3' align=center><b>", Resource.Trans_059, " ", Resource.Source_002, "</b></td>" };
                rep.Write(string.Concat(textArray3));
            }
            if (this.CbAddInfo.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>ADDITIONAL INFO</b></td>");
            }
            if (this.checkParty.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>Party</b></td>");
            }
            if (this.checkTank.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Rep01_014 + "</b></td>");
            }
            if (this.checkOPRef.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>3rd Party Ref No</b></td>");
            }
            rep.Write("<td nowrap rowspan='3' align=center><b>Weighted In</b></td>");
            if ((this.checkEstQ.Checked || this.check3rdParty.Checked) && (num > 0))
            {
                string[] textArray4 = new string[] { "<td colspan= ", num.ToString(), " align=center><b>", Resource.ContractE_037, "</td>" };
                rep.Write(string.Concat(textArray4));
            }
            if (((this.checkFactQ.Checked || this.checkBrutoTarra.Checked) || this.checkQDeductKG.Checked) && (num2 > 0))
            {
                string[] textArray5 = new string[] { "<td colspan= ", num2.ToString(), " align=center><b>", Resource.ContractE_038, "</td>" };
                rep.Write(string.Concat(textArray5));
            }
            if (this.checkConv.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>Qty.Unit</b></td>");
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Setting_079 + "</b></td>");
            }
            if (this.checkVariance.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>DIFF</b></td>");
                rep.Write("<td nowrap rowspan='3' align=center><b>DIFF %</b></td>");
            }
            if (this.checkLoadingQty.Checked)
            {
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap colspan='7' align=center><b>Loading Qty</b></td>");
                }
                else
                {
                    rep.Write("<td nowrap colspan='5' align=center><b>Loading Qty</b></td>");
                }
            }
            if (this.cBoxReturnInKG.Checked && this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap colspan='2' align=center><b>Return</b></td>");
            }
            else if (this.cBoxReturnInKG.Checked || this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap colspan='1' align=center><b>Return</b></td>");
            }
            if (this.cBoxLossInKG.Checked && this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap colspan='2' align=center><b>Loss(-)/Gain(+)</b></td>");
            }
            else if (this.cBoxLossInKG.Checked || this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap colspan='1' align=center><b>Loss(-)/Gain(+)</b></td>");
            }
            if (this.checkSeal.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>SEAL</b></td>");
            }
            if (this.checkBoxMaterialStuffing.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>Mat.Stuffing</b></td>");
            }
            if (this.checkDeliveryLetter.Checked)
            {
                if (this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap colspan='7' align=center><b>" + Resource.Rep01_041 + "</b></td>");
                }
                else
                {
                    rep.Write("<td nowrap colspan='9' align=center><b>" + Resource.Rep01_041 + "</b></td>");
                }
            }
            if (this.checkRmkReport.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Rep01_037 + "</b></td>");
            }
            if (this.checkRmkTicket.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>" + Resource.Rep01_036 + "</b></td>");
            }
            if (this.checkCreate.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>Create By</b></td>");
            }
            if (this.checkChange.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>Change By</b></td>");
            }
            if (this.cBoxWBCode.Checked)
            {
                rep.Write("<td nowrap rowspan='3' align=center><b>WB Code 1st</b></td>");
                rep.Write("<td nowrap rowspan='3' align=center><b>WB Code 2nd</b></td>");
                if (WBSetting.Container == "Y")
                {
                    rep.Write("<td nowrap rowspan='3' align=center><b>WB Code 3rd</b></td>");
                    rep.Write("<td nowrap rowspan='3' align=center><b>WB Code 4th</b></td>");
                }
            }
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            if (this.checkHour.Checked)
            {
                rep.Write("<td rowspan='2' nowrap align=center><b>" + Resource.Main_014 + "</b></td>");
                rep.Write("<td rowspan='2' nowrap align=center><b>" + Resource.Main_015 + "</b></td>");
            }
            if (this.checkHourDiff.Checked)
            {
                rep.Write("<td rowspan='2' nowrap align=center><b>Dif.Time</b></td>");
            }
            if (this.checkRegistrationInOut.Checked)
            {
                rep.Write("<td nowrap align=center rowspan=2><b>Date Time In</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Registered By</b></td>");
                rep.Write("<td align=center rowspan=2><b>Date Time Out</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Checked Out By</b></td>");
            }
            if (this.cb_interval12.Checked)
            {
                rep.Write("<td nowrap align=center rowspan=2><b>Time In</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time Out</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Interval</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time In</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time Out</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Interval</b></td>");
            }
            if (this.cb_interval34.Checked)
            {
                rep.Write("<td nowrap align=center rowspan=2><b>Time In</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time Out</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Interval</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time In</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Time Out</b></td>");
                rep.Write("<td nowrap align=center rowspan=2><b>Interval</b></td>");
            }
            if (this.checkEstQ.Checked && (this.jlhQa > 0))
            {
                if (this.check3rdParty.Checked)
                {
                    rep.Write("<td colspan= " + this.jlhQa.ToString() + " align=center><b>Quality in %</b></td>");
                }
                else
                {
                    rep.Write("<td colspan= " + num.ToString() + " align=center><b>Quality in %</b></td>");
                }
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td colspan=3 align=center><b>Weight</b></td>");
                rep.Write("<td align=center rowspan='2'><b>Sub</b></td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td align=center rowspan='2'><b>U/ Today</b></td>");
                    rep.Write("<td align=center rowspan='2'><b>Outstanding</b></td>");
                }
            }
            if (this.checkFactQ.Checked && (this.jlhQa > 0))
            {
                if (this.checkBrutoTarra.Checked)
                {
                    rep.Write("<td colspan= " + this.jlhQa.ToString() + " align=center><b>Quality in %</b></td>");
                }
                else
                {
                    rep.Write("<td colspan= " + num2.ToString() + " align=center><b>Quality in %</b></td>");
                }
            }
            if (this.checkQDeductKG.Checked && (this.jlhQa > 0))
            {
                if (this.checkBrutoTarra.Checked)
                {
                    rep.Write("<td colspan= " + this.jlhQa.ToString() + " align=center><b>Quality in KG</b></td>");
                }
                else
                {
                    rep.Write("<td colspan= " + num2.ToString() + " align=center><b>Quality in KG</b></td>");
                }
            }
            if (this.checkBrutoTarra.Checked)
            {
                int num5 = 3;
                if (this.cbDeduction.Checked)
                {
                    num5 += 2;
                }
                if (this.cbGunny.Checked)
                {
                    num5++;
                }
                rep.Write("<td colspan=" + num5.ToString() + "  align=center><b>Weight</b></td>");
                rep.Write("<td align=center rowspan='2'><b>Sub</b></td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap rowspan='2' align=center><b>U/ Today</b></td>");
                    rep.Write("<td nowrap rowspan='2' align=center><b>Outstanding</b></td>");
                }
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>Qty</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>OPW</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>UOM</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>Loading Net(KG)</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>Sub</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap rowspan='2' align=center><b>U/ Today</b></td>");
                    rep.Write("<td nowrap rowspan='2' align=center><b>Outstanding</b></td>");
                }
            }
            if (this.cBoxReturnInKG.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>Kg</b></td>");
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>Pack</b></td>");
            }
            if (this.cBoxLossInKG.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>Kg</b></td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>Pack</b></td>");
            }
            if (this.checkDeliveryLetter.Checked)
            {
                rep.Write("<td nowrap rowspan='2' align=center><b>NO</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>Item</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>Batch</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>STO No</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>STO Batch</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>Gunny</b></td>");
                rep.Write("<td nowrap rowspan='2' align=center><b>KG.</b></td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap rowspan='2' align=center><b>Till Today</b></td>");
                    rep.Write("<td nowrap rowspan='2' align=center><b>Remaining QTY</b></td>");
                }
            }
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            if (this.cb_interval12.Checked)
            {
            }
            if (this.cb_interval34.Checked)
            {
            }
            if (this.checkEstQ.Checked)
            {
                foreach (DataRow row in this.tbl_CommDetail.DT.Rows)
                {
                    rep.Write("<td nowrap align=center><b>" + row["qcode"].ToString() + "</b></td>");
                }
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td nowrap align=center><b>" + Resource.Main_019 + "</b></td>");
                rep.Write("<td nowrap align=center><b>" + Resource.Main_020 + "</b></td>");
                rep.Write("<td nowrap align=center><b>" + Resource.Main_023 + "</b></td>");
            }
            if (this.checkFactQ.Checked)
            {
                foreach (DataRow row2 in this.tbl_CommDetail.DT.Rows)
                {
                    rep.Write("<td nowrap align=center><b>" + row2["qcode"].ToString() + "</b></td>");
                }
            }
            if (this.checkQDeductKG.Checked)
            {
                foreach (DataRow row3 in this.tbl_CommDetail.DT.Rows)
                {
                    rep.Write("<td nowrap align=center><b>" + row3["qcode"].ToString() + "</b></td>");
                }
            }
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<td nowrap align=center><b>" + Resource.Main_019 + "</b></td>");
                rep.Write("<td nowrap align=center><b>" + Resource.Main_020 + "</b></td>");
                if (this.cbDeduction.Checked)
                {
                    rep.Write("<td nowrap align=center><b>Received</b></td>");
                    rep.Write("<td nowrap align=center><b>" + Resource.Main_022 + "</b></td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td nowrap align=center><b>GUNNY </b></td>");
                }
                rep.Write("<td nowrap align=center><b>NET   </b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.panel1 = new Panel();
            this.checkBoxDOSAPItem = new CheckBox();
            this.checkBoxDOSAP = new CheckBox();
            this.checkQDeductKG = new CheckBox();
            this.checkRegistrationInOut = new CheckBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxReturnInPack = new CheckBox();
            this.cBoxLossInKG = new CheckBox();
            this.cBoxReturnInKG = new CheckBox();
            this.checkOI = new CheckBox();
            this.checkOPRef = new CheckBox();
            this.cb_interval34 = new CheckBox();
            this.cb_interval12 = new CheckBox();
            this.checkBoxGatepassNumber = new CheckBox();
            this.checkGrade = new CheckBox();
            this.chkShowOSUTDPerVendor = new CheckBox();
            this.checkTransporterName = new CheckBox();
            this.checkSourceDesc = new CheckBox();
            this.checkSourceCode = new CheckBox();
            this.cBoxWBCode = new CheckBox();
            this.cb_yellow = new CheckBox();
            this.cBoxCommName = new CheckBox();
            this.checkLoadingQty = new CheckBox();
            this.checkBoxMaterialStuffing = new CheckBox();
            this.cBoxPISI = new CheckBox();
            this.CbAddInfo = new CheckBox();
            this.checkChange = new CheckBox();
            this.checkCreate = new CheckBox();
            this.checkQSt = new CheckBox();
            this.checkRelationName = new CheckBox();
            this.checkDeliveryLetter = new CheckBox();
            this.checkContract = new CheckBox();
            this.cbGunny = new CheckBox();
            this.cbDeduction = new CheckBox();
            this.checkHourDiff = new CheckBox();
            this.checkRegDate = new CheckBox();
            this.checkFactQ = new CheckBox();
            this.checkEstQ = new CheckBox();
            this.checkHour = new CheckBox();
            this.checkParty = new CheckBox();
            this.checkTank = new CheckBox();
            this.checkConv = new CheckBox();
            this.checkSeal = new CheckBox();
            this.checkRmkReport = new CheckBox();
            this.checkRmkTicket = new CheckBox();
            this.checkVariance = new CheckBox();
            this.checkBrutoTarra = new CheckBox();
            this.check3rdParty = new CheckBox();
            this.checkTransporter = new CheckBox();
            this.checkDeliNote = new CheckBox();
            this.checkDriverName = new CheckBox();
            this.checkLicenseNo = new CheckBox();
            this.checkEstate = new CheckBox();
            this.checkRelation = new CheckBox();
            this.check1xDO = new CheckBox();
            this.check1xSTO = new CheckBox();
            this.checkPO = new CheckBox();
            this.checkSTO = new CheckBox();
            this.checkDO_No = new CheckBox();
            this.checkDelivery = new CheckBox();
            this.grType = new GroupBox();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.grKB = new GroupBox();
            this.rboNonKB = new RadioButton();
            this.rboKB = new RadioButton();
            this.monthCalendar1 = new DateTimePicker();
            this.labelDate = new Label();
            this.labelTransTypeName = new Label();
            this.buttonType = new Button();
            this.textType = new TextBox();
            this.label9 = new Label();
            this.label4 = new Label();
            this.panel2 = new Panel();
            this.radioCommodity = new RadioButton();
            this.radioPO = new RadioButton();
            this.radioTank = new RadioButton();
            this.radioEstate = new RadioButton();
            this.radioRelation = new RadioButton();
            this.radioContract = new RadioButton();
            this.radioDo = new RadioButton();
            this.labelMinOS = new Label();
            this.textMinOS = new TextBox();
            this.checkProcess = new CheckBox();
            this.groupBox1 = new GroupBox();
            this.label1 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.radioMonthlyCumulative = new RadioButton();
            this.radioDailyCumulative = new RadioButton();
            this.radioDOReport = new RadioButton();
            this.TimeTo = new MaskedTextBox();
            this.TimeFrom = new MaskedTextBox();
            this.radioDaily = new RadioButton();
            this.button2 = new Button();
            this.button1 = new Button();
            this.checkISO = new CheckBox();
            this.labelProcess = new Label();
            this.labelRecNo = new Label();
            this.cBoxAll = new CheckBox();
            this.label3 = new Label();
            this.txt_ref = new TextBox();
            this.textTransport = new TextBox();
            this.buttonTransporter = new Button();
            this.label2 = new Label();
            this.labelQStandard = new Label();
            this.ComboIscc = new ComboBox();
            this.chkNonQ = new CheckBox();
            this.chkQstandard = new CheckBox();
            this.btnQstandard = new Button();
            this.txtqstandard = new TextBox();
            this.comboDO = new ComboBox();
            this.ComboComm = new ComboBox();
            this.labelTank = new Label();
            this.textTanker = new TextBox();
            this.label5 = new Label();
            this.buttonDoNo = new Button();
            this.labelDoNo = new Label();
            this.textDoNo = new TextBox();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.panel1.SuspendLayout();
            this.grType.SuspendLayout();
            this.grKB.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBoxDOSAPItem);
            this.panel1.Controls.Add(this.checkBoxDOSAP);
            this.panel1.Controls.Add(this.checkQDeductKG);
            this.panel1.Controls.Add(this.checkRegistrationInOut);
            this.panel1.Controls.Add(this.cBoxLossInPack);
            this.panel1.Controls.Add(this.cBoxReturnInPack);
            this.panel1.Controls.Add(this.cBoxLossInKG);
            this.panel1.Controls.Add(this.cBoxReturnInKG);
            this.panel1.Controls.Add(this.checkOI);
            this.panel1.Controls.Add(this.checkOPRef);
            this.panel1.Controls.Add(this.cb_interval34);
            this.panel1.Controls.Add(this.cb_interval12);
            this.panel1.Controls.Add(this.checkBoxGatepassNumber);
            this.panel1.Controls.Add(this.checkGrade);
            this.panel1.Controls.Add(this.chkShowOSUTDPerVendor);
            this.panel1.Controls.Add(this.checkTransporterName);
            this.panel1.Controls.Add(this.checkSourceDesc);
            this.panel1.Controls.Add(this.checkSourceCode);
            this.panel1.Controls.Add(this.cBoxWBCode);
            this.panel1.Controls.Add(this.cb_yellow);
            this.panel1.Controls.Add(this.cBoxCommName);
            this.panel1.Controls.Add(this.checkLoadingQty);
            this.panel1.Controls.Add(this.checkBoxMaterialStuffing);
            this.panel1.Controls.Add(this.cBoxPISI);
            this.panel1.Controls.Add(this.CbAddInfo);
            this.panel1.Controls.Add(this.checkChange);
            this.panel1.Controls.Add(this.checkCreate);
            this.panel1.Controls.Add(this.checkQSt);
            this.panel1.Controls.Add(this.checkRelationName);
            this.panel1.Controls.Add(this.checkDeliveryLetter);
            this.panel1.Controls.Add(this.checkContract);
            this.panel1.Controls.Add(this.cbGunny);
            this.panel1.Controls.Add(this.cbDeduction);
            this.panel1.Controls.Add(this.checkHourDiff);
            this.panel1.Controls.Add(this.checkRegDate);
            this.panel1.Controls.Add(this.checkFactQ);
            this.panel1.Controls.Add(this.checkEstQ);
            this.panel1.Controls.Add(this.checkHour);
            this.panel1.Controls.Add(this.checkParty);
            this.panel1.Controls.Add(this.checkTank);
            this.panel1.Controls.Add(this.checkConv);
            this.panel1.Controls.Add(this.checkSeal);
            this.panel1.Controls.Add(this.checkRmkReport);
            this.panel1.Controls.Add(this.checkRmkTicket);
            this.panel1.Controls.Add(this.checkVariance);
            this.panel1.Controls.Add(this.checkBrutoTarra);
            this.panel1.Controls.Add(this.check3rdParty);
            this.panel1.Controls.Add(this.checkTransporter);
            this.panel1.Controls.Add(this.checkDeliNote);
            this.panel1.Controls.Add(this.checkDriverName);
            this.panel1.Controls.Add(this.checkLicenseNo);
            this.panel1.Controls.Add(this.checkEstate);
            this.panel1.Controls.Add(this.checkRelation);
            this.panel1.Controls.Add(this.check1xDO);
            this.panel1.Controls.Add(this.check1xSTO);
            this.panel1.Controls.Add(this.checkPO);
            this.panel1.Controls.Add(this.checkSTO);
            this.panel1.Controls.Add(this.checkDO_No);
            this.panel1.Controls.Add(this.checkDelivery);
            this.panel1.Location = new Point(14, 0x1af);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x390, 0xe9);
            this.panel1.TabIndex = 60;
            this.checkBoxDOSAPItem.AutoSize = true;
            this.checkBoxDOSAPItem.Checked = true;
            this.checkBoxDOSAPItem.CheckState = CheckState.Checked;
            this.checkBoxDOSAPItem.Location = new Point(0x194, 210);
            this.checkBoxDOSAPItem.Name = "checkBoxDOSAPItem";
            this.checkBoxDOSAPItem.Size = new Size(0x59, 0x11);
            this.checkBoxDOSAPItem.TabIndex = 0x80;
            this.checkBoxDOSAPItem.Text = "DO SAP Item";
            this.checkBoxDOSAPItem.UseVisualStyleBackColor = true;
            this.checkBoxDOSAP.AutoSize = true;
            this.checkBoxDOSAP.Checked = true;
            this.checkBoxDOSAP.CheckState = CheckState.Checked;
            this.checkBoxDOSAP.Location = new Point(0x195, 0xbb);
            this.checkBoxDOSAP.Name = "checkBoxDOSAP";
            this.checkBoxDOSAP.Size = new Size(0x42, 0x11);
            this.checkBoxDOSAP.TabIndex = 0x7f;
            this.checkBoxDOSAP.Text = "DO SAP";
            this.checkBoxDOSAP.UseVisualStyleBackColor = true;
            this.checkQDeductKG.AutoSize = true;
            this.checkQDeductKG.Location = new Point(0x239, 0x8d);
            this.checkQDeductKG.Name = "checkQDeductKG";
            this.checkQDeductKG.Size = new Size(0x80, 0x11);
            this.checkQDeductKG.TabIndex = 0x7e;
            this.checkQDeductKG.Text = "Quality Deduction KG";
            this.checkQDeductKG.UseVisualStyleBackColor = false;
            this.checkRegistrationInOut.AutoSize = true;
            this.checkRegistrationInOut.Location = new Point(0x194, 0xa4);
            this.checkRegistrationInOut.Name = "checkRegistrationInOut";
            this.checkRegistrationInOut.Size = new Size(0x7b, 0x11);
            this.checkRegistrationInOut.TabIndex = 0x79;
            this.checkRegistrationInOut.Text = "Registration In && Out";
            this.checkRegistrationInOut.UseVisualStyleBackColor = true;
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0xda, 210);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0x7d;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxReturnInPack.AutoSize = true;
            this.cBoxReturnInPack.Location = new Point(100, 210);
            this.cBoxReturnInPack.Name = "cBoxReturnInPack";
            this.cBoxReturnInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturnInPack.TabIndex = 0x7c;
            this.cBoxReturnInPack.Text = "Return in Pack";
            this.cBoxReturnInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKG.AutoSize = true;
            this.cBoxLossInKG.Location = new Point(0xda, 0xbb);
            this.cBoxLossInKG.Name = "cBoxLossInKG";
            this.cBoxLossInKG.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKG.TabIndex = 0x7b;
            this.cBoxLossInKG.Text = "Loss in KG";
            this.cBoxLossInKG.UseVisualStyleBackColor = true;
            this.cBoxReturnInKG.AutoSize = true;
            this.cBoxReturnInKG.Location = new Point(6, 210);
            this.cBoxReturnInKG.Name = "cBoxReturnInKG";
            this.cBoxReturnInKG.Size = new Size(0x57, 0x11);
            this.cBoxReturnInKG.TabIndex = 0x7a;
            this.cBoxReturnInKG.Text = "Return in KG";
            this.cBoxReturnInKG.UseVisualStyleBackColor = true;
            this.checkOI.AutoSize = true;
            this.checkOI.Location = new Point(0xda, 0xa4);
            this.checkOI.Name = "checkOI";
            this.checkOI.Size = new Size(0x75, 0x11);
            this.checkOI.TabIndex = 0x79;
            this.checkOI.Text = "Outbound/Inbound";
            this.checkOI.UseVisualStyleBackColor = true;
            this.checkOPRef.AutoSize = true;
            this.checkOPRef.Location = new Point(100, 0xbb);
            this.checkOPRef.Name = "checkOPRef";
            this.checkOPRef.Size = new Size(0x63, 0x11);
            this.checkOPRef.TabIndex = 0x77;
            this.checkOPRef.Text = "Other Party Ref";
            this.checkOPRef.UseVisualStyleBackColor = true;
            this.cb_interval34.AutoSize = true;
            this.cb_interval34.Location = new Point(0x2bb, 210);
            this.cb_interval34.Name = "cb_interval34";
            this.cb_interval34.Size = new Size(0xd3, 0x11);
            this.cb_interval34.TabIndex = 120;
            this.cb_interval34.Text = "Interval barrier gate for 3rd && 4th weight";
            this.cb_interval34.UseVisualStyleBackColor = true;
            this.cb_interval12.AutoSize = true;
            this.cb_interval12.Location = new Point(0x2bb, 0xbb);
            this.cb_interval12.Name = "cb_interval12";
            this.cb_interval12.Size = new Size(0xd5, 0x11);
            this.cb_interval12.TabIndex = 0x77;
            this.cb_interval12.Text = "Interval barrier gate for 1st && 2nd weight";
            this.cb_interval12.UseVisualStyleBackColor = true;
            this.checkBoxGatepassNumber.AutoSize = true;
            this.checkBoxGatepassNumber.Location = new Point(0x2bb, 0x8d);
            this.checkBoxGatepassNumber.Name = "checkBoxGatepassNumber";
            this.checkBoxGatepassNumber.Size = new Size(0x6f, 0x11);
            this.checkBoxGatepassNumber.TabIndex = 0x75;
            this.checkBoxGatepassNumber.Text = "Gatepass Number";
            this.checkBoxGatepassNumber.UseVisualStyleBackColor = true;
            this.checkGrade.AutoSize = true;
            this.checkGrade.Location = new Point(0x239, 0x76);
            this.checkGrade.Name = "checkGrade";
            this.checkGrade.Size = new Size(0x4d, 0x11);
            this.checkGrade.TabIndex = 0x76;
            this.checkGrade.Text = "FFB Grade";
            this.checkGrade.UseVisualStyleBackColor = true;
            this.chkShowOSUTDPerVendor.AutoSize = true;
            this.chkShowOSUTDPerVendor.Location = new Point(0x2bb, 0xa4);
            this.chkShowOSUTDPerVendor.Name = "chkShowOSUTDPerVendor";
            this.chkShowOSUTDPerVendor.Size = new Size(0xce, 0x11);
            this.chkShowOSUTDPerVendor.TabIndex = 0x74;
            this.chkShowOSUTDPerVendor.Text = "Show OS, Until Today in Total Vendor";
            this.chkShowOSUTDPerVendor.UseVisualStyleBackColor = true;
            this.checkTransporterName.AutoSize = true;
            this.checkTransporterName.Location = new Point(100, 0x31);
            this.checkTransporterName.Name = "checkTransporterName";
            this.checkTransporterName.Size = new Size(0x6f, 0x11);
            this.checkTransporterName.TabIndex = 0x73;
            this.checkTransporterName.Text = "Transporter Name";
            this.checkTransporterName.UseVisualStyleBackColor = true;
            this.checkSourceDesc.AutoSize = true;
            this.checkSourceDesc.Location = new Point(0x239, 0xbb);
            this.checkSourceDesc.Name = "checkSourceDesc";
            this.checkSourceDesc.Size = new Size(0x76, 0x11);
            this.checkSourceDesc.TabIndex = 0x72;
            this.checkSourceDesc.Text = "Source/Dest Desc.";
            this.checkSourceDesc.UseVisualStyleBackColor = true;
            this.checkSourceCode.AutoSize = true;
            this.checkSourceCode.Location = new Point(0x239, 0xa4);
            this.checkSourceCode.Name = "checkSourceCode";
            this.checkSourceCode.Size = new Size(0x73, 0x11);
            this.checkSourceCode.TabIndex = 0x71;
            this.checkSourceCode.Text = "Source/Dest Code";
            this.checkSourceCode.UseVisualStyleBackColor = true;
            this.cBoxWBCode.AutoSize = true;
            this.cBoxWBCode.Location = new Point(100, 0xa4);
            this.cBoxWBCode.Name = "cBoxWBCode";
            this.cBoxWBCode.Size = new Size(0x48, 0x11);
            this.cBoxWBCode.TabIndex = 0x70;
            this.cBoxWBCode.Text = "WB Code";
            this.cBoxWBCode.UseVisualStyleBackColor = true;
            this.cb_yellow.AutoSize = true;
            this.cb_yellow.Location = new Point(0xda, 0x8d);
            this.cb_yellow.Name = "cb_yellow";
            this.cb_yellow.Size = new Size(0x54, 0x11);
            this.cb_yellow.TabIndex = 0x6f;
            this.cb_yellow.Text = "Yellow Plate";
            this.cb_yellow.UseVisualStyleBackColor = true;
            this.cBoxCommName.AutoSize = true;
            this.cBoxCommName.Location = new Point(0x195, 0x8d);
            this.cBoxCommName.Name = "cBoxCommName";
            this.cBoxCommName.Size = new Size(0x6c, 0x11);
            this.cBoxCommName.TabIndex = 0x6a;
            this.cBoxCommName.Text = "Commodity Name";
            this.cBoxCommName.UseVisualStyleBackColor = true;
            this.checkLoadingQty.AutoSize = true;
            this.checkLoadingQty.Location = new Point(0x239, 0x5f);
            this.checkLoadingQty.Name = "checkLoadingQty";
            this.checkLoadingQty.Size = new Size(0x6a, 0x11);
            this.checkLoadingQty.TabIndex = 110;
            this.checkLoadingQty.Text = "Loading Quantity";
            this.checkLoadingQty.UseVisualStyleBackColor = true;
            this.checkBoxMaterialStuffing.AutoSize = true;
            this.checkBoxMaterialStuffing.Location = new Point(0x2bb, 0x76);
            this.checkBoxMaterialStuffing.Name = "checkBoxMaterialStuffing";
            this.checkBoxMaterialStuffing.Size = new Size(0x66, 0x11);
            this.checkBoxMaterialStuffing.TabIndex = 0x6d;
            this.checkBoxMaterialStuffing.Text = "Material Stuffing";
            this.checkBoxMaterialStuffing.UseVisualStyleBackColor = true;
            this.cBoxPISI.AutoSize = true;
            this.cBoxPISI.Location = new Point(0x2bb, 0x5f);
            this.cBoxPISI.Name = "cBoxPISI";
            this.cBoxPISI.Size = new Size(0x4a, 0x11);
            this.cBoxPISI.TabIndex = 0x6a;
            this.cBoxPISI.Text = "PI / SI No";
            this.cBoxPISI.UseVisualStyleBackColor = true;
            this.CbAddInfo.AutoSize = true;
            this.CbAddInfo.Location = new Point(0x239, 0x48);
            this.CbAddInfo.Name = "CbAddInfo";
            this.CbAddInfo.Size = new Size(0x5d, 0x11);
            this.CbAddInfo.TabIndex = 0x6c;
            this.CbAddInfo.Text = "Additional Info";
            this.CbAddInfo.UseVisualStyleBackColor = true;
            this.checkChange.AutoSize = true;
            this.checkChange.Location = new Point(0x195, 0x76);
            this.checkChange.Name = "checkChange";
            this.checkChange.Size = new Size(0x4e, 0x11);
            this.checkChange.TabIndex = 0x6b;
            this.checkChange.Text = "Change By";
            this.checkChange.UseVisualStyleBackColor = true;
            this.checkCreate.AutoSize = true;
            this.checkCreate.Location = new Point(0xda, 0x76);
            this.checkCreate.Name = "checkCreate";
            this.checkCreate.Size = new Size(0x48, 0x11);
            this.checkCreate.TabIndex = 0x6a;
            this.checkCreate.Text = "Create By";
            this.checkCreate.UseVisualStyleBackColor = true;
            this.checkQSt.AutoSize = true;
            this.checkQSt.Location = new Point(100, 0x8d);
            this.checkQSt.Name = "checkQSt";
            this.checkQSt.Size = new Size(80, 0x11);
            this.checkQSt.TabIndex = 0x4e;
            this.checkQSt.Text = "Q.Standard";
            this.checkQSt.UseVisualStyleBackColor = true;
            this.checkRelationName.AutoSize = true;
            this.checkRelationName.Location = new Point(100, 0x5f);
            this.checkRelationName.Name = "checkRelationName";
            this.checkRelationName.Size = new Size(0x60, 0x11);
            this.checkRelationName.TabIndex = 0x4d;
            this.checkRelationName.Text = "Relation Name";
            this.checkRelationName.UseVisualStyleBackColor = true;
            this.checkDeliveryLetter.AutoSize = true;
            this.checkDeliveryLetter.Location = new Point(0x2bb, 0x48);
            this.checkDeliveryLetter.Name = "checkDeliveryLetter";
            this.checkDeliveryLetter.Size = new Size(0x5e, 0x11);
            this.checkDeliveryLetter.TabIndex = 0x4c;
            this.checkDeliveryLetter.Text = "Delivery Letter";
            this.checkDeliveryLetter.UseVisualStyleBackColor = true;
            this.checkContract.AutoSize = true;
            this.checkContract.Location = new Point(6, 0x1a);
            this.checkContract.Name = "checkContract";
            this.checkContract.Size = new Size(0x56, 0x11);
            this.checkContract.TabIndex = 0x4b;
            this.checkContract.Text = "Contract No.";
            this.checkContract.UseVisualStyleBackColor = true;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0x195, 0x5f);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 0x4a;
            this.cbGunny.Text = "Show Gunny as Deduction";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.cbGunny.CheckedChanged += new EventHandler(this.cbGunny_CheckedChanged);
            this.cbDeduction.AutoSize = true;
            this.cbDeduction.Location = new Point(0xda, 0x5f);
            this.cbDeduction.Name = "cbDeduction";
            this.cbDeduction.Size = new Size(0x69, 0x11);
            this.cbDeduction.TabIndex = 0x49;
            this.cbDeduction.Text = "Show Deduction";
            this.cbDeduction.UseVisualStyleBackColor = true;
            this.checkHourDiff.AutoSize = true;
            this.checkHourDiff.Location = new Point(6, 0xa4);
            this.checkHourDiff.Name = "checkHourDiff";
            this.checkHourDiff.Size = new Size(0x44, 0x11);
            this.checkHourDiff.TabIndex = 0x1a;
            this.checkHourDiff.Text = "Hour Diff";
            this.checkHourDiff.UseVisualStyleBackColor = true;
            this.checkRegDate.AutoSize = true;
            this.checkRegDate.Location = new Point(0xda, 0x48);
            this.checkRegDate.Name = "checkRegDate";
            this.checkRegDate.Size = new Size(0x7d, 0x11);
            this.checkRegDate.TabIndex = 0x19;
            this.checkRegDate.Text = "Register Date / Time";
            this.checkRegDate.UseVisualStyleBackColor = true;
            this.checkFactQ.AutoSize = true;
            this.checkFactQ.Location = new Point(0x195, 0x1a);
            this.checkFactQ.Name = "checkFactQ";
            this.checkFactQ.Size = new Size(0x60, 0x11);
            this.checkFactQ.TabIndex = 0x18;
            this.checkFactQ.Text = "Factory Quality";
            this.checkFactQ.UseVisualStyleBackColor = true;
            this.checkEstQ.AutoSize = true;
            this.checkEstQ.Location = new Point(0xda, 0x1a);
            this.checkEstQ.Name = "checkEstQ";
            this.checkEstQ.Size = new Size(0x5b, 0x11);
            this.checkEstQ.TabIndex = 0x17;
            this.checkEstQ.Text = "Estate Quality";
            this.checkEstQ.UseVisualStyleBackColor = true;
            this.checkHour.AutoSize = true;
            this.checkHour.Checked = true;
            this.checkHour.CheckState = CheckState.Checked;
            this.checkHour.Location = new Point(6, 0x8d);
            this.checkHour.Name = "checkHour";
            this.checkHour.Size = new Size(0x31, 0x11);
            this.checkHour.TabIndex = 0x16;
            this.checkHour.Text = "Hour";
            this.checkHour.UseVisualStyleBackColor = true;
            this.checkParty.AutoSize = true;
            this.checkParty.Checked = true;
            this.checkParty.CheckState = CheckState.Checked;
            this.checkParty.Location = new Point(6, 0x31);
            this.checkParty.Name = "checkParty";
            this.checkParty.Size = new Size(50, 0x11);
            this.checkParty.TabIndex = 0x15;
            this.checkParty.Text = "Party";
            this.checkParty.UseVisualStyleBackColor = true;
            this.checkTank.AutoSize = true;
            this.checkTank.CausesValidation = false;
            this.checkTank.Location = new Point(0x195, 0x48);
            this.checkTank.Name = "checkTank";
            this.checkTank.Size = new Size(0x33, 0x11);
            this.checkTank.TabIndex = 0x13;
            this.checkTank.Text = "Tank";
            this.checkTank.UseVisualStyleBackColor = true;
            this.checkTank.CheckedChanged += new EventHandler(this.checkTank_CheckedChanged);
            this.checkConv.AutoSize = true;
            this.checkConv.Location = new Point(0x2bb, 0x31);
            this.checkConv.Name = "checkConv";
            this.checkConv.Size = new Size(0x83, 0x11);
            this.checkConv.TabIndex = 0x12;
            this.checkConv.Text = "Commodity Convertion";
            this.checkConv.UseVisualStyleBackColor = true;
            this.checkSeal.AutoSize = true;
            this.checkSeal.Location = new Point(6, 0xbb);
            this.checkSeal.Name = "checkSeal";
            this.checkSeal.Size = new Size(0x35, 0x11);
            this.checkSeal.TabIndex = 0x11;
            this.checkSeal.Text = "SEAL";
            this.checkSeal.UseVisualStyleBackColor = true;
            this.checkRmkReport.AutoSize = true;
            this.checkRmkReport.Location = new Point(0x239, 0x31);
            this.checkRmkReport.Name = "checkRmkReport";
            this.checkRmkReport.Size = new Size(0x71, 0x11);
            this.checkRmkReport.TabIndex = 0x10;
            this.checkRmkReport.Text = "Remark for Report";
            this.checkRmkReport.UseVisualStyleBackColor = true;
            this.checkRmkTicket.AutoSize = true;
            this.checkRmkTicket.Location = new Point(0x239, 0x1a);
            this.checkRmkTicket.Name = "checkRmkTicket";
            this.checkRmkTicket.Size = new Size(0x6f, 0x11);
            this.checkRmkTicket.TabIndex = 15;
            this.checkRmkTicket.Text = "Remark for Ticket";
            this.checkRmkTicket.UseVisualStyleBackColor = true;
            this.checkVariance.AutoSize = true;
            this.checkVariance.Location = new Point(0x195, 0x31);
            this.checkVariance.Name = "checkVariance";
            this.checkVariance.Size = new Size(0x4f, 0x11);
            this.checkVariance.TabIndex = 14;
            this.checkVariance.Text = "Weight Diff";
            this.checkVariance.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.AutoSize = true;
            this.checkBrutoTarra.Checked = true;
            this.checkBrutoTarra.CheckState = CheckState.Checked;
            this.checkBrutoTarra.Location = new Point(0x195, 3);
            this.checkBrutoTarra.Name = "checkBrutoTarra";
            this.checkBrutoTarra.Size = new Size(0x56, 0x11);
            this.checkBrutoTarra.TabIndex = 13;
            this.checkBrutoTarra.Text = "Gross / Tare";
            this.checkBrutoTarra.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.CheckedChanged += new EventHandler(this.checkBrutoTarra_CheckedChanged);
            this.check3rdParty.AutoSize = true;
            this.check3rdParty.Location = new Point(0xda, 3);
            this.check3rdParty.Name = "check3rdParty";
            this.check3rdParty.Size = new Size(0xb3, 0x11);
            this.check3rdParty.TabIndex = 12;
            this.check3rdParty.Text = "Other Party Quantity (Estate Qty)";
            this.check3rdParty.UseVisualStyleBackColor = true;
            this.checkTransporter.AutoSize = true;
            this.checkTransporter.Location = new Point(100, 0x1a);
            this.checkTransporter.Name = "checkTransporter";
            this.checkTransporter.Size = new Size(80, 0x11);
            this.checkTransporter.TabIndex = 11;
            this.checkTransporter.Text = "Transporter";
            this.checkTransporter.UseVisualStyleBackColor = true;
            this.checkDeliNote.AutoSize = true;
            this.checkDeliNote.Checked = true;
            this.checkDeliNote.CheckState = CheckState.Checked;
            this.checkDeliNote.Location = new Point(0x2bb, 0x1a);
            this.checkDeliNote.Name = "checkDeliNote";
            this.checkDeliNote.Size = new Size(90, 0x11);
            this.checkDeliNote.TabIndex = 10;
            this.checkDeliNote.Text = "Delivery Note";
            this.checkDeliNote.UseVisualStyleBackColor = true;
            this.checkDriverName.AutoSize = true;
            this.checkDriverName.Checked = true;
            this.checkDriverName.CheckState = CheckState.Checked;
            this.checkDriverName.Location = new Point(0x2bb, 3);
            this.checkDriverName.Name = "checkDriverName";
            this.checkDriverName.Size = new Size(0x55, 0x11);
            this.checkDriverName.TabIndex = 9;
            this.checkDriverName.Text = "Driver Name";
            this.checkDriverName.UseVisualStyleBackColor = true;
            this.checkLicenseNo.AutoSize = true;
            this.checkLicenseNo.Checked = true;
            this.checkLicenseNo.CheckState = CheckState.Checked;
            this.checkLicenseNo.Location = new Point(0x239, 3);
            this.checkLicenseNo.Name = "checkLicenseNo";
            this.checkLicenseNo.Size = new Size(0x53, 0x11);
            this.checkLicenseNo.TabIndex = 8;
            this.checkLicenseNo.Text = "License No.";
            this.checkLicenseNo.UseVisualStyleBackColor = true;
            this.checkEstate.AutoSize = true;
            this.checkEstate.Location = new Point(100, 0x76);
            this.checkEstate.Name = "checkEstate";
            this.checkEstate.Size = new Size(0x38, 0x11);
            this.checkEstate.TabIndex = 7;
            this.checkEstate.Text = "Estate";
            this.checkEstate.UseVisualStyleBackColor = true;
            this.checkRelation.AutoSize = true;
            this.checkRelation.Checked = true;
            this.checkRelation.CheckState = CheckState.Checked;
            this.checkRelation.Location = new Point(100, 0x48);
            this.checkRelation.Name = "checkRelation";
            this.checkRelation.Size = new Size(0x5d, 0x11);
            this.checkRelation.TabIndex = 6;
            this.checkRelation.Text = "Relation Code";
            this.checkRelation.UseVisualStyleBackColor = true;
            this.check1xDO.AutoSize = true;
            this.check1xDO.Location = new Point(100, 3);
            this.check1xDO.Name = "check1xDO";
            this.check1xDO.Size = new Size(0x4e, 0x11);
            this.check1xDO.TabIndex = 5;
            this.check1xDO.Text = "1xDO STO";
            this.check1xDO.UseVisualStyleBackColor = true;
            this.check1xSTO.AutoSize = true;
            this.check1xSTO.Location = new Point(6, 0x76);
            this.check1xSTO.Name = "check1xSTO";
            this.check1xSTO.Size = new Size(0x3b, 0x11);
            this.check1xSTO.TabIndex = 4;
            this.check1xSTO.Text = "1xSTO";
            this.check1xSTO.UseVisualStyleBackColor = true;
            this.checkPO.AutoSize = true;
            this.checkPO.Location = new Point(6, 0x5f);
            this.checkPO.Name = "checkPO";
            this.checkPO.Size = new Size(0x3d, 0x11);
            this.checkPO.TabIndex = 3;
            this.checkPO.Text = "PO No.";
            this.checkPO.UseVisualStyleBackColor = true;
            this.checkSTO.AutoSize = true;
            this.checkSTO.Location = new Point(6, 0x48);
            this.checkSTO.Name = "checkSTO";
            this.checkSTO.Size = new Size(0x44, 0x11);
            this.checkSTO.TabIndex = 2;
            this.checkSTO.Text = "STO No.";
            this.checkSTO.UseVisualStyleBackColor = true;
            this.checkDO_No.AutoSize = true;
            this.checkDO_No.Checked = true;
            this.checkDO_No.CheckState = CheckState.Checked;
            this.checkDO_No.Location = new Point(6, 3);
            this.checkDO_No.Name = "checkDO_No";
            this.checkDO_No.Size = new Size(0x52, 0x11);
            this.checkDO_No.TabIndex = 1;
            this.checkDO_No.Text = "DO/SO No.";
            this.checkDO_No.UseVisualStyleBackColor = true;
            this.checkDelivery.AutoSize = true;
            this.checkDelivery.Checked = true;
            this.checkDelivery.CheckState = CheckState.Checked;
            this.checkDelivery.Location = new Point(0xda, 0x31);
            this.checkDelivery.Name = "checkDelivery";
            this.checkDelivery.Size = new Size(0x7c, 0x11);
            this.checkDelivery.TabIndex = 0;
            this.checkDelivery.Text = "Delivery Date / Time";
            this.checkDelivery.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x15, 12);
            this.grType.Name = "grType";
            this.grType.Size = new Size(260, 0x27);
            this.grType.TabIndex = 0x31;
            this.grType.TabStop = false;
            this.grType.Text = "Transaction";
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0x9b, 0x10);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGI.TextChanged += new EventHandler(this.rboGI_TextChanged);
            this.rboGI.Leave += new EventHandler(this.rboGI_Leave);
            this.rboGR.AutoSize = true;
            this.rboGR.Checked = true;
            this.rboGR.Location = new Point(0x10, 0x10);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.rboGR.CheckedChanged += new EventHandler(this.rboGR_CheckedChanged);
            this.grKB.Controls.Add(this.rboNonKB);
            this.grKB.Controls.Add(this.rboKB);
            this.grKB.Location = new Point(0x11f, 12);
            this.grKB.Name = "grKB";
            this.grKB.Size = new Size(0x94, 0x27);
            this.grKB.TabIndex = 0x33;
            this.grKB.TabStop = false;
            this.rboNonKB.AutoSize = true;
            this.rboNonKB.Location = new Point(0x4c, 0x10);
            this.rboNonKB.Name = "rboNonKB";
            this.rboNonKB.Size = new Size(60, 0x11);
            this.rboNonKB.TabIndex = 0x11;
            this.rboNonKB.TabStop = true;
            this.rboNonKB.Text = "non KB";
            this.rboNonKB.UseVisualStyleBackColor = true;
            this.rboKB.AutoSize = true;
            this.rboKB.Location = new Point(0x11, 0x10);
            this.rboKB.Name = "rboKB";
            this.rboKB.Size = new Size(0x27, 0x11);
            this.rboKB.TabIndex = 0x10;
            this.rboKB.TabStop = true;
            this.rboKB.Text = "KB";
            this.rboKB.UseVisualStyleBackColor = true;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x35, 0x34);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new Point(14, 0x38);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new Size(0x24, 13);
            this.labelDate.TabIndex = 3;
            this.labelDate.Text = "Date :";
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Location = new Point(0xc0, 150);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(0x16, 13);
            this.labelTransTypeName.TabIndex = 0x4c;
            this.labelTransTypeName.Text = "     ";
            this.buttonType.Location = new Point(0xa5, 0x91);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x17, 0x17);
            this.buttonType.TabIndex = 0x4a;
            this.buttonType.Text = "...";
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonType.Click += new EventHandler(this.buttonType_Click);
            this.textType.CharacterCasing = CharacterCasing.Upper;
            this.textType.Location = new Point(0x61, 0x93);
            this.textType.MaxLength = 20;
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x41, 20);
            this.textType.TabIndex = 0x49;
            this.textType.Leave += new EventHandler(this.textType_Leave);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x19, 150);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x3d, 13);
            this.label9.TabIndex = 0x4b;
            this.label9.Text = "Trans Type";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(14, 0x19b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x5d, 13);
            this.label4.TabIndex = 0x4f;
            this.label4.Text = "Display Column";
            this.panel2.BorderStyle = BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.radioCommodity);
            this.panel2.Controls.Add(this.radioPO);
            this.panel2.Controls.Add(this.radioTank);
            this.panel2.Controls.Add(this.radioEstate);
            this.panel2.Controls.Add(this.radioRelation);
            this.panel2.Controls.Add(this.radioContract);
            this.panel2.Controls.Add(this.radioDo);
            this.panel2.Controls.Add(this.labelMinOS);
            this.panel2.Controls.Add(this.textMinOS);
            this.panel2.Location = new Point(13, 0x14c);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x390, 0x42);
            this.panel2.TabIndex = 0x13;
            this.panel2.Paint += new PaintEventHandler(this.panel2_Paint);
            this.radioCommodity.AutoSize = true;
            this.radioCommodity.Location = new Point(290, 0x21);
            this.radioCommodity.Name = "radioCommodity";
            this.radioCommodity.Size = new Size(0x4c, 0x11);
            this.radioCommodity.TabIndex = 0x57;
            this.radioCommodity.TabStop = true;
            this.radioCommodity.Text = "Commodity";
            this.radioCommodity.UseVisualStyleBackColor = true;
            this.radioPO.AutoSize = true;
            this.radioPO.Location = new Point(0xc0, 0x23);
            this.radioPO.Name = "radioPO";
            this.radioPO.Size = new Size(60, 0x11);
            this.radioPO.TabIndex = 0x56;
            this.radioPO.TabStop = true;
            this.radioPO.Text = "PO No.";
            this.radioPO.UseVisualStyleBackColor = true;
            this.radioTank.AutoSize = true;
            this.radioTank.Location = new Point(0xc0, 12);
            this.radioTank.Name = "radioTank";
            this.radioTank.Size = new Size(50, 0x11);
            this.radioTank.TabIndex = 0x55;
            this.radioTank.TabStop = true;
            this.radioTank.Text = "Tank";
            this.radioTank.UseVisualStyleBackColor = true;
            this.radioEstate.AutoSize = true;
            this.radioEstate.Location = new Point(0x65, 0x23);
            this.radioEstate.Name = "radioEstate";
            this.radioEstate.Size = new Size(0x37, 0x11);
            this.radioEstate.TabIndex = 0x54;
            this.radioEstate.TabStop = true;
            this.radioEstate.Text = "Estate";
            this.radioEstate.UseVisualStyleBackColor = true;
            this.radioRelation.AutoSize = true;
            this.radioRelation.Location = new Point(0x65, 12);
            this.radioRelation.Name = "radioRelation";
            this.radioRelation.Size = new Size(0x40, 0x11);
            this.radioRelation.TabIndex = 0x53;
            this.radioRelation.TabStop = true;
            this.radioRelation.Text = "Relation";
            this.radioRelation.UseVisualStyleBackColor = true;
            this.radioContract.AutoSize = true;
            this.radioContract.Location = new Point(14, 0x21);
            this.radioContract.Name = "radioContract";
            this.radioContract.Size = new Size(0x41, 0x11);
            this.radioContract.TabIndex = 0x52;
            this.radioContract.TabStop = true;
            this.radioContract.Text = "Contract";
            this.radioContract.UseVisualStyleBackColor = true;
            this.radioDo.AutoSize = true;
            this.radioDo.Checked = true;
            this.radioDo.Location = new Point(14, 10);
            this.radioDo.Name = "radioDo";
            this.radioDo.Size = new Size(0x51, 0x11);
            this.radioDo.TabIndex = 0x51;
            this.radioDo.TabStop = true;
            this.radioDo.Text = "DO/SO No.";
            this.radioDo.UseVisualStyleBackColor = true;
            this.radioDo.CheckedChanged += new EventHandler(this.radioDo_CheckedChanged);
            this.labelMinOS.AutoSize = true;
            this.labelMinOS.Location = new Point(290, 12);
            this.labelMinOS.Name = "labelMinOS";
            this.labelMinOS.Size = new Size(0x6c, 13);
            this.labelMinOS.TabIndex = 80;
            this.labelMinOS.Text = "Minimum Outstanding";
            this.textMinOS.CharacterCasing = CharacterCasing.Upper;
            this.textMinOS.Location = new Point(0x191, 8);
            this.textMinOS.Name = "textMinOS";
            this.textMinOS.Size = new Size(0x73, 20);
            this.textMinOS.TabIndex = 0x4f;
            this.textMinOS.Leave += new EventHandler(this.textMinOS_Leave);
            this.checkProcess.AutoSize = true;
            this.checkProcess.Location = new Point(15, 0x29d);
            this.checkProcess.Name = "checkProcess";
            this.checkProcess.Size = new Size(0x93, 0x11);
            this.checkProcess.TabIndex = 0x51;
            this.checkProcess.Text = "Include Processing Truck";
            this.checkProcess.UseVisualStyleBackColor = true;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Controls.Add(this.radioMonthlyCumulative);
            this.groupBox1.Controls.Add(this.radioDailyCumulative);
            this.groupBox1.Controls.Add(this.radioDOReport);
            this.groupBox1.Controls.Add(this.TimeTo);
            this.groupBox1.Controls.Add(this.TimeFrom);
            this.groupBox1.Controls.Add(this.radioDaily);
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.labelDate);
            this.groupBox1.Location = new Point(0x15, 0x39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x248, 0x54);
            this.groupBox1.TabIndex = 0x51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Name";
            this.groupBox1.Enter += new EventHandler(this.groupBox1_Enter);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0xdf, 0x37);
            this.label1.Name = "label1";
            this.label1.Size = new Size(20, 13);
            this.label1.TabIndex = 0x59;
            this.label1.Text = "To";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x112, 0x33);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 0x47;
            this.radioMonthlyCumulative.AutoSize = true;
            this.radioMonthlyCumulative.Location = new Point(0x112, 0x13);
            this.radioMonthlyCumulative.Name = "radioMonthlyCumulative";
            this.radioMonthlyCumulative.Size = new Size(0x75, 0x11);
            this.radioMonthlyCumulative.TabIndex = 70;
            this.radioMonthlyCumulative.TabStop = true;
            this.radioMonthlyCumulative.Text = "Monthly Cumulative";
            this.radioMonthlyCumulative.UseVisualStyleBackColor = true;
            this.radioDailyCumulative.AutoSize = true;
            this.radioDailyCumulative.Location = new Point(0x83, 0x13);
            this.radioDailyCumulative.Name = "radioDailyCumulative";
            this.radioDailyCumulative.Size = new Size(0x67, 0x11);
            this.radioDailyCumulative.TabIndex = 0x45;
            this.radioDailyCumulative.TabStop = true;
            this.radioDailyCumulative.Text = "Daily Cumulative";
            this.radioDailyCumulative.UseVisualStyleBackColor = true;
            this.radioDOReport.AutoSize = true;
            this.radioDOReport.Location = new Point(0x1b6, 0x13);
            this.radioDOReport.Name = "radioDOReport";
            this.radioDOReport.Size = new Size(0x4c, 0x11);
            this.radioDOReport.TabIndex = 0x44;
            this.radioDOReport.TabStop = true;
            this.radioDOReport.Text = "DO Details";
            this.radioDOReport.UseVisualStyleBackColor = true;
            this.radioDOReport.CheckedChanged += new EventHandler(this.radioDOReport_CheckedChanged);
            this.TimeTo.Location = new Point(0x181, 0x33);
            this.TimeTo.Mask = "00:00";
            this.TimeTo.Name = "TimeTo";
            this.TimeTo.Size = new Size(0x29, 20);
            this.TimeTo.TabIndex = 0x41;
            this.TimeTo.ValidatingType = typeof(DateTime);
            this.TimeTo.Visible = false;
            this.TimeFrom.Location = new Point(0xa4, 0x33);
            this.TimeFrom.Mask = "00:00";
            this.TimeFrom.Name = "TimeFrom";
            this.TimeFrom.Size = new Size(0x24, 20);
            this.TimeFrom.TabIndex = 0x40;
            this.TimeFrom.ValidatingType = typeof(DateTime);
            this.TimeFrom.Visible = false;
            this.radioDaily.AutoSize = true;
            this.radioDaily.Checked = true;
            this.radioDaily.Location = new Point(0x10, 0x13);
            this.radioDaily.Name = "radioDaily";
            this.radioDaily.Size = new Size(0x53, 0x11);
            this.radioDaily.TabIndex = 0x3d;
            this.radioDaily.TabStop = true;
            this.radioDaily.Text = "Daily Report";
            this.radioDaily.UseVisualStyleBackColor = true;
            this.radioDaily.CheckedChanged += new EventHandler(this.radioDaily_CheckedChanged);
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x2b7, 0x80);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x37);
            this.button2.TabIndex = 0x53;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x2b7, 0x3b);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x38);
            this.button1.TabIndex = 0x52;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.checkISO.AutoSize = true;
            this.checkISO.Location = new Point(0xfe, 0x29c);
            this.checkISO.Name = "checkISO";
            this.checkISO.Size = new Size(70, 0x11);
            this.checkISO.TabIndex = 0x54;
            this.checkISO.Text = "Form ISO";
            this.checkISO.UseVisualStyleBackColor = true;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x267, 0x11);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x55;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x2ff, 0x11);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x56;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.cBoxAll.AutoSize = true;
            this.cBoxAll.Location = new Point(0x76, 410);
            this.cBoxAll.Name = "cBoxAll";
            this.cBoxAll.Size = new Size(150, 0x11);
            this.cBoxAll.TabIndex = 0x71;
            this.cBoxAll.Text = "Checked / Unchecked All";
            this.cBoxAll.UseVisualStyleBackColor = true;
            this.cBoxAll.CheckedChanged += new EventHandler(this.cBoxAll_CheckedChanged);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x31, 0xb0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x29, 13);
            this.label3.TabIndex = 0x76;
            this.label3.Text = "Ref No";
            this.txt_ref.CharacterCasing = CharacterCasing.Upper;
            this.txt_ref.Location = new Point(0x61, 0xad);
            this.txt_ref.Name = "txt_ref";
            this.txt_ref.Size = new Size(0xbf, 20);
            this.txt_ref.TabIndex = 0x75;
            this.textTransport.CharacterCasing = CharacterCasing.Upper;
            this.textTransport.Location = new Point(0x61, 0xc7);
            this.textTransport.Name = "textTransport";
            this.textTransport.Size = new Size(0xbf, 20);
            this.textTransport.TabIndex = 140;
            this.buttonTransporter.Location = new Point(0x123, 0xc4);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 0x8a;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1c, 0xca);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3d, 13);
            this.label2.TabIndex = 0x8b;
            this.label2.Text = "Transporter";
            this.labelQStandard.AutoSize = true;
            this.labelQStandard.Location = new Point(0x143, 0x117);
            this.labelQStandard.Name = "labelQStandard";
            this.labelQStandard.Size = new Size(0x3d, 13);
            this.labelQStandard.TabIndex = 0x89;
            this.labelQStandard.Text = "Q.Standard";
            this.ComboIscc.FormattingEnabled = true;
            this.ComboIscc.Location = new Point(0xa4, 300);
            this.ComboIscc.Name = "ComboIscc";
            this.ComboIscc.Size = new Size(0x7c, 0x15);
            this.ComboIscc.TabIndex = 0x88;
            this.ComboIscc.Visible = false;
            this.chkNonQ.AutoSize = true;
            this.chkNonQ.Location = new Point(0x31, 0x12b);
            this.chkNonQ.Name = "chkNonQ";
            this.chkNonQ.Size = new Size(0x67, 0x11);
            this.chkNonQ.TabIndex = 0x87;
            this.chkNonQ.Text = "Non Q.Standard";
            this.chkNonQ.UseVisualStyleBackColor = true;
            this.chkQstandard.AutoSize = true;
            this.chkQstandard.Location = new Point(0x31, 0x113);
            this.chkQstandard.Name = "chkQstandard";
            this.chkQstandard.Size = new Size(80, 0x11);
            this.chkQstandard.TabIndex = 0x86;
            this.chkQstandard.Text = "Q.Standard";
            this.chkQstandard.UseVisualStyleBackColor = true;
            this.btnQstandard.Enabled = false;
            this.btnQstandard.Location = new Point(0x123, 0x110);
            this.btnQstandard.Margin = new Padding(0);
            this.btnQstandard.Name = "btnQstandard";
            this.btnQstandard.Size = new Size(0x17, 0x17);
            this.btnQstandard.TabIndex = 0x85;
            this.btnQstandard.Text = "...";
            this.btnQstandard.UseVisualStyleBackColor = true;
            this.txtqstandard.CharacterCasing = CharacterCasing.Upper;
            this.txtqstandard.Enabled = false;
            this.txtqstandard.Location = new Point(0x8d, 0x112);
            this.txtqstandard.Name = "txtqstandard";
            this.txtqstandard.Size = new Size(0x93, 20);
            this.txtqstandard.TabIndex = 0x84;
            this.txtqstandard.Leave += new EventHandler(this.txtqstandard_Leave);
            this.comboDO.FormattingEnabled = true;
            this.comboDO.Location = new Point(0x1b2, 0xf7);
            this.comboDO.Name = "comboDO";
            this.comboDO.Size = new Size(0xbf, 0x15);
            this.comboDO.TabIndex = 0x83;
            this.comboDO.Visible = false;
            this.ComboComm.FormattingEnabled = true;
            this.ComboComm.Location = new Point(0x17d, 0xde);
            this.ComboComm.Name = "ComboComm";
            this.ComboComm.Size = new Size(0xbf, 0x15);
            this.ComboComm.TabIndex = 130;
            this.ComboComm.Visible = false;
            this.labelTank.AutoSize = true;
            this.labelTank.Location = new Point(0x143, 0xfc);
            this.labelTank.Name = "labelTank";
            this.labelTank.Size = new Size(0x20, 13);
            this.labelTank.TabIndex = 0x81;
            this.labelTank.Text = "Tank";
            this.textTanker.CharacterCasing = CharacterCasing.Upper;
            this.textTanker.Enabled = false;
            this.textTanker.Location = new Point(0x169, 0xf8);
            this.textTanker.Name = "textTanker";
            this.textTanker.Size = new Size(0x3e, 20);
            this.textTanker.TabIndex = 0x80;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(14, 0x145);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x30, 13);
            this.label5.TabIndex = 0x7f;
            this.label5.Text = "Sort By";
            this.buttonDoNo.Location = new Point(0x123, 0xf7);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x17, 0x17);
            this.buttonDoNo.TabIndex = 0x7b;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(0x38, 0xfc);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(40, 13);
            this.labelDoNo.TabIndex = 0x7e;
            this.labelDoNo.Text = "DO No";
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x61, 0xf8);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xbf, 20);
            this.textDoNo.TabIndex = 0x79;
            this.textDoNo.Leave += new EventHandler(this.textDoNo_Leave);
            this.buttonComm.Location = new Point(0x123, 0xdd);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x7a;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x13d, 0xe2);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x7d;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x61, 0xdf);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xbf, 20);
            this.textCommodity.TabIndex = 120;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x24, 0xe1);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x7c;
            this.labelcommodity.Text = "Commodity";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3ab, 0x2b4);
            base.ControlBox = false;
            base.Controls.Add(this.textTransport);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.labelQStandard);
            base.Controls.Add(this.ComboIscc);
            base.Controls.Add(this.chkNonQ);
            base.Controls.Add(this.chkQstandard);
            base.Controls.Add(this.btnQstandard);
            base.Controls.Add(this.txtqstandard);
            base.Controls.Add(this.comboDO);
            base.Controls.Add(this.ComboComm);
            base.Controls.Add(this.labelTank);
            base.Controls.Add(this.textTanker);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.txt_ref);
            base.Controls.Add(this.cBoxAll);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.checkISO);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.checkProcess);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.buttonType);
            base.Controls.Add(this.textType);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.grKB);
            base.Name = "RepRecIssue";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Goods Report Weighbridge System";
            base.Load += new EventHandler(this.RepDODetail_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepRecIssue_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.grKB.ResumeLayout(false);
            this.grKB.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initTable()
        {
            this.tbl_Comm = new WBTable();
            this.tbl_CommDetail = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Do = new WBTable();
            this.tbl_TransType = new WBTable();
            this.tblTransType = new WBTable();
            this.tbl_TransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tbl_Do.OpenTable("wb_contract", "Select * from wb_contract", WBData.conn);
            Program.AutoComp(this.tbl_TransType, "Transaction_code", this.textType);
            Program.AutoComp(this.tbl_Do, "Do_No", this.textDoNo);
            this.tbl_Iscc = new WBTable();
            this.tbl_Iscc.OpenTable("wb_iscc", "Select * from wb_iscc where 1 = 1", WBData.conn);
            Program.AutoComp(this.tbl_Iscc, "Iscc_Code", this.txtqstandard);
            this.tbl_Transport = new WBTable();
            this.tbl_Transport.OpenTable("wb_Transport", "Select * from wb_Transporter", WBData.conn);
            Program.AutoComp(this.tbl_Transport, "Transporter_code", this.textTransport);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void radioDaily_CheckedChanged(object sender, EventArgs e)
        {
            this.label1.Enabled = this.radioDaily.Checked;
            this.monthCalendar2.Enabled = this.radioDaily.Checked;
            this.reportName();
        }

        private void radioDailyCumulative_CheckedChanged(object sender, EventArgs e)
        {
            this.reportName();
        }

        private void radioDo_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioDo.Checked)
            {
                this.labelMinOS.Visible = true;
                this.textMinOS.Visible = true;
            }
            else
            {
                this.labelMinOS.Visible = false;
                this.textMinOS.Visible = false;
            }
        }

        private void radioDOReport_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioDOReport.Checked)
            {
                this.grType.Enabled = false;
                this.monthCalendar1.Enabled = false;
                this.labelDate.Enabled = false;
            }
            else
            {
                this.grType.Enabled = true;
                this.monthCalendar1.Enabled = true;
                this.labelDate.Enabled = true;
            }
        }

        private void radioMonthlyCumulative_CheckedChanged(object sender, EventArgs e)
        {
            this.label1.Enabled = !this.radioMonthlyCumulative.Checked;
            this.monthCalendar2.Enabled = !this.radioMonthlyCumulative.Checked;
            this.reportName();
        }

        private void rboGI_Leave(object sender, EventArgs e)
        {
            if (this.rboGR.Checked)
            {
                this.IO = "I";
                this.labelDoNo.Text = "DO No.";
            }
            else
            {
                this.IO = "O";
                this.labelDoNo.Text = "SO No.";
            }
        }

        private void rboGI_TextChanged(object sender, EventArgs e)
        {
            if (this.rboGR.Checked)
            {
                this.IO = "I";
                this.labelDoNo.Text = "DO No.";
            }
            else
            {
                this.IO = "O";
                this.labelDoNo.Text = "SO No.";
            }
        }

        private void rboGR_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rboGR.Checked)
            {
                this.IO = "I";
                this.labelDoNo.Text = "DO No.";
            }
            else
            {
                this.IO = "O";
                this.labelDoNo.Text = "SO No.";
            }
        }

        private void RepDODetail_Load(object sender, EventArgs e)
        {
            this.translate();
            this.labelCommName.Text = "";
            this.labelQStandard.Text = "";
            this.labelTransTypeName.Text = "";
            this.initTable();
            this.reportName();
            if (WBSetting.Field("KB").ToString() == "N")
            {
                this.kb = "N";
                this.rboNonKB.Checked = true;
            }
            else
            {
                this.kb = "Y";
                this.rboKB.Checked = true;
            }
            if (WBSetting.region == "1")
            {
                this.checkSourceCode.Visible = true;
                this.checkSourceDesc.Visible = true;
            }
            else
            {
                this.checkSourceCode.Visible = false;
                this.checkSourceDesc.Visible = false;
            }
            if (WBSetting.transflow == "1")
            {
                this.checkBoxGatepassNumber.Visible = false;
                this.checkBoxGatepassNumber.Checked = false;
            }
            else if (WBSetting.transflow == "2")
            {
                this.checkBoxGatepassNumber.Visible = true;
                this.checkBoxGatepassNumber.Checked = true;
            }
            else if (WBSetting.transflow == "3")
            {
                this.checkBoxGatepassNumber.Visible = true;
                this.checkBoxGatepassNumber.Checked = true;
            }
            if (WBSetting.bGate == "Y")
            {
                this.cb_interval12.Visible = true;
                this.cb_interval34.Visible = true;
            }
            else
            {
                this.cb_interval12.Visible = false;
                this.cb_interval34.Visible = false;
            }
        }

        private void reportName()
        {
            if (this.radioDaily.Checked)
            {
                this.TimeFrom.Visible = true;
                this.TimeTo.Visible = true;
                this.rptName = "Daily Report";
            }
            else
            {
                this.TimeFrom.Visible = false;
                this.TimeTo.Visible = false;
                if (this.radioDailyCumulative.Checked)
                {
                    this.rptName = "Daily Cumulative Report";
                }
                else if (this.radioMonthlyCumulative.Checked)
                {
                    this.rptName = "Monthly Cumulative Report";
                }
                else if (this.radioDOReport.Checked)
                {
                    this.rptName = "DO/SO Details Report";
                }
            }
        }

        private void RepRecIssue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void subTotalComm(HTML rep, string comm)
        {
            rep.Write("<tr class='bd'>");
            if (this.checkEstQ.Checked)
            {
                string[] textArray1 = new string[] { "<td colspan=", (this.jlhKolom + this.jlhQa).ToString(), "><b>Sub Total of Commodity ", comm, "</td>" };
                rep.Write(string.Concat(textArray1));
            }
            else
            {
                string[] textArray2 = new string[] { "<td colspan=", this.jlhKolom.ToString(), "><b>Sub Total of Commodity ", comm, "</td>" };
                rep.Write(string.Concat(textArray2));
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.teGross:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.teTare:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.teNet:N0}") + "</b></td>");
                if (this.radioCommodity.Checked)
                {
                    rep.Write("<td  align=right>&nbsp</td>");
                }
                else
                {
                    rep.Write("<td colspan='3' align=right>&nbsp</td>");
                }
            }
            if (this.checkFactQ.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkQDeductKG.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfBruto:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfTarra:N0}") + "</b></td>");
                if (this.cbDeduction.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfreceived:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfdeduc:N0}") + "</b></td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfgunny:N0}") + "</b></td>");
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfNett:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right>&nbsp</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td colspan=2  align=right>&nbsp</td>");
                }
            }
            if (this.checkConv.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tConv:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right>&nbsp</td>");
            }
            if (this.checkVariance.Checked)
            {
                this.wDiff = 0.0;
                this.pwDiff = 0.0;
                this.wDiff = this.sfNett - this.seNet;
                if (this.seNet > 0.0)
                {
                    this.pwDiff = (this.wDiff / this.seNet) * 100.0;
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.wDiff:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.pwDiff:N3}") + "</b></td>");
                this.jlhKolomB -= 2;
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingQty:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingQty_opw:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq(this.commUOM) + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingNetW:N0}") + "</b></td>");
                this.jlhKolomB -= 4;
                if (this.radioCommodity.Checked)
                {
                    rep.Write("<td>&nbsp</td>");
                }
                else
                {
                    rep.Write("<td colspan=3>&nbsp</td>");
                }
            }
            if (this.cBoxReturnInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seReturInKg:N0}") + "</b></td>");
                this.jlhKolomB++;
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seReturInPack:N0}") + "</b></td>");
                this.jlhKolomB++;
            }
            if (this.cBoxLossInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seLossInKg:N0}") + "</b></td>");
                this.jlhKolomB++;
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seLossInPack:N0}") + "</b></td>");
                this.jlhKolomB++;
            }
            if (this.jlhKlmDL <= 0)
            {
                if (this.nextcol > 0)
                {
                    rep.Write("<td colspan=" + this.nextcol.ToString() + ">&nbsp</td>");
                }
            }
            else
            {
                int num2 = 5;
                if (this.checkBoxMaterialStuffing.Checked)
                {
                    num2++;
                }
                if (this.checkSeal.Checked)
                {
                    num2++;
                }
                rep.Write("<td colspan=" + num2 + ">&nbsp</td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sjtgunny:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sjtKG:N0}") + "</b></td>");
                this.nextcol += this.radioCommodity.Checked ? 0 : 3;
                if (this.nextcol > 0)
                {
                    rep.Write("<td colspan=" + this.nextcol.ToString() + ">&nbsp</td>");
                }
            }
            rep.Write("</tr>");
        }

        private void subTotalDO(HTML rep, string DoNo)
        {
            int num = 0;
            rep.Write("<tr class='bd'>");
            if (this.checkEstQ.Checked)
            {
                string[] textArray1 = new string[] { "<td colspan=", (this.jlhKolom + this.jlhQa).ToString(), "><b>Sub Total of DO/SO ", DoNo, " </td>" };
                rep.Write(string.Concat(textArray1));
            }
            else
            {
                string[] textArray2 = new string[] { "<td colspan=", this.jlhKolom.ToString(), "><b>Sub Total of DO/SO ", DoNo, " </td>" };
                rep.Write(string.Concat(textArray2));
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.seGross:N0}") + "</b></td>");
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.seTare:N0}") + "</b></td>");
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.seNet:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.subDO_est:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.weightIn2[0] + this.subDO_est:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.party_est - (this.weightIn2[0] + this.subDO_est):N0}") + "</b></td>");
            }
            if (this.checkFactQ.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkQDeductKG.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfBruto:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfTarra:N0}") + "</b></td>");
                if (this.cbDeduction.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfreceived:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfdeduc:N0}") + "</b></td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfgunny:N0}") + "</b></td>");
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sfNett:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.subDO_fac:N0}") + "</b></td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.weightIn2[1] + this.subDO_fac:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.party_fac - (this.weightIn2[1] + this.subDO_fac):N0}") + "</b></td>");
                }
            }
            if (this.checkConv.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sConv:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>&nbsp</td>");
                num += 2;
            }
            if (this.checkVariance.Checked)
            {
                this.wDiff = 0.0;
                this.pwDiff = 0.0;
                this.wDiff = this.sfNett - this.seNet;
                if (this.seNet > 0.0)
                {
                    this.pwDiff = (this.wDiff / this.seNet) * 100.0;
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.wDiff:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.pwDiff:N3}") + "</b></td>");
                num += 2;
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingQty:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingQty_opw:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq(this.commUOM) + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.tfLoadingNetW:N0}") + "</b></td>");
                num += 4;
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.subDO_loadQty:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.weightIn + this.subDO_loadQty:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.party - (this.weightIn + this.subDO_loadQty):N0}") + "</b></td>");
            }
            if (this.cBoxReturnInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seReturInKg:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seReturInPack:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxLossInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seLossInKg:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.seLossInPack:N0}") + "</b></td>");
                num++;
            }
            if ((this.jlhKolomB - (3 + num)) > 0)
            {
                rep.Write("<td colspan=" + (this.jlhKolomB - (3 + num)).ToString() + ">&nbsp</td>");
            }
            if (this.jlhKlmDL > 0)
            {
                int num3 = 5;
                if (this.checkBoxMaterialStuffing.Checked)
                {
                    num3++;
                    this.nextcol--;
                }
                if (this.checkSeal.Checked)
                {
                    num3++;
                    this.nextcol--;
                }
                rep.Write("<td colspan=" + num3.ToString() + ">&nbsp</td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sjgunny:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.sjKG:N0}") + "</b></td>");
                if (this.radioCommodity.Checked)
                {
                    rep.Write("<td colspan=" + this.nextcol.ToString() + ">&nbsp</td>");
                }
                else
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.jlhGunnyToday * this.netGunny:N0}") + "</td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.party - (this.jlhGunnyToday * this.netGunny):N0}") + "</td>");
                }
            }
            if (this.nextcol > 0)
            {
                object[] objArray1 = new object[] { "<td colspan=", this.nextcol, 2, ">&nbsp</td>" };
                rep.Write(string.Concat(objArray1));
            }
            rep.Write("</tr>");
        }

        private void subTotalVendor(HTML rep, string Vendor)
        {
            int num = 0;
            rep.Write("<tr class='bd'>");
            if (this.checkEstQ.Checked)
            {
                string[] textArray1 = new string[] { "<td colspan=", (this.jlhKolom + this.jlhQa).ToString(), "><b>Sub Total of Vendor ", Vendor, " </td>" };
                rep.Write(string.Concat(textArray1));
            }
            else
            {
                string[] textArray2 = new string[] { "<td colspan=", this.jlhKolom.ToString(), "><b>Sub Total of Vendor ", Vendor, " </td>" };
                rep.Write(string.Concat(textArray2));
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.veGross:N0}") + "</b></td>");
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.veTare:N0}") + "</b></td>");
                rep.Write("<td nowrap  align=right><b>" + rep.strq($"{this.veNet:N0}") + "</b></td>");
                rep.Write("<td colspan=3 nowrap align=right><b>" + rep.strq("") + "</b></td>");
            }
            if (this.checkFactQ.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkQDeductKG.Checked && (this.jlhQa > 0))
            {
                rep.Write("<td colspan=" + this.jlhQa.ToString() + ">&nbsp</td>");
            }
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfBruto:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfTarra:N0}") + "</b></td>");
                if (this.cbDeduction.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfreceived:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfdeduc:N0}") + "</b></td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfgunny:N0}") + "</b></td>");
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfNett:N0}") + "</b></td>");
                if (!this.chkShowOSUTDPerVendor.Checked)
                {
                    rep.Write("<td colspan=3 nowrap align=right><b>" + rep.strq("") + "</b></td>");
                }
                else if (this.chkShowOSUTDPerVendor.Checked)
                {
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vsubDO:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vweightIn + this.vsubDO:N0}") + "</b></td>");
                    rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vparty - (this.vweightIn + this.vsubDO):N0}") + "</b></td>");
                }
            }
            if (this.checkConv.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vConv:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>&nbsp</td>");
                num += 2;
            }
            if (this.checkVariance.Checked)
            {
                this.wDiff = 0.0;
                this.pwDiff = 0.0;
                this.wDiff = this.vfNett - this.veNet;
                if (this.veNet > 0.0)
                {
                    this.pwDiff = (this.wDiff / this.veNet) * 100.0;
                }
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.wDiff:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.pwDiff:N3}") + "</b></td>");
                num += 2;
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfLoadingQty:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfLoadingQty_opw:N0}") + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq(this.commUOM) + "</b></td>");
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.vfLoadingNetW:N0}") + "</b></td>");
                num += 4;
                rep.Write("<td colspan=3 nowrap align=right><b>" + rep.strq("") + "</b></td>");
            }
            if (this.cBoxReturnInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.veReturInKg:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.veReturInPack:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxLossInKG.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.veLossInKg:N0}") + "</b></td>");
                num++;
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + rep.strq($"{this.veLossInPack:N0}") + "</b></td>");
                num++;
            }
            if (this.jlhKlmDL > 0)
            {
                int num3 = 5;
                if (this.checkBoxMaterialStuffing.Checked)
                {
                    num3++;
                }
                if (this.checkSeal.Checked)
                {
                    num3++;
                }
                rep.Write("<td colspan=" + num3.ToString() + ">&nbsp</td>");
                rep.Write("<td>&nbsp</td>");
                rep.Write("<td>&nbsp</td>");
                if (!this.radioCommodity.Checked)
                {
                    rep.Write("<td>&nbsp</td>");
                    rep.Write("<td>&nbsp</td>");
                    rep.Write("<td>&nbsp</td>");
                }
            }
            if (this.nextcol > 0)
            {
                rep.Write("<td colspan=" + this.nextcol + ">&nbsp</td>");
            }
            rep.Write("</tr>");
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
                else
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                    if (this.ComboComm.Items.IndexOf(this.textCommodity.Text) < 0)
                    {
                        this.ComboComm.Items.Add(this.textCommodity.Text);
                    }
                }
            }
        }

        private void textCommodity_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormPickList list = new FormPickList();
            this.tbl_Comm.ReOpen();
            list.tempTable = this.tbl_Comm;
            list.dgView.Rows.Clear();
            list.autoField = "Comm_Code";
            int num = 0;
            while (true)
            {
                if (num >= this.ComboComm.Items.Count)
                {
                    list.ShowDialog();
                    this.ComboComm.Items.Clear();
                    num = 0;
                    while (true)
                    {
                        if (num >= (list.dgView.Rows.Count - 1))
                        {
                            this.textCommodity.Text = (this.ComboComm.Items.Count <= 0) ? "" : this.ComboComm.Items[0].ToString();
                            return;
                        }
                        this.ComboComm.Items.Add(list.dgView.Rows[num].Cells[0].Value.ToString());
                        num++;
                    }
                }
                object[] values = new object[] { this.ComboComm.Items[num].ToString() };
                list.dgView.Rows.Add(values);
                num++;
            }
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
            if (this.textDoNo.Text.Trim() != "")
            {
                this.tbl_Do.ReOpen();
                string[] aField = new string[] { "Do_NO" };
                string[] aFind = new string[] { this.textDoNo.Text.Trim() };
                DataRow data = this.tbl_Do.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    this.buttonDoNo.PerformClick();
                    this.textDoNo.Focus();
                }
                else
                {
                    if (data["Deductedby"].ToString() == "1")
                    {
                        this.check3rdParty.Checked = true;
                    }
                    this.tbl_Comm.ReOpen();
                    string[] textArray3 = new string[] { "comm_code" };
                    string[] textArray4 = new string[] { data["comm_code"].ToString() };
                    DataRow row2 = this.tbl_Comm.GetData(textArray3, textArray4);
                    if ((row2 != null) && ((row2["bulkpack"].ToString() == "P") || ((row2["unit"].ToString() != "") && (row2["unit"].ToString() != "KG"))))
                    {
                        this.checkLoadingQty.Checked = true;
                    }
                    if (this.comboDO.Items.IndexOf(this.textDoNo.Text) < 0)
                    {
                        this.comboDO.Items.Add(this.textDoNo.Text);
                    }
                }
            }
        }

        private void textDoNo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormPickList list = new FormPickList();
            this.tbl_Do.ReOpen();
            list.tempTable = this.tbl_Do;
            list.dgView.Rows.Clear();
            list.autoField = "DO_No";
            int num = 0;
            while (true)
            {
                if (num >= this.comboDO.Items.Count)
                {
                    list.ShowDialog();
                    this.comboDO.Items.Clear();
                    num = 0;
                    while (true)
                    {
                        if (num >= (list.dgView.Rows.Count - 1))
                        {
                            this.textDoNo.Text = (this.comboDO.Items.Count <= 0) ? "" : this.comboDO.Items[0].ToString();
                            return;
                        }
                        this.comboDO.Items.Add(list.dgView.Rows[num].Cells[0].Value.ToString());
                        num++;
                    }
                }
                object[] values = new object[] { this.comboDO.Items[num].ToString() };
                list.dgView.Rows.Add(values);
                num++;
            }
        }

        private void textMinOS_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textMinOS);
        }

        private void textType_Leave(object sender, EventArgs e)
        {
            this.labelTransTypeName.Text = "";
            if (this.textType.Text.Trim() != "")
            {
                this.tbl_TransType.ReOpen();
                string[] aField = new string[] { "Transaction_code" };
                string[] aFind = new string[] { this.textType.Text.Trim() };
                int recNo = this.tbl_TransType.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelTransTypeName.Text = this.tbl_TransType.DT.Rows[recNo]["Transaction_name"].ToString().Trim();
                }
                else
                {
                    this.buttonType.PerformClick();
                    this.textType.Focus();
                }
            }
        }

        private void translate()
        {
            this.Text = Resource.Report05_001;
            this.rboGR.Text = Resource.Report05_002;
            this.rboGI.Text = Resource.Report05_003;
            this.rboKB.Text = Resource.Report05_004;
            this.rboNonKB.Text = Resource.Report05_005;
            this.groupBox1.Text = Resource.Report05_006;
            this.radioDaily.Text = Resource.Report05_007;
            this.label1.Text = Resource.Report05_009;
            this.radioDailyCumulative.Text = Resource.Report05_010;
            this.radioMonthlyCumulative.Text = Resource.Report05_011;
            this.label9.Text = Resource.Report05_012;
            this.radioCommodity.Text = Resource.Report05_013;
            this.radioTank.Text = Resource.Report05_014;
            this.label5.Text = Resource.Report05_015;
            this.radioDo.Text = Resource.Report05_016;
            this.radioContract.Text = Resource.Report05_017;
            this.radioRelation.Text = Resource.Report05_018;
            this.radioEstate.Text = Resource.Report05_019;
            this.radioPO.Text = Resource.Report05_020;
            this.labelMinOS.Text = Resource.Report05_021;
            this.label4.Text = Resource.Report05_022;
            this.checkSTO.Text = Resource.Report05_023;
            this.check1xSTO.Text = Resource.Report05_024;
            this.check1xDO.Text = Resource.Report05_025;
            this.check3rdParty.Text = Resource.Report05_029;
            this.checkEstQ.Text = Resource.Report05_030;
            this.checkDelivery.Text = Resource.Report05_031;
            this.checkRegDate.Text = Resource.Report05_032;
            this.cbDeduction.Text = Resource.Report05_033;
            this.checkBrutoTarra.Text = Resource.Report05_034;
            this.checkFactQ.Text = Resource.Report05_035;
            this.checkVariance.Text = Resource.Report05_036;
            this.cbGunny.Text = Resource.Report05_037;
            this.checkHour.Text = Resource.Report05_038;
            this.checkHourDiff.Text = Resource.Report05_039;
            this.checkLicenseNo.Text = Resource.Report05_040;
            this.checkRmkTicket.Text = Resource.Report05_041;
            this.checkRmkReport.Text = Resource.Report05_042;
            this.checkSeal.Text = Resource.Report05_043;
            this.checkDriverName.Text = Resource.Report05_044;
            this.checkDeliNote.Text = Resource.Report05_045;
            this.checkConv.Text = Resource.Report05_046;
            this.checkDeliveryLetter.Text = Resource.Report05_047;
            this.checkProcess.Text = Resource.Report05_048;
            this.checkISO.Text = Resource.Report05_049;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
            this.checkRelation.Text = Resource.Rep01_026;
            this.checkRelationName.Text = Resource.Rep01_027;
            this.cBoxCommName.Text = Resource.CommE_003;
            this.checkTransporter.Text = Resource.Rep01_011;
            this.checkTransporterName.Text = Resource.Transporter_002;
            this.checkSourceCode.Text = Resource.Source_014;
            this.checkSourceDesc.Text = Resource.Trans_059;
            this.checkBoxGatepassNumber.Text = Resource.Gatepass_001;
        }

        private void txtqstandard_Leave(object sender, EventArgs e)
        {
            this.labelQStandard.Text = "";
            if (this.txtqstandard.Text.Trim() != "")
            {
                this.tbl_Iscc.ReOpen();
                string[] aField = new string[] { "Iscc_code" };
                string[] aFind = new string[] { this.txtqstandard.Text.Trim() };
                int recNo = this.tbl_Iscc.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.btnQstandard.PerformClick();
                    this.txtqstandard.Focus();
                }
                else
                {
                    this.labelQStandard.Text = this.tbl_Iscc.DT.Rows[recNo]["Iscc_Text"].ToString().Trim();
                    if (this.ComboIscc.Items.IndexOf(this.txtqstandard.Text) < 0)
                    {
                        this.ComboIscc.Items.Add(this.txtqstandard.Text);
                    }
                }
            }
        }

        private void txtqstandard_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.btnQstandard.PerformClick();
        }

        private void txtqstandard_TextChanged(object sender, EventArgs e)
        {
        }
    }
}

