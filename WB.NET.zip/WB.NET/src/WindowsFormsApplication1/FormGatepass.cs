﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO.Ports;
    using System.Windows.Forms;

    public class FormGatepass : Form
    {
        public WBTable tblVwGatepass = new WBTable();
        public WBTable tblGatepass = new WBTable();
        public DateTime dFrom;
        public DateTime dTo;
        private int idxFind = 0;
        private string cField;
        private string loadComment = "";
        private string changeReason = "";
        private string logKey = "";
        private IContainer components = null;
        private CheckBox checkDeleted;
        private TextBox TextFind;
        private CheckBox checkSubmitted;
        private Button buttonFind;
        private TextBox textDriver;
        private TextBox textTruck;
        private TextBox textTransporter;
        private DateTimePicker dateTimePicker2;
        private TextBox textTransType;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem submitToolStripMenuItem;
        private ToolStripMenuItem backToolStripMenuItem;
        private DataGridView dataGridView1;
        private Label labelJumlahRecord;
        private Label labelGatepass;
        private Label label6;
        private BackgroundWorker backgroundWorker1;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private CheckBox checkPartial;
        private GroupBox groupFilter;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label5;
        private Label label4;
        private Label label9;
        private Label label7;
        private Button buttonFilter;
        private Timer timer1;
        private Label lblNow;
        private SerialPort serialPort1;
        private Timer timerSAPUpd;
        private Label lblDate;
        private Label label2;
        private ToolStripMenuItem addToolStripMenuItem;
        private TextBox textLoadComment;
        private Label labelLoadComment;
        private ToolStripMenuItem printGatepassToolStripMenuItem;

        public FormGatepass()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            if (WBSetting.transflow == "3")
            {
                this.addToolStripMenuItem.Visible = false;
            }
            else if (WBSetting.transflow == "2")
            {
                this.addToolStripMenuItem.Visible = true;
            }
            this.addToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_GATEPASS", "A");
            this.editToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_GATEPASS", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_GATEPASS", "D");
            this.viewToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_GATEPASS", "V");
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGatepassEntry entry = new FormGatepassEntry();
            this.tblVwGatepass.BeforeEdit(this.dataGridView1, "ADD");
            entry.pMode = "ADD";
            entry.Text = "ADD GATEPASS";
            entry.ShowDialog();
            if (entry.saved)
            {
                this.tblVwGatepass.ReOpen();
                this.dataGridView1 = this.tblVwGatepass.AfterEdit(entry.pMode);
                this.dataGridView1.Refresh();
                string[] aField = new string[] { "TA_Number" };
                string[] aFind = new string[] { entry.textGatepass_Number.Text };
                this.tblVwGatepass.SetCursor(this.dataGridView1, this.tblVwGatepass.GetCurrentRow(this.dataGridView1, aField, aFind));
                this.ShowStatus();
            }
            entry.Dispose();
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string str2 = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND (Gatepass_Number is not null)  And  (Approved = 'Y') And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass='')or (Submit_Gatepass='N'))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
            string sqltext = ("select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation("")) + " AND (Reject = 'N') ";
            if (WBSetting.transflow == "3")
            {
                sqltext = sqltext + " And ((Approved = 'Y')  ANd (Gatepass_number is not null)) ";
            }
            sqltext = !this.checkDeleted.Checked ? (sqltext + " AND ((Deleted = 'N') OR (Deleted is null) OR (Deleted =''))") : (sqltext + " AND (Deleted = 'Y' OR ((Deleted = 'N') or (Deleted is null) or (Deleted =''))) ");
            sqltext = !this.checkSubmitted.Checked ? (sqltext + " AND ((Submit_Gatepass = 'N') or (Submit_Gatepass is null) or (Submit_Gatepass =''))  ") : (sqltext + " AND ((Submit_Gatepass = 'Y') OR (Submit_Gatepass = 'N') OR (Submit_Gatepass is null) OR (Submit_Gatepass ='')) ");
            this.dFrom = this.dateTimePicker1.Value;
            this.dTo = this.dateTimePicker2.Value;
            string str3 = Program.DTOC(this.dFrom) + " 00:00:00";
            string str4 = Program.DTOC(this.dTo) + " 00:00:00";
            string[] textArray1 = new string[] { sqltext, " and ((In_Date>='", str3, "' and In_Date<='", str4, "'))" };
            sqltext = string.Concat(textArray1);
            this.tblVwGatepass.Close();
            this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
            this.DataReset();
            Cursor.Current = Cursors.Default;
            this.ShowStatus();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.idxFind = this.tblVwGatepass.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
            Cursor.Current = Cursors.Default;
        }

        private bool checkGroup() => 
            (Convert.ToInt16(WBUser.UserLevel) <= 1) || ((this.dataGridView1.CurrentRow.Cells["user_Group1"].Value != null) && ((WBUser.UserGroup.Trim().ToUpper() != this.dataGridView1.CurrentRow.Cells["user_Group1"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != this.dataGridView1.CurrentRow.Cells["user_Group2"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != this.dataGridView1.CurrentRow.Cells["user_Group3"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != this.dataGridView1.CurrentRow.Cells["user_Group4"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != this.dataGridView1.CurrentRow.Cells["user_Group5"].Value.ToString().Trim().ToUpper()) ? (WBUser.UserGroup.Trim().ToUpper() == this.dataGridView1.CurrentRow.Cells["user_Group6"].Value.ToString().Trim().ToUpper()) : true) : true) : true) : true) : true));

        private void checkPartial_CheckedChanged(object sender, EventArgs e)
        {
            string sqltext = "";
            Cursor.Current = Cursors.WaitCursor;
            if (!this.checkPartial.Checked)
            {
                this.groupFilter.Enabled = true;
            }
            else
            {
                this.groupFilter.Enabled = false;
                this.textTruck.Text = "";
                this.textDriver.Text = "";
                this.textTransporter.Text = "";
                this.textTransType.Text = "";
                this.checkSubmitted.Checked = false;
                if (WBSetting.transflow == "3")
                {
                    sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND (Gatepass_Number is not null)  And  (Approved = 'Y') And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass='') or (Submit_Gatepass='N'))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
                }
                else if (WBSetting.transflow == "2")
                {
                    sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND (Gatepass_Number is not null)  And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass='')or (Submit_Gatepass='N'))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
                }
                this.tblVwGatepass.Close();
                this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
                this.DataReset();
                Cursor.Current = Cursors.Default;
                this.ShowStatus();
            }
            Cursor.Current = Cursors.Default;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && (this.dataGridView1.CurrentRow.Cells["Gatepass_number"].ToString() != ""))
            {
                this.textLoadComment.Text = this.dataGridView1.CurrentRow.Cells["Load_Comment"].Value.ToString();
                this.loadComment = this.textLoadComment.Text;
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["Submit_Gatepass"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.DimGray;
                e.CellStyle.SelectionBackColor = Color.Gray;
            }
        }

        private void DataReset()
        {
            string str = this.dataGridView1.SortOrder.ToString();
            DataGridViewColumn sortedColumn = this.dataGridView1.SortedColumn;
            this.tblVwGatepass.BeforeEdit(this.dataGridView1, "REFRESH");
            this.tblVwGatepass.ReOpen();
            this.tblVwGatepass.AfterEdit("REFRESH");
            ListSortDirection direction = (str != "Ascending") ? ListSortDirection.Descending : ListSortDirection.Ascending;
            this.dataGridView1.Sort(this.dataGridView1.Columns[sortedColumn.Name.ToString()], direction);
            this.dataGridView1.Refresh();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table;
            WBTable table2;
            if (this.dataGridView1.Rows.Count <= 0)
            {
                return;
            }
            else if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
            {
                table = new WBTable();
                table.OpenTable("wb_gatepass", "Select * from wb_gatepass where " + WBData.CompanyLocation(" and uniq = '" + this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    goto TR_0002;
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    if ((this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString().Trim() == "") || (table.DR["Ref"].ToString() == ""))
                    {
                        goto TR_0006;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_Trans", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + table.DR["Ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0007;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            if (table2.DR["deleted"].ToString() != "Y")
                            {
                                MessageBox.Show(Resource.Mes_159 + " " + table.DR["Ref"].ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                table2.Dispose();
                            }
                            else
                            {
                                goto TR_0007;
                            }
                        }
                    }
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_154, Resource.Title_002);
                return;
            }
            goto TR_0007;
        TR_0002:
            table.Dispose();
            return;
        TR_0006:
            if (MessageBox.Show(Resource.Mes_153 + " (" + table.DR["TA_Number"].ToString() + ") ? ", Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Gatepass No" },
                    textRefNo = { Text = table.DR["gatepass_number"].ToString() },
                    Text = "DELETE REASON",
                    label2 = { Text = "Delete Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    this.tblVwGatepass.BeforeEdit(this.dataGridView1, "DELETE");
                    table.DR.BeginEdit();
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR["Deleted"] = "Y";
                    table.DR["Delete_By"] = WBUser.UserID;
                    table.DR["Delete_Date"] = DateTime.Now.ToString();
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                    this.tblVwGatepass.ReOpen();
                    this.dataGridView1 = this.tblVwGatepass.AfterEdit("DELETE");
                    this.dataGridView1.Refresh();
                    this.ShowStatus();
                }
                else
                {
                    return;
                }
            }
            goto TR_0002;
        TR_0007:
            table2.Dispose();
            goto TR_0006;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (!this.checkGroup())
                {
                    MessageBox.Show("No Authorization for Selected Gatepass.\nPlease choose another Gatepass or Contact Admin...", Resource.Title_002);
                }
                else if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_026, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if ((this.dataGridView1.CurrentRow.Cells["Submit_date"].Value.ToString().Trim() != "") && !WBUser.CheckTrustee("MN_SUBMITTED_GATEPASS", "E"))
                {
                    MessageBox.Show(Resource.Mes_156, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if ((this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim() != "") && !WBUser.CheckTrustee("MN_WEIGHED_GATEPASS", "E"))
                {
                    MessageBox.Show(Resource.Mes_603, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    FormGatepassEntry entry = new FormGatepassEntry {
                        pMode = "EDIT",
                        Text = "EDIT GATEPASS"
                    };
                    this.tblVwGatepass.BeforeEdit(this.dataGridView1, "EDIT");
                    entry.sUniq = this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString();
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.tblVwGatepass.ReOpen();
                        this.dataGridView1 = this.tblVwGatepass.AfterEdit(entry.pMode);
                        this.dataGridView1.Refresh();
                        string[] aField = new string[] { "Gatepass_Number" };
                        string[] aFind = new string[] { entry.textGatepass_Number.Text };
                        this.tblVwGatepass.SetCursor(this.dataGridView1, this.tblVwGatepass.GetCurrentRow(this.dataGridView1, aField, aFind));
                        this.ShowStatus();
                    }
                    entry.Dispose();
                }
            }
        }

        private void f_load()
        {
            this.cField = " Coy, Location_code, Gatepass_number, TA_number,Ref, transaction_code, transporter_code,  truck_number, trailer_number, Submit_Gatepass,  In_Date, In_time,  loaddate, Out_Date, Out_time, Submit_Date, Submit_Time, GatePass_Remark,  WB, Deleted,Load_Comment, user_group1, user_group2,user_group3,user_group4,user_group5,user_group6, uniq";
            string sqltext = "";
            if (WBSetting.transflow == "3")
            {
                sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND (Gatepass_Number is not null)  AND  (Approved = 'Y')  AND  ((Submit_Gatepass IS NULL) or (Submit_Gatepass='') or (Submit_Gatepass= 'N'))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
            }
            else if (WBSetting.transflow == "2")
            {
                sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND (Gatepass_Number is not null)  And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass='')or (Submit_Gatepass='N'))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
            }
            this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.tblVwGatepass.DV;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Gatepass_Number"], ListSortDirection.Descending);
            this.DataReset();
            this.ShowStatus();
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Uniq"].Visible = false;
            this.dataGridView1.Columns["Deleted"].Visible = false;
            this.dataGridView1.Columns["TA_number"].Visible = false;
            this.dataGridView1.Columns["Load_Comment"].Visible = false;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dataGridView1.Columns["Gatepass_Number"].HeaderText = Resource.Gatepass_001;
            this.dataGridView1.Columns["Transporter_Code"].HeaderText = Resource.Gatepass_002;
            this.dataGridView1.Columns["Truck_Number"].HeaderText = Resource.Gatepass_003;
            this.dataGridView1.Columns["Trailer_Number"].HeaderText = Resource.Gatepass_004;
            this.dataGridView1.Columns["Submit_Gatepass"].HeaderText = Resource.Gatepass_005;
            this.dataGridView1.Columns["In_Date"].HeaderText = Resource.Gatepass_006;
            this.dataGridView1.Columns["In_Time"].HeaderText = Resource.Gatepass_007;
            this.dataGridView1.Columns["Out_Date"].HeaderText = Resource.Gatepass_008;
            this.dataGridView1.Columns["Out_Time"].HeaderText = Resource.Gatepass_009;
            this.dataGridView1.Columns["Submit_Date"].HeaderText = Resource.Gatepass_010;
            this.dataGridView1.Columns["Submit_Time"].HeaderText = Resource.Gatepass_011;
            this.dataGridView1.Columns["Gatepass_Remark"].HeaderText = Resource.Gatepass_012;
            this.dataGridView1.Columns["User_Group1"].HeaderText = Resource.Gatepass_013;
            this.dataGridView1.Columns["User_Group2"].HeaderText = Resource.Gatepass_014;
            this.dateTimePicker1.Value = DateTime.Now.AddDays(-1.0);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Value = DateTime.Now;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            base.KeyPreview = true;
        }

        private void FormGatepass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormGatepass_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            base.Opacity = 0.0;
            this.f_load();
            this.groupFilter.Enabled = false;
            base.Opacity = 100.0;
            Cursor.Current = Cursors.Default;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.checkDeleted = new CheckBox();
            this.TextFind = new TextBox();
            this.checkSubmitted = new CheckBox();
            this.buttonFind = new Button();
            this.textDriver = new TextBox();
            this.textTruck = new TextBox();
            this.textTransporter = new TextBox();
            this.dateTimePicker2 = new DateTimePicker();
            this.textTransType = new TextBox();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addToolStripMenuItem = new ToolStripMenuItem();
            this.viewToolStripMenuItem = new ToolStripMenuItem();
            this.editToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.submitToolStripMenuItem = new ToolStripMenuItem();
            this.printGatepassToolStripMenuItem = new ToolStripMenuItem();
            this.backToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.labelJumlahRecord = new Label();
            this.labelGatepass = new Label();
            this.label6 = new Label();
            this.backgroundWorker1 = new BackgroundWorker();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.panel1 = new Panel();
            this.textLoadComment = new TextBox();
            this.labelLoadComment = new Label();
            this.checkPartial = new CheckBox();
            this.groupFilter = new GroupBox();
            this.dateTimePicker1 = new DateTimePicker();
            this.label3 = new Label();
            this.label5 = new Label();
            this.label4 = new Label();
            this.label9 = new Label();
            this.label7 = new Label();
            this.buttonFilter = new Button();
            this.timer1 = new Timer(this.components);
            this.lblNow = new Label();
            this.serialPort1 = new SerialPort(this.components);
            this.timerSAPUpd = new Timer(this.components);
            this.lblDate = new Label();
            this.label2 = new Label();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupFilter.SuspendLayout();
            base.SuspendLayout();
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x156, 0x22);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x65, 0x11);
            this.checkDeleted.TabIndex = 0x23;
            this.checkDeleted.Text = "Include D&eleted";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.TextFind.CharacterCasing = CharacterCasing.Upper;
            this.TextFind.Location = new Point(4, 9);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 1;
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.checkSubmitted.AutoSize = true;
            this.checkSubmitted.Location = new Point(0x156, 11);
            this.checkSubmitted.Name = "checkSubmitted";
            this.checkSubmitted.Size = new Size(0x6f, 0x11);
            this.checkSubmitted.TabIndex = 0x11;
            this.checkSubmitted.Text = "&Include Submitted";
            this.checkSubmitted.UseVisualStyleBackColor = true;
            this.buttonFind.Location = new Point(0xc2, 6);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x2d, 0x1b);
            this.buttonFind.TabIndex = 2;
            this.buttonFind.Text = "&Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.textDriver.CharacterCasing = CharacterCasing.Upper;
            this.textDriver.Location = new Point(0x16b, 0x53);
            this.textDriver.MaxLength = 20;
            this.textDriver.Name = "textDriver";
            this.textDriver.Size = new Size(0x7b, 20);
            this.textDriver.TabIndex = 0x22;
            this.textDriver.KeyPress += new KeyPressEventHandler(this.textDriver_KeyPress);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x16b, 0x39);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 0x21;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x74, 0x53);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x7b, 20);
            this.textTransporter.TabIndex = 0x20;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(0xee, 0x13);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x62, 20);
            this.dateTimePicker2.TabIndex = 9;
            this.textTransType.CharacterCasing = CharacterCasing.Upper;
            this.textTransType.Location = new Point(0x74, 0x35);
            this.textTransType.MaxLength = 20;
            this.textTransType.Name = "textTransType";
            this.textTransType.Size = new Size(0x7b, 20);
            this.textTransType.TabIndex = 0x1f;
            this.textTransType.KeyPress += new KeyPressEventHandler(this.textTransType_KeyPress);
            this.menuStrip1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.submitToolStripMenuItem, this.printGatepassToolStripMenuItem, this.backToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x4c2, 0x18);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addToolStripMenuItem, this.viewToolStripMenuItem, this.editToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "&Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.addToolStripMenuItem.Text = "&Add";
            this.addToolStripMenuItem.Click += new EventHandler(this.addToolStripMenuItem_Click);
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.viewToolStripMenuItem.Text = "&View";
            this.viewToolStripMenuItem.Click += new EventHandler(this.viewToolStripMenuItem_Click);
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.editToolStripMenuItem.Text = "&Edit";
            this.editToolStripMenuItem.Click += new EventHandler(this.editToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.submitToolStripMenuItem.Name = "submitToolStripMenuItem";
            this.submitToolStripMenuItem.Size = new Size(0x6b, 20);
            this.submitToolStripMenuItem.Text = "&Submit Gatepass";
            this.submitToolStripMenuItem.Click += new EventHandler(this.submitToolStripMenuItem_Click);
            this.printGatepassToolStripMenuItem.Name = "printGatepassToolStripMenuItem";
            this.printGatepassToolStripMenuItem.Size = new Size(0x5e, 20);
            this.printGatepassToolStripMenuItem.Text = "Print Gatepass";
            this.printGatepassToolStripMenuItem.Click += new EventHandler(this.printGatepassToolStripMenuItem_Click);
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new Size(0x2c, 20);
            this.backToolStripMenuItem.Text = "&Back";
            this.backToolStripMenuItem.Click += new EventHandler(this.backToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(3, 0x1b);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x4bc, 430);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.labelJumlahRecord.AutoSize = true;
            this.labelJumlahRecord.Dock = DockStyle.Right;
            this.labelJumlahRecord.Location = new Point(0x49f, 0);
            this.labelJumlahRecord.Name = "labelJumlahRecord";
            this.labelJumlahRecord.Size = new Size(0x23, 13);
            this.labelJumlahRecord.TabIndex = 15;
            this.labelJumlahRecord.Text = "label5";
            this.labelGatepass.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.labelGatepass.AutoSize = true;
            this.labelGatepass.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.labelGatepass.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelGatepass.ForeColor = Color.White;
            this.labelGatepass.Location = new Point(0, 0);
            this.labelGatepass.Margin = new Padding(0);
            this.labelGatepass.Name = "labelGatepass";
            this.labelGatepass.RightToLeft = RightToLeft.Yes;
            this.labelGatepass.Size = new Size(0x4c2, 0x18);
            this.labelGatepass.TabIndex = 1;
            this.labelGatepass.Text = "Gatepass";
            this.labelGatepass.TextAlign = ContentAlignment.TopCenter;
            this.label6.Location = new Point(0x100, 60);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x65, 13);
            this.label6.TabIndex = 0x17;
            this.label6.Text = "Vehicle No.";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelGatepass, 0, 0);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0x18);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 24f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 91.74312f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 136f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 8f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 8f));
            this.tableLayoutPanel1.Size = new Size(0x4c2, 0x264);
            this.tableLayoutPanel1.TabIndex = 13;
            this.panel1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.panel1.Controls.Add(this.textLoadComment);
            this.panel1.Controls.Add(this.labelLoadComment);
            this.panel1.Controls.Add(this.checkPartial);
            this.panel1.Controls.Add(this.groupFilter);
            this.panel1.Controls.Add(this.labelJumlahRecord);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.ForeColor = Color.Black;
            this.panel1.Location = new Point(0, 0x1d3);
            this.panel1.Margin = new Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x4c2, 0x81);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
            this.textLoadComment.Location = new Point(0x37b, 0x34);
            this.textLoadComment.Multiline = true;
            this.textLoadComment.Name = "textLoadComment";
            this.textLoadComment.Size = new Size(0x13b, 0x42);
            this.textLoadComment.TabIndex = 20;
            this.textLoadComment.Leave += new EventHandler(this.textLoadComment_Leave);
            this.labelLoadComment.AutoSize = true;
            this.labelLoadComment.Location = new Point(0x37b, 0x24);
            this.labelLoadComment.Name = "labelLoadComment";
            this.labelLoadComment.Size = new Size(0x75, 13);
            this.labelLoadComment.TabIndex = 0x13;
            this.labelLoadComment.Text = "Load/Unload Comment";
            this.labelLoadComment.TextAlign = ContentAlignment.MiddleCenter;
            this.checkPartial.AutoSize = true;
            this.checkPartial.Checked = true;
            this.checkPartial.CheckState = CheckState.Checked;
            this.checkPartial.Location = new Point(0x37b, 12);
            this.checkPartial.Name = "checkPartial";
            this.checkPartial.Size = new Size(0x37, 0x11);
            this.checkPartial.TabIndex = 0x12;
            this.checkPartial.Text = "&Partial";
            this.checkPartial.UseVisualStyleBackColor = true;
            this.checkPartial.CheckedChanged += new EventHandler(this.checkPartial_CheckedChanged);
            this.groupFilter.Controls.Add(this.checkDeleted);
            this.groupFilter.Controls.Add(this.textDriver);
            this.groupFilter.Controls.Add(this.checkSubmitted);
            this.groupFilter.Controls.Add(this.textTruck);
            this.groupFilter.Controls.Add(this.textTransporter);
            this.groupFilter.Controls.Add(this.dateTimePicker2);
            this.groupFilter.Controls.Add(this.textTransType);
            this.groupFilter.Controls.Add(this.dateTimePicker1);
            this.groupFilter.Controls.Add(this.label6);
            this.groupFilter.Controls.Add(this.label3);
            this.groupFilter.Controls.Add(this.label5);
            this.groupFilter.Controls.Add(this.label4);
            this.groupFilter.Controls.Add(this.label9);
            this.groupFilter.Controls.Add(this.label7);
            this.groupFilter.Controls.Add(this.buttonFilter);
            this.groupFilter.Location = new Point(0x107, 5);
            this.groupFilter.Name = "groupFilter";
            this.groupFilter.Size = new Size(0x26e, 0x71);
            this.groupFilter.TabIndex = 0x10;
            this.groupFilter.TabStop = false;
            this.groupFilter.Text = "Filter By";
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x74, 0x13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x5f, 20);
            this.dateTimePicker1.TabIndex = 8;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xd8, 0x15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x10, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "to";
            this.label5.Location = new Point(0x100, 0x56);
            this.label5.Name = "label5";
            this.label5.Size = new Size(100, 13);
            this.label5.TabIndex = 0x16;
            this.label5.Text = "License No";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x22, 0x15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x4c, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Filter data from";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x16, 60);
            this.label9.Name = "label9";
            this.label9.Size = new Size(90, 13);
            this.label9.TabIndex = 0x15;
            this.label9.Text = "Transaction Type";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(50, 0x56);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x3d, 13);
            this.label7.TabIndex = 0x13;
            this.label7.Text = "Transporter";
            this.buttonFilter.Location = new Point(0x1fd, 0x4d);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new Size(0x5f, 30);
            this.buttonFilter.TabIndex = 4;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new EventHandler(this.buttonFilter_Click);
            this.lblNow.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblNow.AutoSize = true;
            this.lblNow.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblNow.Location = new Point(0x6ac, 8);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new Size(0x31, 13);
            this.lblNow.TabIndex = 14;
            this.lblNow.Text = "00:00:00";
            this.lblNow.Visible = false;
            this.timerSAPUpd.Interval = 0x3e8;
            this.lblDate.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblDate.Location = new Point(0x665, 8);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new Size(0x25, 13);
            this.lblDate.TabIndex = 15;
            this.lblDate.Text = "progre";
            this.label2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label2.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.ForeColor = Color.White;
            this.label2.Location = new Point(0, 0x274);
            this.label2.Margin = new Padding(0);
            this.label2.Name = "label2";
            this.label2.RightToLeft = RightToLeft.Yes;
            this.label2.Size = new Size(0x7e, 0x19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Truck Arival";
            this.label2.TextAlign = ContentAlignment.TopCenter;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4c2, 0x27c);
            base.ControlBox = false;
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.lblNow);
            base.Controls.Add(this.lblDate);
            base.KeyPreview = true;
            base.Name = "FormGatepass";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Gatepass";
            base.Load += new EventHandler(this.FormGatepass_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormGatepass_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupFilter.ResumeLayout(false);
            this.groupFilter.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void printGatepassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["WB"].Value.ToString().Trim() != "0")
                {
                    if ((this.dataGridView1.CurrentRow.Cells["Wb"].Value.ToString().Trim() == "1") && (((WBSetting.Field("GatepassPrint") == "0") || (WBSetting.Field("GatepassPrint") == "")) && (this.dataGridView1.CurrentRow.Cells["Loaddate"].Value.ToString().Trim() == "")))
                    {
                        MessageBox.Show(Resource.Mes_528, Resource.Title_002);
                        return;
                    }
                }
                else if (((WBSetting.Field("GatepassPrint") == "0") || (WBSetting.Field("GatepassPrint") == "")) && (this.dataGridView1.CurrentRow.Cells["Out_date"].Value.ToString().Trim() == ""))
                {
                    MessageBox.Show(Resource.Mes_531, Resource.Title_001);
                    return;
                }
                FormGatepassEntry entry = new FormGatepassEntry {
                    pMode = "PRINT",
                    Text = "PRINT GATEPASS",
                    sUniq = this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString()
                };
                entry.ShowDialog();
                entry.Dispose();
            }
        }

        private void setVisibleRow()
        {
            if (Convert.ToInt16(WBUser.UserLevel) > 1)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dataGridView1.Rows)
                {
                    try
                    {
                        row.Visible = (WBUser.UserGroup.Trim().ToUpper() != row.Cells["user_Group1"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != row.Cells["user_Group2"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != row.Cells["user_Group3"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != row.Cells["user_Group4"].Value.ToString().Trim().ToUpper()) ? ((WBUser.UserGroup.Trim().ToUpper() != row.Cells["user_Group5"].Value.ToString().Trim().ToUpper()) ? (WBUser.UserGroup.Trim().ToUpper() == row.Cells["user_Group6"].Value.ToString().Trim().ToUpper()) : true) : true) : true) : true) : true;
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void ShowStatus()
        {
            this.labelJumlahRecord.Text = this.tblVwGatepass.DT.Rows.Count.ToString() + " " + Resource.Main_034;
            this.labelJumlahRecord.Refresh();
        }

        private void submitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
                {
                    if (this.dataGridView1.CurrentRow.Cells["Submit_date"].Value.ToString().Trim() == "")
                    {
                        if (this.dataGridView1.CurrentRow.Cells["Out_date"].Value.ToString().Trim() == "")
                        {
                            WBTable table = new WBTable();
                            WBTable table2 = new WBTable();
                            table.OpenTable("wb_transaction", "Select * from wb_gatepass WHERE " + WBData.CompanyLocation(" and (uniq = '" + this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() + "')"), WBData.conn);
                            table2.OpenTable("wb_transaction", "Select * from wb_transaction WHERE " + WBData.CompanyLocation(" and (Ref = '" + this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString() + "')AND ((Deleted = 'N') or (Deleted is null) or (Deleted =''))"), WBData.conn);
                            if (table2.DT.Rows.Count <= 0)
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_026, Resource.Title_002);
                                return;
                            }
                            else if ((table2.DT.Rows[0]["Date2"].ToString() == null) || (table2.DT.Rows[0]["Date2"].ToString() == ""))
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_026, Resource.Title_002);
                                return;
                            }
                            else
                            {
                                table.DR = table.DT.Rows[0];
                                table.DR.BeginEdit();
                                this.logKey = table.DR["uniq"].ToString();
                                table.DR["Out_Date"] = table2.DT.Rows[0]["Date2"].ToString();
                                table.DR["Out_time"] = table2.DT.Rows[0]["Time2"].ToString();
                                table.DR.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "UPDATE", "SYSTEM", "UPDATE OUT DATE AND OUT TIME" };
                                Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                                table2.Dispose();
                                table.Dispose();
                            }
                        }
                        FormGatepassEntry entry = new FormGatepassEntry {
                            pMode = "SUBMIT",
                            Text = "SUBMIT GATEPASS"
                        };
                        this.tblVwGatepass.BeforeEdit(this.dataGridView1, "EDIT");
                        entry.sUniq = this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString();
                        entry.ShowDialog();
                        if (entry.saved)
                        {
                            this.tblVwGatepass.ReOpen();
                            this.dataGridView1 = this.tblVwGatepass.AfterEdit(entry.pMode);
                            this.dataGridView1.Refresh();
                            string[] aField = new string[] { "Gatepass_Number" };
                            string[] aFind = new string[] { entry.textGatepass_Number.Text };
                            this.tblVwGatepass.SetCursor(this.dataGridView1, this.tblVwGatepass.GetCurrentRow(this.dataGridView1, aField, aFind));
                            this.ShowStatus();
                        }
                        entry.Dispose();
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_158, Resource.Title_002);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_157, Resource.Title_002);
                }
            }
        }

        private void textDriver_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void textLoadComment_Leave(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string str = this.dataGridView1.CurrentRow.Cells["Gatepass_number"].Value.ToString();
                if ((str != "") && (this.textLoadComment.Text != this.loadComment))
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.tblGatepass.OpenTable("Wb_gatepass", "select * from wb_gatepass where " + WBData.CompanyLocation(" and Gatepass_number = '" + str + "'"), WBData.conn);
                    if (this.tblGatepass.DT.Rows.Count > 0)
                    {
                        this.tblVwGatepass.BeforeEdit(this.dataGridView1, "EDIT");
                        this.tblGatepass.DR = this.tblGatepass.DT.Rows[0];
                        this.logKey = this.tblGatepass.DR["uniq"].ToString();
                        this.tblGatepass.DR.BeginEdit();
                        this.tblGatepass.DR["Load_COmment"] = this.textLoadComment.Text.Trim();
                        this.tblGatepass.DR.EndEdit();
                        this.tblGatepass.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Change Load/Unload Comment" };
                        Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                        this.tblVwGatepass.ReOpen();
                        this.dataGridView1 = this.tblVwGatepass.AfterEdit("EDIT");
                        this.dataGridView1.Refresh();
                        string[] aField = new string[] { "gatepass_number" };
                        string[] aFind = new string[] { str };
                        this.tblVwGatepass.SetCursor(this.dataGridView1, this.tblVwGatepass.GetCurrentRow(this.dataGridView1, aField, aFind));
                        this.ShowStatus();
                    }
                    this.tblGatepass.Close();
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.submitToolStripMenuItem.Text = Resource.Gatepass_005;
            this.activitiesToolStripMenuItem.Text = Resource.Gatepass_015;
            this.submitToolStripMenuItem.Text = Resource.Gatepass_016;
            this.printGatepassToolStripMenuItem.Text = Resource.Gatepass_017;
            this.backToolStripMenuItem.Text = Resource.Gatepass_018;
            this.buttonFind.Text = Resource.Gatepass_019;
            this.buttonFilter.Text = Resource.Gatepass_020;
            this.label4.Text = Resource.Gatepass_021;
            this.label3.Text = Resource.Gatepass_022;
            this.label9.Text = Resource.Gatepass_023;
            this.label7.Text = Resource.Gatepass_024;
            this.label6.Text = Resource.Gatepass_025;
            this.label5.Text = Resource.Gatepass_026;
            this.checkSubmitted.Text = Resource.Gatepass_027;
            this.checkDeleted.Text = Resource.Gatepass_028;
            this.checkPartial.Text = Resource.Gatepass_029;
            this.labelLoadComment.Text = Resource.Gatepass_030;
            this.labelGatepass.Text = Resource.Main_012;
            this.Text = Resource.Main_012;
            this.editToolStripMenuItem.Text = Resource.Menu_Edit;
            this.viewToolStripMenuItem.Text = Resource.Menu_View;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.backToolStripMenuItem.Text = Resource.Menu_Back;
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                FormGatepassEntry entry = new FormGatepassEntry {
                    pMode = "VIEW",
                    Text = "VIEW GATEPASS",
                    sUniq = this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString()
                };
                entry.ShowDialog();
                entry.Dispose();
            }
        }
    }
}

