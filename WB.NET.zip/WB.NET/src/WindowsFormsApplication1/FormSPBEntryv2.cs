﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormSPBEntryv2 : Form
    {
        public WBTable zTable;
        public WBTable tblRelation;
        public string pMode;
        public string OldCode;
        public string pDo_No;
        public string changeReason = "";
        public string logKey = "";
        public string oldDNFrom;
        public string oldDNTo;
        public string oldDNCode;
        public string delRelCode;
        public string delDNFrom;
        public string delDNTo;
        public int nCurrRow;
        public int sUniq;
        public int dataGridPosRow;
        public bool saved = false;
        public DataGridView dataGridView1;
        private string DNto;
        private string DNfrom;
        private string changes = "";
        private string sb = "";
        private IContainer components = null;
        private TextBox txtBoxRelation;
        private Button btnCancel;
        private Button btnSave;
        private TextBox txtBoxDNCode;
        private Button btnRelation;
        private Label lblDNCode;
        private Label lblRelation;
        private Label lblDNFrom;
        private Label lblDNTo;
        private MaskedTextBox maskedtxtBoxDNFrom;
        private MaskedTextBox maskedtxtBoxDNTo;
        private Label relationName;

        public FormSPBEntryv2()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                base.Close();
            }
        }

        private void btnRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.txtBoxRelation.Text.Trim()
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.txtBoxRelation.Text = vendor.ReturnRow["relation_code"].ToString();
                this.relationName.Text = vendor.ReturnRow["relation_name"].ToString();
            }
            vendor.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            WBTable table2;
            if (!((string.IsNullOrEmpty(this.txtBoxRelation.Text) || (string.IsNullOrEmpty(this.txtBoxDNCode.Text) || string.IsNullOrEmpty(this.maskedtxtBoxDNFrom.Text))) || string.IsNullOrEmpty(this.maskedtxtBoxDNTo.Text)))
            {
                if ((this.txtBoxRelation.Text.Trim() == "") || this.ChkVend(1))
                {
                    if (this.txtBoxDNCode.Text.Length == 2)
                    {
                        if (Convert.ToInt32(this.maskedtxtBoxDNFrom.Text) <= Convert.ToInt32(this.maskedtxtBoxDNTo.Text))
                        {
                            if (((this.maskedtxtBoxDNFrom.Text.Length == 8) && ((this.maskedtxtBoxDNTo.Text.Length == 8) && Program.CheckNumeric(this.maskedtxtBoxDNFrom.Text))) && Program.CheckNumeric(this.maskedtxtBoxDNFrom.Text))
                            {
                                if ((Convert.ToInt32(this.maskedtxtBoxDNTo.Text) - Convert.ToInt32(this.maskedtxtBoxDNFrom.Text)) <= 0x33)
                                {
                                    this.DNfrom = this.txtBoxDNCode.Text + this.maskedtxtBoxDNFrom.Text;
                                    this.DNto = this.txtBoxDNCode.Text + this.maskedtxtBoxDNTo.Text;
                                    if ((this.pMode != "EDIT") || (this.oldDNCode == this.txtBoxDNCode.Text))
                                    {
                                        goto TR_0049;
                                    }
                                    else
                                    {
                                        string str = WBUtility.MergeDNNumber(this.oldDNCode + this.oldDNFrom, this.oldDNCode + this.oldDNTo);
                                        table2 = new WBTable();
                                        table2.OpenTable("checkTrx", "select ref,delivery_note from wb_transaction with (nolock) where delivery_note in (" + str + ")", WBData.conn);
                                        if (table2.DT.Rows.Count != 0)
                                        {
                                            if (table2.DT.Rows.Count <= 0)
                                            {
                                                goto TR_004A;
                                            }
                                            else
                                            {
                                                DataRow row2 = table2.DT.Rows[0];
                                                string[] textArray2 = new string[] { "Can't Edit Delivery Note Code. Delivery Note Already Used at Ref ", row2["ref"].ToString(), " with Delivery Note ", row2["delivery_note"].ToString(), "." };
                                                MessageBox.Show(string.Concat(textArray2), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            }
                                        }
                                        else if (!WBSetting.activeTCS)
                                        {
                                            goto TR_004A;
                                        }
                                        else
                                        {
                                            WBTable table3 = new WBTable();
                                            table3.OpenTable("checkGP", "select gatepass_number from wb_gatepass with (nolock) where delivery_note in (" + str + ")", WBData.conn);
                                            if (table3.DT.Rows.Count <= 0)
                                            {
                                                goto TR_004A;
                                            }
                                            else
                                            {
                                                DataRow row = table3.DT.Rows[0];
                                                string[] textArray1 = new string[] { "Can't Edit Delivery Note Code. Delivery Note Already Used at Gatepass ", row["gatepass_number"].ToString(), " with Delivery Note ", row["delivery_note"].ToString(), "." };
                                                MessageBox.Show(string.Concat(textArray1), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(Resource.MD_Delivery_Note_005, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.MD_Delivery_Note_004, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.MD_Delivery_Note_003, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.MD_Delivery_Note_002, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                else
                {
                    this.txtBoxRelation.Focus();
                }
            }
            else
            {
                MessageBox.Show(Resource.MD_Delivery_Note_001, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            return;
        TR_0049:
            if (this.pMode != "ADD")
            {
                if (this.pMode == "EDIT")
                {
                    WBTable table5 = new WBTable();
                    table5.OpenTable("getDNData", "SELECT Delivery_Note_From,Delivery_Note_To,Relation_code FROM wb_delivery_note with (nolock) \r\n                            where relation_code is not null and (Deleted is null or Deleted <> 'Y' or Deleted = 'N') and uniq <>'" + this.sUniq.ToString() + "'", WBData.conn);
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 < table5.DT.Rows.Count)
                        {
                            DataRow row4 = table5.DT.Rows[num3];
                            if ((((string.Compare(this.DNfrom, row4["Delivery_Note_From"].ToString()) <= 0) && (string.Compare(this.DNto, row4["Delivery_Note_From"].ToString()) >= 0)) || ((string.Compare(this.DNfrom, row4["Delivery_Note_to"].ToString()) <= 0) && (string.Compare(this.DNto, row4["Delivery_Note_to"].ToString()) >= 0))) || (((string.Compare(row4["Delivery_Note_From"].ToString(), this.DNfrom) <= 0) && (string.Compare(this.DNfrom, row4["Delivery_Note_to"].ToString()) <= 0)) && ((string.Compare(row4["Delivery_Note_From"].ToString(), this.DNto) <= 0) && (string.Compare(this.DNto, row4["Delivery_Note_to"].ToString()) <= 0))))
                            {
                                string[] textArray5 = new string[9];
                                textArray5[0] = this.sb;
                                textArray5[1] = "Relation Code ";
                                textArray5[2] = row4["Relation_code"].ToString();
                                textArray5[3] = " - ";
                                textArray5[4] = row4["Delivery_Note_From"].ToString();
                                textArray5[5] = " - ";
                                textArray5[6] = row4["Delivery_Note_to"].ToString();
                                textArray5[7] = ".";
                                textArray5[8] = Environment.NewLine;
                                this.sb = string.Concat(textArray5);
                            }
                            num3++;
                            continue;
                        }
                        if (string.IsNullOrEmpty(this.sb))
                        {
                            table5.Dispose();
                        }
                        else
                        {
                            string[] textArray6 = new string[] { "Range already exist in other data.", Environment.NewLine, "Please Input Another Range.", Environment.NewLine, this.sb };
                            MessageBox.Show(string.Concat(textArray6), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.sb = "";
                            return;
                        }
                        break;
                    }
                }
            }
            else
            {
                WBTable table4 = new WBTable();
                table4.OpenTable("getDNData", "SELECT Delivery_Note_From,Delivery_Note_To,Relation_code FROM wb_delivery_note with (nolock) \r\n                            where relation_code is not null and (Deleted is null or Deleted <> 'Y' or Deleted = 'N')", WBData.conn);
                int num2 = 0;
                while (true)
                {
                    if (num2 < table4.DT.Rows.Count)
                    {
                        DataRow row3 = table4.DT.Rows[num2];
                        if ((((string.Compare(this.DNfrom, row3["Delivery_Note_From"].ToString()) <= 0) && (string.Compare(this.DNto, row3["Delivery_Note_From"].ToString()) >= 0)) || ((string.Compare(this.DNfrom, row3["Delivery_Note_to"].ToString()) <= 0) && (string.Compare(this.DNto, row3["Delivery_Note_to"].ToString()) >= 0))) || (((string.Compare(row3["Delivery_Note_From"].ToString(), this.DNfrom) <= 0) && (string.Compare(this.DNfrom, row3["Delivery_Note_to"].ToString()) <= 0)) && ((string.Compare(row3["Delivery_Note_From"].ToString(), this.DNto) <= 0) && (string.Compare(this.DNto, row3["Delivery_Note_to"].ToString()) <= 0))))
                        {
                            string[] textArray3 = new string[9];
                            textArray3[0] = this.sb;
                            textArray3[1] = "Relation ";
                            textArray3[2] = row3["Relation_code"].ToString();
                            textArray3[3] = ". ";
                            textArray3[4] = row3["Delivery_Note_From"].ToString();
                            textArray3[5] = " - ";
                            textArray3[6] = row3["Delivery_Note_to"].ToString();
                            textArray3[7] = ".";
                            textArray3[8] = Environment.NewLine;
                            this.sb = string.Concat(textArray3);
                        }
                        num2++;
                        continue;
                    }
                    if (string.IsNullOrEmpty(this.sb))
                    {
                        table4.Dispose();
                    }
                    else
                    {
                        string[] textArray4 = new string[] { "Range already exist in other data.", Environment.NewLine, "Please Input Another Range.", Environment.NewLine, this.sb };
                        MessageBox.Show(string.Concat(textArray4), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.sb = "";
                        return;
                    }
                    break;
                }
            }
            if (this.pMode == "EDIT")
            {
                string str3;
                string str4;
                string str2 = WBUtility.MergeDNNumber(this.oldDNCode + this.oldDNFrom, this.oldDNCode + this.oldDNTo);
                WBTable table6 = new WBTable();
                table6.OpenTable("checkTrx", "select delivery_note,ref from wb_transaction with (nolock) where delivery_note in (" + str2 + ")", WBData.conn);
                table6.DT = new DataView(table6.DT) { Sort = "delivery_note" }.ToTable();
                if (table6.DT.Rows.Count != 0)
                {
                    if (table6.DT.Rows.Count > 0)
                    {
                        str3 = table6.DT.Rows[0]["delivery_note"].ToString();
                        str4 = table6.DT.Rows[table6.DT.Rows.Count - 1]["delivery_note"].ToString();
                        if ((string.Compare(this.DNfrom, str3) > 0) || (string.Compare(this.DNto, str3) < 0))
                        {
                            string[] textArray9 = new string[] { this.sb, "No Ref ", table6.DT.Rows[0]["ref"].ToString(), " - Delivery Note ", str3, ".", Environment.NewLine };
                            this.sb = string.Concat(textArray9);
                        }
                        if ((str3 != str4) && ((string.Compare(this.DNfrom, str4) > 0) || (string.Compare(this.DNto, str4) < 0)))
                        {
                            string[] textArray10 = new string[] { this.sb, "No Ref ", table6.DT.Rows[table6.DT.Rows.Count - 1]["ref"].ToString(), " - Delivery Note ", str4, ".", Environment.NewLine };
                            this.sb = string.Concat(textArray10);
                        }
                    }
                }
                else if (WBSetting.activeTCS)
                {
                    WBTable table7 = new WBTable();
                    table7.OpenTable("checkGP", "select delivery_note, gatepass_number \r\n                                    from wb_gatepass as gp with (nolock) \r\n                                    where gp.delivery_note in (" + str2 + ")", WBData.conn);
                    table6.DT = new DataView(table7.DT) { Sort = "delivery_note" }.ToTable();
                    if (table7.DT.Rows.Count > 0)
                    {
                        str3 = table7.DT.Rows[0]["delivery_note"].ToString();
                        str4 = table7.DT.Rows[table7.DT.Rows.Count - 1]["delivery_note"].ToString();
                        if ((string.Compare(this.DNfrom, str3) > 0) || (string.Compare(this.DNto, str3) < 0))
                        {
                            string[] textArray7 = new string[] { this.sb, "No Ref ", table7.DT.Rows[0]["ref"].ToString(), " - Delivery Note ", str3, ".", Environment.NewLine };
                            this.sb = string.Concat(textArray7);
                        }
                        if ((str3 != str4) && ((string.Compare(this.DNfrom, str4) > 0) || (string.Compare(this.DNto, str4) < 0)))
                        {
                            string[] textArray8 = new string[] { this.sb, "No Ref ", table7.DT.Rows[table7.DT.Rows.Count - 1]["ref"].ToString(), " - Delivery Note ", str4, ".", Environment.NewLine };
                            this.sb = string.Concat(textArray8);
                        }
                    }
                    table7.Dispose();
                }
                if (string.IsNullOrEmpty(this.sb))
                {
                    table6.Dispose();
                }
                else
                {
                    string[] textArray11 = new string[] { "Can't Edit because Delivery Note Range already used.", Environment.NewLine, "Used Delivery Note must be in Edit Range.", Environment.NewLine, this.sb };
                    MessageBox.Show(string.Concat(textArray11), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.sb = "";
                    return;
                }
            }
            if (this.pMode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Delivery Note for Relation Code" },
                    textRefNo = { Text = this.txtBoxRelation.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            WBTable table = new WBTable();
            table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note Where ( uniq='" + this.sUniq.ToString() + "')", WBData.conn);
            if (this.pMode == "ADD")
            {
                table.DR = table.DT.NewRow();
            }
            else
            {
                table.DR = table.DT.Rows[0];
                this.logKey = table.DR["uniq"].ToString();
                table.DR.BeginEdit();
            }
            table.DR["relation_code"] = this.txtBoxRelation.Text;
            table.DR["Delivery_Note_From"] = this.DNfrom;
            table.DR["Delivery_Note_To"] = this.DNto;
            if (this.pMode == "ADD")
            {
                table.DR["Create_By"] = WBUser.UserID;
                table.DR["Create_Date"] = WBUtility.GetServerDatetime();
                table.DR["expired_date"] = Convert.ToDateTime(WBUtility.GetServerDatetime().ToShortDateString()).AddDays((double) (WBSetting.DeliveryNoteExpiredDuration * 30));
                table.DT.Rows.Add(table.DR);
            }
            else
            {
                table.DR["Change_By"] = WBUser.UserID;
                table.DR["Change_Date"] = WBUtility.GetServerDatetime();
                table.DR["reason"] = this.changeReason;
                table.DR.EndEdit();
            }
            table.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    string sqltext = (("SELECT uniq FROM wb_delivery_note" + " WHERE relation_code = '" + this.txtBoxRelation.Text + "'") + " AND delivery_note_from = '" + this.DNfrom + "'") + " AND delivery_note_to = '" + this.DNto + "'";
                    WBTable table8 = new WBTable();
                    table8.OpenTable("wb_delivery_note", sqltext, WBData.conn);
                    this.logKey = table8.DT.Rows[0]["uniq"].ToString();
                    table8.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_delivery_note", this.logKey, logField, logValue);
            }
            table.Dispose();
            Cursor.Current = Cursors.Default;
            this.saved = true;
            if (this.saved && (this.pMode != "ADD"))
            {
                this.GenerateEmail(this.pMode);
            }
            base.Close();
            return;
        TR_004A:
            table2.Dispose();
            goto TR_0049;
        }

        private bool checkChanges()
        {
            bool flag = false;
            if (this.oldDNCode != this.txtBoxDNCode.Text.Trim())
            {
                string[] textArray1 = new string[] { this.changes, "<tr class='bd'><td nowrap>Delivery Note Code</td><td nowrap>", this.oldDNCode, "</td><td nowrap>", this.txtBoxDNCode.Text.Trim(), "</td></tr>" };
                this.changes = string.Concat(textArray1);
                flag = true;
            }
            if (this.oldDNFrom != this.maskedtxtBoxDNFrom.Text.Trim())
            {
                string[] textArray2 = new string[] { this.changes, "<tr class='bd'><td nowrap>Delivery Note From</td><td nowrap>", this.oldDNFrom, "</td><td nowrap>", this.maskedtxtBoxDNFrom.Text.Trim(), "</td></tr>" };
                this.changes = string.Concat(textArray2);
                flag = true;
            }
            if (this.oldDNTo != this.maskedtxtBoxDNTo.Text.Trim())
            {
                string[] textArray3 = new string[] { this.changes, "<tr class='bd'><td nowrap>Delivery Note To</td><td nowrap>", this.oldDNTo, "</td><td nowrap>", this.maskedtxtBoxDNTo.Text.Trim(), "</td></tr>" };
                this.changes = string.Concat(textArray3);
                flag = true;
            }
            return flag;
        }

        private bool ChkVend(int err)
        {
            bool flag3;
            string[] aField = new string[] { "Relation_Code" };
            string[] aFind = new string[] { this.txtBoxRelation.Text.Trim() };
            this.tblRelation.DR = this.tblRelation.GetData(aField, aFind);
            if (ReferenceEquals(this.tblRelation.DR, null))
            {
                if ((err == 1) || (err == 2))
                {
                    MessageBox.Show(Resource.Mes_108, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                this.relationName.Text = "";
                flag3 = false;
            }
            else if (err == 2)
            {
                flag3 = true;
            }
            else
            {
                this.relationName.Text = this.tblRelation.DR["Relation_Name"].ToString();
                flag3 = true;
            }
            return flag3;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSPBEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSPBEntry_Load(object sender, EventArgs e)
        {
            this.relationName.Text = "";
            this.tblRelation = new WBTable();
            this.tblRelation.OpenTable("wb_relation", "Select * from wb_relation with (nolock) where " + WBData.CompanyLocation(" AND (black_list != 'Y' OR black_list IS NULL) AND (deleted != 'Y' OR deleted IS NULL)"), WBData.conn);
            Program.AutoComp(this.tblRelation, "Relation_code", this.txtBoxRelation);
            if (this.pMode != "ADD")
            {
                this.txtBoxRelation.Enabled = false;
                this.txtBoxRelation.Text = this.dataGridView1.Rows[this.dataGridPosRow].Cells["relation_code"].Value.ToString();
                this.ChkVend(0);
                this.txtBoxDNCode.Text = this.dataGridView1.Rows[this.dataGridPosRow].Cells["Delivery_Note_From"].Value.ToString().Substring(0, 2);
                this.maskedtxtBoxDNFrom.Text = this.dataGridView1.Rows[this.dataGridPosRow].Cells["Delivery_Note_From"].Value.ToString().Substring(2, 8);
                this.maskedtxtBoxDNTo.Text = this.dataGridView1.Rows[this.dataGridPosRow].Cells["Delivery_Note_To"].Value.ToString().Substring(2, 8);
                this.oldDNFrom = this.maskedtxtBoxDNFrom.Text;
                this.oldDNTo = this.maskedtxtBoxDNTo.Text;
                this.oldDNCode = this.txtBoxDNCode.Text;
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.btnCancel.Enabled = true;
            }
            this.tblRelation.Dispose();
        }

        public void GenerateEmail(string pMode)
        {
            string str = "";
            string text = "";
            string delDNFrom = "";
            string delDNTo = "";
            if (pMode == "EDIT")
            {
                string[] textArray1 = new string[] { "<br><br>This email is to notify you that ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " has Edited Delivery Note" };
                str = string.Concat(textArray1);
                text = this.txtBoxRelation.Text;
                delDNFrom = this.maskedtxtBoxDNFrom.Text;
                delDNTo = this.maskedtxtBoxDNTo.Text;
                this.checkChanges();
            }
            else if (pMode == "DELETE")
            {
                string[] textArray2 = new string[] { "<br><br>This email is to notify you that ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " has Mark Deleted Delivery Note" };
                str = string.Concat(textArray2);
                text = this.delRelCode;
                delDNFrom = this.delDNFrom;
                delDNTo = this.delDNTo;
            }
            else if (pMode == "UNDELETE")
            {
                string[] textArray3 = new string[] { "<br><br>This email is to notify you that ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " has Unmark Deleted Delivery Note" };
                str = string.Concat(textArray3);
                text = this.delRelCode;
                delDNFrom = this.delDNFrom;
                delDNTo = this.delDNTo;
            }
            string[] textArray4 = new string[13];
            textArray4[0] = "Dear All,";
            textArray4[1] = str;
            textArray4[2] = "<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : ";
            textArray4[3] = WBData.sCoyName;
            textArray4[4] = "</td></tr><tr class='bd'><td nowrap>Location</td><td nowrap> : ";
            textArray4[5] = WBSetting.Field("Location_name");
            textArray4[6] = "</td></tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ";
            textArray4[7] = WBUtility.GetServerDatetime().ToShortDateString();
            textArray4[8] = " ";
            textArray4[9] = WBUtility.GetServerDatetime().ToString("HH:mm:ss");
            textArray4[10] = "</td></tr><tr class='bd'><td nowrap>Relation Code</td><td nowrap> : ";
            textArray4[11] = text;
            textArray4[12] = "</td></tr>";
            string str5 = string.Concat(textArray4);
            if ((pMode == "DELETE") || (pMode == "UNDELETE"))
            {
                string[] textArray5 = new string[] { str5, "<tr class='bd'><td nowrap>Delivery Number</td><td nowrap> : ", delDNFrom, " - ", delDNTo, "</td></tr>" };
                str5 = string.Concat(textArray5) + "<tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode + "</td></tr></table>";
            }
            else if (pMode == "EDIT")
            {
                string[] textArray6 = new string[] { str5, "<tr class='bd'><td nowrap>Change Reason</td><td nowrap> : ", this.changeReason, "</td></tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : ", WBData.sWBCode, "</td></tr></table><br><table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>", this.changes, "</table><br>" };
                str5 = string.Concat(textArray6);
            }
            WBMail mail = new WBMail();
            mail.Load_SendMail_SPB(str5 + "<br>Thank you.", pMode);
            mail.Dispose();
            WBTable table = new WBTable();
            table.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'EDIT_SPB' and email_date = '" + WBUtility.GetServerDatetime().ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["COY"] = WBData.sCoyCode;
                table.DR["LOCATION_CODE"] = WBData.sLocCode;
                table.DR["Email_code"] = "EDIT_SPB";
                table.DR["Email_date"] = WBUtility.GetServerDatetime().ToString("dd/MM/yyyy");
                table.DR["Status"] = "N";
                table.DT.Rows.Add(table.DR);
                table.Save();
            }
            else if (table.DT.Rows[0]["Status"].ToString() == "Y")
            {
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Status"] = "N";
                table.DR.EndEdit();
                table.Save();
            }
            table.Dispose();
        }

        private void InitializeComponent()
        {
            this.txtBoxRelation = new TextBox();
            this.btnCancel = new Button();
            this.btnSave = new Button();
            this.txtBoxDNCode = new TextBox();
            this.btnRelation = new Button();
            this.lblDNCode = new Label();
            this.lblRelation = new Label();
            this.lblDNFrom = new Label();
            this.lblDNTo = new Label();
            this.maskedtxtBoxDNFrom = new MaskedTextBox();
            this.maskedtxtBoxDNTo = new MaskedTextBox();
            this.relationName = new Label();
            base.SuspendLayout();
            this.txtBoxRelation.Location = new Point(0x87, 0x15);
            this.txtBoxRelation.Name = "txtBoxRelation";
            this.txtBoxRelation.Size = new Size(0x83, 20);
            this.txtBoxRelation.TabIndex = 1;
            this.txtBoxRelation.KeyPress += new KeyPressEventHandler(this.txtBoxRelation_KeyPress);
            this.txtBoxRelation.Leave += new EventHandler(this.txtBoxRelation_Leave);
            this.btnCancel.Location = new Point(230, 0x8d);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x4b, 0x17);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.btnSave.Location = new Point(0x13f, 0x8d);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(0x4b, 0x17);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);
            this.txtBoxDNCode.CharacterCasing = CharacterCasing.Upper;
            this.txtBoxDNCode.Location = new Point(0x87, 0x2f);
            this.txtBoxDNCode.MaxLength = 2;
            this.txtBoxDNCode.Name = "txtBoxDNCode";
            this.txtBoxDNCode.Size = new Size(60, 20);
            this.txtBoxDNCode.TabIndex = 2;
            this.txtBoxDNCode.KeyPress += new KeyPressEventHandler(this.txtBoxDNCode_KeyPress);
            this.txtBoxDNCode.Leave += new EventHandler(this.txtBoxDNCode_Leave);
            this.btnRelation.Location = new Point(0x111, 0x13);
            this.btnRelation.Name = "btnRelation";
            this.btnRelation.Size = new Size(0x20, 0x17);
            this.btnRelation.TabIndex = 7;
            this.btnRelation.Text = "...";
            this.btnRelation.UseVisualStyleBackColor = true;
            this.btnRelation.Click += new EventHandler(this.btnRelation_Click);
            this.lblDNCode.AutoSize = true;
            this.lblDNCode.Location = new Point(0x12, 50);
            this.lblDNCode.Name = "lblDNCode";
            this.lblDNCode.Size = new Size(0x63, 13);
            this.lblDNCode.TabIndex = 14;
            this.lblDNCode.Text = "Delivery Note Code";
            this.lblRelation.AutoSize = true;
            this.lblRelation.Location = new Point(0x12, 0x18);
            this.lblRelation.Name = "lblRelation";
            this.lblRelation.Size = new Size(0x4a, 13);
            this.lblRelation.TabIndex = 15;
            this.lblRelation.Text = "Relation Code";
            this.lblDNFrom.AutoSize = true;
            this.lblDNFrom.Location = new Point(0x12, 0x4f);
            this.lblDNFrom.Name = "lblDNFrom";
            this.lblDNFrom.Size = new Size(30, 13);
            this.lblDNFrom.TabIndex = 0x10;
            this.lblDNFrom.Text = "From";
            this.lblDNTo.AutoSize = true;
            this.lblDNTo.Location = new Point(0x12, 0x69);
            this.lblDNTo.Name = "lblDNTo";
            this.lblDNTo.Size = new Size(20, 13);
            this.lblDNTo.TabIndex = 0x11;
            this.lblDNTo.Text = "To";
            this.maskedtxtBoxDNFrom.Location = new Point(0x87, 0x4c);
            this.maskedtxtBoxDNFrom.Mask = "00000000";
            this.maskedtxtBoxDNFrom.Name = "maskedtxtBoxDNFrom";
            this.maskedtxtBoxDNFrom.Size = new Size(60, 20);
            this.maskedtxtBoxDNFrom.TabIndex = 3;
            this.maskedtxtBoxDNTo.Location = new Point(0x87, 0x66);
            this.maskedtxtBoxDNTo.Mask = "00000000";
            this.maskedtxtBoxDNTo.Name = "maskedtxtBoxDNTo";
            this.maskedtxtBoxDNTo.Size = new Size(60, 20);
            this.maskedtxtBoxDNTo.TabIndex = 4;
            this.relationName.AutoSize = true;
            this.relationName.Location = new Point(0x137, 0x18);
            this.relationName.Name = "relationName";
            this.relationName.Size = new Size(0x4a, 13);
            this.relationName.TabIndex = 0x25;
            this.relationName.Text = "RelationName";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x196, 0xb0);
            base.ControlBox = false;
            base.Controls.Add(this.relationName);
            base.Controls.Add(this.maskedtxtBoxDNTo);
            base.Controls.Add(this.maskedtxtBoxDNFrom);
            base.Controls.Add(this.lblDNTo);
            base.Controls.Add(this.lblDNFrom);
            base.Controls.Add(this.lblRelation);
            base.Controls.Add(this.lblDNCode);
            base.Controls.Add(this.btnRelation);
            base.Controls.Add(this.txtBoxDNCode);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnSave);
            base.Controls.Add(this.txtBoxRelation);
            base.Name = "FormSPBEntryv2";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Delivery Note Entry";
            base.Load += new EventHandler(this.FormSPBEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSPBEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.lblRelation.Text = Resource.Lbl_Vendor_Customer;
            this.lblDNCode.Text = Resource.MD_Delivery_Note_006;
            this.lblDNFrom.Text = Resource.Setting_046;
            this.lblDNTo.Text = Resource.Setting_053;
            this.Text = Resource.Title_Form_SPB_Entry;
        }

        private void txtBoxDNCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.CheckInput(e, "A");
        }

        private void txtBoxDNCode_Leave(object sender, EventArgs e)
        {
            if (WBUtility.CheckLeave(this.txtBoxDNCode.Text, "A"))
            {
                MessageBox.Show(Resource.Filter_005, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtBoxDNCode.Focus();
            }
        }

        private void txtBoxRelation_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txtBoxRelation_Leave(object sender, EventArgs e)
        {
            if ((this.txtBoxRelation.Text.Trim() != "") && !this.ChkVend(1))
            {
                this.txtBoxRelation.Focus();
            }
            else if (this.txtBoxRelation.Text.Trim() == "")
            {
                this.relationName.Text = "";
            }
        }
    }
}

