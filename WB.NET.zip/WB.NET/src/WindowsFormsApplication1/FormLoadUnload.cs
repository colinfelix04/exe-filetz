﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormLoadUnload : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        public TextBox TextFind;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem chooseToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        private ProgressBar progressBar1;
        public Panel panel1;
        public Button buttonFind;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;

        public FormLoadUnload()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLoadUnloadEntry entry = new FormLoadUnloadEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "ADD");
            entry.pMode = "ADD";
            entry.zTable = this.ztable;
            entry.Text = "Add New Load Unload";
            entry.dataGridView1 = this.dataGridView1;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ztable.ReOpen();
                this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                string[] aField = new string[] { "Load_Unload" };
                string[] aFind = new string[] { entry.textLoadUnloadCode.Text };
                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
            }
            this.ztable.UnLock();
            entry.Dispose();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.BeforeEdit(this.dataGridView1, "DELETE");
            this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.CompanyLocation(" and ( Load_Unload ='" + this.ztable.DT.Rows[this.nCurrRow]["Load_Unload"].ToString() + "')"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                string[] textArray2 = new string[] { this.ztable.DT.Rows[this.nCurrRow]["Load_Unload"].ToString(), " - ", this.ztable.DT.Rows[this.nCurrRow]["Load_Desc"].ToString(), ".\n\n ", Resource.Mes_006 };
                if (MessageBox.Show(string.Concat(textArray2), Resource.Title_002, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = "Load Unload" },
                        textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Load_Unload"].ToString() },
                        Text = "DELETE REASON",
                        label2 = { Text = "Delete Reason : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.ReOpen();
                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_load_Unload", this.logKey, logField, logValue);
                        this.ztable.ReOpen();
                        this.ztable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
            }
            else
            {
                string[] textArray1 = new string[] { Resource.Mes_047A, "(", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            this.ztable.UnLock();
            table.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                FormLoadUnloadEntry entry = new FormLoadUnloadEntry();
                this.ztable.BeforeEdit(this.dataGridView1, "EDIT");
                entry.pMode = "EDIT";
                entry.zTable = this.ztable;
                entry.Text = "Edit Record of Load Unload";
                entry.dataGridView1 = this.dataGridView1;
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormLoadUnload_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormLoadUnload_Load(object sender, EventArgs e)
        {
            this.translate();
            if (this.pFilter != "")
            {
                this.ztable.OpenTable("wb_LoadUnload", "SELECT * FROM wb_Load_Unload Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_LoadUnload", "SELECT *FROM wb_Load_Unload", WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Load_Unload"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["Load_Unload"].HeaderText = Resource.Load_001;
            this.dataGridView1.Columns["Load_Desc"].HeaderText = Resource.Load_002;
            this.dataGridView1.Columns["Storage_Loc"].HeaderText = Resource.Load_003;
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("MD_LoadUnload", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_LoadUnload", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_LoadUnload", "D"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
            }
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            this.chooseToolStripMenuItem.Visible = this.pMode == "CHOOSE";
        }

        private void InitializeComponent()
        {
            this.TextFind = new TextBox();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.progressBar1 = new ProgressBar();
            this.panel1 = new Panel();
            this.buttonFind = new Button();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(160, 6);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.progressBar1.Location = new Point(0x290, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 10;
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 380);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x337, 0x21);
            this.panel1.TabIndex = 14;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x337, 0x185);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick_1);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x337, 0x18);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.toolStripSeparator1 };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x337, 0x19d);
            base.ControlBox = false;
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormLoadUnload";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Load Unload";
            base.Load += new EventHandler(this.FormLoadUnload_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Main_026;
        }
    }
}

