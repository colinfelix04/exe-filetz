﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormVendorEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private bool adopt = false;
        private string code = "";
        private string name = "";
        private string address = "";
        private string contact = "";
        private string phone = "";
        private string fax = "";
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        public TextBox textBoxRelationCode;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private CheckBox checkBox1;
        private Button button1;
        private Button button2;
        private CheckBox checkISCC;
        private CheckBox checkDaily;
        private TextBox textQuantity;
        private Label labelKG;
        private Label label10;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape1;
        private Button button3;
        private GroupBox groupType;
        private RadioButton radioCust;
        private RadioButton radioVend;

        public FormVendorEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        public void adoptData()
        {
            try
            {
                this.adopt = false;
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_VENDOR");
                    WBSAP.rfcFunction.SetValue("P_LIFNR", this.textBox8.Text);
                    if (WBSetting.region == "1")
                    {
                        if (this.radioCust.Checked)
                        {
                            WBSAP.rfcFunction.SetValue("P_TYPE", "C");
                        }
                        else if (this.radioVend.Checked)
                        {
                            WBSAP.rfcFunction.SetValue("P_TYPE", "V");
                        }
                    }
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("WA_RECORD");
                    if (structure.GetString("NOT_EXIST") == "X")
                    {
                        MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                    }
                    else
                    {
                        string str = structure.GetString("NAME1");
                        string str2 = structure.GetString("STREET");
                        string str3 = structure.GetString("CITY1");
                        string str6 = structure.GetString("TELF1");
                        string str4 = (str6.Trim() == "") ? structure.GetString("TELF2") : str6;
                        string str5 = structure.GetString("TELFX");
                        this.textBox2.Text = str;
                        this.textBox3.Text = str2;
                        this.textBox4.Text = str3;
                        this.textBox5.Text = str4;
                        this.textBox6.Text = str5;
                        this.adopt = true;
                        MessageBox.Show(Resource.Mes_087, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        public void adoptDataIDSYS()
        {
            try
            {
                WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
                string url = integrator.getURL("IDSYS_ADOPT_VENDOR");
                if (url != "")
                {
                    string[] textArray1 = new string[] { "{coy:'", WBSetting.CoySAP, "',code:'", this.textBox8.Text, "',indc:'1' }" };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                    if (!err)
                    {
                        if (dictionary["data"].Count <= 0)
                        {
                            MessageBox.Show(Resource.IDSY_Adopt_Failled, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            foreach (Dictionary<string, string> dictionary2 in dictionary["data"])
                            {
                                this.code = dictionary2["code"];
                                this.name = dictionary2["name"];
                                this.address = dictionary2["address"];
                                this.contact = dictionary2["contact"];
                                this.phone = dictionary2["phone"];
                                this.fax = dictionary2["fax"];
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                this.textBoxRelationCode.Text = this.code;
                this.textBox2.Text = this.name;
                this.textBox3.Text = this.address;
                this.textBox5.Text = this.phone;
                this.textBox6.Text = this.fax;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBoxRelationCode, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                if (!((this.textBoxRelationCode.Text.Length > 50) && WBSetting.integrationIDSYS))
                {
                    if ((this.textBoxRelationCode.Text.Length <= 10) || WBSetting.integrationIDSYS)
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_relation", "Select Uniq From wb_relation Where " + WBData.CompanyLocation(" and ( relation_Code='" + this.textBoxRelationCode.Text.Trim() + "')"), WBData.conn);
                        if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                        {
                            table.Dispose();
                            if ((WBSetting.region != "1") || (((this.pMode != "ADD") && (this.pMode != "EDIT")) || (this.adopt || WBUser.CheckTrustee("MD_CREATEVST", "V"))))
                            {
                                if ((this.pMode != "EDIT") || (this.textBoxRelationCode.Text.Trim() == this.OldCode.Trim()))
                                {
                                    goto TR_0021;
                                }
                                else
                                {
                                    table2 = new WBTable();
                                    table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.Company(" and ( Relation_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString() + "')"), WBData.conn);
                                    WBTable table3 = new WBTable();
                                    table3.OpenTable("wb_contract", "Select uniq From wb_contract where " + WBData.Company(" and (Relation_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString() + "')"), WBData.conn);
                                    if ((table2.DT.Rows.Count <= 0) && (table3.DT.Rows.Count <= 0))
                                    {
                                        goto TR_0022;
                                    }
                                    else
                                    {
                                        string[] textArray1 = new string[0x11];
                                        textArray1[0] = Resource.Mes_481;
                                        textArray1[1] = " ";
                                        textArray1[2] = this.OldCode;
                                        textArray1[3] = " -> ";
                                        textArray1[4] = this.textBoxRelationCode.Text;
                                        textArray1[5] = "\n\n";
                                        textArray1[6] = Resource.Msg_Replace_Warning;
                                        textArray1[7] = "  - ";
                                        textArray1[8] = table2.DT.Rows.Count.ToString();
                                        textArray1[9] = " ";
                                        textArray1[10] = Resource.Mes_Records_In_Transactions;
                                        textArray1[11] = "\n  - ";
                                        textArray1[12] = table3.DT.Rows.Count.ToString();
                                        textArray1[13] = " ";
                                        textArray1[14] = Resource.Mes_Records_In_DO;
                                        textArray1[15] = "\n\n\n";
                                        textArray1[0x10] = Resource.Msg_Continue;
                                        if (MessageBox.Show(string.Concat(textArray1), Resource.Title_002, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                        {
                                            this.ReplaceAll = true;
                                            goto TR_0022;
                                        }
                                        else
                                        {
                                            this.ReplaceAll = false;
                                            this.textBoxRelationCode.Focus();
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_376 + this.sapIDSYS, Resource.Title_002);
                            }
                        }
                        else
                        {
                            table.Dispose();
                            MessageBox.Show(Resource.Mes_044, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textBoxRelationCode.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Relation_Code_Length, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.textBoxRelationCode.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Relation_Code_Length, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textBoxRelationCode.Focus();
                }
            }
            return;
        TR_0021:
            if (this.pMode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.VendorE_001 },
                    textRefNo = { Text = this.textBoxRelationCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Relation_Code"] = this.textBoxRelationCode.Text.ToString().Trim();
            this.zTable.DR["Relation_Name"] = this.textBox2.Text.ToString().Trim();
            this.zTable.DR["Address"] = this.textBox3.Text;
            this.zTable.DR["City"] = this.textBox4.Text;
            this.zTable.DR["Phone"] = this.textBox5.Text;
            this.zTable.DR["Fax"] = this.textBox6.Text;
            this.zTable.DR["Contact_Person"] = this.textBox7.Text;
            this.zTable.DR["SAP_Code"] = this.textBox8.Text;
            this.zTable.DR["Black_List"] = this.checkBox1.Checked ? "Y" : "N";
            this.zTable.DR["DailyQuantity"] = this.checkDaily.Checked ? "Y" : "N";
            this.zTable.DR["Quantity"] = this.textQuantity.Text;
            this.zTable.DR["ISCC"] = this.checkISCC.Checked ? "Y" : "N";
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_relation", "SELECT uniq FROM wb_relation WHERE " + WBData.CompanyLocation(" AND relation_code = '" + this.textBoxRelationCode.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_relation", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                string[] textArray4 = new string[] { "(Triggered add new relation in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray4);
            }
            else if (this.pMode == "EDIT")
            {
                string[] textArray5 = new string[] { "(Triggered edit relation in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray5);
            }
            Program.copyToLoc("wb_relation", this.textBoxRelationCode.Text, 0, this.changeReason + " " + str);
            if ((this.pMode == "EDIT") && (this.textBoxRelationCode.Text != this.OldCode))
            {
                Program.copyToLoc("wb_relation", this.OldCode, 0, this.changeReason + " " + str);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Relation_Code", "Relation_Name" };
                string[] aNewValue = new string[] { this.textBoxRelationCode.Text, this.textBox2.Text };
                Program.ReplaceInCompany("wb_transDO", aField, aNewValue, " Relation_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit relation master data)");
                string[] textArray8 = new string[] { "Relation_Code" };
                string[] textArray9 = new string[] { this.textBoxRelationCode.Text };
                Program.ReplaceInCompany("wb_contract", textArray8, textArray9, " Relation_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit relation master data)");
            }
            this.saved = true;
            base.Close();
            Cursor.Current = Cursors.Default;
            return;
        TR_0022:
            table2.Dispose();
            goto TR_0021;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((this.textBoxRelationCode.Text.Length > 50) && WBSetting.integrationIDSYS)
            {
                MessageBox.Show(Resource.Mes_Error_Relation_Code_Length, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxRelationCode.Focus();
            }
            else if ((this.textBoxRelationCode.Text.Length > 10) && !WBSetting.integrationIDSYS)
            {
                MessageBox.Show(Resource.Mes_Error_Relation_Code_Length, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxRelationCode.Focus();
            }
            else if ((this.textBoxRelationCode.Text.Length > 50) && WBSetting.integrationIDSYS)
            {
                MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                this.textBoxRelationCode.Focus();
            }
            else if ((this.textBoxRelationCode.Text.Length > 10) && !WBSetting.integrationIDSYS)
            {
                MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                this.textBoxRelationCode.Focus();
            }
            else if (this.textBox8.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                if (WBSetting.integrationIDSYS)
                {
                    this.adoptDataIDSYS();
                }
                else
                {
                    this.adoptData();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void checkDaily_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkDaily.Checked)
            {
                this.textQuantity.Visible = true;
                this.labelKG.Visible = true;
            }
            else
            {
                this.textQuantity.Visible = false;
                this.labelKG.Visible = false;
            }
        }

        private void checkISCC_CheckedChanged(object sender, EventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormVendorEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormVendorEntry_Load(object sender, EventArgs e)
        {
            this.button3.Visible = (WBSetting.region == "1") || WBSetting.integrationIDSYS;
            this.checkISCC.Enabled = WBSetting.Field("ISCC_Checked") == "Y";
            this.checkISCC.Checked = false;
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBoxRelationCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Relation_Code"].Value.ToString();
                this.OldCode = this.textBoxRelationCode.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Relation_Name"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Address"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["City"].Value.ToString();
                this.textBox5.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Phone"].Value.ToString();
                this.textBox6.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Fax"].Value.ToString();
                this.textBox7.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Contact_Person"].Value.ToString();
                this.textBox8.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
                this.checkDaily.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["DailyQuantity"].Value.ToString() == "Y";
                this.textQuantity.Text = (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Quantity"].Value.ToString().Trim() == "") ? "0" : $"{Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Quantity"].Value.ToString(), 0):N0}";
                this.checkISCC.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["ISCC"].Value.ToString() == "Y";
                this.checkBox1.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Black_List"].Value.ToString() == "Y";
                this.checkBox1.Enabled = WBUser.CheckTrustee("BLACK_LIST", "E");
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.label5 = new Label();
            this.label6 = new Label();
            this.label7 = new Label();
            this.label8 = new Label();
            this.label9 = new Label();
            this.textBoxRelationCode = new TextBox();
            this.textBox2 = new TextBox();
            this.textBox3 = new TextBox();
            this.textBox4 = new TextBox();
            this.textBox5 = new TextBox();
            this.textBox6 = new TextBox();
            this.textBox7 = new TextBox();
            this.textBox8 = new TextBox();
            this.checkBox1 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.checkISCC = new CheckBox();
            this.checkDaily = new CheckBox();
            this.textQuantity = new TextBox();
            this.labelKG = new Label();
            this.label10 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape1 = new LineShape();
            this.button3 = new Button();
            this.groupType = new GroupBox();
            this.radioCust = new RadioButton();
            this.radioVend = new RadioButton();
            this.groupType.SuspendLayout();
            base.SuspendLayout();
            this.label1.Location = new Point(0x15, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Relation Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label2.Location = new Point(0x15, 0x2c);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x55, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Relation Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(0x15, 0x44);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x55, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Location = new Point(0x15, 0x7d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x55, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "City";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label5.Location = new Point(0x15, 0x94);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x55, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Phone";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.label6.Location = new Point(0x15, 0xa9);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x55, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Fax.";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.label7.Location = new Point(0x15, 0xc0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x55, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Contact Person";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.label8.Location = new Point(0x15, 0xd6);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x55, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = " Code";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.label9.Location = new Point(0x15, 0xf8);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x55, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Blacklist";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.textBoxRelationCode.CharacterCasing = CharacterCasing.Upper;
            this.textBoxRelationCode.Location = new Point(0x70, 0x11);
            this.textBoxRelationCode.MaxLength = 20;
            this.textBoxRelationCode.Name = "textBoxRelationCode";
            this.textBoxRelationCode.Size = new Size(0xa5, 20);
            this.textBoxRelationCode.TabIndex = 0;
            this.textBoxRelationCode.KeyPress += new KeyPressEventHandler(this.textBoxRelationCode_KeyPress);
            this.textBoxRelationCode.Leave += new EventHandler(this.textBoxRelationCode_Leave);
            this.textBox2.Location = new Point(0x70, 0x29);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x180, 20);
            this.textBox2.TabIndex = 1;
            this.textBox3.Location = new Point(0x70, 0x41);
            this.textBox3.MaxLength = 150;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(500, 0x35);
            this.textBox3.TabIndex = 2;
            this.textBox4.Location = new Point(0x70, 0x7a);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0xfb, 20);
            this.textBox4.TabIndex = 3;
            this.textBox5.Location = new Point(0x70, 0x91);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Size(0xfb, 20);
            this.textBox5.TabIndex = 4;
            this.textBox6.Location = new Point(0x70, 0xa6);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Size(0xfb, 20);
            this.textBox6.TabIndex = 5;
            this.textBox7.Location = new Point(0x70, 0xbd);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Size(0xfb, 20);
            this.textBox7.TabIndex = 6;
            this.textBox8.Location = new Point(0x70, 0xd3);
            this.textBox8.MaxLength = 50;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Size(0xfb, 20);
            this.textBox8.TabIndex = 7;
            this.textBox8.TextChanged += new EventHandler(this.textBox8_TextChanged);
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x70, 0xf7);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0x41, 0x11);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "Blocked";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.button1.Location = new Point(0x194, 0x10b);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x63, 30);
            this.button1.TabIndex = 11;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x1fd, 0x10b);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x63, 30);
            this.button2.TabIndex = 12;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.checkISCC.AutoSize = true;
            this.checkISCC.Location = new Point(0x1a5, 0x10);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x4b, 0x11);
            this.checkISCC.TabIndex = 9;
            this.checkISCC.Text = "ISCC Cert.";
            this.checkISCC.UseVisualStyleBackColor = true;
            this.checkISCC.CheckedChanged += new EventHandler(this.checkISCC_CheckedChanged);
            this.checkDaily.AutoSize = true;
            this.checkDaily.Location = new Point(0x18d, 0xd4);
            this.checkDaily.Name = "checkDaily";
            this.checkDaily.Size = new Size(0x41, 0x11);
            this.checkDaily.TabIndex = 0x18;
            this.checkDaily.Text = "Activate";
            this.checkDaily.UseVisualStyleBackColor = true;
            this.checkDaily.CheckedChanged += new EventHandler(this.checkDaily_CheckedChanged);
            this.textQuantity.Location = new Point(0x1f0, 0xd3);
            this.textQuantity.Name = "textQuantity";
            this.textQuantity.Size = new Size(0x53, 20);
            this.textQuantity.TabIndex = 10;
            this.textQuantity.Text = "0";
            this.textQuantity.TextAlign = HorizontalAlignment.Right;
            this.labelKG.AutoSize = true;
            this.labelKG.Location = new Point(0x249, 0xd5);
            this.labelKG.Name = "labelKG";
            this.labelKG.Size = new Size(0x17, 13);
            this.labelKG.TabIndex = 0x1a;
            this.labelKG.Text = "Kg.";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x18a, 0xbd);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x8e, 13);
            this.label10.TabIndex = 0x1b;
            this.label10.Text = " Daily over Quantity Warning";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x270, 0x135);
            this.shapeContainer1.TabIndex = 0x1c;
            this.shapeContainer1.TabStop = false;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x18c;
            this.lineShape1.X2 = 590;
            this.lineShape1.Y1 = 0xcd;
            this.lineShape1.Y2 = 0xcd;
            this.button3.Location = new Point(0x103, 0xed);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x68, 0x25);
            this.button3.TabIndex = 0x1d;
            this.button3.Text = "Adopt From ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.groupType.Controls.Add(this.radioCust);
            this.groupType.Controls.Add(this.radioVend);
            this.groupType.Location = new Point(0x19c, 0x7d);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(200, 40);
            this.groupType.TabIndex = 0x21;
            this.groupType.TabStop = false;
            this.groupType.Text = "Type";
            this.radioCust.AutoSize = true;
            this.radioCust.Location = new Point(0x19, 0x11);
            this.radioCust.Name = "radioCust";
            this.radioCust.Size = new Size(0x45, 0x11);
            this.radioCust.TabIndex = 30;
            this.radioCust.Text = "Customer";
            this.radioCust.UseVisualStyleBackColor = true;
            this.radioVend.AutoSize = true;
            this.radioVend.Checked = true;
            this.radioVend.Location = new Point(0x7c, 0x11);
            this.radioVend.Name = "radioVend";
            this.radioVend.Size = new Size(0x3b, 0x11);
            this.radioVend.TabIndex = 0x1f;
            this.radioVend.TabStop = true;
            this.radioVend.Text = "Vendor";
            this.radioVend.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x270, 0x135);
            base.ControlBox = false;
            base.Controls.Add(this.groupType);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.labelKG);
            base.Controls.Add(this.textQuantity);
            base.Controls.Add(this.checkDaily);
            base.Controls.Add(this.checkISCC);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.textBox8);
            base.Controls.Add(this.textBox7);
            base.Controls.Add(this.textBox6);
            base.Controls.Add(this.textBox5);
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBoxRelationCode);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.shapeContainer1);
            base.Name = "FormVendorEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Add/Edit Relation";
            base.Load += new EventHandler(this.FormVendorEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormVendorEntry_KeyPress);
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.AlphabetNumber_(e);
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxRelationCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.CheckInput(e, "A|N|U");
        }

        private void textBoxRelationCode_Leave(object sender, EventArgs e)
        {
            if (WBUtility.CheckLeave(this.textBoxRelationCode.Text, "A|N|U"))
            {
                MessageBox.Show(Resource.Filter_003, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxRelationCode.Focus();
            }
        }

        private void translate()
        {
            this.label1.Text = Resource.VendorE_001;
            this.label2.Text = Resource.VendorE_002;
            this.label3.Text = Resource.VendorE_003;
            this.label4.Text = Resource.VendorE_004;
            this.label5.Text = Resource.VendorE_005;
            this.label6.Text = Resource.VendorE_006;
            this.label7.Text = Resource.VendorE_007;
            this.label8.Text = Resource.VendorE_008;
            this.label9.Text = Resource.VendorE_009;
            this.label10.Text = Resource.VendorE_010;
            this.groupType.Text = Resource.VendorE_011;
            this.radioCust.Text = Resource.VendorE_012;
            this.radioVend.Text = Resource.VendorE_013;
            this.checkDaily.Text = Resource.VendorE_014;
            this.checkBox1.Text = Resource.VendorE_015;
            this.button3.Text = Resource.ContractE_039 + this.sapIDSYS;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.checkISCC.Text = Resource.Chk_ISCC_Cert;
            this.Text = Resource.Title_Add_Edit_Relation;
            if (WBSetting.integrationIDSYS)
            {
                this.label8.Text = "IDSYS Code";
                this.button3.Text = "Adopt From IDSYS";
                this.textBoxRelationCode.Enabled = false;
                this.textBox2.Enabled = false;
                this.textBox3.Enabled = false;
                this.textBox4.Enabled = false;
                this.textBox5.Enabled = false;
                this.textBox6.Enabled = false;
                this.textBox7.Enabled = false;
                this.checkISCC.Enabled = false;
                this.groupType.Enabled = false;
                this.checkDaily.Enabled = false;
                this.textQuantity.Enabled = false;
            }
        }
    }
}

