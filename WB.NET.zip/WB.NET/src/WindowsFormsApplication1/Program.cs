﻿namespace WindowsFormsApplication1
{
    using ciloci.Flee;
    using CrystalDecisions.CrystalReports.Engine;
    using CrystalDecisions.Shared;
    using Encryption.Utility;
    using Microsoft.CSharp.RuntimeBinder;
    using Microsoft.Office.Interop.Excel;
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.IO.Ports;
    using System.Linq;
    using System.Management;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
    using System.Xml.XPath;
    using WindowsFormsApplication1.TCSUtility;
    using WindowsFormsApplication1.Utility;

    internal static class Program
    {
        public static TSC_DBIntegrator TCSDatabase = new TSC_DBIntegrator();
        public const string kodeAplikasi = "UWB_WB";
        public static WBData WBDatabase = new WBData();
        public static dBase TMCDatabase = new dBase();
        public static MainForm mainform;
        public static MainFormAfrica mainformAfrica;
        public static bool TMCready = false;
        public static string tmcLoc;
        public static string tmcLocName;
        public static string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        public static SerialPort serialPort1 = new SerialPort();
        public static bool multiSession = false;
        public static bool WBRun = false;
        public static WindowsFormsApplication1.FormAutoSync FormAutoSync;
        public static bool excelSuccess = false;

        public static void AutoCloseDO(string[] DO_uniq)
        {
            for (int i = 0; i < DO_uniq.Length; i++)
            {
                if (!((DO_uniq[i] == "") || ReferenceEquals(DO_uniq[i], null)))
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and uniq = '" + DO_uniq[i] + "'"), WBData.conn);
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["closed"] = "X";
                    table.DR["closed_by"] = WBUser.UserID;
                    table.DR["closed_Date"] = DateTime.Now;
                    table.DR["Change_By"] = WBUser.UserID;
                    table.DR["Change_Date"] = DateTime.Now;
                    table.DR.EndEdit();
                    table.Save();
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and zauto = 'Y' and Do_No LIKE '" + table.DR["DO_NO"].ToString() + "%'"), WBData.conn);
                    if (table2.DT.Rows.Count == 1)
                    {
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["closed"] = "X";
                        table2.DR["closed_by"] = WBUser.UserID;
                        table2.DR["closed_Date"] = DateTime.Now;
                        table2.DR["Change_By"] = WBUser.UserID;
                        table2.DR["Change_Date"] = DateTime.Now;
                        table2.DR.EndEdit();
                        table2.Save();
                    }
                    table.Dispose();
                    table2.Dispose();
                }
            }
        }

        public static void AutoComp(WBTable tbl, string field, TextBox textBox)
        {
            AutoCompleteStringCollection strings = new AutoCompleteStringCollection();
            foreach (DataRow row in tbl.DT.Rows)
            {
                strings.Add(row[field].ToString());
            }
            textBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
            textBox.AutoCompleteCustomSource = strings;
        }

        public static void AutoCompCombo(WBTable tbl, string field, ComboBox comboBox)
        {
            AutoCompleteStringCollection strings = new AutoCompleteStringCollection();
            foreach (DataRow row in tbl.DT.Rows)
            {
                strings.Add(row[field].ToString());
            }
            comboBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
            comboBox.AutoCompleteCustomSource = strings;
        }

        public static DateTime BMON(DateTime pTgl) => 
            new DateTime(pTgl.Year, pTgl.Month, 1);

        public static string checkEditTrans(string zField, string zValue, string zUniq)
        {
            WBTable table = new WBTable();
            return "N";
        }

        public static bool CheckEmpty(TextBox[] aText)
        {
            TextBox[] boxArray = aText;
            int index = 0;
            while (true)
            {
                bool flag2;
                if (index >= boxArray.Length)
                {
                    flag2 = false;
                }
                else
                {
                    TextBox box = boxArray[index];
                    if (box.Text.Trim() != "")
                    {
                        index++;
                        continue;
                    }
                    MessageBox.Show(Resource.Mes_559, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    box.Focus();
                    flag2 = true;
                }
                return flag2;
            }
        }

        public static bool CheckNumeric(string ptxt)
        {
            if (ptxt.Trim() == "")
            {
                ptxt = "0";
            }
            try
            {
                float num = (float) Convert.ToDouble(ptxt.Trim().Substring(ptxt.Length - 1, 1));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool CheckNumeric(TextBox txt)
        {
            if (txt.Text.Trim() == "")
            {
                txt.Text = "0";
            }
            try
            {
                float num = (float) Convert.ToDouble(txt.Text.Trim());
                return true;
            }
            catch
            {
                MessageBox.Show(Resource.Mes_018 + "\n\n( Object : " + txt.Name + " )", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txt.Focus();
                return false;
            }
        }

        public static bool CheckNumericForLoadingQty(string txt)
        {
            if (txt.Trim() == "")
            {
                txt = "0";
            }
            if (!WBSetting.allowDecimalLoadingQty)
            {
                int num;
                if (!int.TryParse(Convert.ToString(txt), out num))
                {
                    MessageBox.Show(Resource.Mes_018, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    return false;
                }
            }
            else
            {
                double num2;
                if (!(!double.TryParse(Convert.ToString(txt), out num2) || txt.Contains<char>(',')))
                {
                    char[] separator = new char[] { '.' };
                    string[] source = txt.Split(separator);
                    if ((source.Count<string>() > 1) && (source[1].Length > 3))
                    {
                        MessageBox.Show(string.Format(Resource.Mes_630, "3"), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_018, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    return false;
                }
            }
            return true;
        }

        public static double checkOS(string DoNo, string pdate, string pref, string ztol)
        {
            double num8;
            string str = "0";
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            string str2 = "";
            string str3 = "";
            string str4 = "KG";
            string str5 = "";
            float num7 = 0f;
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                num8 = 0.0;
            }
            else
            {
                double num6;
                str2 = table.DR["comm_code"].ToString();
                str = table.DR["deductedby"].ToString();
                num3 = (StrToDouble(table.DR["Entry_Est"].ToString(), 0) <= 0.0) ? Convert.ToDouble((table.DR["Quantity"].ToString() == "") ? "0" : table.DR["Quantity"].ToString()) : Convert.ToDouble((table.DR["Entry_Est"].ToString() == "") ? "0" : table.DR["Entry_Est"].ToString());
                num4 = (StrToDouble(table.DR["Entry_Fact"].ToString(), 0) <= 0.0) ? Convert.ToDouble((table.DR["Quantity"].ToString() == "") ? "0" : table.DR["Quantity"].ToString()) : Convert.ToDouble((table.DR["Entry_Fact"].ToString() == "") ? "0" : table.DR["Entry_Fact"].ToString());
                num2 = (table.DR["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(table.DR["tolerance"].ToString());
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str2 + "'"), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                str3 = table2.DR["BulkPack"].ToString();
                str4 = table2.DR["Unit"].ToString();
                str5 = table2.DR["Type"].ToString();
                try
                {
                    num7 = float.Parse(table2.DR["Netto_Weight"].ToString());
                }
                catch (Exception)
                {
                    num7 = 0f;
                }
                WBTable table3 = new WBTable();
                string sqltext = ((("Select " + " sum(netFactory) as NetFactory , " + " sum(case when netOther = '0' and Return_Qty_KG = '0' then netFactory else netOther end) as NetOther, ") + " sum(loading_qty) as loading_qty, sum(case when (loading_qty_opw = 0  or LOADING_QTY_OPW is null) and (Return_Qty_pack = '0' or Return_Qty_pack is null) then loading_qty else loading_qty_opw end) as loading_qty_opw" + " from vw_outstanding") + " WHERE " + WBData.CompanyLocation(" and DO_NO = '" + DoNo + "'")) + " AND (mark_return = '' OR mark_return is null) and (is_return <> 'Y' or is_return is null)";
                if (pdate != "")
                {
                    sqltext = sqltext + " and report_date <= '" + DTOC(Convert.ToDateTime(pdate)) + "' ";
                }
                if (pref != "")
                {
                    sqltext = sqltext + " and Ref <> '" + pref + "' ";
                }
                table3.OpenTable("vw_outstanding", sqltext, WBData.conn);
                if (str == "1")
                {
                    num = num3;
                    num6 = ((str4 != "KG") && (str4 != "")) ? (Math.Truncate((double) ((StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 3) * num7) * 10.0)) / 10.0) : StrToDouble(table3.DT.Rows[0]["NetOther"].ToString(), 0);
                }
                else
                {
                    num = num4;
                    num6 = ((str4 != "KG") && (str4 != "")) ? (Math.Truncate((double) ((StrToDouble(table3.DT.Rows[0]["loading_qty"].ToString(), 3) * num7) * 10.0)) / 10.0) : StrToDouble(table3.DT.Rows[0]["NetFactory"].ToString(), 0);
                }
                num2 = (ztol != "Y") ? 0.0 : ((num2 / 100.0) * num);
                num5 = (num - num6) + num2;
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                num8 = num5;
            }
            return num8;
        }

        public static double checkOS_MultiLine(string DoNo, string pdate, string pref, string ztol, string so_item_detail)
        {
            double num9;
            string str = "0";
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            double num7 = 0.0;
            string str2 = "";
            string str3 = "";
            string str4 = "KG";
            string str5 = "";
            float num8 = 0f;
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                num9 = 0.0;
            }
            else
            {
                double num6;
                WBTable table2 = new WBTable();
                string[] textArray1 = new string[] { " AND do_no = '", DoNo, "' AND so_item = '", so_item_detail, "'" };
                table2.OpenTable("wb_contract_sapinformation", "SELECT * FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                str2 = table2.DR["comm_code"].ToString();
                num7 = StrToDouble(table2.DR["tolerance"].ToString(), 0);
                str = table.DR["deductedby"].ToString();
                num3 = (StrToDouble(table.DR["Entry_Est"].ToString(), 0) <= 0.0) ? Convert.ToDouble((table2.DR["Quantity"].ToString() == "") ? "0" : table2.DR["Quantity"].ToString()) : Convert.ToDouble((table.DR["Entry_Est"].ToString() == "") ? "0" : table.DR["Entry_Est"].ToString());
                num4 = (StrToDouble(table.DR["Entry_Fact"].ToString(), 0) <= 0.0) ? Convert.ToDouble((table2.DR["Quantity"].ToString() == "") ? "0" : table2.DR["Quantity"].ToString()) : Convert.ToDouble((table.DR["Entry_Fact"].ToString() == "") ? "0" : table.DR["Entry_Fact"].ToString());
                num2 = num7;
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str2 + "'"), WBData.conn);
                table3.DR = table3.DT.Rows[0];
                str3 = table3.DR["BulkPack"].ToString();
                str4 = table3.DR["Unit"].ToString();
                str5 = table3.DR["Type"].ToString();
                try
                {
                    num8 = float.Parse(table3.DR["Netto_Weight"].ToString());
                }
                catch (Exception)
                {
                    num8 = 0f;
                }
                WBTable table4 = new WBTable();
                string[] textArray2 = new string[] { " and DO_NO = '", DoNo, "' AND (so_item_detail = '", so_item_detail.PadLeft(6, '0'), "' or so_item_detail = '", Convert.ToInt32(so_item_detail).ToString(), "') " };
                string sqltext = ((("Select " + " sum(netFactory) as NetFactory , " + " sum(case when netOther = '0' and Return_Qty_KG = '0' then netFactory else netOther end) as NetOther, ") + " sum(loading_qty) as loading_qty, sum(case when (loading_qty_opw = 0  or LOADING_QTY_OPW is null) and (Return_Qty_pack = '0' or Return_Qty_pack is null) then loading_qty else loading_qty_opw end) as loading_qty_opw" + " from vw_outstanding") + " WHERE " + WBData.CompanyLocation(string.Concat(textArray2))) + " AND (mark_return = '' OR mark_return is null) and (is_return <> 'Y' or is_return is null)";
                if (pdate != "")
                {
                    sqltext = sqltext + " and report_date <= '" + DTOC(Convert.ToDateTime(pdate)) + "' ";
                }
                if (pref != "")
                {
                    sqltext = sqltext + " and Ref <> '" + pref + "' ";
                }
                table4.OpenTable("vw_outstanding", sqltext, WBData.conn);
                if (str == "1")
                {
                    num = num3;
                    num6 = ((str4 != "KG") && (str4 != "")) ? (Math.Truncate((double) ((StrToDouble(table4.DT.Rows[0]["loading_qty_opw"].ToString(), 3) * num8) * 10.0)) / 10.0) : StrToDouble(table4.DT.Rows[0]["NetOther"].ToString(), 0);
                }
                else
                {
                    num = num4;
                    num6 = ((str4 != "KG") && (str4 != "")) ? (Math.Truncate((double) ((StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 3) * num8) * 10.0)) / 10.0) : StrToDouble(table4.DT.Rows[0]["NetFactory"].ToString(), 0);
                }
                num2 = (ztol != "Y") ? 0.0 : ((num2 / 100.0) * num);
                num5 = (num - num6) + num2;
                table.Dispose();
                table3.Dispose();
                table4.Dispose();
                num9 = num5;
            }
            return num9;
        }

        public static double checkOS_Old(string DoNo, string pdate, string pref, string ztol)
        {
            double num9;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            double num6 = 0.0;
            double num7 = 0.0;
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                table2.Dispose();
                num9 = 0.0;
            }
            else
            {
                double num8;
                if (getFieldValue("wb_commodity", "Type", "Comm_Code", table.DT.Rows[0]["Comm_Code"].ToString()).Trim() == "G")
                {
                    num7 = StrToDouble(getFieldValue("wb_commodity", "Netto_Gunny", "Comm_Code", table.DT.Rows[0]["Comm_Code"].ToString()), 0);
                    num4 = StrToDouble(table.DT.Rows[0]["Entry_Fact"].ToString(), 0);
                    if (pdate == "")
                    {
                        table2.OpenTable("vw_outstanding", "select SUM (TotalGunny) as TotGunny from wb_transaction where " + WBData.CompanyLocation(" and (Do_No = '" + table.DT.Rows[0]["Do_No"].ToString().Trim() + "') and (Deleted is null or Deleted = '') and (report_date is not null)"), WBData.conn);
                    }
                    else
                    {
                        string[] textArray1 = new string[] { " and (Do_No = '", table.DT.Rows[0]["Do_No"].ToString().Trim(), "') and (Deleted is null or Deleted = '') and (report_date is not null) and (report_date <= '", DTOC(Convert.ToDateTime(pdate)), "') " };
                        table2.OpenTable("vw_outstanding", "select SUM (TotalGunny) as TotGunny from wb_transaction where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                    }
                    num3 = StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0);
                    num8 = (table2.DT.Rows.Count <= 0) ? 0.0 : (StrToDouble(table2.DT.Rows[0]["TotGunny"].ToString(), 0) * num7);
                    table.Dispose();
                    table2.Dispose();
                    num9 = ((num4 == 0.0) ? num3 : num4) - num8;
                }
                else
                {
                    num = (StrToDouble(table.DT.Rows[0]["Entry_Est"].ToString(), 0) <= 0.0) ? StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0) : StrToDouble(table.DT.Rows[0]["Entry_Est"].ToString(), 0);
                    num2 = (StrToDouble(table.DT.Rows[0]["Entry_Fact"].ToString(), 0) <= 0.0) ? StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0) : StrToDouble(table.DT.Rows[0]["Entry_Fact"].ToString(), 0);
                    string str = table.DT.Rows[0]["DeductedBy"].ToString();
                    num6 = (table.DT.Rows[0]["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(table.DT.Rows[0]["tolerance"].ToString());
                    string sqltext = "Select ";
                    if (str == "0")
                    {
                        num3 = num2;
                        sqltext = sqltext + "sum(case when do_sap is null then netto else quantity_kg end) as Net from vw_outstanding  ";
                    }
                    else if (str == "1")
                    {
                        num3 = num;
                        sqltext = sqltext + "sum(case when do_sap is null then (case when gross_estate = '0' and tare_estate = '0' then bruto - tarra else estate_qty end) else quantity_kg end) as Net from vw_outstanding  ";
                    }
                    else
                    {
                        num3 = num2;
                        sqltext = sqltext + "sum(case when do_sap is null then netto else quantity_kg end) as Net from vw_outstanding  ";
                    }
                    sqltext = sqltext + "where " + WBData.CompanyLocation(" and DO_NO = '" + DoNo + "'");
                    if (pdate != "")
                    {
                        sqltext = sqltext + " and report_date <= '" + DTOC(Convert.ToDateTime(pdate)) + "' ";
                    }
                    if (pref != "")
                    {
                        sqltext = sqltext + " and Ref <> '" + pref + "' ";
                    }
                    sqltext = sqltext + " and (deleted is null or deleted = 'N') and report_date is not null ";
                    table2.OpenTable("vw_outstanding", sqltext, WBData.conn);
                    num8 = StrToDouble(table2.DT.Rows[0]["Net"].ToString(), 0);
                    num6 = (ztol != "Y") ? 0.0 : ((num6 / 100.0) * num3);
                    num5 = (num3 - num8) + num6;
                    table.Dispose();
                    table2.Dispose();
                    num9 = num5;
                }
            }
            return num9;
        }

        public static double checkOSbyGunny(string DoNo, string pdate, string pref, string ztol)
        {
            double num9;
            Cursor.Current = Cursors.WaitCursor;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            double num6 = 0.0;
            double num7 = 0.0;
            string str4 = "";
            table2.OpenTable("wb_transaction_type", "select * from wb_transaction_type where" + WBData.CompanyLocation(" and is_return = 'Y'"), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                str4 = " and transaction_code <> '" + table2.DT.Rows[0]["transaction_code"] + "'";
            }
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                table3.Dispose();
                num9 = 0.0;
            }
            else
            {
                double num8;
                if (getFieldValue("wb_commodity", "Type", "Comm_Code", table.DT.Rows[0]["Comm_Code"].ToString()).Trim() == "G")
                {
                    num5 = StrToDouble(getFieldValue("wb_commodity", "Netto_Gunny", "Comm_Code", table.DT.Rows[0]["Comm_Code"].ToString()), 0);
                    num3 = StrToDouble(table.DT.Rows[0]["Entry_Fact"].ToString(), 0);
                    if (pdate == "")
                    {
                        string text1 = " and (Do_No = '" + table.DT.Rows[0]["Do_No"].ToString().Trim() + "') and (Deleted is null or Deleted = '') and (mark_accident is null or mark_accident = '') and (returref is null or returref = '') and (report_date is not null) " + str4;
                        string pStr = text1;
                        if (text1 == null)
                        {
                            string local1 = text1;
                            pStr = "";
                        }
                        table3.OpenTable("vw_outstanding", "select SUM (TotalGunny) as TotGunny from wb_transaction where " + WBData.CompanyLocation(pStr), WBData.conn);
                    }
                    else
                    {
                        string[] textArray1 = new string[] { " and (Do_No = '", table.DT.Rows[0]["Do_No"].ToString().Trim(), "') and (Deleted is null or Deleted = '') and (mark_accident is null or mark_accident = '') and (returref is null or returref = '') and (report_date is not null) ", str4, " and (report_date <= '", DTOC(Convert.ToDateTime(pdate)), "') " };
                        table3.OpenTable("vw_outstanding", "select SUM (TotalGunny) as TotGunny from wb_transaction where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                    }
                    num4 = StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0);
                    num8 = (table3.DT.Rows.Count <= 0) ? 0.0 : (StrToDouble(table3.DT.Rows[0]["TotGunny"].ToString(), 0) * num5);
                    table.Dispose();
                    table3.Dispose();
                    num9 = ((num3 == 0.0) ? num4 : num3) - num8;
                }
                else
                {
                    num2 = StrToDouble(table.DT.Rows[0]["Entry_Fact"].ToString(), 0);
                    if (!(StrToDouble(table.DT.Rows[0]["Entry_Est"].ToString(), 0) != 0.0))
                    {
                        num = StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0);
                    }
                    if (!(num2 != 0.0))
                    {
                        num2 = StrToDouble(table.DT.Rows[0]["Quantity"].ToString(), 0);
                    }
                    string str = table.DT.Rows[0]["DeductedBy"].ToString();
                    num7 = (table.DT.Rows[0]["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(table.DT.Rows[0]["tolerance"].ToString());
                    string str3 = getFieldValue("wb_transaction_type", "IO", "transaction_code", table.DT.Rows[0]["Transaction_code"].ToString().Trim());
                    string sqltext = "SELECT ";
                    string str6 = "(SELECT (wb_commodity.Netto_Gunny * vw_outstanding.TotalBunch) As Net_Gunny, vw_outstanding.*,wb_commodity.Netto_Gunny FROM vw_outstanding INNER JOIN wb_commodity ON vw_outstanding.Comm_Code = wb_commodity.Comm_Codeand vw_outstanding.coy = wb_commodity.coy and vw_outstanding.location_code = wb_commodity.location_code) AS tbl ";
                    if (str == "0")
                    {
                        num4 = num2;
                        sqltext = sqltext + "SUM (Net_Gunny) AS Net FROM " + str6;
                    }
                    else if (str == "1")
                    {
                        num4 = num;
                        sqltext = sqltext + "sum(case when gross_estate = '0' and tare_estate = '0' then bruto - tarra else estate_qty end) as Net from " + str6;
                    }
                    else
                    {
                        num4 = num2;
                        sqltext = sqltext + "SUM (Net_Gunny) AS Net FROM " + str6;
                    }
                    sqltext = sqltext + "WHERE " + WBData.CompanyLocation(" AND DO_NO = '" + DoNo + "'");
                    if (pdate != "")
                    {
                        sqltext = sqltext + " AND report_date <= '" + DTOC(Convert.ToDateTime(pdate)) + "' ";
                    }
                    if (pref != "")
                    {
                        sqltext = sqltext + " AND Ref <> '" + pref + "' ";
                    }
                    sqltext = sqltext + " AND (deleted is null or deleted = 'N') AND report_date is not null " + str4;
                    table3.OpenTable("vw_outstanding", sqltext, WBData.conn);
                    num8 = StrToDouble(table3.DT.Rows[0]["Net"].ToString(), 0);
                    num7 = (ztol != "Y") ? 0.0 : ((num7 / 100.0) * num4);
                    num6 = (num4 - num8) + num7;
                    table.Dispose();
                    table3.Dispose();
                    Cursor.Current = Cursors.Default;
                    if (num6 == 0.0)
                    {
                        num6 = checkOS(DoNo, pdate, pref, ztol);
                    }
                    num9 = num6;
                }
            }
            return num9;
        }

        public static double checkQtyUsedOngoingOPW(string DoNo, string pdate, string pref, string pGate, string so_item_detail)
        {
            double num3;
            string str = "";
            string str2 = "";
            string str3 = "KG";
            string str4 = "";
            float num2 = 0f;
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                num3 = 0.0;
            }
            else
            {
                double num;
                str = table.DR["comm_code"].ToString();
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str + "'"), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                str2 = table2.DR["BulkPack"].ToString();
                str3 = table2.DR["Unit"].ToString();
                str4 = table2.DR["Type"].ToString();
                try
                {
                    num2 = float.Parse(table2.DR["Netto_Weight"].ToString());
                }
                catch (Exception)
                {
                    num2 = 0f;
                }
                WBTable table3 = new WBTable();
                string sqltext = ("Select " + " sum(netFactory) as NetFactory , " + " sum(netOther) as NetOther, ") + " sum(loading_qty) as loading_qty, sum(loading_qty_opw) as loading_qty_opw" + " from vw_QtyUsedOngoing_OPW";
                if (so_item_detail == "")
                {
                    sqltext = sqltext + " WHERE " + WBData.CompanyLocation(" and DO_NO = '" + DoNo + "'");
                }
                else
                {
                    string[] textArray1 = new string[] { " and DO_NO = '", DoNo, "' AND (so_item_detail = '", so_item_detail.PadLeft(6, '0'), "' or so_item_detail = '", Convert.ToInt32(so_item_detail).ToString(), "') " };
                    sqltext = sqltext + " WHERE " + WBData.CompanyLocation(string.Concat(textArray1));
                }
                sqltext = sqltext + " AND (mark_return = '' OR mark_return is null) and (is_return <> 'Y' or is_return is null)";
                if (pref != "")
                {
                    sqltext = sqltext + " and Ref <> '" + pref + "' ";
                }
                else if (pGate != "")
                {
                    sqltext = sqltext + " and Gatepass_Number <> '" + pGate + "' ";
                }
                table3.OpenTable("vw_QtyUsedOngoing_OPW", sqltext, WBData.conn);
                if ((str3 == "KG") || (str3 == ""))
                {
                    num = StrToDouble(table3.DT.Rows[0]["NetOther"].ToString(), 0);
                }
                else
                {
                    num = !(StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 3) == 0.0) ? (StrToDouble(table3.DT.Rows[0]["loading_qty_opw"].ToString(), 3) * num2) : 0.0;
                    num = Math.Truncate((double) (num * 10.0)) / 10.0;
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                num3 = num;
            }
            return num3;
        }

        public static bool CheckRegistry()
        {
            bool flag = false;
            WBConfigurationHandler.createDirectory();
            if (File.Exists(WBConfigurationHandler.registryFile))
            {
                Dictionary<string, string> dict = WBConfigurationHandler.readFromTxt(WBConfigurationHandler.registryFile);
                string par = "";
                string str3 = "";
                if (WBConfigurationHandler.dictionaryToString(dict) == "")
                {
                    MessageBox.Show(Resource.Mes_561, Resource.Title_003);
                    FormRegis regis = new FormRegis();
                    par = GPC(GetCPUId());
                    str3 = GPK(par);
                    regis.pCode = par;
                    regis.ShowDialog();
                    if (!regis.pReturn)
                    {
                        flag = false;
                    }
                    else
                    {
                        WBConfigurationHandler.createTxtFile(WBConfigurationHandler.registryFile);
                        Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                            { 
                                "REGCODE",
                                GPC(GetCPUId())
                            },
                            { 
                                "REGKEY",
                                GPK(GPC(GetCPUId()))
                            }
                        };
                        WBConfigurationHandler.writeToTxt(WBConfigurationHandler.registryFile, dictToTxt);
                        dictToTxt.Clear();
                        flag = true;
                    }
                }
                else
                {
                    string str4 = dict.ContainsKey("REGCODE") ? dict["REGCODE"] : "";
                    string str5 = dict.ContainsKey("REGKEY") ? dict["REGKEY"] : "";
                    string str6 = GPC(GetCPUId());
                    string str7 = GPK(str6);
                    if ((str4.Trim() == str6.Trim()) && (str5.Trim() == str7.Trim()))
                    {
                        flag = true;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_561, Resource.Title_003);
                        FormRegis regis2 = new FormRegis();
                        par = GPC(GetCPUId());
                        str3 = GPK(par);
                        regis2.pCode = par;
                        regis2.ShowDialog();
                        if (!regis2.pReturn)
                        {
                            flag = false;
                        }
                        else
                        {
                            WBConfigurationHandler.createTxtFile(WBConfigurationHandler.registryFile);
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "REGCODE",
                                    GPC(GetCPUId())
                                },
                                { 
                                    "REGKEY",
                                    GPK(GPC(GetCPUId()))
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.registryFile, dictToTxt);
                            dictToTxt.Clear();
                            flag = true;
                        }
                    }
                }
                dict.Clear();
            }
            else
            {
                FormRegis regis3 = new FormRegis();
                string par = "";
                string str9 = "";
                try
                {
                    RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                    if (ReferenceEquals(key2.OpenSubKey("WCS"), null))
                    {
                        par = GPC(GetCPUId());
                        str9 = GPK(par);
                        regis3.pCode = par;
                        regis3.ShowDialog();
                        if (!regis3.pReturn)
                        {
                            flag = false;
                        }
                        else
                        {
                            WBConfigurationHandler.createTxtFile(WBConfigurationHandler.registryFile);
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "REGCODE",
                                    GPC(GetCPUId())
                                },
                                { 
                                    "REGKEY",
                                    GPK(GPC(GetCPUId()))
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.registryFile, dictToTxt);
                            dictToTxt.Clear();
                            flag = true;
                        }
                    }
                    else
                    {
                        RegistryKey key4 = key2.CreateSubKey("WCS").CreateSubKey("WB System");
                        string str11 = (string) key4.GetValue("ProjectKey");
                        par = GPC(GetCPUId());
                        str9 = GPK(par);
                        if ((((string) key4.GetValue("ProjectCode")).Trim() != par.Trim()) || (str11.Trim() != str9.Trim()))
                        {
                            MessageBox.Show(Resource.Mes_561, Resource.Title_003);
                            flag = false;
                            key2.DeleteSubKeyTree("WCS");
                            Application.Restart();
                        }
                        else
                        {
                            WBConfigurationHandler.createTxtFile(WBConfigurationHandler.registryFile);
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "REGCODE",
                                    GPC(GetCPUId())
                                },
                                { 
                                    "REGKEY",
                                    GPK(GPC(GetCPUId()))
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.registryFile, dictToTxt);
                            dictToTxt.Clear();
                            flag = true;
                        }
                    }
                }
                catch
                {
                    par = GPC(GetCPUId());
                    str9 = GPK(par);
                    regis3.pCode = par;
                    regis3.ShowDialog();
                    if (!regis3.pReturn)
                    {
                        flag = false;
                    }
                    else
                    {
                        WBConfigurationHandler.createTxtFile(WBConfigurationHandler.registryFile);
                        Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                            { 
                                "REGCODE",
                                GPC(GetCPUId())
                            },
                            { 
                                "REGKEY",
                                GPK(GPC(GetCPUId()))
                            }
                        };
                        WBConfigurationHandler.writeToTxt(WBConfigurationHandler.registryFile, dictToTxt);
                        dictToTxt.Clear();
                        flag = true;
                    }
                }
            }
            return flag;
        }

        public static void copyToLoc(string tabl, string key, int all, string reason)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            WBTable table4 = new WBTable();
            WBTable table5 = new WBTable();
            WBTable table6 = new WBTable();
            string sqltext = "";
            string str2 = "";
            string str3 = "";
            if (WBSetting.copyToLoc == "Y")
            {
                if (tabl == "wb_truck")
                {
                    str3 = "truck_number";
                }
                else if (tabl == "wb_driver")
                {
                    str3 = "license_no";
                }
                else if (tabl == "wb_commodity")
                {
                    str3 = "comm_code";
                }
                else if (tabl == "wb_relation")
                {
                    str3 = "relation_code";
                }
                else if (tabl == "wb_transporter")
                {
                    str3 = "transporter_code";
                }
                else if (tabl == "wb_transaction_type")
                {
                    str3 = "transaction_code";
                }
                else if (tabl == "wb_estate")
                {
                    str3 = "estate_code";
                }
                if (((tabl == "wb_commodity") || (tabl == "wb_truck")) || (tabl == "wb_driver"))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_location WHERE coy <> '", WBData.sCoyCode, "' OR Location_Code <> '", WBData.sLocCode, "'" };
                    table.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
                }
                else
                {
                    string[] textArray2 = new string[] { "SELECT * FROM wb_location WHERE coy = '", WBData.sCoyCode, "' AND Location_Code <> '", WBData.sLocCode, "'" };
                    table.OpenTable(tabl, string.Concat(textArray2), WBData.conn);
                }
                foreach (DataRow row in table.DT.Rows)
                {
                    string[] textArray3 = new string[] { "SELECT * FROM ", tabl, " WHERE Coy = '", row["Coy"].ToString(), "' AND Location_Code = '", row["Location_Code"].ToString(), "'" };
                    sqltext = string.Concat(textArray3);
                    str2 = "SELECT * FROM " + tabl + " WHERE " + WBData.CompanyLocation("");
                    if (all == 1)
                    {
                        table2.OpenTable(tabl, sqltext, WBData.conn);
                        table6.OpenTable(tabl, str2, WBData.conn);
                    }
                    else
                    {
                        string[] textArray4 = new string[] { sqltext, " AND ", str3, " = '", key, "'" };
                        sqltext = string.Concat(textArray4);
                        string[] textArray5 = new string[] { str2, " AND ", str3, " = '", key, "'" };
                        str2 = string.Concat(textArray5);
                        table2.OpenTable(tabl, sqltext, WBData.conn);
                        table6.OpenTable(tabl, str2, WBData.conn);
                    }
                    foreach (DataRow row2 in table6.DT.Rows)
                    {
                        string[] aField = new string[] { str3 };
                        string[] aFind = new string[] { row2[str3].ToString() };
                        DataRow data = table2.GetData(aField, aFind);
                        if (ReferenceEquals(data, null))
                        {
                            table2.DR = table2.DT.NewRow();
                            int num = 0;
                            while (true)
                            {
                                if (num >= table6.DT.Columns.Count)
                                {
                                    table2.DR["Coy"] = row["Coy"].ToString();
                                    table2.DR["Location_Code"] = row["Location_Code"].ToString();
                                    table2.DT.Rows.Add(table2.DR);
                                    table2.Save();
                                    table2.ReOpen();
                                    string[] textArray8 = new string[] { str3 };
                                    string[] textArray9 = new string[] { row2[str3].ToString() };
                                    DataRow row4 = table2.GetData(textArray8, textArray9);
                                    string[] textArray10 = new string[9];
                                    textArray10[0] = "SELECT * FROM wb_log_header  WHERE Coy = '";
                                    textArray10[1] = row["Coy"].ToString();
                                    textArray10[2] = "'  AND Location_Code = '";
                                    textArray10[3] = row["Location_Code"].ToString();
                                    textArray10[4] = "'  AND tableName = '";
                                    textArray10[5] = tabl;
                                    textArray10[6] = "'  AND keyField = '";
                                    textArray10[7] = row4["uniq"].ToString();
                                    textArray10[8] = "'  AND PMode is null  AND UserID is null  AND ChangeReason is null  ORDER BY uniq DESC";
                                    table3.OpenTable("wb_log_header", string.Concat(textArray10), WBData.conn);
                                    if (table3.DT.Rows.Count > 0)
                                    {
                                        table3.DR = table3.DT.Rows[0];
                                        table3.DR.BeginEdit();
                                        table3.DR["PMode"] = "ADD";
                                        table3.DR["UserID"] = WBUser.UserID;
                                        table3.DR["ChangeReason"] = reason;
                                        table3.DR.EndEdit();
                                        table3.Save();
                                    }
                                    break;
                                }
                                string str4 = table6.DT.Columns[num].ColumnName.ToString();
                                bool flag12 = str4.ToUpper() != "UNIQ";
                                if (flag12 && ((row2[str4] != null) && (row2[str4].ToString() != "")))
                                {
                                    table2.DR[str4] = row2[str4].ToString();
                                }
                                num++;
                            }
                            continue;
                        }
                        string[] textArray11 = new string[] { str3 };
                        string[] textArray12 = new string[] { row2[str3].ToString() };
                        int recNo = table2.GetRecNo(textArray11, textArray12);
                        table2.DR = table2.DT.Rows[recNo];
                        string str5 = table2.DR["uniq"].ToString();
                        table2.DR.BeginEdit();
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= table6.DT.Columns.Count)
                            {
                                table2.DR["Coy"] = row["Coy"].ToString();
                                table2.DR["Location_Code"] = row["Location_Code"].ToString();
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] textArray13 = new string[9];
                                textArray13[0] = "SELECT * FROM wb_log_header  WHERE Coy = '";
                                textArray13[1] = row["Coy"].ToString();
                                textArray13[2] = "'  AND Location_Code = '";
                                textArray13[3] = row["Location_Code"].ToString();
                                textArray13[4] = "'  AND tableName = '";
                                textArray13[5] = tabl;
                                textArray13[6] = "'  AND keyField = '";
                                textArray13[7] = str5;
                                textArray13[8] = "'  AND PMode is null  AND UserID is null  AND ChangeReason is null  ORDER BY uniq DESC";
                                table3.OpenTable("wb_log_header", string.Concat(textArray13), WBData.conn);
                                if (table3.DT.Rows.Count > 0)
                                {
                                    table3.DR = table3.DT.Rows[0];
                                    table3.DR.BeginEdit();
                                    table3.DR["PMode"] = "EDIT";
                                    table3.DR["UserID"] = WBUser.UserID;
                                    table3.DR["ChangeReason"] = reason;
                                    table3.DR.EndEdit();
                                    table3.Save();
                                }
                                break;
                            }
                            string str6 = table6.DT.Columns[num3].ColumnName.ToString();
                            bool flag16 = str6.ToUpper() != "UNIQ";
                            if (flag16 && ((row2[str6] != null) && (row2[str6].ToString() != "")))
                            {
                                table2.DR[str6] = row2[str6].ToString();
                            }
                            num3++;
                        }
                    }
                }
            }
            table.Dispose();
            table4.Dispose();
            table5.Dispose();
        }

        public static string DTOC(DateTime pTgl)
        {
            string[] textArray1 = new string[] { pTgl.Year.ToString(), "-", pTgl.Month.ToString().PadLeft(2, '0'), "-", pTgl.Day.ToString().PadLeft(2, '0') };
            return string.Concat(textArray1);
        }

        public static string DTOCSAP(DateTime pTgl)
        {
            string[] textArray1 = new string[] { pTgl.Year.ToString(), ".", pTgl.Month.ToString().PadLeft(2, '0'), ".", pTgl.Day.ToString().PadLeft(2, '0') };
            return string.Concat(textArray1);
        }

        public static string DTOCSAP2(DateTime pTgl)
        {
            string[] textArray1 = new string[] { pTgl.Day.ToString().PadLeft(2, '0'), ".", pTgl.Month.ToString().PadLeft(2, '0'), ".", pTgl.Year.ToString() };
            return string.Concat(textArray1);
        }

        public static string DTOS(DateTime pTgl) => 
            pTgl.Year.ToString() + pTgl.Month.ToString().PadLeft(2, '0') + pTgl.Day.ToString().PadLeft(2, '0');

        public static DateTime EMON(DateTime pTgl)
        {
            DateTime time = new DateTime(pTgl.Year, pTgl.Month, 1);
            return time.AddMonths(1).AddDays(-1.0);
        }

        public static double eval(string pStr, ExpressionVariabel owner)
        {
            double num = 0.0;
            try
            {
                owner.opsi();
                num = ((ExpressionEvaluator<double>) new Expression(pStr, owner, owner.opsi()).Evaluator)();
            }
            catch (ExpressionCompileException exception1)
            {
                MessageBox.Show(exception1.Message);
                return -999999999.0;
            }
            return num;
        }

        public static double Evaluate(string expression) => 
            (double) new XPathDocument(new StringReader("<r/>")).CreateNavigator().Evaluate($"number({new Regex(@"([\+\-\*])").Replace(expression, " ${1} ").Replace("/", " div ").Replace("%", " mod ")})");

        public static void export2Excel(DataTable datatable, string SAPDest, string title)
        {
            _Application application = (Application) Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
            _Workbook workbook = application.Workbooks.Add(Type.Missing);
            _Worksheet worksheet = null;
            <>o__23.<>p__0 ??= CallSite<Func<CallSite, object, _Worksheet>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(_Worksheet), typeof(Program)));
            worksheet = <>o__23.<>p__0.Target(<>o__23.<>p__0, workbook.Sheets["Sheet1"]);
            <>o__23.<>p__1 ??= CallSite<Func<CallSite, object, _Worksheet>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(_Worksheet), typeof(Program)));
            worksheet = <>o__23.<>p__1.Target(<>o__23.<>p__1, workbook.ActiveSheet);
            worksheet.Name = "Exported from gridview";
            int num2 = 2;
            while (true)
            {
                if (num2 >= (datatable.Columns.Count + 2))
                {
                    int num = 0;
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= datatable.Rows.Count)
                        {
                            try
                            {
                                if (SAPDest != "")
                                {
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_SAPDest", "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND SAPDest = '" + SAPDest + "'"), WBData.conn);
                                    if ((table.DT.Rows.Count > 0) && (table.DT.Rows[0]["protectExcel"].ToString() == "Y"))
                                    {
                                        workbook.Password = shoot(table.DT.Rows[0]["passwordExcel"].ToString(), false);
                                    }
                                }
                                SaveFileDialog dialog = new SaveFileDialog {
                                    InitialDirectory = @"C:\",
                                    Title = "Save Excel Template",
                                    DefaultExt = "xlsx",
                                    Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                                    RestoreDirectory = true
                                };
                                if (title == "")
                                {
                                    title = "Book";
                                }
                                dialog.FileName = title + ".xlsx";
                                if (dialog.ShowDialog() == DialogResult.OK)
                                {
                                    workbook.SaveAs(dialog.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                                    workbook.Close(Type.Missing, Type.Missing, Type.Missing);
                                    application.Quit();
                                }
                            }
                            catch
                            {
                            }
                            return;
                        }
                        if (datatable.Rows[num3][0] != null)
                        {
                            int num4 = 1;
                            while (true)
                            {
                                if (num4 >= (datatable.Columns.Count + 1))
                                {
                                    num++;
                                    break;
                                }
                                try
                                {
                                    worksheet.Cells[num + 2, num4] = datatable.Rows[num3][num4 - 1].ToString();
                                }
                                catch
                                {
                                }
                                num4++;
                            }
                        }
                        num3++;
                    }
                }
                worksheet.Cells[1, num2 - 1] = datatable.Columns[num2 - 2].ToString();
                num2++;
            }
        }

        public static void export2Excel(DataGridView dataGridView1, string SAPDest, string title, bool toEncrypt = false)
        {
            _Application application = (Application) Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
            _Workbook workbook = application.Workbooks.Add(Type.Missing);
            _Worksheet worksheet = null;
            <>o__21.<>p__0 ??= CallSite<Func<CallSite, object, _Worksheet>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(_Worksheet), typeof(Program)));
            worksheet = <>o__21.<>p__0.Target(<>o__21.<>p__0, workbook.Sheets["Sheet1"]);
            <>o__21.<>p__1 ??= CallSite<Func<CallSite, object, _Worksheet>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(_Worksheet), typeof(Program)));
            worksheet = <>o__21.<>p__1.Target(<>o__21.<>p__1, workbook.ActiveSheet);
            worksheet.Name = "Exported from gridview";
            if (SAPDest == "TemplateAD")
            {
                worksheet.Name = "Active Directory Template";
                int num2 = 0;
                while (true)
                {
                    if (num2 >= dataGridView1.Columns.Count)
                    {
                        break;
                    }
                    worksheet.Cells[1, num2 + 1] = dataGridView1.Columns[num2].HeaderText;
                    num2++;
                }
            }
            else
            {
                int num3 = 2;
                while (true)
                {
                    if (num3 >= (dataGridView1.Columns.Count + 1))
                    {
                        break;
                    }
                    if (dataGridView1.Columns[num3 - 1].HeaderText.ToUpper().Equals("POSTED"))
                    {
                    }
                    if (!toEncrypt || !dataGridView1.Columns[num3 - 1].HeaderText.ToUpper().Equals("POSTED"))
                    {
                        worksheet.Cells[1, num3 - 1] = dataGridView1.Columns[num3 - 1].HeaderText;
                    }
                    num3++;
                }
            }
            int num = 0;
            int num4 = 0;
            while (true)
            {
                if (num4 >= dataGridView1.Rows.Count)
                {
                    try
                    {
                        if (SAPDest != "")
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_SAPDest", "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND SAPDest = '" + SAPDest + "'"), WBData.conn);
                            if ((table.DT.Rows.Count > 0) && (table.DT.Rows[0]["protectExcel"].ToString() == "Y"))
                            {
                                workbook.Password = shoot(table.DT.Rows[0]["passwordExcel"].ToString(), false);
                            }
                            table.Dispose();
                        }
                        SaveFileDialog dialog = new SaveFileDialog {
                            InitialDirectory = @"C:\",
                            Title = "Save Excel Template",
                            DefaultExt = "xlsx",
                            Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                            RestoreDirectory = true
                        };
                        if (title == "")
                        {
                            title = "Book";
                        }
                        dialog.FileName = title + ".xlsx";
                        excelSuccess = false;
                        if (dialog.ShowDialog() == DialogResult.OK)
                        {
                            string fileName = dialog.FileName;
                            if (!toEncrypt)
                            {
                                workbook.SaveAs(fileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                                workbook.Close(Type.Missing, Type.Missing, Type.Missing);
                                application.Quit();
                            }
                            else
                            {
                                string filename = Path.Combine(Application.UserAppDataPath, Path.GetFileName(fileName));
                                workbook.SaveAs(filename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                                workbook.Close(Type.Missing, Type.Missing, Type.Missing);
                                application.Quit();
                                if (!string.IsNullOrEmpty(GpgEncryptFile(filename, fileName + ".gpg", true)))
                                {
                                    MessageBox.Show("Encryption failed! Please contact Administrator to resolve this problem.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    break;
                                }
                            }
                            excelSuccess = true;
                        }
                    }
                    catch
                    {
                    }
                    break;
                }
                if ((SAPDest == "ZWB") || (SAPDest == ""))
                {
                    if (dataGridView1.Rows[num4].Cells[0].Value != null)
                    {
                        int num5 = 1;
                        while (true)
                        {
                            if (num5 >= dataGridView1.Columns.Count)
                            {
                                num++;
                                break;
                            }
                            try
                            {
                                worksheet.Cells[num + 2, num5] = dataGridView1.Rows[num4].Cells[num5].Value.ToString();
                            }
                            catch
                            {
                            }
                            num5++;
                        }
                    }
                }
                else if (SAPDest == "TemplateAD")
                {
                    if (dataGridView1.Rows[num4].Cells[0].Value != null)
                    {
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= dataGridView1.Columns.Count)
                            {
                                num++;
                                break;
                            }
                            try
                            {
                                worksheet.Cells[num + 2, num6 + 1] = dataGridView1.Rows[num4].Cells[num6].Value.ToString();
                            }
                            catch
                            {
                            }
                            num6++;
                        }
                    }
                }
                else if ((dataGridView1.Rows[num4].Cells[0].Value != null) && (dataGridView1.Rows[num4].Cells[0].Value.ToString() == "True"))
                {
                    int num7 = 1;
                    while (true)
                    {
                        if (num7 >= dataGridView1.Columns.Count)
                        {
                            num++;
                            break;
                        }
                        try
                        {
                            if (dataGridView1.Columns[num7].Name.ToUpper().Equals("POSTED"))
                            {
                            }
                            if (!toEncrypt || (!dataGridView1.Columns[num7].Name.ToUpper().Equals("POSTED") && !dataGridView1.Columns[num7].Name.ToUpper().Equals("GRN")))
                            {
                                worksheet.Cells[num + 2, num7] = !dataGridView1.Columns[num7].Name.ToUpper().Equals("MATERIAL") ? dataGridView1.Rows[num4].Cells[num7].Value.ToString() : ("'" + dataGridView1.Rows[num4].Cells[num7].Value.ToString());
                            }
                        }
                        catch
                        {
                        }
                        num7++;
                    }
                }
                num4++;
            }
        }

        public static string[] fillApproval()
        {
            FormApproval approval;
            string[] strArray = new string[] { approval.approve, approval.approveBy1, approval.approveBy2 };
            approval = new FormApproval {
                approve = "N"
            };
            approval.ShowDialog();
            approval.Dispose();
            return strArray;
        }

        public static string[] fillApproval(string msg)
        {
            FormApproval approval;
            string[] strArray = new string[] { approval.approve, approval.approveBy1, approval.approveBy2 };
            approval = new FormApproval();
            approval.Text = approval.Text + " ( " + msg + ")";
            approval.approve = "N";
            approval.ShowDialog();
            approval.Dispose();
            return strArray;
        }

        public static string[] fillApproval(string msg, string otoObj, string otoAct)
        {
            FormApproval approval;
            string[] strArray = new string[] { approval.approve, approval.approveBy1, approval.approveBy2, approval.appReason };
            approval = new FormApproval();
            approval.Text = approval.Text + " ( " + msg + ")";
            approval.otoAct = otoAct;
            approval.otoObj = otoObj;
            approval.approve = "N";
            approval.ShowDialog();
            approval.Dispose();
            return strArray;
        }

        public static List<Control> GetControls(Control form)
        {
            List<Control> list = new List<Control>();
            foreach (Control control in form.Controls)
            {
                list.AddRange(GetControls(control));
                list.Add(control);
            }
            return list;
        }

        public static string GetCPUId()
        {
            using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("SELECT * FROM Win32_processor").Get().GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    ManagementObject current = (ManagementObject) enumerator.Current;
                    if (current["ProcessorID"] != null)
                    {
                        return current["ProcessorID"].ToString().Trim();
                    }
                }
            }
            return string.Empty;
        }

        public static string getFieldValue(string tblName, string zField, string zKey, string zValue)
        {
            try
            {
                string str2;
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { "and ", zKey, "= '", zValue, "' " };
                string sqltext = ("select * from " + tblName + " where ") + WBData.CompanyLocation(string.Concat(textArray1));
                table.OpenTable(tblName, sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    str2 = "N";
                }
                table.DR = table.DT.Rows[0];
                str2 = table.DR[zField].ToString();
                table.Dispose();
                return str2;
            }
            catch
            {
                return "N";
            }
        }

        public static string GetHDDSerial()
        {
            using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia").Get().GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    ManagementObject current = (ManagementObject) enumerator.Current;
                    if (current["SerialNumber"] != null)
                    {
                        return current["SerialNumber"].ToString().Trim();
                    }
                }
            }
            return string.Empty;
        }

        public static string getSplitGross(string refNo)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string str = " ";
            string str2 = "";
            str2 = !char.IsNumber(refNo.Substring(refNo.Length - 1, 1)[0]) ? refNo.Substring(0, refNo.Length - 1) : refNo;
            table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE zauto <> 'Y' AND ref like '" + str2 + "%'", WBData.conn);
            if (table.DT.Rows.Count > 1)
            {
                table2.OpenTable("wb_transDO", "SELECT sum(Bruto) as B, sum(Tarra) as T FROM wb_transDO WHERE ref like '" + str2 + "%'", WBData.conn);
                if (table2.DT.Rows.Count == 1)
                {
                    table2.DR = table2.DT.Rows[0];
                    object[] objArray1 = new object[] { "Total Gross: ", table2.DR["B"], " KG - Total Tarra: ", table2.DR["T"], " KG " };
                    str = string.Concat(objArray1);
                }
            }
            return str;
        }

        public static string GPC(string par)
        {
            string str = "";
            long num = 0L;
            long num2 = 0L;
            byte[] bytes = Encoding.ASCII.GetBytes(par);
            int index = 0;
            while (true)
            {
                if (index >= par.Length)
                {
                    num = 0L;
                    num2 = str.Length / 12;
                    for (int i = 1; i <= num2; i++)
                    {
                        num += Convert.ToInt64(str.Substring((i * 12) - 12, 12));
                    }
                    return num.ToString();
                }
                str = str + bytes[index].ToString();
                index++;
            }
        }

        public static string GpgEncryptFile(string sourceFileName, string targetFileName, bool deleteSource)
        {
            string str3;
            string str4;
            FileInfo[] files;
            int num;
            string encryptRecipient = WBSetting.encryptRecipient;
            DirectoryInfo info = new DirectoryInfo(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "temporary"));
            Process process = new Process();
            if (!info.Exists)
            {
                goto TR_0003;
            }
            else
            {
                str4 = "";
                files = info.GetFiles();
                num = 0;
            }
            goto TR_000C;
        TR_0003:
            str3 = "";
            process = new Process {
                StartInfo = { 
                    FileName = "gpg2",
                    UseShellExecute = false,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    Arguments = $" --trust-model=always --yes --batch --output "{targetFileName}" --encrypt --recipient "{encryptRecipient}" "{sourceFileName}""
                }
            };
            process.Start();
            str3 = process.StandardError.ReadToEnd();
            process.WaitForExit();
            if (deleteSource)
            {
                try
                {
                    File.Delete(sourceFileName);
                }
                catch
                {
                }
            }
            return str3;
        TR_000C:
            while (true)
            {
                if (num < files.Length)
                {
                    FileInfo info2 = files[num];
                    if (info2.Extension.ToUpper().Equals(".ASC"))
                    {
                        process.StartInfo.FileName = "gpg2";
                        process.StartInfo.UseShellExecute = false;
                        process.StartInfo.RedirectStandardError = true;
                        process.StartInfo.CreateNoWindow = true;
                        process.StartInfo.Arguments = $" --import "{info2.FullName}"";
                        process.Start();
                        str4 = str4 + process.StandardError.ReadToEnd();
                        process.WaitForExit();
                        try
                        {
                            File.Delete(info2.FullName);
                        }
                        catch
                        {
                        }
                    }
                }
                else
                {
                    goto TR_0003;
                }
                break;
            }
            num++;
            goto TR_000C;
        }

        public static string GPK(string par)
        {
            string str = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str2 = "";
            int num3 = par.Length - 1;
            while (true)
            {
                if (num3 < 0)
                {
                    par = str2;
                    str2 = "";
                    int num = 0;
                    if (par.Length > 15)
                    {
                        par = par.Substring(0, 15);
                    }
                    long num2 = Convert.ToInt64(par);
                    par = ((num2 <= 0x3b9aca00L) ? ((num2 / 0x86L) * 4L) : ((num2 / 0x95L) * 3L)).ToString();
                    byte[] bytes = Encoding.ASCII.GetBytes(par);
                    for (int i = 0; i < par.Length; i++)
                    {
                        num = (bytes[i] + par[i]) % str.Length;
                        str2 = str2 + str[num].ToString();
                    }
                    return str2;
                }
                str2 = str2 + par[num3].ToString();
                num3--;
            }
        }

        public static SerialPort InitPort()
        {
            WBSetting.OpenSetting();
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
            try
            {
                serialPort1.ReadTimeout = 0x3e8;
                serialPort1.ReadBufferSize = Convert.ToInt32(WBSetting.Buffer);
                serialPort1.PortName = WBSetting.CommPort;
                serialPort1.BaudRate = Convert.ToInt32(WBSetting.BaudRate);
                serialPort1.DataBits = Convert.ToInt32(WBSetting.DataBits);
                serialPort1.Parity = (WBSetting.parity == "None") ? Parity.None : ((WBSetting.parity == "Even") ? Parity.Even : Parity.Odd);
                serialPort1.StopBits = (WBSetting.Stopbits == "One") ? StopBits.One : StopBits.Two;
                serialPort1.RtsEnable = true;
                serialPort1.DtrEnable = true;
                return serialPort1;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Title_003 + ": " + exception.Message);
                return serialPort1;
            }
        }

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (CheckRegistry() && (ReadConfig() && WBDatabase.Open()))
            {
                TCSDatabase.Open();
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
                if (WBData.sLanguage == "1")
                {
                    Thread.CurrentThread.CurrentUICulture = new CultureInfo("fr");
                }
                else if (WBData.sLanguage == "2")
                {
                    Thread.CurrentThread.CurrentUICulture = new CultureInfo("id");
                }
                if (WBUser.Login())
                {
                    if (WBData.sRegion == "1")
                    {
                        mainformAfrica = new MainFormAfrica();
                        Application.Run(mainformAfrica);
                    }
                    else
                    {
                        WBSetting.OpenSetting(true);
                        if (WBSetting.cpuSAP == "Y")
                        {
                            FormAutoSync = new WindowsFormsApplication1.FormAutoSync();
                            Application.Run(FormAutoSync);
                        }
                        else
                        {
                            mainform = new MainForm();
                            Application.Run(mainform);
                        }
                    }
                }
            }
        }

        public static string omit_last_chars(string chars)
        {
            string str3;
            string objA = chars;
            if (ReferenceEquals(objA, null))
            {
                str3 = null;
            }
            else
            {
                int length = objA.Length;
                int num3 = 0;
                int num4 = 0;
                while (true)
                {
                    int num2;
                    if (num4 > (length - 1))
                    {
                        str3 = chars.Substring(0, length - num3);
                        break;
                    }
                    string s = objA.Substring((length - 1) - num4, 1);
                    if (int.TryParse(s, out num2))
                    {
                        num4 = length;
                    }
                    else
                    {
                        num3++;
                    }
                    num4++;
                }
            }
            return str3;
        }

        private static bool ReadConfig()
        {
            bool pReturn = false;
            WBConfigurationHandler.createDirectory();
            if (!File.Exists(WBConfigurationHandler.configurationFile))
            {
                FormCfg cfg3 = new FormCfg {
                    firstrun = true
                };
                try
                {
                    RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                    if (!ReferenceEquals(key2.OpenSubKey("WCS DATABASE", true), null))
                    {
                        RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                        WBData.sServer = (string) key4.GetValue("Server");
                        WBData.sDatabase = (string) key4.GetValue("Database");
                        WBData.sUserID = shoot((string) key4.GetValue("UserID"), false);
                        WBData.sPassword = shoot((string) key4.GetValue("Password"), false);
                        WBData.sCoyCode = (string) key4.GetValue("Coy_Code");
                        WBData.sLocCode = (string) key4.GetValue("Loc_Code");
                        WBData.sWBCode = (string) key4.GetValue("WBCode");
                        WBData.sRegion = (string) key4.GetValue("Region");
                        WBData.sLanguage = (string) key4.GetValue("Language");
                        WBData.sCheckDirect = (string) key4.GetValue("DirectToPrinter");
                        string str6 = "_SEM_1";
                        if (Convert.ToInt32(DateTime.Today.ToString("MM")) > 6)
                        {
                            str6 = "_SEM_2";
                        }
                        WBData.sDatabase_album = "wb_album_" + DateTime.Today.ToString("yyyy") + str6;
                        WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                        Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                            { 
                                "SERVER",
                                WBData.sServer
                            },
                            { 
                                "DATABASE",
                                WBData.sDatabase
                            },
                            { 
                                "USERID",
                                WBData.sUserID
                            },
                            { 
                                "PASSWORD",
                                WBData.sPassword
                            },
                            { 
                                "COY",
                                WBData.sCoyCode
                            },
                            { 
                                "LOC",
                                WBData.sLocCode
                            },
                            { 
                                "WBCODE",
                                WBData.sWBCode
                            },
                            { 
                                "REGION",
                                WBData.sRegion
                            },
                            { 
                                "LANGUAGE",
                                WBData.sLanguage
                            },
                            { 
                                "DIRECTPRINTING",
                                WBData.sCheckDirect
                            }
                        };
                        WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                        dictToTxt.Clear();
                        return true;
                    }
                    else
                    {
                        cfg3.ShowDialog();
                        string str5 = "_SEM_1";
                        if (Convert.ToInt32(DateTime.Today.ToString("MM")) > 6)
                        {
                            str5 = "_SEM_2";
                        }
                        WBData.sDatabase_album = "wb_album_" + DateTime.Today.ToString("yyyy") + str5;
                        pReturn = cfg3.pReturn;
                    }
                }
                catch
                {
                    cfg3.ShowDialog();
                    pReturn = cfg3.pReturn;
                }
            }
            else
            {
                Dictionary<string, string> dict = WBConfigurationHandler.readFromTxt(WBConfigurationHandler.configurationFile);
                if (string.IsNullOrEmpty(WBConfigurationHandler.dictionaryToString(dict)))
                {
                    FormCfg cfg = new FormCfg {
                        firstrun = true
                    };
                    cfg.ShowDialog();
                    string str2 = "_SEM_1";
                    if (Convert.ToInt32(DateTime.Today.ToString("MM")) > 6)
                    {
                        str2 = "_SEM_2";
                    }
                    WBData.sDatabase_album = "wb_album_" + DateTime.Today.ToString("yyyy") + str2;
                    pReturn = cfg.pReturn;
                }
                else
                {
                    WBData.sServer = dict.ContainsKey("SERVER") ? dict["SERVER"] : "";
                    WBData.sDatabase = dict.ContainsKey("DATABASE") ? dict["DATABASE"] : "";
                    WBData.sUserID = dict.ContainsKey("USERID") ? dict["USERID"] : "";
                    WBData.sPassword = dict.ContainsKey("PASSWORD") ? dict["PASSWORD"] : "";
                    WBData.sCoyCode = dict.ContainsKey("COY") ? dict["COY"] : "";
                    WBData.sLocCode = dict.ContainsKey("LOC") ? dict["LOC"] : "";
                    WBData.sWBCode = dict.ContainsKey("WBCODE") ? dict["WBCODE"] : "";
                    WBData.sRegion = dict.ContainsKey("REGION") ? dict["REGION"] : "";
                    WBData.sLanguage = dict.ContainsKey("LANGUAGE") ? dict["LANGUAGE"] : "";
                    WBData.sCheckDirect = dict.ContainsKey("DIRECTPRINTING") ? dict["DIRECTPRINTING"] : "";
                    if (WBData.sWBCode != "")
                    {
                        string str4 = "_SEM_1";
                        if (Convert.ToInt32(DateTime.Today.ToString("MM")) > 6)
                        {
                            str4 = "_SEM_2";
                        }
                        WBData.sDatabase_album = "wb_album_" + DateTime.Today.ToString("yyyy") + str4;
                        pReturn = true;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Login_009, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        FormCfg cfg2 = new FormCfg();
                        cfg2.ShowDialog();
                        string str3 = "_SEM_1";
                        if (Convert.ToInt32(DateTime.Today.ToString("MM")) > 6)
                        {
                            str3 = "_SEM_2";
                        }
                        WBData.sDatabase_album = "wb_album_" + DateTime.Today.ToString("yyyy") + str3;
                        pReturn = cfg2.pReturn;
                    }
                }
            }
            return pReturn;
        }

        public static void RedRecord(DataGridView dataGridView1, string[] aCond)
        {
            int num = 0;
            while (true)
            {
                if (num >= dataGridView1.Rows.Count)
                {
                    dataGridView1.Refresh();
                    return;
                }
                if (dataGridView1.Rows[num].Cells[aCond[0]].Value.ToString() == aCond[1])
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= dataGridView1.Rows[num].Cells.Count)
                        {
                            break;
                        }
                        dataGridView1.Rows[num].Cells[num2].Style.BackColor = Color.Red;
                        dataGridView1.Rows[num].Cells[num2].Style.SelectionBackColor = Color.HotPink;
                        num2++;
                    }
                }
                num++;
            }
        }

        public static void ReplaceAll(string sTable, string[] aField, string[] aNewValue, string Condition, string reason)
        {
            WBTable table = new WBTable();
            string str = "";
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            if (sTable == "wb_transaction")
            {
                str = "*";
            }
            else
            {
                int index = 0;
                while (true)
                {
                    if (index >= aField.Length)
                    {
                        str = str + "Uniq";
                        break;
                    }
                    str = str + aField[index].Trim() + ",";
                    index++;
                }
            }
            string[] textArray1 = new string[] { "SELECT ", str, " FROM ", sTable, " WHERE ", WBData.CompanyLocation(" AND " + Condition) };
            table.OpenTable(sTable, string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                string[] strArray = new string[table.DT.Rows.Count];
                Cursor.Current = Cursors.WaitCursor;
                int num2 = 1;
                foreach (DataRow row in table.DT.Rows)
                {
                    strArray[num2 - 1] = row["uniq"].ToString();
                    flag = false;
                    flag2 = false;
                    flag3 = false;
                    num2++;
                    row.BeginEdit();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= aField.Length)
                        {
                            if (sTable == "wb_transaction")
                            {
                                if (WBSetting.zwb != "Y")
                                {
                                    row["posted"] = "N";
                                }
                                else
                                {
                                    if (flag2)
                                    {
                                        row["posted"] = "N";
                                    }
                                    if (flag3)
                                    {
                                        row["reposted"] = "N";
                                    }
                                }
                                row["checksum"] = table.Checksum(row);
                                if (row["posted"].ToString() == "N")
                                {
                                    WBTable table3 = new WBTable();
                                    string[] textArray3 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref like '", row["ref"].ToString(), "%'  AND ref != '", row["ref"].ToString(), "' " };
                                    table3.OpenTable("wb_transaction", string.Concat(textArray3), WBData.conn);
                                    string[] strArray2 = new string[table3.DT.Rows.Count];
                                    int num4 = 0;
                                    foreach (DataRow row2 in table3.DT.Rows)
                                    {
                                        strArray2[num4] = row2["uniq"].ToString();
                                        row2.BeginEdit();
                                        row2["posted"] = "N";
                                        row2["reposted"] = "N";
                                        row2["checksum"] = table3.Checksum(row2);
                                        row2.EndEdit();
                                        num4++;
                                    }
                                    table3.Save();
                                    table3.Dispose();
                                    int num5 = 0;
                                    while (true)
                                    {
                                        if (num5 >= strArray2.Length)
                                        {
                                            break;
                                        }
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, reason.Replace(")", "") + " of main transaction)" };
                                        updateLogHeader(sTable, strArray2[num5], logField, logValue);
                                        num5++;
                                    }
                                }
                            }
                            row.EndEdit();
                            break;
                        }
                        if (row[aField[num3].Trim()].ToString().Trim() != aNewValue[num3].ToString().Trim())
                        {
                            if (WBSetting.zwb == "Y")
                            {
                                WBTable table2 = new WBTable();
                                string[] textArray2 = new string[] { " AND modul = 'ZWB' and Table_Name = '", sTable, "' AND field_wb = '", aField[num3].Trim(), "'" };
                                table2.OpenTable("wb_templateSAP", "SELECT * from wb_templateSAP WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                if (table2.DT.Rows.Count > 0)
                                {
                                    if (table2.DT.Rows[0]["important"].ToString() == "N")
                                    {
                                        flag3 = true;
                                    }
                                    else
                                    {
                                        flag2 = true;
                                    }
                                }
                                table2.Dispose();
                            }
                            flag = true;
                            row[aField[num3].Trim()] = aNewValue[num3].Trim();
                        }
                        num3++;
                    }
                }
                table.Save();
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        Cursor.Current = Cursors.Default;
                        break;
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, reason };
                    updateLogHeader(sTable, strArray[index], logField, logValue);
                    index++;
                }
            }
            table.Close();
            table.Dispose();
            if (WBData.sRegion == "1")
            {
                mainformAfrica.DataReset();
            }
            else
            {
                mainform.DataReset();
            }
        }

        public static void ReplaceAllExceptTransporter(string sTable, string[] aField, string[] aNewValue, string Condition, string reason)
        {
            WBTable table = new WBTable();
            string str = "";
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            bool flag4 = false;
            if (sTable != "wb_transaction")
            {
                int index = 0;
                while (true)
                {
                    if (index >= aField.Length)
                    {
                        str = str + "Uniq";
                        break;
                    }
                    str = str + aField[index].Trim() + ",";
                    index++;
                }
            }
            else
            {
                str = "*";
                string[] strArray2 = aField;
                int index = 0;
                while (true)
                {
                    if (index >= strArray2.Length)
                    {
                        if (flag3 | flag4)
                        {
                            List<string> list = aField.ToList<string>();
                            list.Remove("sto");
                            list.Remove("sto_Item");
                            aField = list.ToArray();
                        }
                        break;
                    }
                    string str2 = strArray2[index];
                    if (str2 == "sto")
                    {
                        flag3 = true;
                    }
                    if (str2 == "sto_Item")
                    {
                        flag4 = true;
                    }
                    index++;
                }
            }
            string[] textArray1 = new string[] { "SELECT ", str, " FROM ", sTable, " WHERE ", WBData.CompanyLocation(" AND " + Condition) };
            table.OpenTable(sTable, string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                Cursor.Current = Cursors.WaitCursor;
                int num3 = 1;
                string[] strArray = new string[table.DT.Rows.Count];
                foreach (DataRow row in table.DT.Rows)
                {
                    flag = false;
                    flag2 = false;
                    strArray[num3 - 1] = row["uniq"].ToString();
                    num3++;
                    row.BeginEdit();
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= aField.Length)
                        {
                            if (sTable == "wb_transaction")
                            {
                                if (WBSetting.zwb != "Y")
                                {
                                    row["posted"] = "N";
                                }
                                else
                                {
                                    if (flag)
                                    {
                                        row["posted"] = "N";
                                    }
                                    if (flag2)
                                    {
                                        row["reposted"] = "N";
                                    }
                                    if (flag3 | flag4)
                                    {
                                        row["reposted"] = "N";
                                        row["posted"] = "N";
                                    }
                                }
                                row["checksum"] = table.Checksum(row);
                                if (row["posted"].ToString() == "N")
                                {
                                    WBTable table3 = new WBTable();
                                    string[] textArray3 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref like '", row["ref"].ToString(), "%'  AND ref != '", row["ref"].ToString(), "' " };
                                    table3.OpenTable("wb_transaction", string.Concat(textArray3), WBData.conn);
                                    string[] strArray3 = new string[table3.DT.Rows.Count];
                                    int num5 = 0;
                                    foreach (DataRow row2 in table3.DT.Rows)
                                    {
                                        strArray3[num5] = row2["uniq"].ToString();
                                        row2.BeginEdit();
                                        row2["posted"] = "N";
                                        row2["reposted"] = "N";
                                        row2["checksum"] = table3.Checksum(row2);
                                        row2.EndEdit();
                                        num5++;
                                    }
                                    table3.Save();
                                    table3.Dispose();
                                    int num6 = 0;
                                    while (true)
                                    {
                                        if (num6 >= strArray3.Length)
                                        {
                                            break;
                                        }
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, reason.Replace(")", "") + " of main transaction)" };
                                        updateLogHeader(sTable, strArray3[num6], logField, logValue);
                                        num6++;
                                    }
                                }
                            }
                            row.EndEdit();
                            break;
                        }
                        if (((num4 != 0) || (row["transporter_code"].ToString() == "")) && (row[aField[num4].Trim()].ToString().Trim() != aNewValue[num4].ToString().Trim()))
                        {
                            if (WBSetting.zwb == "Y")
                            {
                                WBTable table2 = new WBTable();
                                string[] textArray2 = new string[] { " AND modul = 'ZWB' and Table_Name = '", sTable, "' AND field_wb = '", aField[num4].Trim(), "'" };
                                table2.OpenTable("wb_templateSAP", "SELECT * from wb_templateSAP WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                if (table2.DT.Rows.Count > 0)
                                {
                                    if (table2.DT.Rows[0]["important"].ToString() == "N")
                                    {
                                        flag2 = true;
                                    }
                                    else
                                    {
                                        flag = true;
                                    }
                                }
                                table2.Dispose();
                            }
                            row[aField[num4].Trim()] = aNewValue[num4].Trim();
                        }
                        num4++;
                    }
                }
                table.Save();
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        Cursor.Current = Cursors.Default;
                        break;
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, reason };
                    updateLogHeader(sTable, strArray[index], logField, logValue);
                    index++;
                }
            }
            table.Close();
            table.Dispose();
            mainform.DataReset();
        }

        public static void ReplaceInCompany(string sTable, string[] aField, string[] aNewValue, string Condition, string reason)
        {
            if (WBSetting.copyToLoc != "Y")
            {
                ReplaceAll(sTable, aField, aNewValue, Condition, reason);
            }
            else
            {
                WBTable table = new WBTable();
                string str = "";
                bool flag2 = false;
                bool flag3 = false;
                if (sTable == "wb_transaction")
                {
                    str = "*";
                }
                else
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= aField.Length)
                        {
                            str = str + "Uniq";
                            break;
                        }
                        str = str + aField[index].Trim() + ",";
                        index++;
                    }
                }
                string[] textArray1 = new string[] { "SELECT ", str, " FROM ", sTable, " WHERE ", WBData.CompanyLocation(" AND " + Condition) };
                table.OpenTable(sTable, string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    int num2 = 1;
                    string[] strArray = new string[table.DT.Rows.Count];
                    foreach (DataRow row in table.DT.Rows)
                    {
                        flag2 = false;
                        flag3 = false;
                        strArray[num2 - 1] = row["uniq"].ToString();
                        num2++;
                        row.BeginEdit();
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= aField.Length)
                            {
                                if (sTable == "wb_transaction")
                                {
                                    if (WBSetting.zwb != "Y")
                                    {
                                        row["posted"] = "N";
                                    }
                                    else
                                    {
                                        if (flag2)
                                        {
                                            row["posted"] = "N";
                                        }
                                        if (flag3)
                                        {
                                            row["reposted"] = "N";
                                        }
                                    }
                                    row["checksum"] = table.Checksum(row);
                                    if (row["posted"].ToString() == "N")
                                    {
                                        WBTable table3 = new WBTable();
                                        string[] textArray3 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref like '", row["ref"].ToString(), "%'  AND ref != '", row["ref"].ToString(), "' " };
                                        table3.OpenTable("wb_transaction", string.Concat(textArray3), WBData.conn);
                                        string[] strArray2 = new string[table3.DT.Rows.Count];
                                        int num4 = 0;
                                        foreach (DataRow row2 in table3.DT.Rows)
                                        {
                                            strArray2[num4] = row2["uniq"].ToString();
                                            row2.BeginEdit();
                                            row2["posted"] = "N";
                                            row2["reposted"] = "N";
                                            row2["checksum"] = table3.Checksum(row2);
                                            row2.EndEdit();
                                            num4++;
                                        }
                                        table3.Save();
                                        table3.Dispose();
                                        int num5 = 0;
                                        while (true)
                                        {
                                            if (num5 >= strArray2.Length)
                                            {
                                                break;
                                            }
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, reason.Replace(")", "") + " of main transaction)" };
                                            updateLogHeader(sTable, strArray2[num5], logField, logValue);
                                            num5++;
                                        }
                                    }
                                }
                                row.EndEdit();
                                break;
                            }
                            if (row[aField[num3].Trim()].ToString().Trim() != aNewValue[num3].ToString().Trim())
                            {
                                if (WBSetting.zwb == "Y")
                                {
                                    WBTable table2 = new WBTable();
                                    string[] textArray2 = new string[] { " AND modul = 'ZWB' and Table_Name = '", sTable, "' AND field_wb = '", aField[num3].Trim(), "'" };
                                    table2.OpenTable("wb_templateSAP", "SELECT * from wb_templateSAP WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                    if (table2.DT.Rows.Count > 0)
                                    {
                                        if (table2.DT.Rows[0]["important"].ToString() == "N")
                                        {
                                            flag3 = true;
                                        }
                                        else
                                        {
                                            flag2 = true;
                                        }
                                    }
                                    table2.Dispose();
                                }
                                row[aField[num3].Trim()] = aNewValue[num3].Trim();
                            }
                            num3++;
                        }
                    }
                    table.Save();
                    int index = 0;
                    while (true)
                    {
                        if (index >= strArray.Length)
                        {
                            Cursor.Current = Cursors.Default;
                            break;
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, reason };
                        updateLogHeader(sTable, strArray[index], logField, logValue);
                        index++;
                    }
                }
                table.Close();
                table.Dispose();
                mainform.DataReset();
            }
        }

        public static double RoundbyTen(double number)
        {
            number = ((int) ((number + 5.0) / 10.0)) * 10;
            return number;
        }

        public static ReportDocument rptLogon(ReportDocument cryRpt)
        {
            TableLogOnInfos infos = new TableLogOnInfos();
            TableLogOnInfo logonInfo = new TableLogOnInfo();
            ConnectionInfo info2 = new ConnectionInfo {
                ServerName = WBData.sServer,
                DatabaseName = WBData.sDatabase,
                UserID = WBData.sUserID,
                Password = WBData.sPassword
            };
            foreach (Table table in cryRpt.Database.Tables)
            {
                logonInfo = table.LogOnInfo;
                logonInfo.ConnectionInfo = info2;
                table.ApplyLogOnInfo(logonInfo);
            }
            cryRpt.Refresh();
            return cryRpt;
        }

        public static ReportDocument setParam(string rptName, string[] paramName, string[] paramValue)
        {
            Cursor.Current = Cursors.WaitCursor;
            ReportDocument cryRpt = new ReportDocument();
            cryRpt.Load(WBData.rptPath + rptName);
            cryRpt = rptLogon(cryRpt);
            for (int i = 0; i < paramName.Length; i++)
            {
                cryRpt.SetParameterValue(paramName[i].Trim(), paramValue[i].Trim());
            }
            return cryRpt;
        }

        public static ReportDocument setParam2(ReportDocument cryRpt, string[] paramName, string[] paramValue)
        {
            for (int i = 0; i < paramName.Length; i++)
            {
                cryRpt.SetParameterValue(paramName[i].Trim(), paramValue[i].Trim());
            }
            return cryRpt;
        }

        public static string shoot(string txt, bool cak) => 
            cak ? WBEncryption.Encrypt(txt) : WBEncryption.Decrypt(txt);

        public static string shoot_old(string txt, bool cak)
        {
            string str = @"AlmnBDpEFTUGHIJKL@#$%M2NQPSVWCXYRZ1/\360 abcd789efgOh45ijkrstuvwoqxyz_~!^&*()-+=|;,.:";
            string str2 = @" _~!@4#yYz$%^&*()0912653aAbBcCdQEfFgGhHwX8\/7iIjJk|tTuUKDeqlLmM;,.:nNoWxOpPrRsSvVZ-+=";
            string str3 = "";
            int num = 0;
            int num2 = 0;
            for (num2 = 0; num2 < txt.Length; num2++)
            {
                if (cak)
                {
                    char[] anyOf = new char[] { txt[num2] };
                    num = str.IndexOfAny(anyOf);
                    str3 = (num <= -1) ? (str3 + anyOf[0].ToString()) : (str3 + str2[num].ToString());
                }
                else
                {
                    char[] anyOf = new char[] { txt[num2] };
                    num = str2.IndexOfAny(anyOf);
                    str3 = (num <= -1) ? (str3 + anyOf[0].ToString()) : (str3 + str[num].ToString());
                }
            }
            return str3;
        }

        public static double StrToDouble(string pArg, int pDec)
        {
            if (pArg == "")
            {
                pArg = "0";
            }
            return Math.Round((double) ((float) Convert.ToDecimal((pArg.Trim() == "") ? "0" : pArg)), pDec, MidpointRounding.AwayFromZero);
        }

        public static double StrToNum(string pStr)
        {
            double num = 0.0;
            pStr = pStr.Trim();
            byte[] bytes = Encoding.ASCII.GetBytes(pStr);
            for (int i = 0; i < pStr.Length; i++)
            {
                num += bytes[i];
            }
            return num;
        }

        public static void unblock_os_bc(string DoNo, string Ref)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[] { " and ref = '", Ref, "' and do_no = '", DoNo, "'" };
            table.OpenTable("wb_tranbc", "select * from wb_transBC where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            table2.OpenTable("wb_contract_detail_bc", "select * from wb_contract_detail_bc where " + WBData.CompanyLocation(" and do_no = '" + DoNo + "' and BC_OS_Closed = 'Y'"), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table.DT.Rows.Count)
                    {
                        break;
                    }
                    string[] aField = new string[] { "BC_NO", "BC_Item" };
                    string[] aFind = new string[] { table.DT.Rows[num2]["BC_No"].ToString(), table.DT.Rows[num2]["BC_Item"].ToString() };
                    int recNo = table2.GetRecNo(aField, aFind);
                    table2.DR = table2.DT.Rows[recNo];
                    table2.DR.BeginEdit();
                    table2.DR["BC_OS_Closed"] = "N";
                    table2.DR.EndEdit();
                    table2.Save();
                    num2++;
                }
            }
            table.Dispose();
            table2.Dispose();
        }

        public static void updateLogHeader(string tableName, string keyField, string[] logField, string[] logValue)
        {
            try
            {
                WBTable table = new WBTable();
                string sqltext = "";
                sqltext = (((tableName != "wb_camera") && (tableName != "wb_delivery_note")) && (tableName != "wb_vendor_nego")) ? ("SELECT * FROM wb_log_header WHERE " + WBData.CompanyLocation(" AND ")) : "SELECT * FROM wb_log_header WHERE ";
                string[] textArray1 = new string[] { sqltext, " tableName = '", tableName, "'  AND keyField = '", keyField, "'  AND PMode is null  AND UserID is null  AND ChangeReason is null  ORDER BY uniq DESC" };
                sqltext = string.Concat(textArray1);
                table.OpenTable("wb_log_header", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    int index = 0;
                    while (true)
                    {
                        if (index >= logField.Length)
                        {
                            table.DR.EndEdit();
                            table.Save();
                            break;
                        }
                        table.DR[logField[index].ToString()] = logValue[index].ToString();
                        index++;
                    }
                }
                table.Dispose();
            }
            catch
            {
            }
        }

        public static void updateLogHeader_otherLocations(string tableName, string keyField, string[] logField, string[] logValue, string coy, string loc)
        {
            WBTable table = new WBTable();
            string sqltext = "";
            string[] textArray1 = new string[10];
            textArray1[0] = sqltext;
            textArray1[1] = "SELECT * FROM wb_log_header  WHERE coy = '";
            textArray1[2] = coy;
            textArray1[3] = "'  AND location_code = '";
            textArray1[4] = loc;
            textArray1[5] = "'  AND tableName = '";
            textArray1[6] = tableName;
            textArray1[7] = "'  AND keyField = '";
            textArray1[8] = keyField;
            textArray1[9] = "'  AND PMode is null  AND UserID is null  AND ChangeReason is null  ORDER BY uniq DESC";
            sqltext = string.Concat(textArray1);
            table.OpenTable("wb_log_header", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                int index = 0;
                while (true)
                {
                    if (index >= logField.Length)
                    {
                        table.DR.EndEdit();
                        table.Save();
                        break;
                    }
                    table.DR[logField[index].ToString()] = logValue[index].ToString();
                    index++;
                }
            }
            table.Dispose();
        }

        public static void UpdateTransactionsPostedReposted(string Do_No, string reason)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND  Do_No='" + Do_No + "'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                string[] strArray = new string[table.DT.Rows.Count];
                Cursor.Current = Cursors.WaitCursor;
                int num = 1;
                foreach (DataRow row in table.DT.Rows)
                {
                    strArray[num - 1] = row["uniq"].ToString();
                    num++;
                    row.BeginEdit();
                    row["posted"] = "N";
                    row["reposted"] = "N";
                    row.EndEdit();
                }
                table.Save();
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        Cursor.Current = Cursors.Default;
                        break;
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, reason };
                    updateLogHeader("wb_transaction", strArray[index], logField, logValue);
                    index++;
                }
            }
            table.Close();
            table.Dispose();
        }

        [CompilerGenerated]
        private static class <>o__21
        {
            public static CallSite<Func<CallSite, object, _Worksheet>> <>p__0;
            public static CallSite<Func<CallSite, object, _Worksheet>> <>p__1;
        }

        [CompilerGenerated]
        private static class <>o__23
        {
            public static CallSite<Func<CallSite, object, _Worksheet>> <>p__0;
            public static CallSite<Func<CallSite, object, _Worksheet>> <>p__1;
        }
    }
}

