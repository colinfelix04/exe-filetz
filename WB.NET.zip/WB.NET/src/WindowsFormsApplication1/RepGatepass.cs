﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepGatepass : Form
    {
        public WBTable tblTruck = new WBTable();
        public WBTable tblCust = new WBTable();
        public WBTable tblDriver = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblTransType = new WBTable();
        public WBTable tblGatepassType1 = new WBTable();
        public WBTable tblGatepassType2 = new WBTable();
        public WBTable tblTAApprove = new WBTable();
        private string gatepassType1 = "";
        private string gatepassType2 = "";
        private string approveBy = "";
        private int maxRow = 0;
        private int currentRow = 0;
        private int rowNumber = 0;
        private IContainer components = null;
        public Label label3;
        public GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label2;
        public DateTimePicker monthCalendar2;
        private Panel panel1;
        public Label label5;
        private TextBox textTruck;
        private TextBox textGatepassType2;
        private TextBox textApprove;
        private TextBox textGatepassType1;
        private TextBox textType;
        private TextBox textTransporter;
        private TextBox textDriverID;
        public Label label6;
        public Label label7;
        public Label label8;
        public Label label9;
        public Label label10;
        public Label label11;
        public Label label12;
        private Panel panel2;
        private RadioButton radioSubmit;
        private RadioButton radioRejectMaterial;
        private RadioButton radioRejectVehicle;
        private RadioButton radio1st;
        private RadioButton radioYetApp;
        private RadioButton radioAll;
        public Label label4;
        public Label label13;
        public Button button2;
        public Button button1;
        public Label labelProses1;
        public Label labelProses2;
        private ComboBox comboDest;
        private Button buttonTransporter;
        private Button buttonTruck;
        private Button buttonDriver;
        private Button buttonType;
        private TextBox textMax;
        public Label label14;

        public RepGatepass()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.maxRow = Convert.ToInt16(this.textMax.Text);
            if (this.maxRow <= 0)
            {
                MessageBox.Show("", Resource.Title_002);
                this.textMax.Focus();
            }
            WBTable table = new WBTable();
            string sqltext = (("Select * From wb_gatepass where " + WBData.CompanyLocation("")) + " and ((IN_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and IN_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00'))";
            if (this.textTransporter.Text.Trim() != "")
            {
                sqltext = sqltext + " and Transporter_Code='" + this.textTransporter.Text.Trim() + "'";
            }
            if (this.textTruck.Text.Trim() != "")
            {
                sqltext = sqltext + " and Truck_NUmber='" + this.textTruck.Text.Trim() + "'";
            }
            if (this.textDriverID.Text.Trim() != "")
            {
                sqltext = sqltext + " and License_No='" + this.textDriverID.Text.Trim() + "'";
            }
            if (this.textType.Text.Trim() != "")
            {
                sqltext = sqltext + " and Transaction_Code='" + this.textType.Text.Trim() + "'";
            }
            if (this.textApprove.Text.Trim() != "")
            {
                sqltext = sqltext + " and Approve_By='" + this.approveBy + "'";
            }
            if (this.comboDest.Text.Trim() != "")
            {
                sqltext = (this.comboDest.Text.Trim() != "WB") ? (sqltext + " and WB= '1'") : (sqltext + " and WB='0'");
            }
            if (this.textGatepassType1.Text.Trim() != "")
            {
                sqltext = sqltext + " and gatepass_type1='" + this.gatepassType1 + "'";
            }
            if (this.textGatepassType2.Text.Trim() != "")
            {
                sqltext = sqltext + " and gatepass_type1='" + this.gatepassType2 + "'";
            }
            if (this.radioYetApp.Checked)
            {
                sqltext = sqltext + " and (approved ='Y' and (Ref is null or Ref = '')) ";
            }
            else if (this.radio1st.Checked)
            {
                sqltext = sqltext + " and (approved ='Y' and Ref is not null and (Out_date is null or Out_Date = '')) ";
            }
            else if (this.radioSubmit.Checked)
            {
                sqltext = sqltext + " and (submit_date is not null or submit_date <> '')";
            }
            else if (this.radioRejectVehicle.Checked)
            {
                sqltext = sqltext + " and Reject = 'Y' ";
            }
            else if (this.radioRejectMaterial.Checked)
            {
                sqltext = sqltext + " and Comm_Ret = 'Y' ";
            }
            sqltext = sqltext + " and (deleted is null or deleted = 'N') Order By TA_Number";
            table.OpenTable("view", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML rep = new HTML {
                    File = Application.StartupPath + @"\" + WBUser.UserID + "_ListofWeighing.htm",
                    Title = "List of Weighing"
                };
                rep.Open();
                rep.Write(rep.Style());
                rep.Write("<head><meta charset='UTF-8'></head>");
                rep.Write("<br><font size=5><b>GATEPASS REPORT</b></font><br>");
                string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                rep.Write(string.Concat(textArray1));
                string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font>" };
                rep.Write(string.Concat(textArray2));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    rep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font>");
                }
                else
                {
                    rep.Write("<br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    rep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br><br>");
                }
                else
                {
                    rep.Write("<br>");
                }
                rep.Write("<font size=3>");
                if (this.textTransporter.Text.Trim() != "")
                {
                    rep.Write("<br>Transporter : " + this.textTransporter.Text);
                }
                if (this.textTruck.Text.Trim() != "")
                {
                    rep.Write("<br>Truck : " + this.textTruck.Text);
                }
                if (this.textDriverID.Text.Trim() != "")
                {
                    rep.Write("<br>Driver ID : " + this.textDriverID.Text);
                }
                if (this.textType.Text.Trim() != "")
                {
                    rep.Write("<br>Transaction Type : " + this.textType.Text);
                }
                if (this.textApprove.Text.Trim() != "")
                {
                    rep.Write("<br>Approve By : " + this.textApprove.Text);
                }
                if (this.comboDest.Text.Trim() != "")
                {
                    rep.Write("<br>Destination : " + this.comboDest.Text);
                }
                if (this.textGatepassType1.Text.Trim() != "")
                {
                    rep.Write("<br>Category : " + this.textGatepassType1.Text);
                }
                if (this.textGatepassType2.Text.Trim() != "")
                {
                    rep.Write("<br>Sub Category : " + this.textGatepassType2.Text);
                }
                if (this.radioYetApp.Checked)
                {
                    rep.Write("<br>Display By : " + this.radioYetApp.Text);
                }
                else if (this.radio1st.Checked)
                {
                    rep.Write("<br>Display By : " + this.radio1st.Text);
                }
                else if (this.radioSubmit.Checked)
                {
                    rep.Write("<br>Display By : " + this.radioSubmit.Text);
                }
                else if (this.radioRejectVehicle.Checked)
                {
                    rep.Write("<br>Display By : " + this.radioRejectVehicle.Text);
                }
                else if (this.radioRejectMaterial.Checked)
                {
                    rep.Write("<br>Display By : " + this.radioRejectMaterial.Text);
                }
                rep.Write("<br>From : " + this.monthCalendar1.Value.ToShortDateString() + " To : " + this.monthCalendar2.Value.ToShortDateString());
                rep.Write("</font></b>");
                rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                this.rowNumber = 0;
                this.currentRow = 0;
                rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                this.labelProses1.Visible = true;
                this.labelProses2.Visible = true;
                this.labelProses2.Refresh();
                int count = table.DT.Rows.Count;
                this.labelProses1.Text = "1/" + count.ToString();
                this.labelProses1.Refresh();
                foreach (DataRow row in table.DT.Rows)
                {
                    this.rowNumber++;
                    this.labelProses1.Text = this.rowNumber.ToString() + "/" + table.DT.Rows.Count.ToString();
                    this.labelProses1.Refresh();
                    if ((this.rowNumber != 0) && (this.currentRow == this.maxRow))
                    {
                        rep.Write("</table>");
                        rep.Write("<br>");
                        rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        this.initHeader(rep);
                        this.currentRow = 0;
                    }
                    this.printDetails(this.rowNumber, rep, row);
                    this.currentRow++;
                }
                rep.Write("</table>");
                rep.Close();
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                };
                report.ShowDialog();
                rep.Dispose();
                report.Dispose();
                this.labelProses1.Text = "";
                this.labelProses2.Text = "";
                this.labelProses1.Visible = false;
                this.labelProses2.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.textDriverID.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriverID.Text = driver.ReturnRow["License_No"].ToString();
                this.textDriverID.Focus();
            }
            driver.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
                this.textTruck.Focus();
            }
            truck.Dispose();
        }

        private void comboDest_Leave(object sender, EventArgs e)
        {
            if ((this.comboDest.Text.Trim().ToUpper() != "WB") && (this.comboDest.Text.Trim().ToUpper() != "STORE"))
            {
                MessageBox.Show(Resource.Mes_582, Resource.Title_002);
                this.comboDest.SelectAll();
                this.comboDest.Focus();
            }
            if (this.comboDest.Text.Trim().ToUpper() == "WB")
            {
                this.approveBy = "01";
            }
            else if (this.comboDest.Text.Trim().ToUpper() == "STORE")
            {
                this.approveBy = "02";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center rowspan='2' nowrap><b>No.</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Truck_001 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Gatepass_001 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Trans_005 + "</b></td>");
            rep.Write("<td align=center colspan='2' nowrap><b>IN</b></td>");
            rep.Write("<td align=center colspan='2' nowrap><b>OUT</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.DriverE_001 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.DriverE_003 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.DoE_008 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Gatepass_023 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Truck_007 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Truck_008 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Upload_008 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Truck_010 + "</b></td>");
            rep.Write("<td align=center rowspan='2' nowrap><b>" + Resource.Contract_030 + "</b></td>");
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center nowrap><b>Date</b></td>");
            rep.Write("<td align=center nowrap><b>Time</b></td>");
            rep.Write("<td align=center nowrap><b>Date</b></td>");
            rep.Write("<td align=center nowrap><b>Time</b></td>");
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.label3 = new Label();
            this.groupDate = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.panel1 = new Panel();
            this.buttonType = new Button();
            this.buttonTransporter = new Button();
            this.buttonTruck = new Button();
            this.buttonDriver = new Button();
            this.comboDest = new ComboBox();
            this.label12 = new Label();
            this.label11 = new Label();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label8 = new Label();
            this.label7 = new Label();
            this.textGatepassType2 = new TextBox();
            this.textApprove = new TextBox();
            this.textGatepassType1 = new TextBox();
            this.textType = new TextBox();
            this.textTransporter = new TextBox();
            this.textDriverID = new TextBox();
            this.label6 = new Label();
            this.label5 = new Label();
            this.textTruck = new TextBox();
            this.panel2 = new Panel();
            this.radioSubmit = new RadioButton();
            this.radioRejectMaterial = new RadioButton();
            this.radioRejectVehicle = new RadioButton();
            this.radio1st = new RadioButton();
            this.radioYetApp = new RadioButton();
            this.radioAll = new RadioButton();
            this.label4 = new Label();
            this.label13 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.textMax = new TextBox();
            this.label14 = new Label();
            this.groupDate.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x18, 9);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x93, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Gatepass Report";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x1c, 0x29);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x19e, 0x2d);
            this.groupDate.TabIndex = 1;
            this.groupDate.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x54, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xd7, 0x13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x111, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.buttonType);
            this.panel1.Controls.Add(this.buttonTransporter);
            this.panel1.Controls.Add(this.buttonTruck);
            this.panel1.Controls.Add(this.buttonDriver);
            this.panel1.Controls.Add(this.comboDest);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.textGatepassType2);
            this.panel1.Controls.Add(this.textApprove);
            this.panel1.Controls.Add(this.textGatepassType1);
            this.panel1.Controls.Add(this.textType);
            this.panel1.Controls.Add(this.textTransporter);
            this.panel1.Controls.Add(this.textDriverID);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textTruck);
            this.panel1.Location = new Point(0x1c, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x124, 0xde);
            this.panel1.TabIndex = 2;
            this.buttonType.Location = new Point(0xf9, 0x57);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x17, 0x17);
            this.buttonType.TabIndex = 0x22;
            this.buttonType.Text = "...";
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonTransporter.Location = new Point(0xf9, 0x3d);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 0x21;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.buttonTruck.Location = new Point(0xf9, 8);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 0x1f;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.buttonDriver.Location = new Point(0xf9, 0x23);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 0x20;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.comboDest.FormattingEnabled = true;
            object[] items = new object[] { "WB", "STORE" };
            this.comboDest.Items.AddRange(items);
            this.comboDest.Location = new Point(0x5d, 140);
            this.comboDest.Name = "comboDest";
            this.comboDest.Size = new Size(0x99, 0x15);
            this.comboDest.TabIndex = 0x10;
            this.comboDest.Leave += new EventHandler(this.comboDest_Leave);
            this.label12.Location = new Point(3, 0xc4);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x54, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Sub Category";
            this.label11.Location = new Point(3, 170);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x54, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Category";
            this.label10.Location = new Point(3, 0x90);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x54, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Destination";
            this.label9.Location = new Point(3, 0x76);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x54, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Approval";
            this.label8.Location = new Point(3, 0x5c);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x54, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Trans. Type";
            this.label7.Location = new Point(3, 0x42);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x54, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Transporter";
            this.textGatepassType2.Location = new Point(0x5d, 0xc1);
            this.textGatepassType2.Name = "textGatepassType2";
            this.textGatepassType2.Size = new Size(0x99, 20);
            this.textGatepassType2.TabIndex = 7;
            this.textGatepassType2.Leave += new EventHandler(this.textGatepassType2_Leave);
            this.textApprove.Location = new Point(0x5d, 0x73);
            this.textApprove.Name = "textApprove";
            this.textApprove.Size = new Size(0x99, 20);
            this.textApprove.TabIndex = 4;
            this.textApprove.Leave += new EventHandler(this.textApprove_Leave);
            this.textGatepassType1.Location = new Point(0x5d, 0xa7);
            this.textGatepassType1.Name = "textGatepassType1";
            this.textGatepassType1.Size = new Size(0x99, 20);
            this.textGatepassType1.TabIndex = 6;
            this.textGatepassType1.Leave += new EventHandler(this.textGatepassType1_Leave);
            this.textType.Location = new Point(0x5d, 0x59);
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x99, 20);
            this.textType.TabIndex = 3;
            this.textType.TextChanged += new EventHandler(this.textTransType_TextChanged);
            this.textType.Leave += new EventHandler(this.textTransType_Leave);
            this.textTransporter.Location = new Point(0x5d, 0x3f);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x99, 20);
            this.textTransporter.TabIndex = 2;
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.textDriverID.Location = new Point(0x5d, 0x25);
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.Size = new Size(0x99, 20);
            this.textDriverID.TabIndex = 1;
            this.textDriverID.Leave += new EventHandler(this.textDriverID_Leave);
            this.label6.Location = new Point(3, 40);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x54, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Driver";
            this.label5.Location = new Point(3, 13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x54, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Vehicle";
            this.textTruck.Location = new Point(0x5d, 8);
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x99, 20);
            this.textTruck.TabIndex = 0;
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.panel2.BorderStyle = BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.radioSubmit);
            this.panel2.Controls.Add(this.radioRejectMaterial);
            this.panel2.Controls.Add(this.radioRejectVehicle);
            this.panel2.Controls.Add(this.radio1st);
            this.panel2.Controls.Add(this.radioYetApp);
            this.panel2.Controls.Add(this.radioAll);
            this.panel2.Location = new Point(0x152, 130);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x101, 0xde);
            this.panel2.TabIndex = 3;
            this.radioSubmit.AutoSize = true;
            this.radioSubmit.Location = new Point(0x12, 0x5c);
            this.radioSubmit.Name = "radioSubmit";
            this.radioSubmit.Size = new Size(0x7c, 0x11);
            this.radioSubmit.TabIndex = 3;
            this.radioSubmit.Text = "Gatepass Yet Submit";
            this.radioSubmit.UseVisualStyleBackColor = true;
            this.radioRejectMaterial.AutoSize = true;
            this.radioRejectMaterial.Location = new Point(0x12, 0x90);
            this.radioRejectMaterial.Name = "radioRejectMaterial";
            this.radioRejectMaterial.Size = new Size(0x60, 0x11);
            this.radioRejectMaterial.TabIndex = 5;
            this.radioRejectMaterial.Text = "Reject Material";
            this.radioRejectMaterial.UseVisualStyleBackColor = true;
            this.radioRejectMaterial.CheckedChanged += new EventHandler(this.radioButton3_CheckedChanged);
            this.radioRejectVehicle.AutoSize = true;
            this.radioRejectVehicle.Location = new Point(0x12, 0x76);
            this.radioRejectVehicle.Name = "radioRejectVehicle";
            this.radioRejectVehicle.Size = new Size(0x5e, 0x11);
            this.radioRejectVehicle.TabIndex = 4;
            this.radioRejectVehicle.Text = "Reject Vehicle";
            this.radioRejectVehicle.UseVisualStyleBackColor = true;
            this.radio1st.AutoSize = true;
            this.radio1st.Location = new Point(0x12, 0x42);
            this.radio1st.Name = "radio1st";
            this.radio1st.Size = new Size(0x85, 0x11);
            this.radio1st.TabIndex = 2;
            this.radio1st.Text = "Vehicle Yet 1st Weight";
            this.radio1st.UseVisualStyleBackColor = true;
            this.radioYetApp.AutoSize = true;
            this.radioYetApp.Location = new Point(0x12, 40);
            this.radioYetApp.Name = "radioYetApp";
            this.radioYetApp.Size = new Size(0x7a, 0x11);
            this.radioYetApp.TabIndex = 1;
            this.radioYetApp.Text = "Vehicle Yet Approve";
            this.radioYetApp.UseVisualStyleBackColor = true;
            this.radioAll.AutoSize = true;
            this.radioAll.Checked = true;
            this.radioAll.Location = new Point(0x12, 0x11);
            this.radioAll.Name = "radioAll";
            this.radioAll.Size = new Size(0x24, 0x11);
            this.radioAll.TabIndex = 0;
            this.radioAll.TabStop = true;
            this.radioAll.Text = "All";
            this.radioAll.UseVisualStyleBackColor = true;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(40, 0x72);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2c, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Filter By";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(350, 0x72);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x38, 13);
            this.label13.TabIndex = 6;
            this.label13.Text = "Display By";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1e5, 0x175);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x171, 0x175);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelProses1.AutoSize = true;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x20d, 3);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0x37, 13);
            this.labelProses1.TabIndex = 0x31;
            this.labelProses1.Text = "1/88888";
            this.labelProses2.AutoSize = true;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x187, 14);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x30;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.textMax.Location = new Point(0x7a, 370);
            this.textMax.Name = "textMax";
            this.textMax.Size = new Size(0x21, 20);
            this.textMax.TabIndex = 0x9e;
            this.textMax.Text = "30";
            this.textMax.TextAlign = HorizontalAlignment.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(12, 0x175);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x66, 13);
            this.label14.TabIndex = 0x9d;
            this.label14.Text = "Max Row Per Page ";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x25e, 0x1a3);
            base.ControlBox = false;
            base.Controls.Add(this.textMax);
            base.Controls.Add(this.label14);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label13);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.label3);
            base.Name = "RepGatepass";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Gatepass Report";
            base.Load += new EventHandler(this.RepGatepass_Load);
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initTable()
        {
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblTAApprove.OpenTable("wb_TAApprove", "Select * from wb_TAApprove where " + WBData.CompanyLocation(""), WBData.conn);
            this.tblGatepassType1.OpenTable("wb_GatepassType1", "Select * from wb_GatepassType1 where 1=1", WBData.conn);
            this.tblGatepassType2.OpenTable("wb_GatepassType2", "Select * from wb_GatepassType2  where 1=1", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriverID);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblTAApprove, "ApproveCode", this.textApprove);
            Program.AutoComp(this.tblGatepassType1, "gatepass_typeName", this.textApprove);
            Program.AutoComp(this.tblGatepassType2, "gatepass_typeName", this.textApprove);
            Program.AutoComp(this.tblTransType, "Transaction_code", this.textType);
        }

        private void printDetails(int no, HTML rep, DataRow aRow)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap>" + rep.strq(no.ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["TA_Number"].ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["Gatepass_Number"].ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["Ref"].ToString()) + "</td>");
            if (aRow["IN_date"].ToString().Trim() != "")
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["IN_date"].ToString().Substring(0, 10)) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            if (aRow["IN_time"].ToString().Trim() != "")
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["IN_Time"].ToString().Substring(0, 5)) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            if (aRow["Out_date"].ToString().Trim() != "")
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Out_Date"].ToString().Substring(0, 10)) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            if (aRow["out_time"].ToString().Trim() != "")
            {
                rep.Write("<td nowrap>" + rep.strq(aRow["Out_time"].ToString().Substring(0, 5)) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            rep.Write("<td nowrap>" + rep.strq(aRow["License_no"].ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["Truck_number"].ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["Transporter_Code"].ToString()) + "</td>");
            rep.Write("<td nowrap>" + rep.strq(aRow["Transaction_code"].ToString()) + "</td>");
            string[] aField = new string[] { "gatepass_type1" };
            string[] aFind = new string[] { aRow["Gatepass_type1"].ToString() };
            DataRow data = this.tblGatepassType1.GetData(aField, aFind);
            if (data != null)
            {
                rep.Write("<td nowrap>" + rep.strq(data["gatepass_TypeName"].ToString()) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            string[] textArray3 = new string[] { "gatepass_type2" };
            string[] textArray4 = new string[] { aRow["Gatepass_type2"].ToString() };
            data = this.tblGatepassType2.GetData(textArray3, textArray4);
            if (data != null)
            {
                rep.Write("<td nowrap>" + rep.strq(data["gatepass_TypeName"].ToString()) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            if (aRow["WB"].ToString() == "0")
            {
                rep.Write("<td nowrap>" + rep.strq("WB") + "</td>");
            }
            else if (aRow["WB"].ToString() == "1")
            {
                rep.Write("<td nowrap>" + rep.strq("STORE") + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            string[] textArray5 = new string[] { "ApproveCode" };
            string[] textArray6 = new string[] { aRow["ApproveBy"].ToString() };
            data = this.tblTAApprove.GetData(textArray5, textArray6);
            if (data != null)
            {
                rep.Write("<td nowrap>" + rep.strq(data["ApproveName"].ToString()) + "</td>");
            }
            else
            {
                rep.Write("<td nowrap>&nbsp</td>");
            }
            rep.Write("<td nowrap>" + rep.strq(aRow["Gatepass_Remark"].ToString()) + "</td>");
            rep.Write("</tr>");
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void RepGatepass_Load(object sender, EventArgs e)
        {
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Rep01_043;
            this.label5.Text = Resource.Truck_003;
            this.label6.Text = Resource.TruckE_009;
            this.label7.Text = Resource.TruckE_010;
            this.label8.Text = Resource.TruckE_007;
            this.label9.Text = Resource.TruckE_013;
            this.label10.Text = Resource.Upload_008;
            this.label11.Text = Resource.Truck_007;
            this.label12.Text = Resource.Truck_008;
            this.label1.Text = Resource.Rep01_008;
            this.label2.Text = Resource.Rep01_009;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            this.labelProses1.Visible = false;
            this.labelProses2.Visible = false;
            this.initTable();
        }

        private void textApprove_Leave(object sender, EventArgs e)
        {
            if (this.textApprove.Text.Trim() != "")
            {
                this.tblTAApprove.ReOpen();
                string[] aField = new string[] { "ApproveCode" };
                string[] aFind = new string[] { this.textApprove.Text.Trim() };
                if (this.tblTAApprove.GetRecNo(aField, aFind) <= -1)
                {
                    MessageBox.Show(Resource.Mes_582, Resource.Title_002);
                    this.textApprove.SelectAll();
                    this.textApprove.Focus();
                }
            }
        }

        private void textDriverID_Leave(object sender, EventArgs e)
        {
            if (this.textDriverID.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                if (this.tblDriver.GetRecNo(aField, aFind) <= -1)
                {
                    MessageBox.Show(Resource.Mes_585, Resource.Title_002);
                    this.textDriverID.SelectAll();
                    this.textDriverID.Focus();
                }
            }
        }

        private void textGatepassType1_Leave(object sender, EventArgs e)
        {
            if (this.textGatepassType1.Text.Trim() != "")
            {
                this.tblGatepassType1.ReOpen();
                string[] aField = new string[] { "gatepass_typeName" };
                string[] aFind = new string[] { this.textGatepassType1.Text.Trim() };
                int recNo = this.tblGatepassType1.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.gatepassType1 = this.tblGatepassType1.DT.Rows[recNo]["Gatepass_type1"].ToString().Trim();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_584, Resource.Title_002);
                    this.textGatepassType1.SelectAll();
                    this.textGatepassType1.Focus();
                }
            }
        }

        private void textGatepassType2_Leave(object sender, EventArgs e)
        {
            if (this.textGatepassType2.Text.Trim() != "")
            {
                this.tblGatepassType2.ReOpen();
                string[] aField = new string[] { "gatepass_typeName" };
                string[] aFind = new string[] { this.textGatepassType2.Text.Trim() };
                int recNo = this.tblGatepassType2.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.gatepassType2 = this.tblGatepassType2.DT.Rows[recNo]["Gatepass_type2"].ToString().Trim();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_586, Resource.Title_002);
                    this.textGatepassType2.SelectAll();
                    this.textGatepassType2.Focus();
                }
            }
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (this.textTransporter.Text.Trim() != "")
            {
                this.tblTransporter.ReOpen();
                string[] aField = new string[] { "Transporter_code" };
                string[] aFind = new string[] { this.textTransporter.Text.Trim() };
                if (this.tblTransporter.GetRecNo(aField, aFind) <= -1)
                {
                    MessageBox.Show(Resource.Mes_588, Resource.Title_002);
                    this.textTransporter.SelectAll();
                    this.textTransporter.Focus();
                }
            }
        }

        private void textTransType_Leave(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { this.textType.Text.Trim() };
            int recNo = this.tblTransType.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.textType.Text = this.tblTransType.DT.Rows[recNo]["Transaction_Code"].ToString();
            }
            else
            {
                MessageBox.Show(Resource.Mes_587, Resource.Title_002);
                this.textType.SelectAll();
                this.textType.Focus();
            }
        }

        private void textTransType_TextChanged(object sender, EventArgs e)
        {
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            if (this.textTruck.Text.Trim() != "")
            {
                this.tblTruck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.textTruck.Text.Trim() };
                int recNo = this.tblTruck.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_589, Resource.Title_002);
                    this.textTruck.SelectAll();
                    this.textTruck.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }
    }
}

