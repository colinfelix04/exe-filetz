﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDelay : Form
    {
        private int delayTime;
        public bool post;
        private IContainer components = null;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private Timer timerDelay;
        private Label labelWarning;
        private Button btnPost;
        private Button btnCancel;
        private Label label1;
        private Label labelTick;

        public FormDelay()
        {
            this.InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.timerDelay.Enabled = false;
            this.post = false;
            base.Close();
        }

        private void btnPost_Click(object sender, EventArgs e)
        {
            this.timerDelay.Enabled = false;
            this.post = true;
            base.Close();
        }

        private void btnPost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.timerDelay.Enabled = false;
                this.post = false;
                base.Close();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDelay_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.timerDelay.Enabled = false;
                this.post = false;
                base.Close();
            }
        }

        private void FormDelay_Load(object sender, EventArgs e)
        {
            this.delayTime = 10;
            this.timerDelay.Enabled = true;
            this.labelWarning.Text = this.labelWarning.Text + this.sapIDSYS;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.timerDelay = new Timer(this.components);
            this.labelWarning = new Label();
            this.btnPost = new Button();
            this.btnCancel = new Button();
            this.label1 = new Label();
            this.labelTick = new Label();
            base.SuspendLayout();
            this.timerDelay.Interval = 0x3e8;
            this.timerDelay.Tick += new EventHandler(this.timerDelay_Tick);
            this.labelWarning.AutoSize = true;
            this.labelWarning.Location = new Point(30, 9);
            this.labelWarning.Name = "labelWarning";
            this.labelWarning.Size = new Size(0xeb, 13);
            this.labelWarning.TabIndex = 0;
            this.labelWarning.Text = "This computer has been set to auto-sync to ";
            this.btnPost.Location = new Point(12, 0x55);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new Size(0x4b, 0x17);
            this.btnPost.TabIndex = 1;
            this.btnPost.Text = "Start Now";
            this.btnPost.UseVisualStyleBackColor = true;
            this.btnPost.Click += new EventHandler(this.btnPost_Click);
            this.btnPost.KeyPress += new KeyPressEventHandler(this.btnPost_KeyPress);
            this.btnCancel.Location = new Point(0xcd, 0x55);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x4b, 0x17);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(30, 0x20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x6f, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Auto-sync will begin in";
            this.labelTick.AutoSize = true;
            this.labelTick.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelTick.Location = new Point(0x93, 0x20);
            this.labelTick.Name = "labelTick";
            this.labelTick.Size = new Size(0x15, 13);
            this.labelTick.TabIndex = 4;
            this.labelTick.Text = "10";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x124, 120);
            base.Controls.Add(this.labelTick);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnPost);
            base.Controls.Add(this.labelWarning);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormDelay";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Information";
            base.TopMost = true;
            base.Load += new EventHandler(this.FormDelay_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDelay_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void timerDelay_Tick(object sender, EventArgs e)
        {
            this.delayTime--;
            this.labelTick.Text = this.delayTime.ToString();
            if (this.delayTime == 0)
            {
                this.btnPost_Click(null, EventArgs.Empty);
            }
        }
    }
}

