﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormGrading : Form
    {
        private int idxFind;
        public string pMode;
        public string changeReason;
        public string logKey;
        public int nCurrRow;
        public WBTable zTable;
        public DataRow ReturnRow;
        private string chMode;
        private string sqlText;
        private IContainer components;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addCommodityItemToolStripMenuItem;
        private ToolStripMenuItem editCommodityToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private TextBox TextFind;
        private Panel panel1;
        private Button buttonFind;
        private DataGridView dataGridView1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormGrading()
        {
            this.idxFind = 0;
            this.pMode = "";
            this.changeReason = "";
            this.logKey = "";
            this.zTable = new WBTable();
            this.chMode = "0";
            this.components = null;
            this.InitializeComponent();
        }

        public FormGrading(string mode)
        {
            this.idxFind = 0;
            this.pMode = "";
            this.changeReason = "";
            this.logKey = "";
            this.zTable = new WBTable();
            this.chMode = "0";
            this.components = null;
            this.InitializeComponent();
            this.chMode = mode;
            this.translate();
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("ADD", Resource.Title_Add_Grading);
            if (this.dataGridView1.RowCount > 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = true;
                this.editCommodityToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
                this.toolStripMenuItem1.Enabled = true;
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.zTable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.toolStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.toolStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_TransactionD", "Select uniq From wb_TransactionD where " + WBData.CompanyLocation("and (Code='" + this.zTable.DT.Rows[this.nCurrRow]["Grading_Code"].ToString() + "') and (Type='1' or Type='F')"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    table.Close();
                    string[] textArray2 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Grading_Code"].ToString(), " - ", this.zTable.DT.Rows[this.nCurrRow]["Grading_Name"].ToString(), ".\n\n", Resource.Mes_250 };
                    if (MessageBox.Show(string.Concat(textArray2), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Grade_001 },
                            textRefNo = { Text = this.zTable.DT.Rows[this.nCurrRow]["Grading_Code"].ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.zTable.ReOpen();
                            this.logKey = this.zTable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.zTable.DT.Rows[this.nCurrRow].Delete();
                            this.zTable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_grading", this.logKey, logField, logValue);
                            this.zTable.ReOpen();
                            this.zTable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                    table.Dispose();
                    this.zTable.UnLock();
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editCommodityToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.toolStripMenuItem1.Enabled = false;
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_047A, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("EDIT", Resource.Title_Edit_Grading);
        }

        private void entry(string pMode, string formText)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, pMode))
            {
                FormGradingEntry entry = new FormGradingEntry {
                    pMode = pMode,
                    zTable = this.zTable,
                    Text = formText,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.zTable.ReOpen();
                    this.dataGridView1 = this.zTable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Grading_Code" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.zTable.SetCursor(this.dataGridView1, this.zTable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.zTable.UnLock();
            }
        }

        private void FormGrading_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormGrading_Load(object sender, EventArgs e)
        {
            this.sqlText = "Select * From wb_grading";
            if ((Convert.ToInt16(this.chMode) <= 2) && (Convert.ToInt16(this.chMode) != 0))
            {
                this.sqlText = this.sqlText + " where " + WBData.CompanyLocation(" and (formula is null or formula ='')");
            }
            else if (Convert.ToInt16(this.chMode) > 0)
            {
                this.sqlText = this.sqlText + " where " + WBData.CompanyLocation(" and LEN(formula) > 0");
            }
            this.zTable.OpenTable("wb_grading", this.sqlText, WBData.conn);
            this.dataGridView1.DataSource = this.zTable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Grading_Code"], ListSortDirection.Ascending);
            this.dataGridView1.Focus();
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = true;
            this.dataGridView1.Columns["completed"].Visible = true;
            this.dataGridView1.Columns["Grading_Code"].HeaderText = Resource.Setting_120;
            this.dataGridView1.Columns["Grading_Name"].HeaderText = Resource.Col_Grading_Description;
            base.KeyPreview = true;
            this.toolStripMenuItem1.Visible = this.pMode != "";
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editCommodityToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.toolStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addCommodityItemToolStripMenuItem = new ToolStripMenuItem();
            this.editCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.buttonFind = new Button();
            this.dataGridView1 = new DataGridView();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.toolStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x27a, 0x18);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addCommodityItemToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editCommodityToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addCommodityItemToolStripMenuItem.Name = "addCommodityItemToolStripMenuItem";
            this.addCommodityItemToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addCommodityItemToolStripMenuItem.Text = "Add New Record";
            this.addCommodityItemToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            this.editCommodityToolStripMenuItem.Name = "editCommodityToolStripMenuItem";
            this.editCommodityToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editCommodityToolStripMenuItem.Text = "Edit  Record";
            this.editCommodityToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x3b, 20);
            this.toolStripMenuItem1.Text = "Choose";
            this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x155);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x27a, 0x21);
            this.panel1.TabIndex = 4;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x27a, 0x13d);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x27a, 0x176);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormGrading";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Grading List";
            base.Load += new EventHandler(this.FormGrading_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormGrading_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.zTable.GetRecNo(aField, aFind);
            this.ReturnRow = this.zTable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.toolStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCommodityItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCommodityToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Grading;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.zTable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormGradingEntry entry = new FormGradingEntry {
                    pMode = "VIEW",
                    zTable = this.zTable,
                    Text = Resource.Title_View_Grading,
                    nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.zTable.UnLock();
                entry.Dispose();
            }
        }
    }
}

