﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUser : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public WBTable ztable = new WBTable();
        public bool ShowDeleted = false;
        private string sqlOtorisasi = "";
        public DataRow ReturnRow;
        private string sqlShow = "";
        public string sField = "";
        public string pFilter = "";
        private IContainer components = null;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private Button buttonFind;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem addToolStripMenuItem;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private TextBox TextFind;
        private Panel panel1;
        private MenuStrip menuStrip1;
        private Label label1;
        private Panel panel2;
        private DataGridView dataGridView1;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem checksumValidationToolStripMenuItem;
        private ToolStripMenuItem repairAllChecksumToolStripMenuItem;
        private CheckBox checkShowAllUser;
        private Label labelCount;
        private ToolStripMenuItem disableEnableUserToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem changePasswordToolStripMenuItem;
        private ToolStripMenuItem copyToOtherLocationsToolStripMenuItem;
        private ToolStripMenuItem GenerateADTemplatetoolStripMenuItem;
        private ToolStripMenuItem resetPasswordToolStripMenuItem;
        private ProgressBar progressBar1;
        private CheckBox checkDeleted;

        public FormUser()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && WBUser.CheckTrustee("USERLIST", "D"))
            {
                if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "*")
                {
                    this.disableEnableUserToolStripMenuItem.Text = "Activate User";
                    this.editToolStripMenuItem.Enabled = false;
                    this.changePasswordToolStripMenuItem.Enabled = false;
                    this.resetPasswordToolStripMenuItem.Enabled = false;
                }
                else
                {
                    this.disableEnableUserToolStripMenuItem.Text = "Disactivate User";
                    this.editToolStripMenuItem.Enabled = true;
                    this.changePasswordToolStripMenuItem.Enabled = true;
                    this.resetPasswordToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormUserEntry entry = new FormUserEntry {
                    pMode = "ADD",
                    Text = "Add New User",
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("ADD");
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count != 0) && this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormUserEntry entry = new FormUserEntry {
                    pMode = "PASS",
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = "Change Password",
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void checkDeleted_CheckedChanged(object sender, EventArgs e)
        {
            this.filter();
        }

        private void checkShowAllUser_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkShowAllUser.Checked)
            {
                this.dataGridView1.Columns["Coy"].Visible = true;
                this.dataGridView1.Columns["Location_Code"].Visible = true;
            }
            else
            {
                this.dataGridView1.Columns["Coy"].Visible = false;
                this.dataGridView1.Columns["Location_Code"].Visible = false;
            }
            this.filter();
        }

        private void checksumValidationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                int recNo = this.ztable.GetRecNo(aField, aFind);
                DataRow row = this.ztable.DT.Rows[recNo];
                if (this.ztable.ValidChecksum(row))
                {
                    MessageBox.Show(Resource.Mes_456, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_457, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch
            {
                MessageBox.Show(Resource.Mes_453, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count <= 0)
            {
                int recNo = 0;
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                recNo = this.ztable.GetRecNo(aField, aFind);
                this.ReturnRow = this.ztable.DT.Rows[recNo];
                base.Close();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyToOtherLocationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                int index = this.dataGridView1.CurrentRow.Index;
                FormCopyUserAutho autho = new FormCopyUserAutho {
                    pMode = "COPY",
                    userID = this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(),
                    userGroup = this.dataGridView1.CurrentRow.Cells["user_group"].Value.ToString(),
                    userPass = this.dataGridView1.CurrentRow.Cells["user_pass"].Value.ToString(),
                    userLevel = this.dataGridView1.CurrentRow.Cells["user_level"].Value.ToString(),
                    userName = this.dataGridView1.CurrentRow.Cells["user_name"].Value.ToString(),
                    table = "user",
                    Text = "Copy User to Other Locations"
                };
                string[] textArray1 = new string[] { "Copy user ", this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(), " (", this.dataGridView1.CurrentRow.Cells["user_name"].Value.ToString(), ") to locations:" };
                autho.label1.Text = string.Concat(textArray1);
                autho.ShowDialog();
                if (autho.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                    this.ztable.SetCursor(this.dataGridView1, index);
                }
                this.ztable.UnLock();
                autho.Dispose();
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if ((this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "*") || (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y"))
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                int index = this.dataGridView1.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_455, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int posRec = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = "User ID" },
                        textRefNo = { Text = this.ztable.DT.Rows[posRec]["User_ID"].ToString() },
                        Text = "DELETE REASON",
                        label2 = { Text = "Delete Reason : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        bool flag1;
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.DR = this.ztable.DT.Rows[posRec];
                        string str = this.ztable.DR["user_id"].ToString();
                        string str2 = this.ztable.DR["user_group"].ToString();
                        string str3 = this.ztable.DR["user_pass"].ToString();
                        string str4 = this.ztable.DR["user_level"].ToString();
                        string str5 = this.ztable.DR["user_name"].ToString();
                        this.logKey = this.ztable.DR["uniq"].ToString();
                        this.ztable.DR.Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_user", this.logKey, logField, logValue);
                        WBTable table = new WBTable();
                        table.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
                        int num3 = Convert.ToInt16(table.DT.Rows[0]["n"].ToString());
                        table.Dispose();
                        if (num3 <= 1)
                        {
                            flag1 = false;
                        }
                        else
                        {
                            string[] textArray3 = new string[] { "Do you want to delete user ", str, " (", str5, ") in other locations?" };
                            flag1 = MessageBox.Show(string.Concat(textArray3), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
                        }
                        if (!flag1)
                        {
                            this.ztable.ReOpen();
                            this.dataGridView1.DataSource = this.ztable.AfterEdit("DELETE");
                            this.ztable.SetCursor(this.dataGridView1, index);
                        }
                        else
                        {
                            FormCopyUserAutho autho = new FormCopyUserAutho {
                                pMode = "DELETE",
                                userID = str,
                                userGroup = str2,
                                userPass = str3,
                                userLevel = str4,
                                userName = str5,
                                changeReason = this.changeReason,
                                table = "user",
                                Text = "Delete User in Other Locations"
                            };
                            string[] textArray4 = new string[] { "Delete user ", str, " (", str5, ") in locations:" };
                            autho.label1.Text = string.Concat(textArray4);
                            autho.ShowDialog();
                            if (autho.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1.DataSource = this.ztable.DT;
                                this.ztable.SetCursor(this.dataGridView1, index);
                            }
                            autho.Dispose();
                        }
                    }
                }
            }
        }

        private void disableEnableUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                int index = this.dataGridView1.CurrentRow.Index;
                bool flag = (this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString() != "*") && (this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString() != "Y");
                string str = flag ? "Disactivate" : "Activate";
                if (MessageBox.Show("Do you want to " + str.ToLower() + " user " + this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int posRec = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = "User ID" },
                        textRefNo = { Text = this.ztable.DT.Rows[posRec]["user_id"].ToString() }
                    };
                    if (!flag)
                    {
                        cancel.Text = "ACTIVATE REASON";
                        cancel.label2.Text = "Activate Reason : ";
                    }
                    else
                    {
                        cancel.Text = "DISACTIVATE REASON";
                        cancel.label2.Text = "Disactivate Reason : ";
                    }
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        bool flag1;
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.DR = this.ztable.DT.Rows[posRec];
                        this.logKey = this.ztable.DR["uniq"].ToString();
                        this.ztable.DR.BeginEdit();
                        if (!flag)
                        {
                            this.ztable.DR["deleted"] = "";
                            this.ztable.DR["Delete_By"] = "";
                            this.ztable.DR["Delete_Date"] = DBNull.Value;
                            this.ztable.DR["ChangeReason"] = this.changeReason;
                        }
                        else
                        {
                            this.ztable.DR["deleted"] = "*";
                            this.ztable.DR["Delete_By"] = WBUser.UserID;
                            this.ztable.DR["Delete_Date"] = DateTime.Now;
                            this.ztable.DR["ChangeReason"] = this.changeReason;
                        }
                        this.ztable.DR["Checksum"] = this.ztable.Checksum(this.ztable.DR);
                        this.ztable.DR.EndEdit();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_user", this.logKey, logField, logValue);
                        WBTable table = new WBTable();
                        table.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
                        int num3 = Convert.ToInt16(table.DT.Rows[0]["n"].ToString());
                        table.Dispose();
                        if (num3 <= 1)
                        {
                            flag1 = false;
                        }
                        else
                        {
                            string[] textArray3 = new string[] { "Do you want to ", str.ToLower(), " user ", this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(), " (", this.dataGridView1.CurrentRow.Cells["user_name"].Value.ToString(), ") in other locations?" };
                            flag1 = MessageBox.Show(string.Concat(textArray3), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
                        }
                        if (!flag1)
                        {
                            this.ztable.ReOpen();
                            this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                            this.ztable.SetCursor(this.dataGridView1, index);
                        }
                        else
                        {
                            FormCopyUserAutho autho = new FormCopyUserAutho {
                                pMode = "ACT-NON",
                                userID = this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(),
                                userGroup = this.dataGridView1.CurrentRow.Cells["user_group"].Value.ToString(),
                                userPass = this.dataGridView1.CurrentRow.Cells["user_pass"].Value.ToString(),
                                userLevel = this.dataGridView1.CurrentRow.Cells["user_level"].Value.ToString(),
                                userName = this.dataGridView1.CurrentRow.Cells["user_name"].Value.ToString(),
                                changeReason = this.changeReason,
                                table = "user",
                                Text = str + " User in Other Locations"
                            };
                            string[] textArray4 = new string[] { str, " user ", this.dataGridView1.CurrentRow.Cells["user_id"].Value.ToString(), " (", this.dataGridView1.CurrentRow.Cells["user_name"].Value.ToString(), ") in locations:" };
                            autho.label1.Text = string.Concat(textArray4);
                            autho.ShowDialog();
                            if (autho.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                                this.ztable.SetCursor(this.dataGridView1, index);
                            }
                            autho.Dispose();
                        }
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormUserEntry entry = new FormUserEntry {
                    pMode = "EDIT",
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = "Edit User ID",
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void filter()
        {
            this.pFilter = this.sqlOtorisasi;
            if (!this.checkShowAllUser.Checked)
            {
                this.sqlShow = this.checkDeleted.Checked ? "" : " and (deleted is null or deleted = 'N' or deleted = '')";
                this.ztable.OpenTable("wb_user", "SELECT * FROM wb_user where " + ((this.pFilter == "") ? WBData.CompanyLocation(this.sqlShow) : WBData.CompanyLocation(this.pFilter + this.sqlShow)), WBData.conn);
            }
            else if (!this.checkDeleted.Checked)
            {
                this.ztable.OpenTable("wb_user", "SELECT * FROM wb_user WHERE (deleted is null or deleted = 'N' or deleted = '') " + this.pFilter, WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_user", "SELECT * FROM wb_user WHERE 1 = 1 " + this.pFilter, WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["user_id"], ListSortDirection.Ascending);
            this.labelCount.Text = this.ztable.DT.Rows.Count.ToString() + " Records";
            this.labelCount.Refresh();
            this.dataGridView1.Update();
            this.dataGridView1.Refresh();
        }

        private void FormUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormUser_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            if (WBUser.UserLevel == "2")
            {
                this.sqlOtorisasi = " and User_Level>='2'";
            }
            else if (Convert.ToInt16(WBUser.UserLevel) >= 3)
            {
                this.sqlOtorisasi = !WBUser.CheckTrustee("USERLIST", "D") ? (" and User_Id='" + WBUser.UserID.Trim() + "'") : " and User_Level>='3'";
            }
            this.checkShowAllUser.Checked = false;
            if (Convert.ToInt16(WBUser.UserLevel) > 1)
            {
                this.checkShowAllUser.Visible = false;
                this.checkDeleted.Visible = false;
            }
            else
            {
                this.checkShowAllUser.Visible = true;
                this.checkDeleted.Visible = true;
            }
            this.filter();
            this.labelCount.Text = this.ztable.DT.Rows.Count.ToString() + " Records";
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["User_Id"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["User_Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            this.dataGridView1.Columns["User_Name"].Width = 200;
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["User_Pass"].Visible = false;
            this.dataGridView1.Columns["Deleted"].Visible = false;
            this.dataGridView1.Columns["LastPassword"].Visible = false;
            this.dataGridView1.Columns["require_change_pass"].Visible = false;
            this.dataGridView1.Columns["is_resetting_pass"].Visible = false;
            this.dataGridView1.Columns["email"].Visible = false;
            this.dataGridView1.Columns["lastLoginIP"].Visible = false;
            this.dataGridView1.Columns["lastLogoutIP"].Visible = false;
            this.dataGridView1.Columns["lastLoginCompName"].Visible = false;
            this.dataGridView1.Columns["lastLogoutCompName"].Visible = false;
            this.dataGridView1.Columns["lastloginresult"].Visible = false;
            this.dataGridView1.Columns["coy"].HeaderText = "Company";
            this.dataGridView1.Columns["location_code"].HeaderText = "Location";
            this.dataGridView1.Columns["user_id"].HeaderText = Resource.User_002;
            this.dataGridView1.Columns["user_name"].HeaderText = Resource.User_003;
            this.dataGridView1.Columns["user_group"].HeaderText = Resource.User_004;
            this.dataGridView1.Columns["user_level"].HeaderText = Resource.User_005;
            this.dataGridView1.Columns["Create_By"].HeaderText = "Create By";
            this.dataGridView1.Columns["Create_Date"].HeaderText = "Create Date";
            this.dataGridView1.Columns["Change_By"].HeaderText = "Change By";
            this.dataGridView1.Columns["Change_Date"].HeaderText = "Change Date";
            this.dataGridView1.Columns["Delete_By"].HeaderText = "Delete By";
            this.dataGridView1.Columns["Delete_Date"].HeaderText = "Delete Date";
            this.dataGridView1.Columns["Deleted"].HeaderText = "* Del";
            this.dataGridView1.Columns["checksum"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            if (!WBUser.CheckTrustee("USERLIST", "A"))
            {
                this.addToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("USERLIST", "E"))
            {
                this.changePasswordToolStripMenuItem.Enabled = false;
                this.resetPasswordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("USERLIST", "D"))
            {
                this.editToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.disableEnableUserToolStripMenuItem.Enabled = false;
            }
            if ((!WBUser.CheckTrustee("RESETPASS_USERLIST", "V") || !WBUser.CheckTrustee("RESETPASS_USERLIST", "A")) || !WBUser.CheckTrustee("RESETPASS_USERLIST", "E"))
            {
                this.resetPasswordToolStripMenuItem.Enabled = false;
                this.resetPasswordToolStripMenuItem.Visible = false;
            }
            if (WBUser.UserLevel == "1")
            {
                this.repairAllChecksumToolStripMenuItem.Visible = true;
                this.copyToOtherLocationsToolStripMenuItem.Visible = true;
                this.GenerateADTemplatetoolStripMenuItem.Visible = true;
            }
            else
            {
                this.repairAllChecksumToolStripMenuItem.Visible = false;
                this.copyToOtherLocationsToolStripMenuItem.Visible = false;
                this.GenerateADTemplatetoolStripMenuItem.Visible = false;
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
            int num = Convert.ToInt16(table.DT.Rows[0]["n"].ToString());
            table.Dispose();
            if (num <= 1)
            {
                this.copyToOtherLocationsToolStripMenuItem.Enabled = false;
            }
            base.KeyPreview = true;
            Cursor.Current = Cursors.Default;
        }

        private void GenerateADTemplatetoolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string str = "UWB_WB_";
                string str2 = "UWB_TCS_";
                DataTable table = new DataTable();
                string[] strArray = new string[3];
                WBTable table2 = new WBTable();
                DataTable dT = this.ztable.DT;
                dT.Dispose();
                if (!dT.Columns.Contains("Notes"))
                {
                    dT.Columns.Add("Notes");
                }
                foreach (DataRow row in dT.Rows)
                {
                    if (string.IsNullOrEmpty(row["coy"].ToString()) && string.IsNullOrEmpty(row["location_code"].ToString()))
                    {
                        object[] objArray1 = new object[] { str2, WBData.sCoyCode, WBData.sLocCode, "_", row["user_group"] };
                        row["notes"] = string.Concat(objArray1);
                        continue;
                    }
                    object[] objArray2 = new object[] { str, row["coy"].ToString(), row["location_code"].ToString(), "_", row["user_group"] };
                    row["notes"] = string.Concat(objArray2);
                }
                dT = new DataView(dT) { 
                    RowFilter = "(deleted is null or deleted = '' or deleted = 'N')",
                    Sort = "user_id"
                }.ToTable();
                table2.OpenTable("wb_user", "select distinct(user_id) from wb_user where 1=1", WBData.conn);
                DataTable table4 = table2.DT;
                table4.Columns.Add("user_name");
                table4.Columns.Add("Remark");
                foreach (DataRow row2 in table4.Rows)
                {
                    foreach (DataRow row3 in dT.Rows)
                    {
                        if (row2["user_id"].ToString() == row3["user_id"].ToString())
                        {
                            if (string.IsNullOrEmpty(row2["user_name"].ToString()))
                            {
                                row2["user_name"] = row3["user_name"].ToString();
                            }
                            if (string.IsNullOrEmpty(row2["Remark"].ToString()))
                            {
                                row2["Remark"] = row3["Notes"].ToString();
                            }
                            else if (!string.IsNullOrEmpty(row2["remark"].ToString()))
                            {
                                row2["remark"] = row2["Remark"].ToString() + " | " + row3["Notes"].ToString();
                            }
                        }
                    }
                }
                table4 = new DataView(table4) { RowFilter = "Isnull(Remark,'') <> ''" }.ToTable();
                new FormTemplateAD { aTable = table4 }.ShowDialog();
                table4.Dispose();
                dT.Dispose();
            }
        }

        private void InitializeComponent()
        {
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.buttonFind = new Button();
            this.editToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.addToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new ToolStripMenuItem();
            this.copyToOtherLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.disableEnableUserToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.resetPasswordToolStripMenuItem = new ToolStripMenuItem();
            this.checksumValidationToolStripMenuItem = new ToolStripMenuItem();
            this.repairAllChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.GenerateADTemplatetoolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.labelCount = new Label();
            this.checkShowAllUser = new CheckBox();
            this.menuStrip1 = new MenuStrip();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripMenuItem();
            this.label1 = new Label();
            this.panel2 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.dataGridView1 = new DataGridView();
            this.checkDeleted = new CheckBox();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.buttonFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.editToolStripMenuItem.Text = "Edit Record";
            this.editToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.addToolStripMenuItem.Text = "Add New Record";
            this.addToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            ToolStripItem[] toolStripItems = new ToolStripItem[11];
            toolStripItems[0] = this.addToolStripMenuItem;
            toolStripItems[1] = this.changePasswordToolStripMenuItem;
            toolStripItems[2] = this.editToolStripMenuItem;
            toolStripItems[3] = this.copyToOtherLocationsToolStripMenuItem;
            toolStripItems[4] = this.disableEnableUserToolStripMenuItem;
            toolStripItems[5] = this.deleteToolStripMenuItem;
            toolStripItems[6] = this.toolStripMenuItem1;
            toolStripItems[7] = this.resetPasswordToolStripMenuItem;
            toolStripItems[8] = this.checksumValidationToolStripMenuItem;
            toolStripItems[9] = this.repairAllChecksumToolStripMenuItem;
            toolStripItems[10] = this.GenerateADTemplatetoolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new EventHandler(this.changePasswordToolStripMenuItem_Click);
            this.copyToOtherLocationsToolStripMenuItem.Name = "copyToOtherLocationsToolStripMenuItem";
            this.copyToOtherLocationsToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.copyToOtherLocationsToolStripMenuItem.Text = "Copy to Other Locations";
            this.copyToOtherLocationsToolStripMenuItem.Click += new EventHandler(this.copyToOtherLocationsToolStripMenuItem_Click);
            this.disableEnableUserToolStripMenuItem.Name = "disableEnableUserToolStripMenuItem";
            this.disableEnableUserToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.disableEnableUserToolStripMenuItem.Text = "Activate/Disactivate User";
            this.disableEnableUserToolStripMenuItem.TextImageRelation = TextImageRelation.TextAboveImage;
            this.disableEnableUserToolStripMenuItem.Click += new EventHandler(this.disableEnableUserToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xe7, 6);
            this.resetPasswordToolStripMenuItem.Name = "resetPasswordToolStripMenuItem";
            this.resetPasswordToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.resetPasswordToolStripMenuItem.Text = "Reset Password (All Locations)";
            this.resetPasswordToolStripMenuItem.Click += new EventHandler(this.resetPasswordToolStripMenuItem_Click);
            this.checksumValidationToolStripMenuItem.Name = "checksumValidationToolStripMenuItem";
            this.checksumValidationToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.checksumValidationToolStripMenuItem.Text = "Checksum Validation";
            this.checksumValidationToolStripMenuItem.Click += new EventHandler(this.checksumValidationToolStripMenuItem_Click);
            this.repairAllChecksumToolStripMenuItem.Name = "repairAllChecksumToolStripMenuItem";
            this.repairAllChecksumToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.repairAllChecksumToolStripMenuItem.Text = "Repair all Checksum";
            this.repairAllChecksumToolStripMenuItem.Click += new EventHandler(this.repairAllChecksumToolStripMenuItem_Click);
            this.GenerateADTemplatetoolStripMenuItem.Name = "GenerateADTemplatetoolStripMenuItem";
            this.GenerateADTemplatetoolStripMenuItem.Size = new Size(0xea, 0x16);
            this.GenerateADTemplatetoolStripMenuItem.Text = "Generate Template AD";
            this.GenerateADTemplatetoolStripMenuItem.Click += new EventHandler(this.GenerateADTemplatetoolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.checkDeleted);
            this.panel1.Controls.Add(this.labelCount);
            this.panel1.Controls.Add(this.checkShowAllUser);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x199);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2b3, 0x21);
            this.panel1.TabIndex = 8;
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new Point(0x222, 8);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new Size(0x5c, 13);
            this.labelCount.TabIndex = 6;
            this.labelCount.Text = "labelCountRecord";
            this.checkShowAllUser.AutoSize = true;
            this.checkShowAllUser.Location = new Point(0x114, 8);
            this.checkShowAllUser.Name = "checkShowAllUser";
            this.checkShowAllUser.Size = new Size(0x89, 0x11);
            this.checkShowAllUser.TabIndex = 5;
            this.checkShowAllUser.Text = "Show All User in Server";
            this.checkShowAllUser.UseVisualStyleBackColor = true;
            this.checkShowAllUser.CheckedChanged += new EventHandler(this.checkShowAllUser_CheckedChanged);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem, this.toolStripMenuItem2 };
            this.menuStrip1.Items.AddRange(itemArray2);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x2b3, 0x18);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(12, 20);
            this.label1.Anchor = AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x128, 5);
            this.label1.Name = "label1";
            this.label1.Size = new Size(120, 0x19);
            this.label1.TabIndex = 12;
            this.label1.Text = "USER LIST";
            this.label1.TextAlign = ContentAlignment.MiddleCenter;
            this.panel2.Controls.Add(this.progressBar1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = DockStyle.Top;
            this.panel2.Location = new Point(0, 0x18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x2b3, 0x25);
            this.panel2.TabIndex = 13;
            this.progressBar1.Location = new Point(0x24c, 7);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(100, 0x17);
            this.progressBar1.TabIndex = 13;
            this.progressBar1.Visible = false;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x3d);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x2b3, 0x15c);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x1a3, 8);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x5d, 0x11);
            this.checkDeleted.TabIndex = 0x16;
            this.checkDeleted.Text = "Show Deleted";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.checkDeleted.CheckedChanged += new EventHandler(this.checkDeleted_CheckedChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.Lavender;
            base.ClientSize = new Size(0x2b3, 0x1ba);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormUser";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of User";
            base.Load += new EventHandler(this.FormUser_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUser_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void repairAllChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.progressBar1.Visible = true;
                int num = 0;
                while (true)
                {
                    if (num >= this.dataGridView1.Rows.Count)
                    {
                        MessageBox.Show(Resource.Mes_454, Resource.Title_007);
                        this.progressBar1.Visible = false;
                        break;
                    }
                    this.progressBar1.Maximum = this.dataGridView1.Rows.Count;
                    this.progressBar1.Value = num;
                    this.progressBar1.Refresh();
                    if ((this.dataGridView1.Rows[num].Cells["Deleted"].Value.ToString() != "*") && (this.dataGridView1.Rows[num].Cells["Deleted"].Value.ToString() != "Y"))
                    {
                        string[] aField = new string[] { "Uniq" };
                        string[] aFind = new string[] { this.dataGridView1.Rows[num].Cells["Uniq"].Value.ToString() };
                        int recNo = this.ztable.GetRecNo(aField, aFind);
                        this.ztable.DR = this.ztable.DT.Rows[recNo];
                        this.logKey = this.ztable.DR["uniq"].ToString();
                        this.ztable.DR.BeginEdit();
                        this.ztable.DR["checksum"] = this.ztable.Checksum(this.ztable.DR);
                        this.ztable.DR.EndEdit();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair checksum" };
                        Program.updateLogHeader("wb_user", this.logKey, logField, logValue);
                        this.dataGridView1.Rows[num].Cells["checksum"].Value = this.ztable.DR["checksum"].ToString();
                    }
                    num++;
                }
            }
        }

        private void resetPasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = "EDIT";
            int posRec = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            this.ztable.DR = this.ztable.DT.Rows[posRec];
            if (MessageBox.Show(string.Format(Resource.Mes_Are_you_sure_want_to_reset_password, this.ztable.DR["User_Id"].ToString()), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "User ID" },
                    textRefNo = { Text = this.ztable.DR["User_Id"].ToString() },
                    Text = "RESET REASON",
                    label2 = { Text = "Reset Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_user", "SELECT * from wb_user WHERE User_Id = '" + this.ztable.DR["user_id"].ToString() + "'", WBData.conn);
                    foreach (DataRow row in table.DT.Rows)
                    {
                        row.BeginEdit();
                        row["User_pass"] = Program.shoot(ResetPasswordValue(), true);
                        row["require_change_pass"] = "Y";
                        row["Change_By"] = WBUser.UserID;
                        row["Change_Date"] = DateTime.Now;
                        row["Checksum"] = table.Checksum(row);
                        row.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { str, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_user", row["uniq"].ToString(), logField, logValue);
                    }
                    MessageBox.Show(string.Format(Resource.Mes_Reset_Password_Success, this.ztable.DR["User_Id"].ToString(), ResetPasswordValue()), Resource.Title_007);
                }
            }
        }

        public static string ResetPasswordValue() => 
            "Wilmar" + DateTime.Now.ToString("MM") + DateTime.Now.ToString("yyyy");

        private void showRecordByMarkDeletedToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addToolStripMenuItem.Text = Resource.Menu_Add;
            this.editToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
        }
    }
}

