﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormContract : Form
    {
        private int idxFind = 0;
        public WBTable tblContract_log = new WBTable();
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string flagTimbun = "";
        public string pFrom = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private string sqlShow = "";
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private WBTable tblContractGRCust = new WBTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x38];
        public bool vessel = false;
        private string[] hasil = new string[3];
        public string sField;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Panel panel1;
        public Button buttonFind;
        private Label Garis1;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem chooseStripMenuItem3;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;
        private ToolStripMenuItem copyRecordToolStripMenuItem;
        private ToolStripMenuItem filterToolStripMenuItem;
        private ToolStripMenuItem unfilterToolStripMenuItem;
        private ToolStripMenuItem diagnosticMasterDataToolStripMenuItem;
        private ToolStripMenuItem closeDOToolStripMenuItem;
        private CheckBox checkClosed;
        private Label labelCount;
        private ToolStripMenuItem editLockBongkarToolStripMenuItem;
        private CheckBox cbAll;
        private ToolStripMenuItem mapVesselDOToolStripMenuItem;
        private ToolStripMenuItem entryPINToolStripMenuItem;
        private ToolStripMenuItem getContractSpecificationOutspecWarningToolStripMenuItem;
        private ToolStripMenuItem setCommToolStripMenuItem;
        private ToolStripMenuItem readoptNoTokenToolStripMenuItem;
        private ToolStripMenuItem editKBContractToolStripMenuItem;
        private ToolStripMenuItem setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem;

        public FormContract()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.closeDOToolStripMenuItem.Text = (this.dataGridView1.CurrentRow.Cells["Closed"].Value.ToString() != "X") ? Resource.Menu_Close_DO : Resource.Menu_Open_DO;
            }
        }

        private void activitiesToolStripMenuItem_LocationChanged(object sender, EventArgs e)
        {
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WBData.sRegion != "2")
            {
                FormContractEntry entry = new FormContractEntry();
                if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
                {
                    entry.pMode = "ADD";
                    entry.zTable = this.ztable;
                    entry.Text = Resource.Title_Add_DO;
                    entry.dataGridView1 = this.dataGridView1;
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { entry.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    entry.Dispose();
                    this.ztable.UnLock();
                }
                else
                {
                    return;
                }
            }
            else
            {
                FormContractEntryMsia msia = new FormContractEntryMsia();
                if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
                {
                    msia.pMode = "ADD";
                    msia.zTable = this.ztable;
                    msia.Text = Resource.Title_Add_DO;
                    msia.dataGridView1 = this.dataGridView1;
                    msia.ShowDialog();
                    if (msia.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(msia.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { msia.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    msia.Dispose();
                    this.ztable.UnLock();
                }
                else
                {
                    return;
                }
            }
            this.menu_auth();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        public void can_show_all_do()
        {
            this.cbAll.Visible = true;
        }

        private void cbAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cbAll.Checked)
            {
                this.dataGridView1.Columns["Coy"].Visible = true;
                this.dataGridView1.Columns["Location_Code"].Visible = true;
            }
            else
            {
                this.dataGridView1.Columns["Coy"].Visible = false;
                this.dataGridView1.Columns["Location_Code"].Visible = false;
            }
            this.filter();
            this.addNewRecordToolStripMenuItem.Enabled = false;
            this.copyRecordToolStripMenuItem.Enabled = false;
            this.editRecordToolStripMenuItem.Enabled = false;
            this.editLockBongkarToolStripMenuItem.Enabled = false;
            this.closeDOToolStripMenuItem.Enabled = false;
            this.deleteToolStripMenuItem.Enabled = false;
            this.printToolStripMenuItem.Enabled = false;
            this.zWBToolStripMenuItem.Enabled = false;
        }

        private void cek_before_sync(bool kb_lock)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_073, Resource.Mes_Warning);
            }
            else
            {
                DataRow sRow = null;
                DataRow data = null;
                string str2 = this.dataGridView1.CurrentRow.Cells["Do_no"].Value.ToString().Trim();
                string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
                string[] aField = new string[] { "DO_NO", "uniq" };
                string[] aFind = new string[] { str2, str };
                sRow = this.ztable.GetData(aField, aFind);
                string str3 = this.dataGridView1.CurrentRow.Cells["tolling"].Value.ToString().Trim();
                if (str3 == "6")
                {
                    string[] textArray3 = new string[] { "DO_NO", "zAuto" };
                    string[] textArray4 = new string[] { str2 + Constant.TITIP_TIMBUN_POSTFIX, "Y" };
                    data = this.ztable.GetData(textArray3, textArray4);
                }
                string str4 = !kb_lock ? (Resource.Mes_Send_Allow_Edit + " ") : (Resource.Menu_Synchronize + " ");
                string[] textArray5 = new string[] { str4, str2, " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ?" };
                if (MessageBox.Show(string.Concat(textArray5), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.send1ZWB(sRow, kb_lock);
                    if ((str3 == "6") && (data != null))
                    {
                        this.send1ZWB(data, kb_lock);
                    }
                }
            }
        }

        private void checkClosed_CheckedChanged(object sender, EventArgs e)
        {
            this.filter();
        }

        private bool checkCollectivetoken()
        {
            bool flag = false;
            DateTime now = Convert.ToDateTime(this.dataGridView1.CurrentRow.Cells["Do_Date"].Value.ToString());
            DateTime time = Convert.ToDateTime(now.ToShortDateString());
            WBTable table = new WBTable();
            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation("") + " AND token_code = 'EDIT_COLLECTIVE'  AND completed = 'Y'", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(row["key_1"].ToString()).ToShortDateString());
                DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(row["key_2"].ToString()).ToShortDateString());
                DateTime time5 = Convert.ToDateTime(Convert.ToDateTime(row["datetime1"].ToString()).ToShortDateString()).AddDays(7.0);
                if ((time >= time3) && (time <= time4))
                {
                    now = DateTime.Now;
                    if ((time5 - Convert.ToDateTime(now.ToShortDateString())).Days >= 0)
                    {
                        flag = true;
                        break;
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        private void chooseStripMenuItem3_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            if ((this.ztable.DT.Rows[this.nCurrRow]["closed"].ToString() == "X") && (this.pFrom == "formTransDO"))
            {
                MessageBox.Show(Resource.Mes_063, Resource.Mes_Warning);
            }
            else if (this.ztable.DT.Rows[this.nCurrRow]["zAuto"].ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_062, Resource.Mes_Warning);
            }
            else if ((this.flagTimbun == "6") && (this.ztable.DT.Rows[this.nCurrRow]["tolling"].ToString() != "6"))
            {
                MessageBox.Show(Resource.Mes_061, Resource.Mes_Warning);
            }
            else if ((WBSetting.Field("GM") == "Y") && (this.ztable.DT.Rows[this.nCurrRow]["completedGRCust"].ToString() == "N"))
            {
                MessageBox.Show(Resource.Mes_064, Resource.Mes_Warning);
            }
            else
            {
                this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void closeDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
            {
                if ((WBSetting.Field("GM") == "Y") && (this.dataGridView1.CurrentRow.Cells["completed"].Value.ToString() == "N"))
                {
                    string str2 = "";
                    if (this.closeDOToolStripMenuItem.Text == Resource.Menu_Open_DO)
                    {
                        str2 = Resource.Mes_Open;
                    }
                    else if (this.closeDOToolStripMenuItem.Text == Resource.Menu_Close_DO)
                    {
                        str2 = Resource.Mes_Close;
                    }
                    string[] textArray1 = new string[] { Resource.Mes_Warning_Reset_Token, " ", str2, " ", Resource.Mes_Warning_Reset_Token_2 };
                    if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        return;
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        string keyField = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                        if (this.ztable.BeforeEdit(this.dataGridView1, "CLOSED"))
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE uniq = '" + keyField + "' ", WBData.conn);
                            table.DR = table.DT.Rows[0];
                            table.DR.BeginEdit();
                            table.DR["token"] = "";
                            table.DR["completed"] = "";
                            table.DR.EndEdit();
                            table.Save();
                            table.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, str2 + " DO" };
                            Program.updateLogHeader("wb_contract", keyField, logField, logValue);
                            this.ztable.ReOpen();
                            this.dataGridView1 = this.ztable.AfterEdit("CLOSED");
                            string[] aField = new string[] { "uniq" };
                            string[] aFind = new string[] { keyField };
                            this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                            Cursor.Current = Cursors.Default;
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                if (this.ztable.BeforeEdit(this.dataGridView1, "CLOSED"))
                {
                    string str = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString();
                    if (WBSetting.dummy_contract_on_registration && (WBSetting.dummy_contract == str))
                    {
                        MessageBox.Show(Resource.Mes_Error_Close_Reserved_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        FormContractStatus status = new FormContractStatus {
                            doNo = str,
                            sUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()
                        };
                        status.ShowDialog();
                        this.ztable.AfterEdit("CLOSED");
                        if (status.saved)
                        {
                            this.ztable.ReOpen();
                            this.dataGridView1 = this.ztable.AfterEdit("CLOSED");
                            string[] aField = new string[] { "Do_no" };
                            string[] aFind = new string[] { str };
                            this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        status.Dispose();
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_065, Resource.Mes_Warning);
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void ContractToLog(WBTable tLog, DataRow aRow)
        {
            tLog.OpenTable("wb_contract_log", "SELECT * FROM wb_contract_log where deleted = '9' ", WBData.conn);
            tLog.DR = tLog.DT.NewRow();
            using (IEnumerator enumerator = tLog.DT.Columns.GetEnumerator())
            {
                DataColumn current;
                goto TR_0012;
            TR_000C:
                if (current.ColumnName.ToUpper() == "log_Date".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("dd/MM/yyyy");
                }
                else if (current.ColumnName.ToUpper() == "log_time".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (current.ColumnName.ToUpper() == "sUniq".ToUpper())
                {
                    tLog.DR[current.ColumnName] = aRow["uniq"];
                }
                if (current.ColumnName.ToUpper() == "Deleted".ToUpper())
                {
                    tLog.DR[current.ColumnName] = "Y";
                }
            TR_0012:
                while (true)
                {
                    if (enumerator.MoveNext())
                    {
                        current = (DataColumn) enumerator.Current;
                        if (current.ColumnName.ToUpper() != "UNIQ")
                        {
                            try
                            {
                                tLog.DR[current.ColumnName] = aRow[current.ColumnName];
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        goto TR_0004;
                    }
                    break;
                }
                goto TR_000C;
            }
        TR_0004:
            tLog.DT.Rows.Add(tLog.DR);
        }

        private void copyRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_067, Resource.Mes_Warning);
                }
                else if ((WBSetting.Field("GM") == "Y") && (this.ztable.DT.Rows[this.nCurrRow]["completed"].ToString() == "N"))
                {
                    MessageBox.Show(Resource.Mes_068, Resource.Mes_Warning);
                }
                else if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
                {
                    if (WBData.sRegion == "2")
                    {
                        FormContractEntryMsia msia = new FormContractEntryMsia {
                            pMode = "COPY",
                            zTable = this.ztable,
                            Text = Resource.Title_Add_DO,
                            dataGridView1 = this.dataGridView1,
                            nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString())
                        };
                        msia.ShowDialog();
                        if (msia.saved)
                        {
                            this.ztable.ReOpen();
                            this.dataGridView1 = this.ztable.AfterEdit(msia.pMode);
                            string[] aField = new string[] { "Do_no" };
                            string[] aFind = new string[] { msia.textDO.Text };
                            this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        msia.Dispose();
                        this.ztable.UnLock();
                    }
                    else
                    {
                        FormContractEntry entry = new FormContractEntry {
                            pMode = "COPY",
                            zTable = this.ztable,
                            Text = Resource.Title_Add_DO,
                            dataGridView1 = this.dataGridView1,
                            nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString())
                        };
                        entry.ShowDialog();
                        if (entry.saved)
                        {
                            this.ztable.ReOpen();
                            this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                            string[] aField = new string[] { "Do_no" };
                            string[] aFind = new string[] { entry.textDO.Text };
                            this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        entry.Dispose();
                        this.ztable.UnLock();
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem3.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["closed"].Value.ToString() == "X")
            {
                e.CellStyle.BackColor = Color.Gray;
                e.CellStyle.SelectionBackColor = Color.Black;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["zAuto"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Yellow;
                e.CellStyle.SelectionBackColor = Color.YellowGreen;
            }
            if (WBSetting.Field("GM") == "Y")
            {
                if (this.dataGridView1.Rows[e.RowIndex].Cells["completedGRCust"].Value.ToString() == "N")
                {
                    e.CellStyle.BackColor = Color.Red;
                    e.CellStyle.SelectionBackColor = Color.PaleVioletRed;
                }
                else if (this.dataGridView1.Rows[e.RowIndex].Cells["completedGRCust"].Value.ToString() == "X")
                {
                    e.CellStyle.BackColor = Color.Green;
                    e.CellStyle.SelectionBackColor = Color.GreenYellow;
                }
            }
            WBTable table = new WBTable();
            if ((e.ColumnIndex == this.dataGridView1.Columns["comm_code"].Index) && (e.Value != null))
            {
                DataGridViewCell cell = this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                table.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + e.Value.ToString().Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    cell.ToolTipText = table.DT.Rows[0]["comm_name"].ToString();
                }
            }
            table.Dispose();
            WBTable table2 = new WBTable();
            if ((e.ColumnIndex == this.dataGridView1.Columns["relation_code"].Index) && (e.Value != null))
            {
                DataGridViewCell cell2 = this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                table2.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + e.Value.ToString().Trim() + "'"), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    cell2.ToolTipText = table2.DT.Rows[0]["relation_name"].ToString();
                }
            }
            table2.Dispose();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem3.PerformClick();
            }
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string pUniq = "";
            string str2 = "N";
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
            {
                if ((this.dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() != "N") && (this.dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() != "X"))
                {
                    if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                    {
                        if (!WBSetting.dummy_contract_on_registration || (WBSetting.dummy_contract != this.dataGridView1.CurrentRow.Cells["do_no"].Value.ToString()))
                        {
                            this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                            WBTable table = new WBTable();
                            table.OpenTable("wb_transDO", "Select ref From wb_transDO where " + WBData.CompanyLocation(" and (Do_No='" + this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString() + "')"), WBData.conn);
                            if (table.DT.Rows.Count <= 0)
                            {
                                string[] textArray1 = new string[] { Resource.Main_018, " : ", this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString(), ".\n\n", Resource.Mes_250 };
                                if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    FormTransCancel cancel = new FormTransCancel {
                                        label1 = { Text = "DO No" },
                                        textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString() },
                                        Text = Resource.Form_Delete_Reason,
                                        label2 = { Text = Resource.Lbl_Delete_Reason }
                                    };
                                    cancel.textReason.Focus();
                                    cancel.ShowDialog();
                                    if (cancel.Saved)
                                    {
                                        this.changeReason = cancel.textReason.Text;
                                        cancel.Dispose();
                                        if (this.dataGridView1.CurrentRow.Cells["tolling"].Value.ToString() == "6")
                                        {
                                            pUniq = this.findTimbun();
                                            str2 = "T";
                                        }
                                        this.ztable.ReOpen();
                                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                                        string str3 = this.ztable.DT.Rows[this.nCurrRow]["do_no"].ToString();
                                        this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
                                        this.ztable.ReOpen();
                                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                                        if ((str2 == "T") && (pUniq != ""))
                                        {
                                            this.nCurrRow = this.ztable.GetPosRec(pUniq);
                                            this.ztable.DT.Rows[this.nCurrRow].Delete();
                                        }
                                        this.ztable.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                        Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                                        this.ztable.ReOpen();
                                        this.ztable.AfterEdit("DELETE");
                                        WBTable table2 = new WBTable();
                                        table2.OpenTable("wb_contract_sapinformation", "SELECT * FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(" AND do_no = '" + str3 + "'"), WBData.conn);
                                        string[] strArray = new string[table2.DT.Rows.Count];
                                        int index = 0;
                                        while (true)
                                        {
                                            if (index >= table2.DT.Rows.Count)
                                            {
                                                table2.Save();
                                                int num3 = 0;
                                                while (true)
                                                {
                                                    if (num3 >= strArray.Length)
                                                    {
                                                        table2.Dispose();
                                                        break;
                                                    }
                                                    string[] textArray4 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] textArray5 = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                                    Program.updateLogHeader("wb_contract_sapinformation", strArray[num3], textArray4, textArray5);
                                                    num3++;
                                                }
                                                break;
                                            }
                                            strArray[index] = table2.DT.Rows[index]["uniq"].ToString();
                                            table2.DT.Rows[index].Delete();
                                            index++;
                                        }
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Error_Delete_Transaction_Exists + table.DT.Rows.Count.ToString(), Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            table.Dispose();
                            table.UnLock();
                            if (this.dataGridView1.RowCount == 0)
                            {
                                this.viewRecordToolStripMenuItem.Enabled = false;
                                this.editRecordToolStripMenuItem.Enabled = false;
                                this.editLockBongkarToolStripMenuItem.Enabled = false;
                                this.entryPINToolStripMenuItem.Enabled = false;
                                this.closeDOToolStripMenuItem.Enabled = false;
                                this.copyRecordToolStripMenuItem.Enabled = false;
                                this.deleteToolStripMenuItem.Enabled = false;
                                this.printToolStripMenuItem.Enabled = false;
                                this.mapVesselDOToolStripMenuItem.Enabled = false;
                                this.readoptNoTokenToolStripMenuItem.Enabled = false;
                                this.zWBToolStripMenuItem.Enabled = false;
                                this.diagnosticMasterDataToolStripMenuItem.Enabled = false;
                                this.getContractSpecificationOutspecWarningToolStripMenuItem.Enabled = false;
                                this.setCommToolStripMenuItem.Enabled = false;
                                this.chooseStripMenuItem3.Enabled = false;
                                this.filterToolStripMenuItem.Enabled = false;
                                this.unfilterToolStripMenuItem.Enabled = false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Error_Delete_Reserved_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Delete_Temp_DO, Resource.Mes_Warning);
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_070, Resource.Mes_Warning);
            }
        }

        private void diagnosticMasterDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormContractDiag { 
                textBox1 = { Text = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() },
                textBox2 = { Text = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() }
            }.ShowDialog();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void edit_data(string pMode)
        {
            if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, pMode))
            {
                if (WBData.sRegion == "2")
                {
                    FormContractEntryMsia msia = new FormContractEntryMsia {
                        pMode = pMode,
                        zTable = this.ztable,
                        Text = Resource.Form_Edit_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    msia.ShowDialog();
                    if (msia.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(msia.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { msia.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    msia.Dispose();
                    this.ztable.UnLock();
                }
                else
                {
                    FormContractEntry entry = new FormContractEntry {
                        pMode = pMode,
                        zTable = this.ztable,
                        Text = Resource.Form_Edit_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { entry.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    entry.Dispose();
                    this.ztable.UnLock();
                }
            }
        }

        private bool edit_data_CollectiveToken(string pMode)
        {
            bool flag3;
            bool flag = false;
            if (this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
            {
                flag3 = false;
            }
            else
            {
                this.ztable.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), true);
                this.ztable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                if (WBData.sRegion == "2")
                {
                    FormContractEntryMsia msia = new FormContractEntryMsia {
                        pMode = pMode,
                        zTable = this.ztable,
                        Text = Resource.Form_Edit_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    msia.ShowDialog();
                    if (msia.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1.DataSource = this.ztable.DT;
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { msia.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    msia.Dispose();
                    this.ztable.UnLock();
                }
                else
                {
                    FormContractEntry entry = new FormContractEntry {
                        pMode = pMode,
                        zTable = this.ztable,
                        Text = Resource.Form_Edit_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1.DataSource = this.ztable.DT;
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { entry.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    entry.Dispose();
                    this.ztable.UnLock();
                }
                this.ztable.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), false);
                flag3 = flag;
            }
            return flag3;
        }

        private void editKBContractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.cek_before_sync(false);
        }

        private void editLockBongkarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() == "N")
                {
                    this.edit_data("GRCUST");
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Warning_Not_Temp_DO, Resource.Mes_Warning);
                }
            }
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_060, Resource.Mes_Warning);
                }
                else if (this.dataGridView1.CurrentRow.Cells["closed"].Value.ToString() == "X")
                {
                    MessageBox.Show(Resource.Mes_072, Resource.Mes_Warning);
                }
                else if ((this.dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() == "N") || (this.dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() == "X"))
                {
                    MessageBox.Show(Resource.Mes_Error_Edit_Temp_DO, Resource.Mes_Warning);
                }
                else if (this.ztable.CekTokenCompleted(this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString(), "", "NOT_ADOPTSAP", false) != "")
                {
                    MessageBox.Show(WBSetting.integrationIDSYS ? Resource.MES_Error_DO_Not_Adopt_SAP_IDSYS : Resource.MES_Error_DO_Not_Adopt_SAP, Resource.Mes_Warning);
                }
                else if (WBSetting.dummy_contract_on_registration && (WBSetting.dummy_contract == this.dataGridView1.CurrentRow.Cells["do_no"].Value.ToString()))
                {
                    MessageBox.Show(Resource.Mes_Error_Edit_Reserved_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (this.checkCollectivetoken())
                {
                    this.edit_data_CollectiveToken("EDIT");
                }
                else
                {
                    this.edit_data("EDIT");
                }
            }
        }

        private void entryPINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.ztable.CekTokenCompleted(this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString(), "", "NOT_ADOPTSAP", false) == "")
                {
                    MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_Warning_DO_Already_Adopt_IDSYS : Resource.Mes_Warning_DO_Already_Adopt, Resource.Mes_Warning);
                }
                else
                {
                    this.hasil = this.ztable.tokenOrApp(this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString(), "", "NOT_ADOPTSAP", "TOKEN_ADOPTSAP", "NOT_ADOPTSAP", "E", "", null);
                    if (this.hasil[0] == "completed")
                    {
                        this.edit_data("EDIT");
                    }
                }
            }
        }

        private void filter()
        {
            this.sqlShow = "";
            if (!this.cbAll.Checked)
            {
                this.sqlShow = this.checkClosed.Checked ? "" : " and (closed is null or closed <> 'X' or closed = 'N')";
                this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract where " + ((this.pFilter == "") ? WBData.CompanyLocation(this.sqlShow) : WBData.CompanyLocation(this.pFilter + this.sqlShow)), WBData.conn);
            }
            else if (!this.checkClosed.Checked)
            {
                this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract WHERE (closed is null or closed <> 'X' or closed = 'N') " + this.pFilter, WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract WHERE 1 = 1 " + this.pFilter, WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
            this.labelCount.Text = Resource.Lbl_Total_Record + " = " + this.ztable.DT.Rows.Count.ToString();
            this.labelCount.Refresh();
            this.dataGridView1.Update();
            this.dataGridView1.Refresh();
        }

        private void filterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContractFilter filter = new FormContractFilter();
            filter.ShowDialog();
            if (filter.saved)
            {
                try
                {
                    this.pFilter = filter.pFilter;
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract ", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_077, "WARNING");
                    this.unfilterToolStripMenuItem.PerformClick();
                    return;
                }
                this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
                this.dataGridView1.Refresh();
                filter.Dispose();
            }
        }

        private string findTimbun()
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contractTTB", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_NO = '" + this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString().Trim() + Constant.TITIP_TIMBUN_POSTFIX + "' and tolling = 'T'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = "";
            }
            else
            {
                table.DR = table.DT.Rows[0];
                str = table.DR["uniq"].ToString();
            }
            table.Dispose();
            return str;
        }

        private void FormContract_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContract_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x38)
                {
                    this.cbAll.Visible = WBSetting.copyToLoc == "Y";
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    DataGridViewCellStyle style = new DataGridViewCellStyle {
                        Format = "d"
                    };
                    this.sField = "Coy,Location_Code,Berikat,Do_No,Do_Date,Comm_Code,Transaction_Code,Relation_Code,PI_No,Quantity,QtyAdopt,Contract,Contract_Date,Confirmation,Agen,Confirmation_Date,Estate1_Code,Estate2_Code,Transporter_Code,Vessel,STO,STO_Item,GR,GR_Cust, SO,SO_Item,Nego,PO,PO_Item,Coy_Tolling,Mov_Type,Remark,Group_Type,Franco,DeductedBy,UnGraded,Control_Os,Status_Do,Close_Do_Date,CheckPeriod, Do_Date2,Big_Fruit1,Big_Fruit2,Mid_Fruit1,Mid_Fruit2,Sml_Fruit1,Sml_Fruit2,Scout1,Scout2,Loose1,Loose2,Upd_Est,Upd_Fact,Entry_Est,ISCC,Entry_Fact,Type_Estate,check_qty,closed,closed_date,closed_by,Tolerance,Upload_Type, QualityInfo,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date, Convertion,ConvertionUnit,ConvertionTolerance,ConvertionCheck ,Deleted,STO1DO,zadp,zwb,tolling,plant,str_loc,zAuto,token, completed, tokenGRCust, completedGrcust, qstandard, uniq, Batch, so_item_count, approveby1, approve_type, approve_reason,mill, gain_loss,langsir_type,qOrigin,sync_return,BC_No,BC_Date,BC_Exp_Date, lock_KB, Tolling2, Plasma, spb_no, spb_item, STO_Qty, STO_UoM, Tracking_No, Tracking_Item, Require_BC, calcLoadingQtyAutomatically";
                    base.KeyPreview = true;
                    Cursor.Current = Cursors.WaitCursor;
                    this.sqlShow = "";
                    this.sqlShow = this.checkClosed.Checked ? "" : " and (closed is null or closed <> 'X' or closed = 'N')";
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract Where " + WBData.CompanyLocation(this.pFilter + this.sqlShow), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract where " + WBData.CompanyLocation(this.sqlShow), WBData.conn);
                    }
                    if (this.vessel)
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract  where " + WBData.CompanyLocation(this.sqlShow + "AND Transaction_Code IN (SELECT Transaction_Code FROM wb_transaction_type where is_vessel = 'Y')"), WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
                    this.labelCount.Text = Resource.Lbl_Total_Record + " = " + this.ztable.DT.Rows.Count.ToString();
                    this.labelCount.Refresh();
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["Control_Os"].Visible = false;
                    this.dataGridView1.Columns["Tolling"].Visible = false;
                    this.dataGridView1.Columns["zAuto"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["sync_return"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["completedGRCust"].Visible = true;
                    this.dataGridView1.Columns["PI_NO"].HeaderText = Resource.Contract_PI_SI_No;
                    this.dataGridView1.Columns["PI_NO"].Width = 40;
                    this.dataGridView1.Columns["Do_NO"].HeaderText = Resource.Contract_DO_SO_No;
                    this.dataGridView1.Columns["Do_NO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    this.dataGridView1.Columns["Do_Date"].HeaderText = Resource.Contract_DO_SO_Date;
                    this.dataGridView1.Columns["Do_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Contract"].HeaderText = Resource.Contract_No;
                    this.dataGridView1.Columns["Contract_Date"].HeaderText = Resource.Contract_011;
                    this.dataGridView1.Columns["Contract_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Confirmation"].HeaderText = Resource.Contract_Confirmation_No;
                    this.dataGridView1.Columns["Confirmation_Date"].HeaderText = Resource.Contract_014;
                    this.dataGridView1.Columns["Confirmation_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Relation_Code"].HeaderText = Resource.Contract_006;
                    this.dataGridView1.Columns["Estate1_Code"].HeaderText = Resource.Contract_Estate_ADM;
                    this.dataGridView1.Columns["Estate2_Code"].HeaderText = Resource.Contract_Estate_LAB;
                    this.dataGridView1.Columns["Comm_Code"].HeaderText = Resource.Contract_004;
                    this.dataGridView1.Columns["Coy_Tolling"].HeaderText = Resource.Contract_Tolling_Company;
                    this.dataGridView1.Columns["Transaction_Code"].HeaderText = Resource.Contract_005;
                    this.dataGridView1.Columns["Transaction_Code"].ToolTipText = Resource.Contract_Transaction_Code_ToolTip;
                    this.dataGridView1.Columns["Mov_Type"].HeaderText = this.sapIDSYS + Resource.Contract_SAP_Mov_Type;
                    this.dataGridView1.Columns["Group_Type"].HeaderText = Resource.Contract_031;
                    this.dataGridView1.Columns["Franco"].HeaderText = Resource.Contract_Incoterm;
                    this.dataGridView1.Columns["closed"].HeaderText = Resource.Contract_Closed;
                    this.dataGridView1.Columns["berikat"].HeaderText = Resource.Contract_001;
                    this.dataGridView1.Columns["berikat"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["berikat"].ToolTipText = Resource.Contract_Berikat_ToolTip;
                    this.dataGridView1.Columns["Tolling2"].HeaderText = "Tolling 2";
                    this.dataGridView1.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dataGridView1.Columns["Quantity"].DefaultCellStyle.Format = "N0";
                    this.dataGridView1.Columns["approveby1"].Visible = false;
                    this.dataGridView1.Columns["approve_type"].Visible = false;
                    this.dataGridView1.Columns["approve_reason"].Visible = false;
                    this.menu_auth();
                    this.Garis1.Width = 2;
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    Cursor.Current = Cursors.Default;
                    this.chooseStripMenuItem3.Visible = this.pMode != "";
                    if (this.chooseStripMenuItem3.Visible)
                    {
                        this.cbAll.Visible = false;
                    }
                    if (WBUser.UserGroup != "ADMIN")
                    {
                        this.getContractSpecificationOutspecWarningToolStripMenuItem.Visible = false;
                    }
                    if (WBSetting.integrationIDSYS)
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                        this.getContractSpecificationOutspecWarningToolStripMenuItem.Enabled = false;
                        this.zWBToolStripMenuItem.Text = "IDSYS";
                    }
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void getContractSpecificationOutspecWarningToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new WBTable().OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND GR_Cust != ''"), WBData.conn);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editLockBongkarToolStripMenuItem = new ToolStripMenuItem();
            this.entryPINToolStripMenuItem = new ToolStripMenuItem();
            this.closeDOToolStripMenuItem = new ToolStripMenuItem();
            this.copyRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.mapVesselDOToolStripMenuItem = new ToolStripMenuItem();
            this.readoptNoTokenToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.editKBContractToolStripMenuItem = new ToolStripMenuItem();
            this.diagnosticMasterDataToolStripMenuItem = new ToolStripMenuItem();
            this.getContractSpecificationOutspecWarningToolStripMenuItem = new ToolStripMenuItem();
            this.setCommToolStripMenuItem = new ToolStripMenuItem();
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem3 = new ToolStripMenuItem();
            this.filterToolStripMenuItem = new ToolStripMenuItem();
            this.unfilterToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.cbAll = new CheckBox();
            this.labelCount = new Label();
            this.checkClosed = new CheckBox();
            this.progressBar1 = new ProgressBar();
            this.Garis1 = new Label();
            this.buttonFind = new Button();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x39e, 0x193);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.dataGridView1.KeyPress += new KeyPressEventHandler(this.dataGridView1_KeyPress);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem3, this.filterToolStripMenuItem, this.unfilterToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x39e, 0x18);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[0x12];
            itemArray2[0] = this.addNewRecordToolStripMenuItem;
            itemArray2[1] = this.viewRecordToolStripMenuItem;
            itemArray2[2] = this.editRecordToolStripMenuItem;
            itemArray2[3] = this.editLockBongkarToolStripMenuItem;
            itemArray2[4] = this.entryPINToolStripMenuItem;
            itemArray2[5] = this.closeDOToolStripMenuItem;
            itemArray2[6] = this.copyRecordToolStripMenuItem;
            itemArray2[7] = this.deleteToolStripMenuItem;
            itemArray2[8] = this.toolStripMenuItem1;
            itemArray2[9] = this.printToolStripMenuItem;
            itemArray2[10] = this.mapVesselDOToolStripMenuItem;
            itemArray2[11] = this.readoptNoTokenToolStripMenuItem;
            itemArray2[12] = this.toolStripMenuItem2;
            itemArray2[13] = this.zWBToolStripMenuItem;
            itemArray2[14] = this.diagnosticMasterDataToolStripMenuItem;
            itemArray2[15] = this.getContractSpecificationOutspecWarningToolStripMenuItem;
            itemArray2[0x10] = this.setCommToolStripMenuItem;
            itemArray2[0x11] = this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(50, 20);
            this.activitiesToolStripMenuItem.Text = "Menu";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.activitiesToolStripMenuItem.LocationChanged += new EventHandler(this.activitiesToolStripMenuItem_LocationChanged);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.editLockBongkarToolStripMenuItem.Name = "editLockBongkarToolStripMenuItem";
            this.editLockBongkarToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.editLockBongkarToolStripMenuItem.Text = "Edit Lock Bongkar";
            this.editLockBongkarToolStripMenuItem.Click += new EventHandler(this.editLockBongkarToolStripMenuItem_Click);
            this.entryPINToolStripMenuItem.Name = "entryPINToolStripMenuItem";
            this.entryPINToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.entryPINToolStripMenuItem.Text = "Entry PIN";
            this.entryPINToolStripMenuItem.Click += new EventHandler(this.entryPINToolStripMenuItem_Click);
            this.closeDOToolStripMenuItem.Name = "closeDOToolStripMenuItem";
            this.closeDOToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.closeDOToolStripMenuItem.Text = "Close/Open DO";
            this.closeDOToolStripMenuItem.Click += new EventHandler(this.closeDOToolStripMenuItem_Click);
            this.copyRecordToolStripMenuItem.Name = "copyRecordToolStripMenuItem";
            this.copyRecordToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.copyRecordToolStripMenuItem.Text = "Copy Record";
            this.copyRecordToolStripMenuItem.Click += new EventHandler(this.copyRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x196, 6);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.printToolStripMenuItem.Text = "Delivery Note";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            this.mapVesselDOToolStripMenuItem.Name = "mapVesselDOToolStripMenuItem";
            this.mapVesselDOToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.mapVesselDOToolStripMenuItem.Text = "Map Vessel DO";
            this.mapVesselDOToolStripMenuItem.Click += new EventHandler(this.mapVesselDOToolStripMenuItem_Click);
            this.readoptNoTokenToolStripMenuItem.Name = "readoptNoTokenToolStripMenuItem";
            this.readoptNoTokenToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.readoptNoTokenToolStripMenuItem.Text = "Readopt From SAP (No Token)";
            this.readoptNoTokenToolStripMenuItem.Click += new EventHandler(this.readoptNoTokenToolStripMenuItem_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0x196, 6);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem, this.editKBContractToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.zWBToolStripMenuItem.Click += new EventHandler(this.zWBToolStripMenuItem_Click);
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x12f, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x12f, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            this.editKBContractToolStripMenuItem.Name = "editKBContractToolStripMenuItem";
            this.editKBContractToolStripMenuItem.Size = new Size(0x12f, 0x16);
            this.editKBContractToolStripMenuItem.Text = "Request Edit Data in SAP for BC Documents";
            this.editKBContractToolStripMenuItem.Click += new EventHandler(this.editKBContractToolStripMenuItem_Click);
            this.diagnosticMasterDataToolStripMenuItem.Name = "diagnosticMasterDataToolStripMenuItem";
            this.diagnosticMasterDataToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.diagnosticMasterDataToolStripMenuItem.Text = "Diagnostic Master Data";
            this.diagnosticMasterDataToolStripMenuItem.Click += new EventHandler(this.diagnosticMasterDataToolStripMenuItem_Click);
            this.getContractSpecificationOutspecWarningToolStripMenuItem.Name = "getContractSpecificationOutspecWarningToolStripMenuItem";
            this.getContractSpecificationOutspecWarningToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.getContractSpecificationOutspecWarningToolStripMenuItem.Text = "Get Contract Specification (Outspec Warning)";
            this.getContractSpecificationOutspecWarningToolStripMenuItem.Click += new EventHandler(this.getContractSpecificationOutspecWarningToolStripMenuItem_Click);
            this.setCommToolStripMenuItem.Name = "setCommToolStripMenuItem";
            this.setCommToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.setCommToolStripMenuItem.Text = "Set Comm Tolerance for Check Gross Weight Pack Commodity ";
            this.setCommToolStripMenuItem.Click += new EventHandler(this.setCommToolStripMenuItem_Click);
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem.Name = "setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem";
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem.Size = new Size(0x199, 0x16);
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem.Text = "Set Vessel Maximum Percentage Tolerance for Split DO";
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem.Click += new EventHandler(this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem_Click);
            this.chooseStripMenuItem3.Name = "chooseStripMenuItem3";
            this.chooseStripMenuItem3.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem3.Text = "Choose";
            this.chooseStripMenuItem3.Click += new EventHandler(this.chooseStripMenuItem3_Click);
            this.filterToolStripMenuItem.Name = "filterToolStripMenuItem";
            this.filterToolStripMenuItem.Size = new Size(0x2d, 20);
            this.filterToolStripMenuItem.Text = "Filter";
            this.filterToolStripMenuItem.Click += new EventHandler(this.filterToolStripMenuItem_Click);
            this.unfilterToolStripMenuItem.Name = "unfilterToolStripMenuItem";
            this.unfilterToolStripMenuItem.Size = new Size(0x3a, 20);
            this.unfilterToolStripMenuItem.Text = "Unfilter";
            this.unfilterToolStripMenuItem.Click += new EventHandler(this.unfilterToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 7);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.cbAll);
            this.panel1.Controls.Add(this.labelCount);
            this.panel1.Controls.Add(this.checkClosed);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x1ab);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x39e, 0x26);
            this.panel1.TabIndex = 11;
            this.cbAll.AutoSize = true;
            this.cbAll.Location = new Point(0x120, 0);
            this.cbAll.Name = "cbAll";
            this.cbAll.Size = new Size(0xac, 0x11);
            this.cbAll.TabIndex = 0x17;
            this.cbAll.Text = "Show All DO from All Locations";
            this.cbAll.UseVisualStyleBackColor = true;
            this.cbAll.Visible = false;
            this.cbAll.CheckedChanged += new EventHandler(this.cbAll_CheckedChanged);
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new Point(0x21e, 12);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new Size(0x57, 13);
            this.labelCount.TabIndex = 0x16;
            this.labelCount.Text = "Total Record = 0";
            this.checkClosed.AutoSize = true;
            this.checkClosed.Location = new Point(0x120, 0x12);
            this.checkClosed.Name = "checkClosed";
            this.checkClosed.Size = new Size(0x58, 0x11);
            this.checkClosed.TabIndex = 0x15;
            this.checkClosed.Text = "Show Closed";
            this.checkClosed.UseVisualStyleBackColor = true;
            this.checkClosed.CheckedChanged += new EventHandler(this.checkClosed_CheckedChanged);
            this.progressBar1.Location = new Point(0x2bb, 10);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xe0, 0x11);
            this.progressBar1.TabIndex = 20;
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0x112, -8);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(10, 0x2d);
            this.Garis1.TabIndex = 5;
            this.buttonFind.Location = new Point(0xc3, 7);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x39e, 0x1d1);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormContract";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Contract";
            base.Load += new EventHandler(this.FormContract_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContract_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void mapVesselDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, this.pMode))
            {
                if (Program.getFieldValue("wb_transaction_type", "is_vessel", "transaction_code", this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString()) != "Y")
                {
                    MessageBox.Show(Resource.Mes_Warning_Not_Vessel_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    FormMapVessel vessel = new FormMapVessel {
                        uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()
                    };
                    vessel.ShowDialog();
                    vessel.Dispose();
                    this.filter();
                }
            }
        }

        private void menu_auth()
        {
            this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
            if (!WBUser.CheckTrustee("MD_CONTRACT", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
                this.copyRecordToolStripMenuItem.Enabled = false;
            }
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.editLockBongkarToolStripMenuItem.Enabled = false;
                this.entryPINToolStripMenuItem.Enabled = false;
                this.closeDOToolStripMenuItem.Enabled = false;
                this.copyRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.printToolStripMenuItem.Enabled = false;
                this.mapVesselDOToolStripMenuItem.Enabled = false;
                this.readoptNoTokenToolStripMenuItem.Enabled = false;
                this.zWBToolStripMenuItem.Enabled = false;
                this.diagnosticMasterDataToolStripMenuItem.Enabled = false;
                this.getContractSpecificationOutspecWarningToolStripMenuItem.Enabled = false;
                this.setCommToolStripMenuItem.Enabled = false;
                this.chooseStripMenuItem3.Enabled = false;
                this.filterToolStripMenuItem.Enabled = false;
                this.unfilterToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.viewRecordToolStripMenuItem.Enabled = true;
                this.chooseStripMenuItem3.Enabled = true;
                this.mapVesselDOToolStripMenuItem.Enabled = true;
                this.readoptNoTokenToolStripMenuItem.Enabled = true;
                this.getContractSpecificationOutspecWarningToolStripMenuItem.Enabled = true;
                this.filterToolStripMenuItem.Enabled = true;
                this.unfilterToolStripMenuItem.Enabled = true;
                this.setCommToolStripMenuItem.Enabled = (WBSetting.Field("GM") == "Y") && WBUser.CheckTrustee("COMM_CONT_TOL", "E");
                if (!WBUser.CheckTrustee("MD_CONTRACT", "E"))
                {
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.editLockBongkarToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_CONTRACT", "D"))
                {
                    this.deleteToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_CONTRACT", "P"))
                {
                    this.printToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                {
                    this.zWBToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_OPENCLOSE_CONTRACT", "A"))
                {
                    this.closeDOToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("NOT_ADOPTSAP", "E"))
                {
                    this.entryPINToolStripMenuItem.Enabled = false;
                }
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_069, Resource.Mes_Warning);
            }
            else
            {
                new FormSPB { 
                    pDo_No = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString(),
                    Text = Resource.Form_Range_Delivery_Note + this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString()
                }.ShowDialog();
            }
        }

        private void readoptNoTokenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                if (WBData.sRegion == "2")
                {
                    FormContractEntryMsia msia = new FormContractEntryMsia {
                        pMode = "READOPT",
                        zTable = this.ztable,
                        Text = Resource.Title_Readopt_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    msia.ShowDialog();
                    if (msia.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(msia.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { msia.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    this.ztable.UnLock();
                    msia.Dispose();
                }
                else
                {
                    FormContractEntry entry = new FormContractEntry {
                        pMode = "READOPT",
                        zTable = this.ztable,
                        Text = Resource.Title_Readopt_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { entry.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    this.ztable.UnLock();
                    entry.Dispose();
                }
            }
        }

        public bool send1ZWB(DataRow sRow, bool kb_lock)
        {
            bool flag17;
            bool flag = false;
            string coySAP = "";
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            if (!WBSetting.activeMulesoftIntegration)
            {
                this.zwbRow[0] = (sRow["zAuto"].ToString() == "Y") ? this.dataGridView1.CurrentRow.Cells["Coy_tolling"].Value.ToString() : WBSetting.CoySAP;
                coySAP = this.zwbRow[0];
                this.zwbRow[1] = sRow["DO_NO"].ToString().Trim();
                if ((sRow["zAuto"].ToString() == "Y") && this.zwbRow[1].ToString().EndsWith(Constant.TITIP_TIMBUN_POSTFIX))
                {
                    this.zwbRow[1] = this.zwbRow[1].Remove(this.zwbRow[1].Length - 1);
                }
                str2 = this.zwbRow[1];
                this.zwbRow[2] = (sRow["Do_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Do_Date"].ToString().Trim()));
                this.zwbRow[3] = sRow["Transaction_code"].ToString().Trim();
                this.zwbRow[4] = sRow["Relation_code"].ToString().Trim();
                this.zwbRow[5] = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", this.zwbRow[4]);
                this.zwbRow[6] = sRow["Comm_code"].ToString().Trim();
                this.zwbRow[7] = sRow["Remark"].ToString().Trim();
                this.zwbRow[9] = (sRow["Berikat"].ToString().Trim() == "Y") ? "X" : "";
                this.zwbRow[8] = (this.zwbRow[9] != "X") ? "NOKB" : "DPIL";
                this.zwbRow[10] = "";
                this.zwbRow[11] = sRow["Contract"].ToString().Trim();
                this.zwbRow[12] = (sRow["Contract_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Contract_Date"].ToString().Trim()));
                this.zwbRow[13] = sRow["Transporter_code"].ToString().Trim();
                this.zwbRow[14] = sRow["Estate1_code"].ToString().Trim();
                this.zwbRow[15] = sRow["Quantity"].ToString().Trim();
                this.zwbRow[0x10] = "WB1";
                this.zwbRow[0x11] = (sRow["langsir_type"].ToString().Trim() != "") ? sRow["langsir_type"].ToString().Trim() : ((Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", sRow["transaction_code"].ToString().Trim()) != "I") ? "S" : "P");
                this.zwbRow[0x12] = sRow["Vessel"].ToString().Trim();
                this.zwbRow[0x13] = sRow["Tolerance"].ToString().Trim();
                this.zwbRow[20] = sRow["Estate2_code"].ToString().Trim();
                this.zwbRow[0x15] = (sRow["DeductedBy"].ToString().Trim() != "0") ? "1" : "2";
                this.zwbRow[0x16] = (sRow["Confirmation_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Confirmation_Date"].ToString().Trim()));
                this.zwbRow[0x17] = sRow["PO"].ToString().Trim();
                this.zwbRow[0x18] = sRow["GR"].ToString().Trim();
                this.zwbRow[0x19] = sRow["STO"].ToString().Trim();
                this.zwbRow[0x1a] = (sRow["STO1DO"].ToString().Trim() == "Y") ? "X" : "";
                this.zwbRow[0x1b] = sRow["SO"].ToString().Trim();
                this.zwbRow[0x1c] = (sRow["SO_Item"].ToString().Trim() == "*") ? "" : sRow["SO_Item"].ToString().Trim();
                this.zwbRow[0x1d] = "";
                this.zwbRow[30] = sRow["PI_No"].ToString().Trim();
                this.zwbRow[0x1f] = sRow["tolling"].ToString().Trim();
                this.zwbRow[0x22] = sRow["Batch"].ToString();
                this.zwbRow[0x23] = (sRow["gain_loss"].ToString().Trim() == "Y") ? "X" : "";
                this.zwbRow[0x24] = Convert.ToString((int) (Convert.ToInt16(sRow["Group_Type"].ToString().Trim()) + 1));
                this.zwbRow[0x25] = "";
                this.zwbRow[0x26] = sRow["Create_BY"].ToString();
                this.zwbRow[0x27] = Program.DTOCSAP2(DateTime.Now);
                this.zwbRow[40] = DateTime.Now.ToString("HH:mm");
                this.zwbRow[0x29] = sRow["Change_By"].ToString();
                this.zwbRow[0x2a] = Program.DTOCSAP2(DateTime.Now);
                this.zwbRow[0x2b] = DateTime.Now.ToString("HH:mm");
                this.zwbRow[0x2c] = "";
                this.zwbRow[0x2d] = "";
                this.zwbRow[0x2e] = sRow["GR_Cust"].ToString().Trim();
                this.zwbRow[0x2f] = ((sRow["completedGRCust"].ToString().Trim() != "N") && (sRow["completedGRCust"].ToString().Trim() != "X")) ? "" : sRow["TokenGRCust"].ToString().Trim();
                this.zwbRow[0x30] = sRow["QStandard"].ToString().Trim();
                this.zwbRow[0x31] = (sRow["STO_ITEM"].ToString().Trim() == "*") ? "" : sRow["STO_ITEM"].ToString().Trim();
                str3 = this.zwbRow[0x2e];
                str5 = this.zwbRow[0x2f];
                try
                {
                    this.zwbRow[0x20] = sRow["PLANT"].ToString().Trim();
                }
                catch
                {
                    this.zwbRow[0x20] = "";
                }
            }
            else
            {
                DataTable table2;
                Cursor.Current = Cursors.WaitCursor;
                WBTable table = new WBTable();
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                Dictionary<string, string> item = new Dictionary<string, string>();
                if (sRow["zAuto"].ToString() != "Y")
                {
                    item.Add("ZWB_LOC", WBSetting.CoySAP);
                    coySAP = WBSetting.CoySAP;
                }
                else
                {
                    item.Add("ZWB_LOC", this.dataGridView1.CurrentRow.Cells["Coy_tolling"].Value.ToString());
                    coySAP = this.dataGridView1.CurrentRow.Cells["Coy_tolling"].Value.ToString();
                }
                string str6 = sRow["DO_NO"].ToString().Trim();
                if ((sRow["zAuto"].ToString() == "Y") && str6.ToString().EndsWith(Constant.TITIP_TIMBUN_POSTFIX))
                {
                    str6 = str6.Remove(this.zwbRow[1].Length - 1);
                }
                item.Add("STDO", str6);
                str2 = str6;
                if (sRow["Do_Date"].ToString().Trim().Length > 0)
                {
                    item.Add("STDADO", Program.DTOCSAP2(Convert.ToDateTime(sRow["Do_Date"].ToString().Trim())));
                }
                else
                {
                    item.Add("STDADO", "");
                }
                item.Add("STSTATUS", sRow["Transaction_code"].ToString().Trim());
                item.Add("STRELASI", sRow["Relation_code"].ToString().Trim());
                item.Add("STCU", Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", sRow["Relation_code"].ToString().Trim()));
                item.Add("STCOMM", sRow["Comm_code"].ToString().Trim());
                item.Add("STKET", sRow["Remark"].ToString().Trim());
                str6 = (sRow["Berikat"].ToString().Trim() == "Y") ? "X" : "";
                item.Add("STKB", str6);
                if (str6 == "X")
                {
                    item.Add("SBL", "DPIL");
                }
                else
                {
                    item.Add("SBL", "NOKB");
                }
                item.Add("STMC", "");
                item.Add("STKONT", sRow["Contract"].ToString().Trim());
                if (sRow["Contract_Date"].ToString().Trim().Length > 0)
                {
                    item.Add("STDAKONT", Program.DTOCSAP2(Convert.ToDateTime(sRow["Contract_Date"].ToString().Trim())));
                }
                else
                {
                    item.Add("STDAKONT", "");
                }
                item.Add("STANGKUT", sRow["Transporter_code"].ToString().Trim());
                item.Add("STKEBUN", sRow["Estate1_code"].ToString().Trim());
                item.Add("STQTY", sRow["Quantity"].ToString().Trim());
                item.Add("STREF", "WB1");
                if (sRow["langsir_type"].ToString().Trim() != "")
                {
                    item.Add("STTYPE", sRow["langsir_type"].ToString().Trim());
                }
                else if (Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", sRow["transaction_code"].ToString().Trim()) == "I")
                {
                    item.Add("STTYPE", "P");
                }
                else
                {
                    item.Add("STTYPE", "S");
                }
                item.Add("STVESSEL", sRow["Vessel"].ToString().Trim());
                item.Add("STTOL", sRow["Tolerance"].ToString().Trim());
                item.Add("STTOPRMK", sRow["Estate2_code"].ToString().Trim());
                if (sRow["DeductedBy"].ToString().Trim() == "0")
                {
                    item.Add("STTOP", "2");
                }
                else
                {
                    item.Add("STTOP", "1");
                }
                if (sRow["Confirmation_Date"].ToString().Trim().Length > 0)
                {
                    item.Add("STDAKONF", Program.DTOCSAP2(Convert.ToDateTime(sRow["Confirmation_Date"].ToString().Trim())));
                }
                else
                {
                    item.Add("STDAKONF", "");
                }
                item.Add("STPO", sRow["PO"].ToString().Trim());
                item.Add("STGRPO", sRow["GR"].ToString().Trim());
                item.Add("STSTO", sRow["STO"].ToString().Trim());
                item.Add("ST1STO", (sRow["STO1DO"].ToString().Trim() == "Y") ? "X" : "");
                item.Add("STSO", sRow["SO"].ToString().Trim());
                item.Add("POSNR", (sRow["SO_Item"].ToString().Trim() == "*") ? "" : sRow["SO_Item"].ToString().Trim());
                item.Add("INT_DO", "");
                item.Add("PI_NO", sRow["PI_No"].ToString().Trim());
                item.Add("STLANGSIR", sRow["tolling"].ToString().Trim());
                try
                {
                    item.Add("STPLANT", sRow["PLANT"].ToString().Trim());
                }
                catch
                {
                    item.Add("STPLANT", "");
                }
                try
                {
                    item.Add("STR_LOC", sRow["STR_LOC"].ToString().Trim());
                }
                catch
                {
                    item.Add("STR_LOC", "");
                }
                item.Add("STBATCH", sRow["Batch"].ToString());
                item.Add("STGLDEST", (sRow["gain_loss"].ToString().Trim() == "Y") ? "X" : "");
                try
                {
                    item.Add("STGROUP", Convert.ToString((int) (Convert.ToInt16(sRow["Group_Type"].ToString().Trim()) + 1)));
                }
                catch
                {
                    item.Add("STGROUP", "");
                }
                item.Add("STTUTUPDA", "");
                item.Add("ERNAM", sRow["Create_BY"].ToString());
                item.Add("ERDAT", Program.DTOCSAP2(DateTime.Now));
                item.Add("ERZET", DateTime.Now.ToString("HH:mm"));
                item.Add("AENAM", sRow["Change_By"].ToString());
                item.Add("AEDAT", Program.DTOCSAP2(DateTime.Now));
                item.Add("AEZET", DateTime.Now.ToString("HH:mm"));
                item.Add("STAT", "");
                item.Add("RFC_TEXT", "");
                item.Add("GRPO2", sRow["GR_Cust"].ToString().Trim());
                str5 = ((sRow["completedGRCust"].ToString().Trim() != "N") && (sRow["completedGRCust"].ToString().Trim() != "X")) ? "" : sRow["TokenGRCust"].ToString().Trim();
                item.Add("TOKEN", str5);
                item.Add("ZZISCC", sRow["QStandard"].ToString().Trim());
                item.Add("EBELP_STO", (sRow["STO_ITEM"].ToString().Trim() == "*") ? "" : sRow["STO_ITEM"].ToString().Trim());
                str3 = sRow["GR_Cust"].ToString().Trim();
                try
                {
                    item.Add("MILL", sRow["MILL"].ToString().Trim());
                }
                catch
                {
                    item.Add("MILL", "");
                }
                item.Add("INCO1", sRow["Franco"].ToString().Trim());
                if (kb_lock)
                {
                    item.Add("LOCK_POVAT", "X");
                }
                else
                {
                    item.Add("LOCK_POVAT", "");
                }
                item.Add("STPOITEM", (sRow["PO_Item"].ToString().Trim() == "*") ? "" : sRow["PO_Item"].ToString().Trim());
                item.Add("SPBNO", sRow["SPB_No"].ToString().Trim());
                item.Add("SPBITEM", sRow["SPB_Item"].ToString().Trim());
                sentTable.Add(item);
                integrator.prepareTable();
                integrator.addTable(sentTable, "I_RECORD");
                bool err = false;
                string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                Dictionary<string, List<Dictionary<string, string>>> dictionary2 = integrator.sendDataToMulesoft(integrator.getURL("ZRFC_DNET_WB_CONTRACT"), resultHeaderName, out err);
                if (!err)
                {
                    if (dictionary2["ERRORS"].Count > 0)
                    {
                        MessageBox.Show("Error from SAP : \n\n" + dictionary2["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        return false;
                    }
                    else
                    {
                        table2 = new DataTable();
                        DataColumn column = new DataColumn {
                            ColumnName = "Ref1"
                        };
                        table2.Columns.Add(column);
                        column = new DataColumn {
                            ColumnName = "Stts2"
                        };
                        table2.Columns.Add(column);
                        column = new DataColumn {
                            ColumnName = "Rmrk3"
                        };
                        table2.Columns.Add(column);
                        column.Dispose();
                        foreach (Dictionary<string, string> dictionary3 in dictionary2["I_RECORD"])
                        {
                            object[] values = new object[] { dictionary3["ZWB_LOC"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                            table2.Rows.Add(values);
                        }
                    }
                }
                else
                {
                    return false;
                }
                try
                {
                    WBTable table3 = new WBTable();
                    if (sRow["uniq"].ToString() != "")
                    {
                        table3.OpenTable("wb_contract", "Select top 1 * From wb_contract where " + WBData.CompanyLocation(" and uniq='" + sRow["uniq"].ToString() + "'"), WBData.conn);
                        table3.DR = table3.DT.Rows[0];
                        this.logKey = table3.DR["uniq"].ToString();
                        table3.DR.BeginEdit();
                        table3.DR["zwb"] = (table2.Rows[0]["Stts2"].ToString() == "Y") ? "Y" : "N";
                    }
                    if (table2.Rows[0]["Stts2"].ToString() != "Y")
                    {
                        string[] textArray2 = new string[10];
                        textArray2[0] = Resource.Mes_Failed_Sync;
                        textArray2[1] = " ";
                        textArray2[2] = sRow["DO_NO"].ToString().Trim();
                        textArray2[3] = " ";
                        textArray2[4] = Resource.Mes_To_ZWB;
                        textArray2[5] = this.sapIDSYS;
                        textArray2[6] = " ";
                        textArray2[7] = coySAP;
                        textArray2[8] = " \n";
                        textArray2[9] = table2.Rows[0]["Rmrk3"].ToString();
                        MessageBox.Show(string.Concat(textArray2), Resource.Mes_Notice);
                    }
                    else
                    {
                        if (sRow["uniq"].ToString() == "")
                        {
                            string[] textArray5 = new string[] { Resource.Mes_Success_Sync, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                            MessageBox.Show(string.Concat(textArray5), Resource.Mes_Notice);
                        }
                        else
                        {
                            table3.DR["completedGRCust"] = "Y";
                            if (kb_lock)
                            {
                                table3.DR["Lock_KB"] = "Y";
                                string[] textArray3 = new string[] { Resource.Mes_Success_Sync, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                                MessageBox.Show(string.Concat(textArray3), Resource.Mes_Notice);
                            }
                            else
                            {
                                table3.DR["Lock_KB"] = "N";
                                string[] textArray4 = new string[] { Resource.Mes_Success_Request_Edit_DO, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                                MessageBox.Show(string.Concat(textArray4), Resource.Mes_Notice);
                            }
                        }
                        flag = true;
                    }
                    if (sRow["uniq"].ToString() != "")
                    {
                        table3.DR.EndEdit();
                        table3.Save();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + this.sapIDSYS };
                    Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                }
                catch (RfcInvalidParameterException exception)
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception2)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception4)
                {
                    MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                if ((str5 != "") && ((str3 == "") & (str4 != "")))
                {
                    if (this.ztable.BeforeEdit(this.dataGridView1, "GRCUST"))
                    {
                        if (WBData.sRegion == "2")
                        {
                            FormContractEntryMsia msia = new FormContractEntryMsia {
                                pMode = "GRCUST",
                                zTable = this.ztable,
                                grCust = str4
                            };
                            string[] textArray8 = new string[] { Resource.Title_Replace_Temp_Do, " (", str2, ") ", Resource.Title_Replace_Temp_Do_2 };
                            msia.Text = string.Concat(textArray8);
                            msia.zTable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                            msia.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                            msia.dataGridView1 = this.dataGridView1;
                            msia.ShowDialog();
                            if (msia.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1 = this.ztable.AfterEdit(msia.pMode);
                                string[] aField = new string[] { "Do_no" };
                                string[] aFind = new string[] { msia.textDO.Text };
                                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            msia.Dispose();
                        }
                        else
                        {
                            FormContractEntry entry = new FormContractEntry {
                                pMode = "GRCUST",
                                zTable = this.ztable,
                                grCust = str4
                            };
                            string[] textArray11 = new string[] { Resource.Title_Replace_Temp_Do, " (", str2, ") ", Resource.Title_Replace_Temp_Do_2 };
                            entry.Text = string.Concat(textArray11);
                            entry.zTable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                            entry.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                            entry.dataGridView1 = this.dataGridView1;
                            entry.ShowDialog();
                            if (entry.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                                string[] aField = new string[] { "Do_no" };
                                string[] aFind = new string[] { entry.textDO.Text };
                                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            entry.Dispose();
                        }
                    }
                    else
                    {
                        return flag;
                    }
                }
                return flag;
            }
            try
            {
                this.zwbRow[0x21] = sRow["STR_LOC"].ToString().Trim();
            }
            catch
            {
                this.zwbRow[0x21] = "";
            }
            try
            {
                this.zwbRow[50] = sRow["MILL"].ToString().Trim();
            }
            catch
            {
                this.zwbRow[50] = "";
            }
            this.zwbRow[0x33] = sRow["Franco"].ToString().Trim();
            this.zwbRow[0x34] = !kb_lock ? "" : "X";
            this.zwbRow[0x35] = (sRow["PO_Item"].ToString().Trim() == "*") ? "" : sRow["PO_Item"].ToString().Trim();
            this.zwbRow[0x36] = sRow["SPB_No"].ToString().Trim();
            this.zwbRow[0x37] = sRow["SPB_Item"].ToString().Trim();
            if (WBSAP.connect())
            {
                try
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CONTRACT");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    WBSAP.appendTable(this.zwbRow);
                    WBSAP.sendZWB();
                    this.zwbResult = WBSAP.getResult();
                    str4 = WBSAP.rfcTable[0].GetString("GRPO2").ToString();
                    WBTable table4 = new WBTable();
                    if (sRow["uniq"].ToString() != "")
                    {
                        table4.OpenTable("wb_contract", "Select top 1 * From wb_contract where " + WBData.CompanyLocation(" and uniq='" + sRow["uniq"].ToString() + "'"), WBData.conn);
                        table4.DR = table4.DT.Rows[0];
                        this.logKey = table4.DR["uniq"].ToString();
                        table4.DR.BeginEdit();
                        table4.DR["zwb"] = (this.zwbResult[1].ToUpper().Trim() == "Y") ? "Y" : "N";
                    }
                    if (this.zwbResult[1].ToUpper().Trim() != "Y")
                    {
                        string[] textArray14 = new string[10];
                        textArray14[0] = Resource.Mes_Failed_Sync;
                        textArray14[1] = " ";
                        textArray14[2] = sRow["DO_NO"].ToString().Trim();
                        textArray14[3] = " ";
                        textArray14[4] = Resource.Mes_To_ZWB;
                        textArray14[5] = this.sapIDSYS;
                        textArray14[6] = " ";
                        textArray14[7] = coySAP;
                        textArray14[8] = " \n";
                        textArray14[9] = this.zwbResult[2];
                        MessageBox.Show(string.Concat(textArray14), Resource.Mes_Notice);
                    }
                    else
                    {
                        if (sRow["uniq"].ToString() == "")
                        {
                            string[] textArray17 = new string[] { Resource.Mes_Success_Sync, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                            MessageBox.Show(string.Concat(textArray17), Resource.Mes_Notice);
                        }
                        else
                        {
                            table4.DR["completedGRCust"] = "Y";
                            if (kb_lock)
                            {
                                table4.DR["Lock_KB"] = "Y";
                                string[] textArray15 = new string[] { Resource.Mes_Success_Sync, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                                MessageBox.Show(string.Concat(textArray15), Resource.Mes_Notice);
                            }
                            else
                            {
                                table4.DR["Lock_KB"] = "N";
                                string[] textArray16 = new string[] { Resource.Mes_Success_Request_Edit_DO, " ", sRow["DO_NO"].ToString().Trim(), " ", Resource.Mes_To_ZWB, this.sapIDSYS, " ", coySAP };
                                MessageBox.Show(string.Concat(textArray16), Resource.Mes_Notice);
                            }
                        }
                        flag = true;
                    }
                    if (sRow["uniq"].ToString() != "")
                    {
                        table4.DR.EndEdit();
                        table4.Save();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to ZWB" };
                    Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                }
                catch (RfcInvalidParameterException exception5)
                {
                    MessageBox.Show($"{exception5.GetType().Name} : {exception5.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception6)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception6.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception7)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception7.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception8)
                {
                    MessageBox.Show(Resource.Title_003 + " " + exception8.ToString(), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                if ((str5 != "") && ((str3 == "") & (str4 != "")))
                {
                    if (this.ztable.BeforeEdit(this.dataGridView1, "GRCUST"))
                    {
                        if (WBData.sRegion == "2")
                        {
                            FormContractEntryMsia msia2 = new FormContractEntryMsia {
                                pMode = "GRCUST",
                                zTable = this.ztable,
                                grCust = str4
                            };
                            string[] textArray20 = new string[] { Resource.Title_Replace_Temp_Do, " (", str2, ") ", Resource.Title_Replace_Temp_Do_2 };
                            msia2.Text = string.Concat(textArray20);
                            msia2.zTable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                            msia2.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                            msia2.dataGridView1 = this.dataGridView1;
                            msia2.ShowDialog();
                            if (msia2.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1 = this.ztable.AfterEdit(msia2.pMode);
                                string[] aField = new string[] { "Do_no" };
                                string[] aFind = new string[] { msia2.textDO.Text };
                                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            msia2.Dispose();
                        }
                        else
                        {
                            FormContractEntry entry2 = new FormContractEntry {
                                pMode = "GRCUST",
                                zTable = this.ztable,
                                grCust = str4
                            };
                            string[] textArray23 = new string[] { Resource.Title_Replace_Temp_Do, " (", str2, ") ", Resource.Title_Replace_Temp_Do_2 };
                            entry2.Text = string.Concat(textArray23);
                            entry2.zTable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                            entry2.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                            entry2.dataGridView1 = this.dataGridView1;
                            entry2.ShowDialog();
                            if (entry2.saved)
                            {
                                this.ztable.ReOpen();
                                this.dataGridView1 = this.ztable.AfterEdit(entry2.pMode);
                                string[] aField = new string[] { "Do_no" };
                                string[] aFind = new string[] { entry2.textDO.Text };
                                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            entry2.Dispose();
                        }
                    }
                    else
                    {
                        return flag;
                    }
                }
                flag17 = flag;
            }
            else
            {
                MessageBox.Show(Resource.Mes_Error_Connect_SAP + this.sapIDSYS, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag17 = flag;
            }
            return flag17;
        }

        private void setCommToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBCondition condition = new WBCondition();
            table2.OpenTable("wb_do", "Select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dataGridView1.CurrentRow.Cells["comm_code"].Value.ToString() + "' and gross_weight is not null"), WBData.conn);
            DataRow row = table.DT.Rows[0];
            table2.DR = table2.DT.Rows[0];
            DataRow[] dgRows = new DataRow[] { table2.DT.Rows[0], row };
            condition.fillParameter("CHECK_GROSS_WEIGHT", dgRows);
            if ((!condition.getResult() || ((row["UNIT"].ToString().Trim().ToUpper() == "KG") || (row["Gross_Weight"].ToString() == "0"))) || (row["Gross_Weight"].ToString() == ""))
            {
                MessageBox.Show(Resource.Mes_Only_Pack_Commodity, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                this.hasil = table.tokenOrApp(this.dataGridView1.CurrentRow.Cells["do_No"].Value.ToString(), "", "COMM_CONT_TOL", "TOKEN_COMM_CONT_TOL", "COMM_CONT_TOL", "XX", "", null);
                if (this.hasil[0] != "cancel")
                {
                    if ((this.hasil[0] == "completed") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                    {
                        WBMail mail = new WBMail();
                        WBTable table3 = new WBTable();
                        string[] textArray1 = new string[] { "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE COY ='", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' AND ( Email_Code ='TOKEN_COMM_CONT_TOL')" };
                        table3.OpenTable("wb_email_master", string.Concat(textArray1), WBData.conn);
                        int num = 0;
                        while (true)
                        {
                            if (num >= table3.DT.Rows.Count)
                            {
                                RepCommTol tol = new RepCommTol {
                                    textDoNo = { Text = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString() }
                                };
                                tol.generateRep(tol.initTable(false, DateTime.Now, DateTime.Now, this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString(), WBData.sCoyCode, WBData.sLocCode), DateTime.Now, this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString(), WBData.sCoyCode, WBData.sLocCode);
                                tol.Dispose();
                                mail.haveAttachment = true;
                                string str3 = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString().Replace("/", "");
                                string[] textArray3 = new string[] { Application.UserAppDataPath, @"\LogReport\", WBData.sCoyCode, WBData.sLocCode, "COMM_CONT_LOG_", str3, ".htm" };
                                mail.mailAttachment(string.Concat(textArray3));
                                mail.Body = ("<br><br>Attached Changes of commodity tolerance for Contract : " + this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString()) ?? "";
                                mail.SendMail();
                                mail.Dispose();
                                break;
                            }
                            DataRow row2 = table3.DT.Rows[num];
                            string[] textArray2 = new string[] { row2[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                            mail.Subject = string.Concat(textArray2);
                            mail.To = row2[1].ToString().Trim();
                            mail.CC = row2[2].ToString().Trim();
                            num++;
                        }
                    }
                    condition.Dispose();
                }
            }
        }

        private void setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, this.pMode))
            {
                if (Program.getFieldValue("wb_transaction_type", "is_vessel", "transaction_code", this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString()) != "Y")
                {
                    MessageBox.Show(Resource.Mes_Warning_Not_Vessel_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    string str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                    WBTable table = new WBTable();
                    string[] textArray1 = new string[9];
                    textArray1[0] = "select uniq from wb_transaction\r\n                                      where Coy = '";
                    textArray1[1] = WBData.sCoyCode;
                    textArray1[2] = "' and Location_Code = '";
                    textArray1[3] = WBData.sLocCode;
                    textArray1[4] = "' and Do_No in (\r\n                                      select do_no from wb_contract where uniq in \r\n                                      (select uniq_item from wb_vessel_map where uniq_vessel = '";
                    textArray1[5] = str2;
                    textArray1[6] = "') or uniq = '";
                    textArray1[7] = str2;
                    textArray1[8] = "')\r\n                                      AND ((mark_accident IS NULL) AND(Deleted IS NULL) AND\r\n                                    (Report_Date IS NOT NULL) OR(mark_accident = '') AND(Deleted = '')) AND (split is not null and(split = 'X' or split = 'Y'))";
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_contract", sqltext, WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        MessageBox.Show(Resource.Mes_Vessel_Please_Merge_All_Transaction, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        table.Close();
                        table.Dispose();
                        this.hasil = new WBTable().tokenOrApp(this.dataGridView1.CurrentRow.Cells["do_no"].Value.ToString(), "", "VESSEL_PERCENTAGE_TOLERANCE", "TOKEN_VESSEL_PERCENTAGE_TOLERANCE", "VESSEL_PERCENTAGE_TOLERANCE", "E", "", null);
                        if (this.hasil[0] == "completed")
                        {
                            FormMapVessel vessel = new FormMapVessel {
                                pMode = "EDIT_PERCENTAGE_TOLERANCE",
                                uniq = str2
                            };
                            vessel.ShowDialog();
                            vessel.Dispose();
                        }
                    }
                }
            }
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str;
            WBMulesoftIntegrator integrator;
            List<Dictionary<string, string>> list;
            int num3;
            int num7;
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            string[] textArray1 = new string[] { Resource.Menu_Synchronize_All, " ", this.dataGridView1.Rows.Count.ToString(), " ", Resource.Mes_Rows_To_ZWB, this.sapIDSYS, " ?" };
            if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
            {
                return;
            }
            else
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (!WBSetting.activeMulesoftIntegration)
                {
                    if (WBSAP.connect())
                    {
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CONTRACT");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        num7 = 0;
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    WBTable table = new WBTable();
                    integrator = new WBMulesoftIntegrator();
                    list = new List<Dictionary<string, string>>();
                    num3 = 0;
                    goto TR_004D;
                }
            }
            while (true)
            {
                if (num7 >= count)
                {
                    WBSAP.setImportReturn();
                    WBSAP.sendTable(this.updTable);
                    WBSAP.sendZWB();
                    WBSAP.getAllResult(this.updTable, this.retTable, "STDO");
                    int num8 = 0;
                    while (true)
                    {
                        if (num8 >= this.retTable.Rows.Count)
                        {
                            WBSAP.showReturn();
                            this.progressBar1.Visible = false;
                            break;
                        }
                        DataRow row2 = this.retTable.Rows[num8];
                        string[] aField = new string[] { "DO_NO" };
                        string[] aFind = new string[] { this.ztable.DT.Rows[num8]["DO_NO"].ToString() };
                        int recNo = this.ztable.GetRecNo(aField, aFind);
                        if (recNo > -1)
                        {
                            this.ztable.DR = this.ztable.DT.Rows[recNo];
                            this.logKey = this.ztable.DR["uniq"].ToString();
                            this.ztable.DR.BeginEdit();
                            this.ztable.DR["zwb"] = (row2[1].ToString() == "Y") ? "Y" : "N";
                            this.ztable.DR["sync_return"] = (row2[1].ToString() != "Y") ? row2[2].ToString() : "";
                            this.ztable.DR.EndEdit();
                            this.ztable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to ZWB" };
                            Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                        }
                        num8++;
                    }
                    break;
                }
                this.progressBar1.Refresh();
                if (this.dataGridView1.Rows[num7].Cells["ZWB"].Value.ToString().Trim() != "Y")
                {
                    string zValue = this.dataGridView1.Rows[num7].Cells["DO_NO"].Value.ToString().Trim();
                    str = this.dataGridView1.Rows[num7].Cells["uniq"].Value.ToString().Trim();
                    if (this.dataGridView1.Rows[num7].Cells["zAuto"].Value.ToString() != "Y")
                    {
                        this.zwbRow[0] = WBSetting.CoySAP;
                    }
                    else if (zValue.Substring(zValue.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                    {
                        zValue = this.dataGridView1.Rows[num7].Cells["DO_NO"].Value.ToString().Trim();
                    }
                    else
                    {
                        zValue = zValue.Substring(0, zValue.Length - 1);
                        this.zwbRow[0] = Program.getFieldValue("wb_contract", "Coy_tolling", "DO_NO", zValue);
                    }
                    this.zwbRow[1] = zValue.Trim();
                    this.zwbRow[2] = (this.dataGridView1.Rows[num7].Cells["Do_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num7].Cells["Do_Date"].Value.ToString().Trim()));
                    this.zwbRow[3] = this.dataGridView1.Rows[num7].Cells["Transaction_code"].Value.ToString().Trim();
                    this.zwbRow[4] = this.dataGridView1.Rows[num7].Cells["Relation_code"].Value.ToString().Trim();
                    this.zwbRow[5] = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", this.zwbRow[4]);
                    this.zwbRow[6] = this.dataGridView1.Rows[num7].Cells["Comm_code"].Value.ToString().Trim();
                    this.zwbRow[7] = this.dataGridView1.Rows[num7].Cells["Remark"].Value.ToString().Trim();
                    this.zwbRow[9] = (this.dataGridView1.Rows[num7].Cells["Berikat"].Value.ToString().Trim() == "Y") ? "X" : "";
                    this.zwbRow[8] = (this.zwbRow[9] != "X") ? "NOKB" : "DPIL";
                    this.zwbRow[10] = "";
                    this.zwbRow[11] = this.dataGridView1.Rows[num7].Cells["Contract"].Value.ToString().Trim();
                    this.zwbRow[12] = (this.dataGridView1.Rows[num7].Cells["Contract_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num7].Cells["Contract_Date"].Value.ToString().Trim()));
                    this.zwbRow[13] = this.dataGridView1.Rows[num7].Cells["Transporter_code"].Value.ToString().Trim();
                    this.zwbRow[14] = this.dataGridView1.Rows[num7].Cells["Estate1_code"].Value.ToString().Trim();
                    this.zwbRow[15] = this.dataGridView1.Rows[num7].Cells["Quantity"].Value.ToString().Trim();
                    this.zwbRow[0x10] = "WB1";
                    this.zwbRow[0x11] = (this.dataGridView1.Rows[num7].Cells["langsir_type"].Value.ToString().Trim() != "") ? this.dataGridView1.Rows[num7].Cells["langsir_type"].Value.ToString().Trim() : ((Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", this.dataGridView1.Rows[num7].Cells["transaction_code"].Value.ToString().Trim()) != "I") ? "S" : "P");
                    this.zwbRow[0x12] = this.dataGridView1.Rows[num7].Cells["Vessel"].Value.ToString().Trim();
                    this.zwbRow[0x13] = this.dataGridView1.Rows[num7].Cells["Tolerance"].Value.ToString().Trim();
                    this.zwbRow[20] = this.dataGridView1.Rows[num7].Cells["Estate2_code"].Value.ToString().Trim();
                    this.zwbRow[0x15] = (this.dataGridView1.Rows[num7].Cells["DeductedBy"].Value.ToString().Trim() != "0") ? "1" : "2";
                    this.zwbRow[0x16] = (this.dataGridView1.Rows[num7].Cells["Confirmation_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num7].Cells["Confirmation_Date"].Value.ToString().Trim()));
                    this.zwbRow[0x17] = this.dataGridView1.Rows[num7].Cells["PO"].Value.ToString().Trim();
                    this.zwbRow[0x18] = this.dataGridView1.Rows[num7].Cells["GR"].Value.ToString().Trim();
                    this.zwbRow[0x19] = this.dataGridView1.Rows[num7].Cells["STO"].Value.ToString().Trim();
                    this.zwbRow[0x1a] = (this.dataGridView1.Rows[num7].Cells["STO1DO"].Value.ToString().Trim() == "Y") ? "X" : "";
                    this.zwbRow[0x1b] = this.dataGridView1.Rows[num7].Cells["SO"].Value.ToString().Trim();
                    this.zwbRow[0x1c] = this.dataGridView1.Rows[num7].Cells["SO_Item"].Value.ToString().Trim();
                    this.zwbRow[0x1d] = "";
                    this.zwbRow[30] = this.dataGridView1.Rows[num7].Cells["PI_No"].Value.ToString().Trim();
                    this.zwbRow[0x1f] = this.dataGridView1.Rows[num7].Cells["tolling"].Value.ToString().Trim();
                    this.zwbRow[0x22] = this.dataGridView1.Rows[num7].Cells["Batch"].Value.ToString().Trim();
                    this.zwbRow[0x23] = (this.dataGridView1.Rows[num7].Cells["gain_loss"].Value.ToString().Trim() == "Y") ? "X" : "";
                    this.zwbRow[0x24] = Convert.ToString((int) (Convert.ToInt16(this.dataGridView1.Rows[num7].Cells["Group_Type"].Value.ToString().Trim()) + 1));
                    this.zwbRow[0x25] = "";
                    this.zwbRow[0x26] = this.dataGridView1.Rows[num7].Cells["Create_by"].Value.ToString().Trim();
                    this.zwbRow[0x27] = Program.DTOCSAP2(DateTime.Now);
                    this.zwbRow[40] = DateTime.Now.ToString("HH:mm");
                    this.zwbRow[0x29] = this.dataGridView1.Rows[num7].Cells["Change_by"].Value.ToString().Trim();
                    this.zwbRow[0x2a] = Program.DTOCSAP2(DateTime.Now);
                    this.zwbRow[0x2b] = DateTime.Now.ToString("HH:mm");
                    this.zwbRow[0x2c] = "";
                    this.zwbRow[0x2d] = "";
                    this.zwbRow[0x2e] = this.dataGridView1.Rows[num7].Cells["GR_Cust"].Value.ToString().Trim();
                    this.zwbRow[0x30] = this.dataGridView1.Rows[num7].Cells["Qstandard"].Value.ToString().Trim();
                    this.zwbRow[0x31] = this.dataGridView1.Rows[num7].Cells["STO_ITEM"].Value.ToString().Trim();
                    try
                    {
                        this.zwbRow[0x20] = this.dataGridView1.Rows[num7].Cells["PLANT"].Value.ToString().Trim();
                    }
                    catch
                    {
                        this.zwbRow[0x20] = "";
                    }
                    try
                    {
                        this.zwbRow[0x21] = this.dataGridView1.Rows[num7].Cells["STR_LOC"].Value.ToString().Trim();
                    }
                    catch
                    {
                        this.zwbRow[0x21] = "";
                    }
                    try
                    {
                        this.zwbRow[50] = this.dataGridView1.Rows[num7].Cells["MILL"].Value.ToString().Trim();
                    }
                    catch
                    {
                        this.zwbRow[50] = "";
                    }
                    this.zwbRow[0x33] = this.dataGridView1.Rows[num7].Cells["Franco"].Value.ToString().Trim();
                    this.zwbRow[0x34] = "X";
                    this.zwbRow[0x35] = (this.dataGridView1.Rows[num7].Cells["PO_Item"].Value.ToString().Trim() == "*") ? "" : this.dataGridView1.Rows[num7].Cells["PO_Item"].Value.ToString().Trim();
                    this.zwbRow[0x36] = this.dataGridView1.Rows[num7].Cells["SPB_No"].Value.ToString().Trim();
                    this.zwbRow[0x37] = this.dataGridView1.Rows[num7].Cells["SPB_Item"].Value.ToString().Trim();
                    this.progressBar1.Value = num7;
                    this.updTable.Rows.Add(this.zwbRow);
                }
                num7++;
            }
            return;
        TR_0019:
            num3++;
        TR_004D:
            while (true)
            {
                if (num3 >= count)
                {
                    integrator.prepareTable();
                    integrator.addTable(list, "I_RECORD");
                    bool err = false;
                    string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(integrator.getURL("ZRFC_DNET_WB_CONTRACT"), resultHeaderName, out err);
                    if (!err)
                    {
                        if (dictionary["ERRORS"].Count > 0)
                        {
                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            DataTable table2 = new DataTable();
                            int num4 = 0;
                            while (true)
                            {
                                DataColumn column;
                                if (num4 >= 0x38)
                                {
                                    column = new DataColumn {
                                        ColumnName = "Ref1"
                                    };
                                    table2.Columns.Add(column);
                                    column = new DataColumn {
                                        ColumnName = "Stts2"
                                    };
                                    table2.Columns.Add(column);
                                    column = new DataColumn {
                                        ColumnName = "Rmrk3"
                                    };
                                    table2.Columns.Add(column);
                                    column.Dispose();
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["STDO"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table2.Rows.Add(values);
                                    }
                                    int num5 = 0;
                                    while (true)
                                    {
                                        if (num5 >= table2.Rows.Count)
                                        {
                                            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                                aTable = table2
                                            };
                                            return2.ShowDialog();
                                            return2.Dispose();
                                            break;
                                        }
                                        DataRow row = table2.Rows[num5];
                                        string[] aField = new string[] { "DO_NO" };
                                        string[] aFind = new string[] { row[0].ToString() };
                                        int recNo = this.ztable.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            this.ztable.DR = this.ztable.DT.Rows[recNo];
                                            this.logKey = this.ztable.DR["uniq"].ToString();
                                            this.ztable.DR.BeginEdit();
                                            this.ztable.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            this.ztable.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                            this.ztable.DR.EndEdit();
                                            this.ztable.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to ZWB" };
                                            Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                                        }
                                        num5++;
                                    }
                                    break;
                                }
                                column = new DataColumn();
                                this.updTable.Columns.Add(column);
                                column.Dispose();
                                num4++;
                            }
                        }
                    }
                    break;
                }
                this.progressBar1.Refresh();
                Dictionary<string, string> item = new Dictionary<string, string>();
                if (this.dataGridView1.Rows[num3].Cells["ZWB"].Value.ToString().Trim() != "Y")
                {
                    string zValue = this.dataGridView1.Rows[num3].Cells["DO_NO"].Value.ToString().Trim();
                    str = this.dataGridView1.Rows[num3].Cells["uniq"].Value.ToString().Trim();
                    if (this.dataGridView1.Rows[num3].Cells["zAuto"].Value.ToString() != "Y")
                    {
                        item.Add("ZWB_LOC", WBSetting.CoySAP);
                    }
                    else if (zValue.Substring(zValue.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                    {
                        zValue = this.dataGridView1.Rows[num3].Cells["DO_NO"].Value.ToString().Trim();
                    }
                    else
                    {
                        zValue = zValue.Substring(0, zValue.Length - 1);
                        item.Add("ZWB_LOC", Program.getFieldValue("wb_contract", "Coy_tolling", "DO_NO", zValue));
                    }
                    item.Add("STDO", zValue.Trim());
                    if (this.dataGridView1.Rows[num3].Cells["Do_Date"].Value.ToString().Trim().Length > 0)
                    {
                        item.Add("STDADO", Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Do_Date"].Value.ToString().Trim())));
                    }
                    else
                    {
                        item.Add("STDADO", "");
                    }
                    item.Add("STSTATUS", this.dataGridView1.Rows[num3].Cells["Transaction_code"].Value.ToString().Trim());
                    item.Add("STRELASI", this.dataGridView1.Rows[num3].Cells["Relation_code"].Value.ToString().Trim());
                    item.Add("STCU", Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", this.dataGridView1.Rows[num3].Cells["Relation_code"].Value.ToString().Trim()));
                    item.Add("STCOMM", this.dataGridView1.Rows[num3].Cells["Comm_code"].Value.ToString().Trim());
                    item.Add("STKET", this.dataGridView1.Rows[num3].Cells["Remark"].Value.ToString().Trim());
                    item.Add("STKB", (this.dataGridView1.Rows[num3].Cells["Berikat"].Value.ToString().Trim() == "Y") ? "X" : "");
                    if (this.dataGridView1.Rows[num3].Cells["Berikat"].Value.ToString().Trim() == "X")
                    {
                        item.Add("SBL", "DPIL");
                    }
                    else
                    {
                        item.Add("SBL", "NOKB");
                    }
                    item.Add("STMC", "");
                    item.Add("STKONT", this.dataGridView1.Rows[num3].Cells["Contract"].Value.ToString().Trim());
                    if (this.dataGridView1.Rows[num3].Cells["Contract_Date"].Value.ToString().Trim().Length > 0)
                    {
                        item.Add("STDAKONT", Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Contract_Date"].Value.ToString().Trim())));
                    }
                    else
                    {
                        item.Add("STDAKONT", "");
                    }
                    item.Add("STANGKUT", this.dataGridView1.Rows[num3].Cells["Transporter_code"].Value.ToString().Trim());
                    item.Add("STKEBUN", this.dataGridView1.Rows[num3].Cells["Estate1_code"].Value.ToString().Trim());
                    item.Add("STQTY", this.dataGridView1.Rows[num3].Cells["Quantity"].Value.ToString().Trim());
                    item.Add("STREF", "WB1");
                    if (this.dataGridView1.Rows[num3].Cells["langsir_type"].Value.ToString().Trim() != "")
                    {
                        item.Add("STTYPE", this.dataGridView1.Rows[num3].Cells["langsir_type"].Value.ToString().Trim());
                    }
                    else if (Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", this.dataGridView1.Rows[num3].Cells["transaction_code"].Value.ToString().Trim()) == "I")
                    {
                        item.Add("STTYPE", "P");
                    }
                    else
                    {
                        item.Add("STTYPE", "S");
                    }
                    item.Add("STVESSEL", this.dataGridView1.Rows[num3].Cells["Vessel"].Value.ToString().Trim());
                    item.Add("STTOL", this.dataGridView1.Rows[num3].Cells["Tolerance"].Value.ToString().Trim());
                    item.Add("STTOPRMK", this.dataGridView1.Rows[num3].Cells["Estate2_code"].Value.ToString().Trim());
                    if (this.dataGridView1.Rows[num3].Cells["DeductedBy"].Value.ToString().Trim() == "0")
                    {
                        item.Add("STTOP", "2");
                    }
                    else
                    {
                        item.Add("STTOP", "1");
                    }
                    if (this.dataGridView1.Rows[num3].Cells["Confirmation_Date"].Value.ToString().Trim().Length > 0)
                    {
                        item.Add("STDAKONF", Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Confirmation_Date"].Value.ToString().Trim())));
                    }
                    else
                    {
                        item.Add("STDAKONF", "");
                    }
                    item.Add("STGRPO", this.dataGridView1.Rows[num3].Cells["PO"].Value.ToString().Trim());
                    item.Add("STPO", this.dataGridView1.Rows[num3].Cells["GR"].Value.ToString().Trim());
                    item.Add("STSTO", this.dataGridView1.Rows[num3].Cells["STO"].Value.ToString().Trim());
                    item.Add("ST1STO", (this.dataGridView1.Rows[num3].Cells["STO1DO"].Value.ToString().Trim() == "Y") ? "X" : "");
                    item.Add("STSO", this.dataGridView1.Rows[num3].Cells["SO"].Value.ToString().Trim());
                    item.Add("POSNR", (this.dataGridView1.Rows[num3].Cells["SO_Item"].Value.ToString().Trim() == "*") ? "" : this.dataGridView1.Rows[num3].Cells["SO_Item"].Value.ToString().Trim());
                    item.Add("INT_DO", "");
                    item.Add("PI_NO", this.dataGridView1.Rows[num3].Cells["PI_No"].Value.ToString().Trim());
                    item.Add("STLANGSIR", this.dataGridView1.Rows[num3].Cells["tolling"].Value.ToString().Trim());
                    try
                    {
                        item.Add("STPLANT", this.dataGridView1.Rows[num3].Cells["PLANT"].Value.ToString().Trim());
                    }
                    catch
                    {
                        item.Add("STPLANT", "");
                    }
                }
                else
                {
                    goto TR_0019;
                }
                try
                {
                    item.Add("STR_LOC", this.dataGridView1.Rows[num3].Cells["STR_LOC"].Value.ToString().Trim());
                }
                catch
                {
                    item.Add("STR_LOC", "");
                }
                item.Add("STBATCH", this.dataGridView1.Rows[num3].Cells["Batch"].Value.ToString().Trim());
                item.Add("STGLDEST", (this.dataGridView1.Rows[num3].Cells["gain_loss"].Value.ToString().Trim() == "Y") ? "X" : "");
                try
                {
                    item.Add("STGROUP", Convert.ToString((int) (Convert.ToInt16(this.dataGridView1.Rows[num3].Cells["Group_Type"].Value.ToString().Trim()) + 1)));
                }
                catch
                {
                    item.Add("STGROUP", "");
                }
                item.Add("STTUTUPDA", "");
                item.Add("ERNAM", this.dataGridView1.Rows[num3].Cells["Create_by"].Value.ToString().Trim());
                item.Add("ERDAT", Program.DTOCSAP2(DateTime.Now));
                item.Add("ERZET", DateTime.Now.ToString("HH:mm"));
                item.Add("AENAM", this.dataGridView1.Rows[num3].Cells["Change_by"].Value.ToString().Trim());
                item.Add("AEDAT", Program.DTOCSAP2(DateTime.Now));
                item.Add("AEZET", DateTime.Now.ToString("HH:mm"));
                item.Add("STAT", "");
                item.Add("RFC_TEXT", "");
                item.Add("GRPO2", this.dataGridView1.Rows[num3].Cells["GR_Cust"].Value.ToString().Trim());
                string str2 = ((this.dataGridView1.Rows[num3].Cells["completedGRCust"].Value.ToString().Trim() != "N") && (this.dataGridView1.Rows[num3].Cells["completedGRCust"].Value.ToString().Trim() != "X")) ? "" : this.dataGridView1.Rows[num3].Cells["TokenGRCust"].Value.ToString().Trim();
                item.Add("TOKEN", str2);
                item.Add("ZZISCC", this.dataGridView1.Rows[num3].Cells["Qstandard"].Value.ToString().Trim());
                item.Add("EBELP_STO", this.dataGridView1.Rows[num3].Cells["STO_ITEM"].Value.ToString().Trim());
                try
                {
                    item.Add("MILL", this.dataGridView1.Rows[num3].Cells["MILL"].Value.ToString().Trim());
                }
                catch
                {
                    item.Add("MILL", "");
                }
                item.Add("INCO1", this.dataGridView1.Rows[num3].Cells["Franco"].Value.ToString().Trim());
                item.Add("LOCK_POVAT", "");
                list.Add(item);
                this.progressBar1.Value = num3;
                goto TR_0019;
            }
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.cek_before_sync(true);
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.editLockBongkarToolStripMenuItem.Text = Resource.Menu_Edit_Lock;
            this.entryPINToolStripMenuItem.Text = Resource.Menu_Entry_PIN;
            this.closeDOToolStripMenuItem.Text = Resource.Menu_Toggle_DO;
            this.copyRecordToolStripMenuItem.Text = Resource.Menu_Copy;
            this.deleteToolStripMenuItem.Text = Resource.Trans_057;
            this.printToolStripMenuItem.Text = Resource.DoE_009;
            this.mapVesselDOToolStripMenuItem.Text = Resource.Menu_Map_Vessel_DO;
            this.readoptNoTokenToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.Menu_Readopt_SAP_IDSYS : Resource.Menu_Readopt_SAP;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Menu_ZWB;
            this.synchronizeToolStripMenuItem.Text = Resource.Menu_Synchronize;
            this.synchronizeAllToolStripMenuItem.Text = Resource.Menu_Synchronize_All;
            this.editKBContractToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.Menu_Request_Edit_SAP_IDSYS : Resource.Menu_Request_Edit_SAP;
            this.diagnosticMasterDataToolStripMenuItem.Text = Resource.Menu_Diagnostic;
            this.getContractSpecificationOutspecWarningToolStripMenuItem.Text = Resource.Menu_Get_Contract_Spec;
            this.setCommToolStripMenuItem.Text = Resource.Menu_Set_Comm_Tolerance;
            this.setVesselMaxPercetangeTolerforSplitDOToolStripMenuItem.Text = Resource.Menu_120;
            this.chooseStripMenuItem3.Text = Resource.Menu_Choose;
            this.filterToolStripMenuItem.Text = Resource.Menu_Filter;
            this.unfilterToolStripMenuItem.Text = Resource.Menu_Unfilter;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.cbAll.Text = Resource.Chk_Show_All_DO;
            this.labelCount.Text = Resource.Lbl_Total_Record + " = 0";
            this.checkClosed.Text = Resource.Chk_Show_Closed;
            this.buttonFind.Text = Resource.Menu_Find;
            this.Text = Resource.Title_Contract_List;
        }

        private void unfilterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract ", WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
            this.dataGridView1.Refresh();
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                if (WBData.sRegion == "2")
                {
                    FormContractEntryMsia msia = new FormContractEntryMsia {
                        pMode = "VIEW",
                        zTable = this.ztable,
                        Text = Resource.Title_View_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    msia.ShowDialog();
                    msia.Dispose();
                    this.ztable.UnLock();
                }
                else
                {
                    FormContractEntry entry = new FormContractEntry {
                        pMode = "VIEW",
                        zTable = this.ztable,
                        Text = Resource.Title_View_DO,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    entry.ShowDialog();
                    entry.Dispose();
                    this.ztable.UnLock();
                }
            }
        }

        private void zWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
    }
}

