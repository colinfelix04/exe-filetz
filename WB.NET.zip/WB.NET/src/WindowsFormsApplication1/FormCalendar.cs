﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCalendar : Form
    {
        public bool isOk = false;
        public string tipe;
        public string kb;
        private IContainer components = null;
        private Button button1;
        public TextBox textCommodity;
        private Button button2;
        public Label labelcommodity;
        public Label labelCommName;
        public Button buttonComm;
        private GroupBox grType;
        private GroupBox grKB;
        private RadioButton rboNonKB;
        private RadioButton rboKB;
        private GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        private Label label1;
        private Label label2;
        public DateTimePicker monthCalendar2;
        public Button buttonDoNo;
        public TextBox textDoNo;
        public Label labelDoNo;
        public CheckBox checkDate;
        private GroupBox GRboxFormat;
        public RadioButton radioButton2;
        public RadioButton radioButton1;
        private Label labelVendor;
        private TextBox textVendor;
        public Button buttonVendor;
        public RadioButton rboGI;
        public RadioButton rboGR;

        public FormCalendar()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.isOk = true;
            base.Close();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.isOk = false;
            base.Close();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonVendor_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                TextFind = { Text = this.textVendor.Text.Trim() }
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textVendor.Text = vendor.ReturnRow["Relation_Code"].ToString();
            }
            vendor.Dispose();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.groupDate.Enabled = this.checkDate.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCalendar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FrmCalendar_Load(object sender, EventArgs e)
        {
            this.tipe = "I";
            this.rboGR.Checked = true;
            this.kb = "N";
            this.rboNonKB.Checked = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.labelcommodity = new Label();
            this.textCommodity = new TextBox();
            this.labelCommName = new Label();
            this.buttonComm = new Button();
            this.button2 = new Button();
            this.grType = new GroupBox();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.grKB = new GroupBox();
            this.rboNonKB = new RadioButton();
            this.rboKB = new RadioButton();
            this.groupDate = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.checkDate = new CheckBox();
            this.buttonDoNo = new Button();
            this.textDoNo = new TextBox();
            this.labelDoNo = new Label();
            this.GRboxFormat = new GroupBox();
            this.radioButton2 = new RadioButton();
            this.radioButton1 = new RadioButton();
            this.labelVendor = new Label();
            this.textVendor = new TextBox();
            this.buttonVendor = new Button();
            this.grType.SuspendLayout();
            this.grKB.SuspendLayout();
            this.groupDate.SuspendLayout();
            this.GRboxFormat.SuspendLayout();
            base.SuspendLayout();
            this.button1.Location = new Point(0x16c, 0x120);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x5f, 0x33);
            this.button1.TabIndex = 2;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x19, 0xcf);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 7;
            this.labelcommodity.Text = "Commodity";
            this.textCommodity.Location = new Point(0x5d, 200);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xc0, 20);
            this.textCommodity.TabIndex = 8;
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x13f, 0xcf);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 9;
            this.labelCommName.Text = "Commodity";
            this.buttonComm.Location = new Point(0x125, 0xc5);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 10;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.button13_Click);
            this.button2.Location = new Point(0x1d1, 0x120);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x5f, 0x33);
            this.button2.TabIndex = 13;
            this.button2.Text = "CANCEL";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x12, 12);
            this.grType.Name = "grType";
            this.grType.Size = new Size(310, 0x2d);
            this.grType.TabIndex = 14;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xb0, 0x13);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.TabStop = true;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGI.CheckedChanged += new EventHandler(this.rboGI_CheckedChanged);
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x10, 0x13);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.rboGR.CheckedChanged += new EventHandler(this.rboGR_CheckedChanged);
            this.grKB.Controls.Add(this.rboNonKB);
            this.grKB.Controls.Add(this.rboKB);
            this.grKB.Location = new Point(0x12, 0x3f);
            this.grKB.Name = "grKB";
            this.grKB.Size = new Size(310, 0x2d);
            this.grKB.TabIndex = 15;
            this.grKB.TabStop = false;
            this.rboNonKB.AutoSize = true;
            this.rboNonKB.Location = new Point(0xb0, 0x13);
            this.rboNonKB.Name = "rboNonKB";
            this.rboNonKB.Size = new Size(60, 0x11);
            this.rboNonKB.TabIndex = 0x11;
            this.rboNonKB.TabStop = true;
            this.rboNonKB.Text = "non KB";
            this.rboNonKB.UseVisualStyleBackColor = true;
            this.rboNonKB.CheckedChanged += new EventHandler(this.rboNonKB_CheckedChanged);
            this.rboKB.AutoSize = true;
            this.rboKB.Location = new Point(0x10, 0x13);
            this.rboKB.Name = "rboKB";
            this.rboKB.Size = new Size(0x27, 0x11);
            this.rboKB.TabIndex = 0x10;
            this.rboKB.TabStop = true;
            this.rboKB.Text = "KB";
            this.rboKB.UseVisualStyleBackColor = true;
            this.rboKB.CheckedChanged += new EventHandler(this.rboKB_CheckedChanged);
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x12, 140);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x21e, 0x2d);
            this.groupDate.TabIndex = 0x12;
            this.groupDate.TabStop = false;
            this.groupDate.Enter += new EventHandler(this.groupBox1_Enter);
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x4e, 0x13);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0xc0, 20);
            this.monthCalendar1.TabIndex = 11;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(6, 0x1a);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x130, 0x1a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x16a, 0x13);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(180, 20);
            this.monthCalendar2.TabIndex = 12;
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(0x1b, 0x7e);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x13;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.buttonDoNo.Location = new Point(0x125, 0xe4);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x17, 0x17);
            this.buttonDoNo.TabIndex = 0x17;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Visible = false;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.textDoNo.Location = new Point(0x5d, 0xe7);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xc0, 20);
            this.textDoNo.TabIndex = 0x15;
            this.textDoNo.Visible = false;
            this.textDoNo.Leave += new EventHandler(this.textDoNo_Leave);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(0x2d, 0xea);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x26, 13);
            this.labelDoNo.TabIndex = 20;
            this.labelDoNo.Text = "Do No";
            this.labelDoNo.Visible = false;
            this.GRboxFormat.Controls.Add(this.radioButton2);
            this.GRboxFormat.Controls.Add(this.radioButton1);
            this.GRboxFormat.Location = new Point(0x180, 0xc5);
            this.GRboxFormat.Name = "GRboxFormat";
            this.GRboxFormat.Size = new Size(0xaf, 70);
            this.GRboxFormat.TabIndex = 0x18;
            this.GRboxFormat.TabStop = false;
            this.GRboxFormat.Text = "Report Format";
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new Point(11, 0x2a);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new Size(0x44, 0x11);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "Summary";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new Point(11, 0x12);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new Size(0x34, 0x11);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Detail";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.labelVendor.AutoSize = true;
            this.labelVendor.Location = new Point(14, 0x10b);
            this.labelVendor.Name = "labelVendor";
            this.labelVendor.Size = new Size(0x45, 13);
            this.labelVendor.TabIndex = 0x19;
            this.labelVendor.Text = "Vendor Code";
            this.textVendor.Location = new Point(0x5d, 0x105);
            this.textVendor.Name = "textVendor";
            this.textVendor.Size = new Size(0xc0, 20);
            this.textVendor.TabIndex = 0x1a;
            this.buttonVendor.Location = new Point(0x125, 0x103);
            this.buttonVendor.Margin = new Padding(0);
            this.buttonVendor.Name = "buttonVendor";
            this.buttonVendor.Size = new Size(0x17, 0x17);
            this.buttonVendor.TabIndex = 0x1b;
            this.buttonVendor.Text = "...";
            this.buttonVendor.UseVisualStyleBackColor = true;
            this.buttonVendor.Click += new EventHandler(this.buttonVendor_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x24c, 0x16a);
            base.ControlBox = false;
            base.Controls.Add(this.buttonVendor);
            base.Controls.Add(this.textVendor);
            base.Controls.Add(this.labelVendor);
            base.Controls.Add(this.GRboxFormat);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.grKB);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormCalendar";
            this.Text = "Calendar";
            base.Load += new EventHandler(this.FrmCalendar_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCalendar_KeyPress);
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.grKB.ResumeLayout(false);
            this.grKB.PerformLayout();
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.GRboxFormat.ResumeLayout(false);
            this.GRboxFormat.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void rboGI_CheckedChanged(object sender, EventArgs e)
        {
            this.tipe = "O";
        }

        private void rboGR_CheckedChanged(object sender, EventArgs e)
        {
            this.tipe = "I";
        }

        private void rboKB_CheckedChanged(object sender, EventArgs e)
        {
            this.kb = "Y";
        }

        private void rboNonKB_CheckedChanged(object sender, EventArgs e)
        {
            this.kb = "N";
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            if (this.textDoNo.Text != "")
            {
                FormContract contract = new FormContract();
                table.OpenTable("wb_contract", "SELECT * FROM wb_contract Where " + WBData.CompanyLocation(" and Do_No='" + this.textDoNo.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.buttonDoNo.PerformClick();
                }
                contract.Dispose();
                table.Dispose();
            }
        }
    }
}

