﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Windows.Forms;
    using TokenAppHandler.Utility;

    public class WBTable : Component
    {
        public WBToken aToken = new WBToken();
        public string noToken = "";
        public SqlDataAdapter DA;
        public DataSet DS;
        public DataTable DT;
        public DataView DV;
        public DataRow DR;
        public int nCurrRow;
        public int dataGridPosRow;
        public SqlCommandBuilder objCommandBuilder;
        public ListSortDirection direction;
        public string dirSort = "";
        public string uniq = "";
        public string lastUniq = "";
        public DataGridViewColumn oldColumn;
        public DataGridView dataGridView;
        public string tblname = "";
        public string SqlCommand = "";
        public SqlConnection Conn;
        public string lockingUser = "";
        public static string cFieldTrans = "Coy,Location_Code,WX,Transaction_Code,Ref_Date,Gatepass_number,RegCard_No,Ref,Time1,Time2,Comm_Code,Comm_Name,Truck_Number,Truck_Number2,Truck_Trailer_Number,Do_No,PI_No,Gross,Tare,Received,Deduction,Net,TotalBunch,TotalBunchGrading,Report_Date,Report2_Date,Delivery_Date,Delivery_Time,Register_Date,Register_Time,Relation_Code,Estate_Code,Storage,License_No,Name,Transporter_Code,Delivery_Note,Unloading,Remark_Ticket,Remark_Report,Gross_Estate,Tare_Estate,Net_Estate,Average,Fruits_Type,Rend_CPO,TBS_Reject,Reason,Seal,_1st,Date1,_2nd,Date2,_3rd,Date3,Time3,_4th,Date4,Time4,In_Time,Out_Time,UnitName,WeightPerUnitName,Estate,Nego,Sto,Gr,Do,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,Edit_By,Edit_Date,Edit_Qty,Edit_Data,Edit_Qc_By,Edit_Qc_Date,Printed,Printed_By,Printed_Date,Ticket,ReturRef,Tanker,TankQC,MaxCap,checksum,ISCC_Checked,ISCC_GC_Checked,ISCC_No,ISCC_No2,ISCC_Weight,ChangeReason,approve,approveBy1,approveBy2,WBCode1,WBCode2,WBCode3,WBCode4,posted,Manual,NonContract,EstateDiff,Split,Tolling,zAuto,Token,TokenDL,completed,completedDL,TotalGunny,NOPW,Addi_Info,sync_return,mark_return,return_ref,materialStuffing,mark_accident,accident_reason,posted_opw,internal_number,do_sap,density,loading_qty,mill,registrationClose_date,registrationClose_time,registrationClose_by,linked, cancel_type,uniq";
        public static string[] cField_from_other_table = new string[] { "comm_name", "internal_number", "do_sap", "density", "loading_qty", "RegCard_No" };
        public static string cFieldTransAfrica = "Coy,Location_Code,WX,Transaction_Code,Ref_Date,Gatepass_number,Ref,Time1,Time2,Comm_Code,Truck_Number,Truck_Number2,Transporter_Code,QCStatus,Truck_Trailer_Number,Do_No,Gross,Tare,Received,Deduction,Net,TotalBunch,TotalBunchGrading,Report_Date,Report2_Date,Delivery_Date,Delivery_Time,Register_Date,Register_Time,Relation_Code,Estate_Code,Storage,License_No,Name,Delivery_Note,Unloading,Remark_Ticket,Remark_Report,Gross_Estate,Tare_Estate,Net_Estate,Average,Fruits_Type,Rend_CPO,Grade,Seal,_1st,Date1,_2nd,Date2,_3rd,Date3,Time3,_4th,Date4,Time4,In_Time,Out_Time,UnitName,WeightPerUnitName,Estate,Nego,Sto,Gr,Do,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,Edit_By,Edit_Date,Edit_Qty,Edit_Data,Edit_Qc_By,Edit_Qc_Date,Printed,Printed_By,Printed_Date,Ticket,ReturRef,Tanker,TankQC,MaxCap,checksum,ISCC_Checked,ISCC_GC_Checked,ISCC_No,ISCC_No2,ISCC_Weight,TotalGunny,bag_code,bag,bag_change,total_Bag_Weight,Source_code,Mill_code,Division_code,DivBlock,load_unload,ChangeReason,approve,approveBy1,approveBy2,WBCode1,WBCode2,WBCode3,WBCode4,posted,Manual,NonContract,EstateDiff,Split,Tolling,zAuto,Token,completed,transWarning,uniq";

        public void AddFromDGV(DataGridView pDGV, string pKey, string pVal)
        {
            this.ReOpen();
            this.nCurrRow = 0;
            foreach (DataRow row in this.DT.Rows)
            {
                if (row[pKey].ToString() == pVal)
                {
                    this.DT.Rows[this.nCurrRow].Delete();
                }
                this.nCurrRow++;
            }
            this.Save();
            string str = "";
            foreach (DataGridViewRow row2 in (IEnumerable) pDGV.Rows)
            {
                this.DR = this.DT.NewRow();
                int num = 0;
                while (true)
                {
                    if (num >= this.DT.Columns.Count)
                    {
                        this.DR["Coy"] = WBData.sCoyCode;
                        this.DR["Location_Code"] = WBData.sLocCode;
                        this.DR[pKey] = pVal;
                        this.DT.Rows.Add(this.DR);
                        this.Save();
                        break;
                    }
                    str = this.DT.Columns[num].ColumnName.ToString();
                    bool flag2 = str.ToUpper() != "UNIQ".ToUpper();
                    if (flag2 && ((row2.Cells[str].Value != null) && (row2.Cells[str].Value.ToString().Trim() != "")))
                    {
                        this.DR[str] = row2.Cells[str].Value;
                    }
                    num++;
                }
            }
        }

        public void AddFromDGV_new(DataGridView pDGV, string pKey, string pVal, string pMode, string reason)
        {
            string str = "";
            this.ReOpen();
            this.nCurrRow = 0;
            int index = 0;
            string[] strArray = new string[this.DT.Rows.Count];
            foreach (DataRow row in this.DT.Rows)
            {
                bool flag = false;
                foreach (DataGridViewRow row2 in (IEnumerable) pDGV.Rows)
                {
                    if (((row[pKey].ToString() == pVal) && (row2.Cells["uniq"].Value != null)) && (row2.Cells["uniq"].Value.ToString() == row["uniq"].ToString()))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    strArray[index] = row["uniq"].ToString();
                    index++;
                    this.DT.Rows[this.nCurrRow].Delete();
                }
                flag = false;
                this.nCurrRow++;
            }
            this.Save();
            int num2 = 0;
            while (true)
            {
                if (num2 >= strArray.Length)
                {
                    this.ReOpen();
                    foreach (DataGridViewRow row3 in (IEnumerable) pDGV.Rows)
                    {
                        bool flag6 = false;
                        foreach (DataRow row4 in this.DT.Rows)
                        {
                            if (((row4[pKey].ToString() == pVal) && (row3.Cells["uniq"].Value != null)) && (row3.Cells["uniq"].Value.ToString() == row4["uniq"].ToString()))
                            {
                                flag6 = true;
                                break;
                            }
                        }
                        if (!flag6)
                        {
                            this.DR = this.DT.NewRow();
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= this.DT.Columns.Count)
                                {
                                    this.DR["Coy"] = WBData.sCoyCode;
                                    this.DR["Location_Code"] = WBData.sLocCode;
                                    this.DR[pKey] = pVal;
                                    this.DT.Rows.Add(this.DR);
                                    this.Save();
                                    this.ReOpen();
                                    WBTable table = new WBTable();
                                    string[] textArray3 = new string[] { " AND ", pKey, "='", pVal, "' ORDER BY uniq DESC" };
                                    table.OpenTable(this.tblname, "SELECT uniq FROM " + this.tblname + " WHERE " + WBData.CompanyLocation(string.Concat(textArray3)), WBData.conn);
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { pMode, WBUser.UserID, reason };
                                    Program.updateLogHeader(this.tblname, table.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                                    break;
                                }
                                str = this.DT.Columns[num3].ColumnName.ToString();
                                bool flag9 = str.ToUpper() != "UNIQ".ToUpper();
                                if (flag9 && (row3.Cells[str].Value != null))
                                {
                                    this.DR[str] = row3.Cells[str].Value;
                                }
                                num3++;
                            }
                        }
                        flag6 = false;
                    }
                    this.ReOpen();
                    this.nCurrRow = 0;
                    foreach (DataGridViewRow row5 in (IEnumerable) pDGV.Rows)
                    {
                        bool flag12 = false;
                        bool flag13 = false;
                        int num4 = 0;
                        foreach (DataRow row6 in this.DT.Rows)
                        {
                            if (((row6[pKey].ToString() == pVal) && (row5.Cells["uniq"].Value != null)) && (row5.Cells["uniq"].Value.ToString() == row6["uniq"].ToString()))
                            {
                                flag12 = true;
                                this.nCurrRow = num4;
                                break;
                            }
                            num4++;
                        }
                        if (flag12)
                        {
                            this.DR = this.DT.Rows[this.nCurrRow];
                            this.DR.BeginEdit();
                            int num5 = 0;
                            while (true)
                            {
                                if (num5 >= this.DT.Columns.Count)
                                {
                                    this.DR.EndEdit();
                                    this.Save();
                                    if (flag13)
                                    {
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { pMode, WBUser.UserID, reason };
                                        Program.updateLogHeader(this.tblname, this.DR["Uniq"].ToString(), logField, logValue);
                                    }
                                    break;
                                }
                                str = this.DT.Columns[num5].ColumnName.ToString();
                                bool flag16 = row5.Cells[str].Value != null;
                                if (flag16 && (row5.Cells[str].Value.ToString() != this.DR[str].ToString()))
                                {
                                    this.DR[str] = row5.Cells[str].Value.ToString();
                                    flag13 = true;
                                }
                                num5++;
                            }
                        }
                        flag12 = false;
                    }
                    return;
                }
                if ((strArray[num2] != "") || ReferenceEquals(strArray[num2], null))
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { pMode, WBUser.UserID, reason };
                    Program.updateLogHeader(this.tblname, strArray[num2], logField, logValue);
                }
                num2++;
            }
        }

        public DataGridView AfterEdit(string pMode)
        {
            pMode = ((pMode == "1ST") || ((pMode == "COPY") || (pMode == "MANUAL"))) ? "ADD" : pMode;
            pMode = ((pMode == "2ND") || ((pMode == "3RD") || ((pMode == "4TH") || (pMode == "CANCEL")))) ? "EDIT" : pMode;
            bool flag = ((pMode == "EDIT") || ((pMode == "SPLIT") || (pMode == "MERGE"))) || (pMode == "DETAIL");
            this.dataGridView.DataSource = this.DT;
            this.direction = (this.dirSort != "Ascending") ? ListSortDirection.Descending : ListSortDirection.Ascending;
            int nCurrRow = this.nCurrRow;
            if (((pMode == "EDIT") || ((pMode == "DELETE") || ((pMode == "SPLIT") || ((pMode == "MERGE") || ((pMode == "ADD_RETUR") || ((pMode == "QTY") || ((pMode == "DEDUCTION") || (pMode == "EDIT_SPB")))))))) || (pMode == "EDIT_REPORTDATE"))
            {
                this.RLock(this.uniq, false);
            }
            else if (pMode == "DELETE")
            {
                this.DelLock(this.uniq);
            }
            else
            {
                nCurrRow = this.DT.Rows.Count - 1;
            }
            if (this.oldColumn != null)
            {
                this.dataGridView.Sort(this.dataGridView.Columns[this.oldColumn.Name.ToString()], this.direction);
            }
            if (nCurrRow > -1)
            {
                if (!flag)
                {
                    if (this.dataGridPosRow > -1)
                    {
                        this.SetCursor(this.dataGridView, this.dataGridPosRow);
                    }
                }
                else if (this.DT.Rows.Count <= 0)
                {
                    return this.dataGridView;
                }
                else
                {
                    nCurrRow = (nCurrRow > (this.DT.Rows.Count - 1)) ? (this.DT.Rows.Count - 1) : nCurrRow;
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { this.DT.Rows[nCurrRow]["uniq"].ToString() };
                    nCurrRow = this.GetCurrentRow(this.dataGridView, aField, aFind);
                    this.SetCursor(this.dataGridView, nCurrRow);
                }
            }
            return this.dataGridView;
        }

        public bool BeforeEdit(DataGridView dataGridView1, string pMode)
        {
            DateTime now;
            WBTable table4;
            bool flag36;
            this.noToken = "";
            bool flag = false;
            string key = "0";
            DataModal dM = new DataModal();
            FormToken ftoken = new FormToken();
            string str2 = "";
            dM.DA = this.DA;
            dM.DT = this.DT;
            dM.DGV = dataGridView1;
            dM.DS = this.DS;
            if ((WBSetting.Field("GM") != "Y") || (Convert.ToInt16(WBUser.UserLevel) <= 1))
            {
                goto TR_0003;
            }
            else
            {
                bool flag3 = true;
                now = DateTime.Now;
                if ((((pMode != "EDIT") && ((pMode != "CANCEL") && ((pMode != "DELETE") && ((pMode != "REPRINT") && ((pMode != "QTY") && ((pMode != "MANUAL") && ((pMode != "TOLERANCE_COMM") && ((pMode != "MARK_ACCIDENT") && ((pMode != "OVER_GROSSQTY") && ((pMode != "NOT_ADOPTSAP") && ((pMode != "DO_SAP") && ((pMode != "DO_SAP_FAIL_VALID") && ((pMode != "OVER_TANKER") && ((pMode != "ADD_RETUR") && ((pMode != "BLACKLIST") && ((pMode != "EDIT_SPAREPART") && ((pMode != "GRCUST") || (dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() != "N")))))))))))))))))) && ((pMode != "DEDUCTION") && ((pMode != "EDIT_SPB") && (pMode != "EDIT_DELETE_MD_DN")))) && (pMode != "EDIT_REPORTDATE"))
                {
                    goto TR_0003;
                }
                else
                {
                    ftoken.email_date = now;
                    ftoken.type = "BEFORE_EDIT";
                    ftoken.DM = dM;
                    string s = pMode;
                    uint num = <PrivateImplementationDetails>.ComputeStringHash(s);
                    if (num <= 0x7cc72f70)
                    {
                        if (num <= 0x4f2762af)
                        {
                            if (num <= 0x5f1a47c)
                            {
                                if (num != 0x19dd70c)
                                {
                                    if ((num == 0x5f1a47c) && (s == "MARK_ACCIDENT"))
                                    {
                                        ftoken.email_code = "TOKEN_MARK_ACCIDENT";
                                    }
                                }
                                else if (s == "DEDUCTION")
                                {
                                    ftoken.email_code = "TOKEN_EDIT_DEDUCTION";
                                }
                            }
                            else if (num == 0x77e1c11)
                            {
                                if (s == "EDIT")
                                {
                                    ftoken.email_code = "TOKEN_EDIT";
                                }
                            }
                            else if (num != 0x2523b2ee)
                            {
                                if ((num == 0x4f2762af) && (s == "DO_SAP"))
                                {
                                    ftoken.email_code = "TOKEN_DO_SAP";
                                }
                            }
                            else if (s == "EDIT_DELETE_MD_DN")
                            {
                                ftoken.email_code = "TOKEN_EDIT_DELETE_MASTER_DATA_DELIVERY_NOTE";
                            }
                        }
                        else if (num <= 0x67cf6a2c)
                        {
                            if (num != 0x52fabbdb)
                            {
                                if ((num == 0x67cf6a2c) && (s == "BLACKLIST"))
                                {
                                    ftoken.email_code = "TOKEN_BLACKLIST";
                                }
                            }
                            else if (s == "CANCEL")
                            {
                                ftoken.email_code = "TOKEN_CANCEL";
                            }
                        }
                        else if (num == 0x70b7f2f3)
                        {
                            if (s == "QTY")
                            {
                                ftoken.email_code = "TOKEN_EDITQTY";
                            }
                        }
                        else if (num != 0x7ba48539)
                        {
                            if ((num == 0x7cc72f70) && (s == "EDIT_SPAREPART"))
                            {
                                ftoken.email_code = "TOKEN_EDIT_SPAREPART";
                            }
                        }
                        else if (s == "TOLERANCE_COMM")
                        {
                            ftoken.email_code = "TOKEN_TOLERANCE_COMM";
                        }
                    }
                    else if (num <= 0xb630cc9d)
                    {
                        if (num <= 0x9cd01f69)
                        {
                            if (num != 0x802918b0)
                            {
                                if ((num == 0x9cd01f69) && (s == "EDIT_SPB"))
                                {
                                    ftoken.email_code = "TOKEN_EDIT_DELIVERY_NOTE_AT_TRANSACTION";
                                }
                            }
                            else if (s == "OVER_GROSSQTY")
                            {
                                ftoken.email_code = "TOKEN_OVER_GROSSQTY";
                            }
                        }
                        else if (num == 0xa6d43504)
                        {
                            if (s == "EDIT_REPORTDATE")
                            {
                                ftoken.email_code = "TOKEN_EDIT_REPORT_DATE_AT_TRANSACTION";
                            }
                        }
                        else if (num != 0xaaced0c7)
                        {
                            if ((num == 0xb630cc9d) && (s == "DO_SAP_FAIL_VALID"))
                            {
                                ftoken.email_code = "TOKEN_DO_SAP_FAIL_VALID";
                            }
                        }
                        else if (s == "ADD_RETUR")
                        {
                            ftoken.email_code = "TOKEN_ADD_RETUR";
                        }
                    }
                    else if (num <= 0xc861e707)
                    {
                        if (num != 0xc3bae7e1)
                        {
                            if ((num == 0xc861e707) && (s == "OVER_TANKER"))
                            {
                                ftoken.email_code = "TOKEN_OVER_TANKER";
                            }
                        }
                        else if (s == "NOT_ADOPTSAP")
                        {
                            ftoken.email_code = "TOKEN_NOT_ADOPTSAP";
                        }
                    }
                    else if (num == 0xcd1b3da3)
                    {
                        if (s == "MANUAL")
                        {
                            ftoken.email_code = "TOKEN_MANUAL";
                        }
                    }
                    else if (num != 0xe87f69c9)
                    {
                        if ((num == 0xf8718eca) && (s == "DELETE"))
                        {
                            ftoken.email_code = "TOKEN_DELETE";
                        }
                    }
                    else if (s == "OVERQTY")
                    {
                        ftoken.email_code = "TOKEN_OVERQTY";
                    }
                    if (pMode == "MANUAL")
                    {
                        goto TR_0019;
                    }
                    else if (this.DT.TableName.ToUpper().Trim() == "WB_TRANSACTION".ToUpper().Trim())
                    {
                        if (this.DT.TableName.ToUpper().Trim() != "WB_TRANSACTION".ToUpper().Trim())
                        {
                            goto TR_0019;
                        }
                        else if (pMode == "QTY")
                        {
                            try
                            {
                                if (Convert.ToInt16(dataGridView1.CurrentRow.Cells["EDIT_QTY"].Value.ToString()) >= 5)
                                {
                                    flag = true;
                                }
                                key = dataGridView1.CurrentRow.Cells["EDIT_QTY"].Value.ToString();
                            }
                            catch
                            {
                                flag = false;
                                key = "0";
                            }
                        }
                        else if (((pMode == "EDIT") || ((pMode == "DEDUCTION") || (pMode == "EDIT_SPB"))) || (pMode == "EDIT_REPORTDATE"))
                        {
                            try
                            {
                                if (Convert.ToInt16(dataGridView1.CurrentRow.Cells["EDIT_DATA"].Value.ToString()) >= 5)
                                {
                                    flag = true;
                                }
                                key = dataGridView1.CurrentRow.Cells["EDIT_DATA"].Value.ToString();
                            }
                            catch
                            {
                                flag = false;
                                key = "0";
                            }
                        }
                        else if ((pMode == "ADD_RETUR") || (pMode == "EDIT_SPAREPART"))
                        {
                            WBTable table3 = new WBTable();
                            string[] textArray3 = new string[] { " AND ( Token_Code ='", pMode, "' and completed = 'N' and key_1 = '", dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim(), "' )" };
                            table3.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray3)), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                ftoken.oldToken = table3.DT.Rows[0]["Token_No"].ToString().Trim();
                                ftoken.textBoxToken.Text = table3.DT.Rows[0]["Token_No"].ToString().Trim();
                            }
                            else
                            {
                                string[] tokenParams = new string[] { dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                                ftoken.initData(tokenParams, pMode, this.tblname, "0", "");
                                ftoken.trans_ref = dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim();
                            }
                            ftoken.pmode = pMode;
                            table3.Dispose();
                        }
                    }
                    else
                    {
                        string str4 = "";
                        try
                        {
                            str4 = dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                        }
                        catch
                        {
                        }
                        if (this.DT.TableName.ToUpper().Trim() == "WB_CONTRACT".ToUpper().Trim())
                        {
                            str2 = "CONTRACTLOG";
                            if (dataGridView1.CurrentRow.Cells["completed"].Value.ToString() == "N")
                            {
                                ftoken.textBoxToken.Text = dataGridView1.CurrentRow.Cells["token"].Value.ToString();
                                flag3 = true;
                            }
                            else if (dataGridView1.CurrentRow.Cells["completedGRCust"].Value.ToString() == "N")
                            {
                                ftoken.textBoxToken.Text = dataGridView1.CurrentRow.Cells["tokengrcust"].Value.ToString();
                                flag3 = true;
                            }
                        }
                        else if (this.DT.TableName.ToUpper().Trim() == "WB_EMAIL_MASTER".ToUpper().Trim())
                        {
                            flag3 = false;
                            ftoken.saved = true;
                            ftoken.completed = "Y";
                        }
                        else if (pMode == "TOLERANCE_COMM")
                        {
                            WBTable table = new WBTable();
                            string[] textArray1 = new string[] { " AND ( Token_Code ='", pMode, "' and completed = 'N' and key_1 = '", dataGridView1.CurrentRow.Cells["Comm_Code"].Value.ToString().Trim(), "' )" };
                            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                ftoken.textBoxToken.Text = table.DT.Rows[0]["Token_No"].ToString().Trim();
                                flag3 = true;
                            }
                            table.Dispose();
                        }
                        else if (pMode != "MARK_ACCIDENT")
                        {
                            if (dataGridView1.CurrentRow.Cells["completed"].Value.ToString() == "N")
                            {
                                ftoken.textBoxToken.Text = dataGridView1.CurrentRow.Cells["token"].Value.ToString();
                                flag3 = true;
                            }
                        }
                        else
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND ( Token_Code ='" + pMode + "' and completed = 'N' )"), WBData.conn);
                            if (table2.DT.Rows.Count > 0)
                            {
                                ftoken.textBoxToken.Text = table2.DT.Rows[0]["Token_No"].ToString().Trim();
                                flag3 = true;
                            }
                            table2.Dispose();
                        }
                        if (((this.DT.TableName.ToUpper().Trim() == "WB_USER".ToUpper().Trim()) || (this.DT.TableName.ToUpper().Trim() == "WB_SAPDEST".ToUpper().Trim())) || (this.DT.TableName.ToUpper().Trim() == "WB_CALIBRATION".ToUpper().Trim()))
                        {
                            flag3 = false;
                            ftoken.saved = true;
                            ftoken.completed = "Y";
                        }
                        if (dataGridView1.CurrentRow.Cells["completed"].Value.ToString() == "N")
                        {
                            ftoken.oldToken = dataGridView1.CurrentRow.Cells["Token"].Value.ToString();
                        }
                        string[] tokenParams = new string[] { str4 };
                        ftoken.initData(tokenParams, pMode, this.tblname, "0", "");
                        if (flag3)
                        {
                            ftoken.ShowDialog();
                        }
                        goto TR_0019;
                    }
                }
            }
            if (((pMode == "EDIT") || ((pMode == "QTY") || ((pMode == "CANCEL") || ((pMode == "DEDUCTION") || (pMode == "EDIT_SPB"))))) || (pMode == "EDIT_REPORTDATE"))
            {
                str2 = "TRANSLOG";
                if (dataGridView1.CurrentRow.Cells["completed"].Value.ToString() == "N")
                {
                    ftoken.oldToken = dataGridView1.CurrentRow.Cells["Token"].Value.ToString();
                    ftoken.textBoxToken.Text = dataGridView1.CurrentRow.Cells["Token"].Value.ToString();
                }
                string[] tokenParams = new string[] { dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                ftoken.initData(tokenParams, pMode, this.tblname, key, "");
                ftoken.trans_ref = dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim();
            }
            ftoken.editnX = flag;
            ftoken.ShowDialog();
            goto TR_0019;
        TR_0003:
            return this.saveToken(pMode, key, dM, ftoken);
        TR_0004:
            if (!this.shouldSaveToken(pMode, ftoken.saved, str2, now, dM))
            {
                return false;
            }
            goto TR_0003;
        TR_0005:
            table4.Dispose();
            goto TR_0004;
        TR_0019:
            if (pMode != "MANUAL")
            {
                goto TR_0004;
            }
            else
            {
                string str6 = "0";
                string str7 = "0";
                bool flag29 = true;
                ftoken.email_code = "TOKEN_MANUAL";
                ftoken.email_date = now;
                table4 = new WBTable();
                WBTable table5 = new WBTable();
                table5.OpenTable("wb_ref", "select * from wb_ref where " + WBData.CompanyLocation(" and ref_code = 'NO_TICKET_REF'"), WBData.conn);
                table4.OpenTable("wb_loc", "select * from wb_location where " + WBData.CompanyLocation(""), WBData.conn);
                if ((table4.DT.Rows.Count <= 0) || (table5.DT.Rows.Count <= 0))
                {
                    flag29 = true;
                }
                else
                {
                    flag29 = false;
                    string str5 = Program.shoot(table4.DT.Rows[0]["tokenManual"].ToString(), false);
                    str6 = Program.shoot(table4.DT.Rows[0]["maxEntry"].ToString(), false);
                    str7 = Program.shoot(table4.DT.Rows[0]["currEntry"].ToString(), false);
                    if (str6 == "")
                    {
                        str6 = "0";
                    }
                    if ((Convert.ToInt16(str6.Trim()) <= 0) || (str6 == str7))
                    {
                        flag29 = true;
                        ftoken.textBoxToken.Text = str5;
                    }
                    else
                    {
                        ftoken.saved = true;
                        ftoken.textBoxToken.Text = str5;
                        flag29 = false;
                    }
                }
                if (!flag29)
                {
                    goto TR_0005;
                }
                else
                {
                    key = "0";
                    str2 = "TRANSLOG";
                    string[] tokenParams = new string[] { "" };
                    ftoken.initData(tokenParams, pMode, this.tblname, key, "");
                    ftoken.ShowDialog();
                    if (!ftoken.saved)
                    {
                        flag36 = false;
                    }
                    else
                    {
                        table4.ReOpen();
                        table4.DR = table4.DT.Rows[0];
                        table5.DR = table5.DT.Rows[0];
                        table4.DR.BeginEdit();
                        table5.DR.BeginEdit();
                        table4.DR["TokenManual"] = Program.shoot(ftoken.textBoxToken.Text, true);
                        if (ftoken.completed != "Y")
                        {
                            table4.DR["completed"] = "N";
                        }
                        else
                        {
                            table4.DR["completed"] = ftoken.completed;
                            string txt = DateTime.Now.Date.ToString().Remove(10);
                            table4.DR["TokenExpiredDate"] = Program.shoot(txt, true);
                        }
                        table4.DR["MaxEntry"] = Program.shoot(ftoken.manualQty, true);
                        table4.DR["CurrEntry"] = Program.shoot("0", true);
                        table4.DR["StartRef"] = Program.shoot(table5.DR["Ref_no"].ToString(), true);
                        table5.DR["ref_No"] = (Convert.ToDouble(table5.DR["Ref_no"].ToString()) + Convert.ToDouble(ftoken.manualQty)).ToString();
                        table4.DR["checksum"] = table4.Checksum(table4.DR);
                        table4.DR.EndEdit();
                        table5.DR.EndEdit();
                        table5.Save();
                        table4.Save();
                        if (ftoken.completed != "N")
                        {
                            goto TR_0005;
                        }
                        else
                        {
                            flag36 = false;
                        }
                    }
                }
            }
            return flag36;
        }

        public string CekTokenCompleted(string key_1, string key_2, string token_code, bool complete)
        {
            string str2 = "";
            WBTable table = new WBTable();
            str2 = !complete ? " AND completed = 'N'" : " AND completed = 'Y'";
            if (key_2 == "")
            {
                string[] textArray1 = new string[9];
                textArray1[0] = " AND ( Token_Code ='";
                textArray1[1] = token_code;
                textArray1[2] = "' AND key_1 = '";
                textArray1[3] = key_1;
                textArray1[4] = "' AND (key_2 = '";
                textArray1[5] = key_2;
                textArray1[6] = "' or key_2 is null) ";
                textArray1[7] = str2;
                textArray1[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            }
            else
            {
                string[] textArray2 = new string[9];
                textArray2[0] = " AND ( Token_Code ='";
                textArray2[1] = token_code;
                textArray2[2] = "' AND key_1 = '";
                textArray2[3] = key_1;
                textArray2[4] = "' AND key_2 = '";
                textArray2[5] = key_2;
                textArray2[6] = "'";
                textArray2[7] = str2;
                textArray2[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
            }
            string str = (table.DT.Rows.Count <= 0) ? "" : table.DT.Rows[0]["Token_No"].ToString().Trim();
            table.Dispose();
            return str;
        }

        public string Checksum(DataRow row)
        {
            string s = "";
            string str3 = "";
            foreach (DataColumn column in this.DT.Columns)
            {
                bool flag = column.ColumnName.ToString().ToUpper() != "CHECKSUM";
                if (flag && ((column.ColumnName.ToString().ToUpper() != "UNIQ") && (column.ColumnName.ToString().ToUpper() != "TOKEN")))
                {
                    string str4 = "";
                    str4 = (row[column.ColumnName].GetType().ToString() != "System.DateTime") ? row[column.ColumnName].ToString().Trim() : Program.DTOS(DateTime.Parse(row[column.ColumnName].ToString())).Trim();
                    s = s + str4;
                    str3 = str3 + "~" + column.ColumnName.ToString().ToUpper();
                }
            }
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            int index = 0;
            while (true)
            {
                if (index >= s.Length)
                {
                    num = (num * 0x13) / 4;
                    string str2 = s;
                    return num.ToString();
                }
                num += bytes[index];
                index++;
            }
        }

        public string Checksum_Main(DataRow row)
        {
            string s = "";
            string str3 = "";
            bool flag = false;
            foreach (DataColumn column in this.DT.Columns)
            {
                flag = false;
                string[] strArray = cField_from_other_table;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= strArray.Length)
                    {
                        if ((!flag && (column.ColumnName.ToString().ToUpper() != "CHECKSUM")) && ((column.ColumnName.ToString().ToUpper() != "UNIQ") && (column.ColumnName.ToString().ToUpper() != "TOKEN")))
                        {
                            string str5 = "";
                            str5 = (row[column.ColumnName].GetType().ToString() != "System.DateTime") ? row[column.ColumnName].ToString().Trim() : Program.DTOS(DateTime.Parse(row[column.ColumnName].ToString())).Trim();
                            s = s + str5;
                            str3 = str3 + "~" + column.ColumnName.ToString().ToUpper();
                        }
                        break;
                    }
                    string str4 = strArray[num2];
                    if (str4.ToUpper() == column.ColumnName.ToString().ToUpper())
                    {
                        flag = true;
                    }
                    num2++;
                }
            }
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            int index = 0;
            while (true)
            {
                if (index >= s.Length)
                {
                    num = (num * 0x13) / 4;
                    string str2 = s;
                    return num.ToString();
                }
                num += bytes[index];
                index++;
            }
        }

        public void ClearToken(string key_1, string key_2, string token_code, bool complete)
        {
            string str2 = "";
            WBTable table = new WBTable();
            str2 = !complete ? " AND completed = 'N'" : " AND completed = 'Y'";
            if (key_2 == "")
            {
                string[] textArray1 = new string[9];
                textArray1[0] = " AND ( Token_Code ='";
                textArray1[1] = token_code;
                textArray1[2] = "' AND key_1 = '";
                textArray1[3] = key_1;
                textArray1[4] = "' AND (key_2 = '";
                textArray1[5] = key_2;
                textArray1[6] = "' or key_2 is null) ";
                textArray1[7] = str2;
                textArray1[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            }
            else
            {
                string[] textArray2 = new string[9];
                textArray2[0] = " AND ( Token_Code ='";
                textArray2[1] = token_code;
                textArray2[2] = "' AND key_1 = '";
                textArray2[3] = key_1;
                textArray2[4] = "' AND key_2 = '";
                textArray2[5] = key_2;
                textArray2[6] = "'";
                textArray2[7] = str2;
                textArray2[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
            }
            if (table.DT.Rows.Count > 0)
            {
                string str = table.DT.Rows[0]["Token_No"].ToString().Trim();
                foreach (DataRow row in table.DT.Rows)
                {
                    row.Delete();
                }
                table.Save();
            }
            table.Dispose();
        }

        public void Close()
        {
            this.DT.Clear();
            this.DS.Clear();
            this.DA.Dispose();
        }

        public WBTable Copy() => 
            new WBTable { DT = this.DT.Copy() };

        public void DelLock(string pUniq)
        {
            WBTable table = new WBTable();
            string text1 = "Select * From wb_rlock Where TableName='" + this.tblname.Trim() + "' and  UniqKey=" + pUniq;
            string sqltext = text1;
            if (text1 == null)
            {
                string local1 = text1;
                sqltext = "";
            }
            table.OpenTable("wb_rlock", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DT.Rows[0].Delete();
                table.Save();
            }
            table.Dispose();
        }

        public bool DelTokenCompleted(string key_1, string key_2, string token_code, bool complete)
        {
            bool flag4;
            string str = "";
            WBTable table = new WBTable();
            str = !complete ? " AND completed = 'N'" : " AND completed = 'Y'";
            if (key_2 == "")
            {
                string[] textArray1 = new string[9];
                textArray1[0] = " AND ( Token_Code ='";
                textArray1[1] = token_code;
                textArray1[2] = "' AND key_1 = '";
                textArray1[3] = key_1;
                textArray1[4] = "' AND (key_2 = '";
                textArray1[5] = key_2;
                textArray1[6] = "' or key_2 is null) ";
                textArray1[7] = str;
                textArray1[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            }
            else
            {
                string[] textArray2 = new string[9];
                textArray2[0] = " AND ( Token_Code ='";
                textArray2[1] = token_code;
                textArray2[2] = "' AND key_1 = '";
                textArray2[3] = key_1;
                textArray2[4] = "' AND key_2 = '";
                textArray2[5] = key_2;
                textArray2[6] = "'";
                textArray2[7] = str;
                textArray2[8] = ")";
                table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
            }
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                flag4 = false;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                table.DR.Delete();
                table.Save();
                table.Dispose();
                flag4 = true;
            }
            return flag4;
        }

        public void DVFind(DataGridView dataGridView1, string TextFind)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                int num = new DataView(this.DS.Tables[0]) { Sort = dataGridView1.SortedColumn.Name.ToString() }.Find(TextFind);
                if (num < 0)
                {
                    MessageBox.Show(Resource.Mes_348);
                }
                else
                {
                    CurrencyManager manager = (CurrencyManager) dataGridView1.BindingContext[this.DS.Tables[0]];
                    DataRowView current = (DataRowView) manager.Current;
                    manager.Position = num;
                    current = (DataRowView) manager.Current;
                }
            }
        }

        public void Find(DataGridView dataGridView1, string TextFind)
        {
            int index;
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
                return;
            }
            else
            {
                string str = dataGridView1.SortedColumn.Name.ToString();
                new DataView(this.DS.Tables[0]).Sort = str;
                index = -1;
                TextFind = TextFind.Trim().ToUpper();
                bool flag2 = false;
                Cursor.Current = Cursors.WaitCursor;
                using (IEnumerator enumerator = ((IEnumerable) dataGridView1.Rows).GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                        string str2 = current.Cells[str].Value.ToString().ToUpper();
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 < TextFind.Trim().Length)
                            {
                                if (str2.Length < TextFind.Trim().Length)
                                {
                                    flag2 = false;
                                }
                                else
                                {
                                    if (TextFind[num2] == str2[num2])
                                    {
                                        flag2 = true;
                                        num2++;
                                        continue;
                                    }
                                    flag2 = false;
                                }
                            }
                            if (!flag2)
                            {
                                break;
                            }
                            index = current.Index;
                            goto TR_0007;
                        }
                    }
                }
            }
        TR_0007:
            Cursor.Current = Cursors.Default;
            if (index < 0)
            {
                MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                CurrencyManager manager = (CurrencyManager) dataGridView1.BindingContext[this.DS.Tables[0]];
                DataRowView current = (DataRowView) manager.Current;
                manager.Position = index;
                current = (DataRowView) manager.Current;
                dataGridView1.Refresh();
            }
        }

        public void FindSql(DataGridView dataGridView1, string textFind)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                string str = dataGridView1.SortedColumn.Name.ToString();
                string sqltext = "";
                string str3 = "";
                string str4 = "";
                string str5 = " = ";
                string str6 = (dataGridView1.SortOrder.ToString() != "Descending") ? "Asc" : "Desc";
                str3 = "";
                int num = 0;
                while (true)
                {
                    if (num >= textFind.Length)
                    {
                        WBTable table = new WBTable();
                        string[] textArray1 = new string[11];
                        textArray1[0] = this.SqlCommand;
                        textArray1[1] = " and ";
                        textArray1[2] = str;
                        textArray1[3] = " ";
                        textArray1[4] = str5;
                        textArray1[5] = " '";
                        textArray1[6] = str3;
                        textArray1[7] = "' order by ";
                        textArray1[8] = str;
                        textArray1[9] = " ";
                        textArray1[10] = str6;
                        sqltext = string.Concat(textArray1);
                        table.OpenTable(this.tblname, sqltext, WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            string uniq = table.DT.Rows[0]["uniq"].ToString();
                            table.DR = table.DT.Rows[0];
                            str4 = table.DR[str].ToString();
                            this.FindUniq(dataGridView1, uniq);
                        }
                        table.Dispose();
                        break;
                    }
                    char ch = textFind[num];
                    if (ch.ToString() != "*")
                    {
                        str3 = str3 + textFind[num].ToString();
                    }
                    else
                    {
                        str5 = " like ";
                        str3 = str3 + "%";
                    }
                    num++;
                }
            }
        }

        public void FindUniq(DataGridView dataGridView1, string Uniq)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                DataView view = new DataView(this.DS.Tables[0]);
                int index = -1;
                Cursor.Current = Cursors.WaitCursor;
                foreach (DataGridViewRow row in (IEnumerable) dataGridView1.Rows)
                {
                    string str = row.Cells["uniq"].Value.ToString().ToUpper();
                    if (str.Equals(Uniq))
                    {
                        index = row.Index;
                        break;
                    }
                }
                Cursor.Current = Cursors.Default;
                if (index < 0)
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    CurrencyManager manager = (CurrencyManager) dataGridView1.BindingContext[this.DS.Tables[0]];
                    DataRowView current = (DataRowView) manager.Current;
                    manager.Position = index;
                    current = (DataRowView) manager.Current;
                    dataGridView1.Refresh();
                }
            }
        }

        public void FindUniqforDoubleData(DataGridView dataGridView1, string Uniq, string additionalHeader, string additionalHeaderData)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                DataView view = new DataView(this.DS.Tables[0]);
                int index = -1;
                Cursor.Current = Cursors.WaitCursor;
                foreach (DataGridViewRow row in (IEnumerable) dataGridView1.Rows)
                {
                    string str = row.Cells["uniq"].Value.ToString().ToUpper();
                    string str2 = row.Cells[additionalHeader].Value.ToString().ToUpper();
                    if (str.Equals(Uniq) && str2.ToUpper().Contains(additionalHeaderData.Replace("*", "").ToUpper()))
                    {
                        index = row.Index;
                        break;
                    }
                }
                Cursor.Current = Cursors.Default;
                if (index < 0)
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    CurrencyManager manager = (CurrencyManager) dataGridView1.BindingContext[this.DS.Tables[0]];
                    DataRowView current = (DataRowView) manager.Current;
                    manager.Position = index;
                    current = (DataRowView) manager.Current;
                    dataGridView1.Refresh();
                }
            }
        }

        public int GetCurrentRow(DataGridView dataGridView1, string[] aField, string[] aFind)
        {
            using (IEnumerator enumerator = ((IEnumerable) dataGridView1.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    bool flag = true;
                    int index = 0;
                    while (true)
                    {
                        if (index < aField.Length)
                        {
                            if (current.Cells[aField[index]].Value.ToString() == aFind[index])
                            {
                                index++;
                                continue;
                            }
                            flag = false;
                        }
                        if (!flag)
                        {
                            break;
                        }
                        return dataGridView1.Rows.IndexOf(current);
                    }
                }
            }
            return -1;
        }

        public DataRow GetData(string[] aField, string[] aFind)
        {
            DataRow row = this.DT.NewRow();
            Cursor.Current = Cursors.WaitCursor;
            if (this.DT.Rows.Count > 0)
            {
                using (IEnumerator enumerator = this.DT.Rows.GetEnumerator())
                {
                    while (true)
                    {
                        if (enumerator.MoveNext())
                        {
                            DataRow current = (DataRow) enumerator.Current;
                            bool flag2 = true;
                            int index = 0;
                            while (true)
                            {
                                if (index < aField.Length)
                                {
                                    if (current[aField[index]].ToString().ToUpper().Trim() == aFind[index].ToUpper().Trim())
                                    {
                                        index++;
                                        continue;
                                    }
                                    flag2 = false;
                                    row = null;
                                }
                                if (!flag2)
                                {
                                    continue;
                                }
                                else
                                {
                                    row = current;
                                }
                                break;
                            }
                        }
                        break;
                    }
                    goto TR_0004;
                }
            }
            row = null;
        TR_0004:
            Cursor.Current = Cursors.Default;
            return row;
        }

        public int GetPosRec(string pUniq)
        {
            if (pUniq == "")
            {
                this.nCurrRow = -1;
            }
            else
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { pUniq };
                this.nCurrRow = this.GetRecNo(aField, aFind);
            }
            return this.nCurrRow;
        }

        public int GetRecNo(string[] aField, string[] aFind)
        {
            int num2 = 0;
            using (IEnumerator enumerator = this.DT.Rows.GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataRow current = (DataRow) enumerator.Current;
                    num2++;
                    DataRowState rowState = current.RowState;
                    if (rowState.ToString().Trim().ToUpper() != "Deleted".ToUpper())
                    {
                        bool flag2 = true;
                        int index = 0;
                        while (true)
                        {
                            if (index < aField.Length)
                            {
                                if (current[aField[index]].ToString().Trim().ToUpper() == aFind[index].Trim().ToUpper())
                                {
                                    index++;
                                    continue;
                                }
                                flag2 = false;
                            }
                            if (!flag2)
                            {
                                break;
                            }
                            return this.DT.Rows.IndexOf(current);
                        }
                    }
                }
            }
            return -1;
        }

        public bool Locked(string pUniq, char msg)
        {
            bool flag3;
            if (pUniq == "")
            {
                flag3 = false;
            }
            else
            {
                bool flag = false;
                WBTable table = new WBTable();
                string text1 = "Select * From wb_rlock Where TableName='" + this.tblname.Trim() + "' and  UniqKey=" + pUniq;
                string sqltext = text1;
                if (text1 == null)
                {
                    string local1 = text1;
                    sqltext = "";
                }
                table.OpenTable("wb_rlock", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    flag3 = flag;
                }
                else
                {
                    this.lockingUser = table.DT.Rows[0]["User_ID"].ToString();
                    if (table.DT.Rows[0]["ComputerName"].ToString().Trim() == Environment.MachineName)
                    {
                        flag3 = false;
                    }
                    else
                    {
                        flag = table.DT.Rows[0]["Status"].ToString().Trim() == "L";
                        if (flag)
                        {
                            if (DateTime.Now.Subtract(Convert.ToDateTime(table.DT.Rows[0]["Da"].ToString())).Minutes >= 10)
                            {
                                flag = false;
                            }
                            else if (msg == '1')
                            {
                                MessageBox.Show(Resource.Mes_562 + " " + table.DT.Rows[0]["ComputerName"].ToString().Trim() + " . . . !", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        flag3 = flag;
                    }
                }
            }
            return flag3;
        }

        public int NextFindSql(DataGridView dataGridView1, string textFind, int currIdx)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                string str = dataGridView1.SortedColumn.Name.ToString();
                string sqltext = "";
                string str3 = "";
                string str4 = "";
                string str5 = " = ";
                string str6 = (dataGridView1.SortOrder.ToString() != "Descending") ? "Asc" : "Desc";
                str3 = "";
                int num = 0;
                while (true)
                {
                    if (num >= textFind.Length)
                    {
                        WBTable table = new WBTable();
                        string[] textArray1 = new string[11];
                        textArray1[0] = this.SqlCommand;
                        textArray1[1] = " and ";
                        textArray1[2] = str;
                        textArray1[3] = " ";
                        textArray1[4] = str5;
                        textArray1[5] = " '";
                        textArray1[6] = str3;
                        textArray1[7] = "' order by ";
                        textArray1[8] = str;
                        textArray1[9] = " ";
                        textArray1[10] = str6;
                        sqltext = string.Concat(textArray1);
                        table.OpenTable(this.tblname, sqltext, WBData.conn);
                        if (currIdx >= table.DT.Rows.Count)
                        {
                            currIdx = 0;
                        }
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            string uniq = table.DT.Rows[currIdx]["uniq"].ToString();
                            table.DR = table.DT.Rows[currIdx];
                            str4 = table.DR[str].ToString();
                            this.FindUniq(dataGridView1, uniq);
                        }
                        table.Dispose();
                        break;
                    }
                    char ch = textFind[num];
                    if (ch.ToString() != "*")
                    {
                        str3 = str3 + textFind[num].ToString();
                    }
                    else
                    {
                        str5 = " like ";
                        str3 = str3 + "%";
                    }
                    num++;
                }
            }
            return (currIdx + 1);
        }

        public int NextFindSqlForDoubleData(DataGridView dataGridView1, string textFind, int currIdx)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                string additionalHeader = dataGridView1.SortedColumn.Name.ToString();
                string sqltext = "";
                string str3 = "";
                string str4 = "";
                string str5 = " = ";
                string str6 = (dataGridView1.SortOrder.ToString() != "Descending") ? "Asc" : "Desc";
                str3 = "";
                int num = 0;
                while (true)
                {
                    if (num >= textFind.Length)
                    {
                        WBTable table = new WBTable();
                        string[] textArray1 = new string[11];
                        textArray1[0] = this.SqlCommand;
                        textArray1[1] = " and ";
                        textArray1[2] = additionalHeader;
                        textArray1[3] = " ";
                        textArray1[4] = str5;
                        textArray1[5] = " '";
                        textArray1[6] = str3;
                        textArray1[7] = "' order by ";
                        textArray1[8] = additionalHeader;
                        textArray1[9] = " ";
                        textArray1[10] = str6;
                        sqltext = string.Concat(textArray1);
                        table.OpenTable(this.tblname, sqltext, WBData.conn);
                        if (currIdx >= table.DT.Rows.Count)
                        {
                            currIdx = 0;
                        }
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            string uniq = table.DT.Rows[currIdx]["uniq"].ToString();
                            table.DR = table.DT.Rows[currIdx];
                            str4 = table.DR[additionalHeader].ToString();
                            this.FindUniqforDoubleData(dataGridView1, uniq, additionalHeader, textFind);
                        }
                        table.Dispose();
                        break;
                    }
                    char ch = textFind[num];
                    if (ch.ToString() != "*")
                    {
                        str3 = str3 + textFind[num].ToString();
                    }
                    else
                    {
                        str5 = " like ";
                        str3 = str3 + "%";
                    }
                    num++;
                }
            }
            return (currIdx + 1);
        }

        public int NextFindSqlv2(DataGridView dataGridView1, string textFind, int currIdx)
        {
            if (dataGridView1.SortOrder.ToString() == "None")
            {
                MessageBox.Show(Resource.Mes_549);
            }
            else
            {
                string str = dataGridView1.SortedColumn.Name.ToString();
                string sqltext = "";
                string str3 = "";
                string str4 = "";
                string str5 = " = ";
                string str6 = (dataGridView1.SortOrder.ToString() != "Descending") ? "Asc" : "Desc";
                str3 = "";
                int num = 0;
                while (true)
                {
                    if (num >= textFind.Length)
                    {
                        WBTable table = new WBTable();
                        string[] textArray1 = new string[12];
                        textArray1[0] = "Select * from (";
                        textArray1[1] = this.SqlCommand;
                        textArray1[2] = ") as sq WHERE sq.";
                        textArray1[3] = str;
                        textArray1[4] = " ";
                        textArray1[5] = str5;
                        textArray1[6] = " '";
                        textArray1[7] = str3;
                        textArray1[8] = "' order by sq.";
                        textArray1[9] = str;
                        textArray1[10] = " ";
                        textArray1[11] = str6;
                        sqltext = string.Concat(textArray1);
                        table.OpenTable(this.tblname, sqltext, WBData.conn);
                        if (currIdx >= table.DT.Rows.Count)
                        {
                            currIdx = 0;
                        }
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mes_348, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            string uniq = table.DT.Rows[currIdx]["uniq"].ToString();
                            table.DR = table.DT.Rows[currIdx];
                            str4 = table.DR[str].ToString();
                            this.FindUniq(dataGridView1, uniq);
                        }
                        table.Dispose();
                        break;
                    }
                    char ch = textFind[num];
                    if (ch.ToString() != "*")
                    {
                        str3 = str3 + textFind[num].ToString();
                    }
                    else
                    {
                        str5 = " like ";
                        str3 = str3 + "%";
                    }
                    num++;
                }
            }
            return (currIdx + 1);
        }

        public void OpenTable(string tablename, string sqltext, SqlConnection conn)
        {
            try
            {
                if (!sqltext.ToUpper().Contains("WHERE") && (((tablename.Trim().ToUpper() != "WB_COMPANY") && ((tablename.Trim().ToUpper() != "WB_LOCATION") && (tablename.Trim().ToUpper() != "WB_RLOCK"))) && (tablename.Trim().ToUpper() != "WB_ZDO")))
                {
                    sqltext = sqltext + " WHERE " + WBData.CompanyLocation("");
                }
                this.DA = new SqlDataAdapter(sqltext, conn);
                this.DS = new DataSet();
                this.DA.Fill(this.DS, tablename);
                this.objCommandBuilder = new SqlCommandBuilder(this.DA);
                this.DT = new DataTable();
                this.DT = this.DS.Tables[tablename];
                this.DV = new DataView(this.DT);
                this.tblname = tablename;
                this.SqlCommand = sqltext;
                this.Conn = conn;
            }
            catch (Exception exception)
            {
                if (WBUser.UserLevel != "1")
                {
                    MessageBox.Show(Resource.Mes_548 + "\n" + exception.Message + "\nPlease Recheck...", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_548, "\n", exception.Message, "\n\nSQLTEXT : ", sqltext, "\n" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        public void ReOpen()
        {
            this.Close();
            this.DA = new SqlDataAdapter(this.SqlCommand, this.Conn);
            this.DS = new DataSet();
            this.DA.Fill(this.DS, this.tblname);
            this.DT = new DataTable();
            this.DT = this.DS.Tables[this.tblname];
            this.DV = new DataView(this.DT);
        }

        public void RLock(string pUniq, bool Locked)
        {
            if (pUniq != "")
            {
                this.lastUniq = pUniq;
                WBTable table = new WBTable();
                string text1 = "Select * From wb_rlock Where TableName='" + this.tblname.Trim() + "' and  UniqKey=" + pUniq;
                string sqltext = text1;
                if (text1 == null)
                {
                    string local1 = text1;
                    sqltext = "";
                }
                table.OpenTable("wb_rlock", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    if (!Locked)
                    {
                        return;
                    }
                    else
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["TableName"] = this.tblname.Trim();
                        table.DR["UniqKey"] = pUniq.Trim();
                        table.DR["Status"] = Locked ? "L" : "F";
                        table.DR["User_ID"] = WBUser.UserID.Trim();
                        table.DR["ComputerName"] = Environment.MachineName;
                        table.DR["Da"] = DateTime.Now;
                        table.DT.Rows.Add(table.DR);
                    }
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["Status"] = Locked ? "L" : "F";
                    table.DR["User_ID"] = WBUser.UserID.Trim();
                    table.DR["ComputerName"] = Environment.MachineName;
                    table.DR["Da"] = DateTime.Now;
                    table.DR.EndEdit();
                }
                table.Save();
                table.Dispose();
            }
        }

        public void Save()
        {
            this.objCommandBuilder = new SqlCommandBuilder(this.DA);
            this.DA.Update(this.DS, this.tblname);
            this.DS.AcceptChanges();
        }

        public bool saveToken(string pMode, string jlhEdit, DataModal DM, FormToken ftoken)
        {
            bool saved = false;
            string completed = "N";
            DataGridView dGV = DM.DGV;
            if (pMode == "GRCUST")
            {
                pMode = "EDIT";
            }
            this.dirSort = dGV.SortOrder.ToString();
            this.oldColumn = dGV.SortedColumn;
            this.dataGridView = dGV;
            pMode = ((pMode == "1ST") || ((pMode == "COPY") || (pMode == "MANUAL"))) ? "ADD" : pMode;
            pMode = ((pMode == "2ND") || ((pMode == "3RD") || ((pMode == "4TH") || (pMode == "CANCEL")))) ? "EDIT" : pMode;
            if (this.dataGridView.RowCount <= 0)
            {
                this.dataGridPosRow = -1;
                this.uniq = "";
            }
            else
            {
                this.dataGridPosRow = dGV.CurrentRow.Index;
                this.uniq = dGV.CurrentRow.Cells["uniq"].Value.ToString();
                if (((pMode == "EDIT") || ((pMode == "DELETE") || ((pMode == "SPLIT") || ((pMode == "MERGE") || ((pMode == "ADD_RETUR") || ((pMode == "QTY") || ((pMode == "DEDUCTION") || (pMode == "EDIT_SPB")))))))) || (pMode == "EDIT_REPORTDATE"))
                {
                    this.RLock(this.uniq, true);
                }
            }
            if (((WBSetting.Field("GM") == "Y") && (Convert.ToInt16(WBUser.UserLevel) > 1)) && (pMode != "ADD"))
            {
                this.DA = DM.DA;
                this.DT = DM.DT;
                this.DS = DM.DS;
                this.tblname = this.DT.TableName;
                saved = ftoken.saved;
                completed = ftoken.completed;
                this.noToken = (ftoken.textBoxToken.Text.Length > 0) ? ftoken.textBoxToken.Text.Trim() : "";
                if (saved)
                {
                    if (this.tblname.ToUpper() == "WB_TRANSACTION")
                    {
                        if (pMode != "ADD_RETUR")
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE uniq ='" + this.uniq + "'", WBData.conn);
                            table2.DR = table2.DT.Rows[0];
                            table2.DR.BeginEdit();
                            table2.DR["token"] = this.noToken;
                            table2.DR["Completed"] = completed;
                            table2.DR["Checksum"] = this.Checksum_Main(table2.DR);
                            table2.DR.EndEdit();
                            table2.Save();
                            table2.Dispose();
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            string[] textArray1 = new string[] { " AND ( Token_Code ='", pMode, "' and key_1 = '", dGV.CurrentRow.Cells["Ref"].Value.ToString().Trim(), "' )" };
                            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                if (completed == "Y")
                                {
                                    table.DR = table.DT.Rows[0];
                                    table.DR.Delete();
                                    table.Save();
                                }
                            }
                            else
                            {
                                table.DR = table.DT.NewRow();
                                table.DR["COY"] = WBData.sCoyCode;
                                table.DR["LOCATION_CODE"] = WBData.sLocCode;
                                table.DR["key_1"] = dGV.CurrentRow.Cells["Ref"].Value.ToString().Trim();
                                table.DR["completed"] = completed;
                                table.DR["Token_No"] = this.noToken;
                                table.DR["Token_Code"] = pMode;
                                table.DT.Rows.Add(table.DR);
                                table.Save();
                            }
                            table.Dispose();
                        }
                    }
                    else if (this.tblname.ToUpper() == "WB_GATEPASS")
                    {
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE uniq ='" + this.uniq + "'", WBData.conn);
                        table3.DR = table3.DT.Rows[0];
                        table3.DR.BeginEdit();
                        table3.DR["token"] = this.noToken;
                        table3.DR["Completed"] = completed;
                        table3.DR.EndEdit();
                        table3.Save();
                        table3.Dispose();
                    }
                    else
                    {
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { this.uniq };
                        this.DR = this.GetData(aField, aFind);
                        this.DR.BeginEdit();
                        if ((this.tblname.ToUpper() == "WB_CONTRACT") && (dGV.CurrentRow.Cells["completedGRCust"].Value.ToString() == "N"))
                        {
                            if (completed == "Y")
                            {
                                this.DR["CompletedGRCust"] = "X";
                                this.DR["tokenGRCust"] = this.noToken;
                            }
                        }
                        else if ((this.tblname.ToUpper() != "WB_COMMODITY") || (pMode != "TOLERANCE_COMM"))
                        {
                            this.DR["token"] = this.noToken;
                            this.DR["Completed"] = completed;
                        }
                        else
                        {
                            WBTable table4 = new WBTable();
                            string[] textArray4 = new string[] { " AND ( Token_Code ='", pMode, "' and key_1 = '", dGV.CurrentRow.Cells["Comm_Code"].Value.ToString().Trim(), "' )" };
                            table4.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray4)), WBData.conn);
                            if (table4.DT.Rows.Count > 0)
                            {
                                if (completed == "Y")
                                {
                                    table4.DR = table4.DT.Rows[0];
                                    table4.DR.Delete();
                                    table4.Save();
                                }
                            }
                            else
                            {
                                table4.DR = table4.DT.NewRow();
                                table4.DR["COY"] = WBData.sCoyCode;
                                table4.DR["LOCATION_CODE"] = WBData.sLocCode;
                                table4.DR["key_1"] = dGV.CurrentRow.Cells["Comm_Code"].Value.ToString().Trim();
                                table4.DR["completed"] = completed;
                                table4.DR["Token_No"] = this.noToken;
                                table4.DR["Token_Code"] = pMode;
                                table4.DT.Rows.Add(table4.DR);
                                table4.Save();
                            }
                            table4.Dispose();
                        }
                        if ((this.tblname.ToUpper() != "WB_COMMODITY") || (pMode != "TOLERANCE_COMM"))
                        {
                            this.DR.EndEdit();
                            this.Save();
                        }
                    }
                    if (completed == "N")
                    {
                        return false;
                    }
                }
            }
            this.nCurrRow = this.GetPosRec(this.uniq);
            return true;
        }

        public bool saveTokenCodeBeforeEdit(string pMode, string jlhEdit, string email_code, DateTime email_date, DataModal DM, FormToken ftoken)
        {
            this.noToken = "";
            bool tokenSaved = false;
            tokenSaved = ftoken.saved;
            return (this.shouldSaveToken(pMode, tokenSaved, email_code, email_date, DM) ? this.saveToken(pMode, jlhEdit, DM, ftoken) : false);
        }

        public string[] saveTokenCodeOrApp(WBTable tblTemp, TokenOrAppModal TM, Dictionary<string, object> disable_condition_params, FormToken fToken)
        {
            string[] strArray = new string[3];
            string str = TM.key_1;
            string str2 = TM.key_2;
            string str3 = TM.token_code;
            bool baru = TM.baru;
            if (!(fToken.saved && (fToken.completed == "N")))
            {
                if (!(fToken.saved && (fToken.completed == "Y")))
                {
                    strArray[0] = "cancel";
                    return strArray;
                }
                else
                {
                    if (((str3 != "COMM_CONT_TOL") && (str3 != "BYPASS_EXPIRED_BC")) && (str3 != "UNLOCK_TDT"))
                    {
                        if (!baru)
                        {
                            tblTemp.DR.Delete();
                            tblTemp.Save();
                        }
                        tblTemp.Dispose();
                    }
                    else
                    {
                        if (!baru)
                        {
                            tblTemp.DR.BeginEdit();
                        }
                        tblTemp.DR["coy"] = WBData.sCoyCode;
                        tblTemp.DR["location_code"] = WBData.sLocCode;
                        tblTemp.DR["key_1"] = str;
                        tblTemp.DR["key_2"] = str2;
                        tblTemp.DR["completed"] = "Y";
                        tblTemp.DR["Token_No"] = fToken.textBoxToken.Text;
                        tblTemp.DR["Token_Code"] = str3;
                        if (str3 == "COMM_CONT_TOL")
                        {
                            tblTemp.DR["CountUsed"] = 0;
                            tblTemp.DR["UnitOfTrx"] = fToken.AllTrx;
                            tblTemp.DR["Tolerance"] = fToken.CommTol;
                            tblTemp.DR["datetime1"] = DateTime.Now;
                        }
                        if (baru)
                        {
                            tblTemp.DT.Rows.Add(tblTemp.DR);
                        }
                        else
                        {
                            tblTemp.DR.EndEdit();
                        }
                        tblTemp.Save();
                    }
                    if ((disable_condition_params != null) && (str3 == "DISABLE_CONDITION"))
                    {
                        foreach (string str7 in (List<string>) disable_condition_params["appliedLocation"])
                        {
                            char[] separator = new char[] { '-' };
                            string str8 = str7.Split(separator)[0];
                            char[] chArray4 = new char[] { '-' };
                            string str9 = str7.Split(chArray4)[1];
                            WBTable table2 = new WBTable();
                            string[] textArray1 = new string[] { "select * from wb_Condition where Coy = '", str8, "' and Location_code = '", str9, "' and Condition_code = '", (string) disable_condition_params["ToBeDisabledCondition"], "'" };
                            string sqltext = string.Concat(textArray1);
                            table2.OpenTable("wb_Condition", sqltext, WBData.conn);
                            foreach (DataRow row in table2.DT.Rows)
                            {
                                row.BeginEdit();
                                row["start_inactive_time"] = (string) disable_condition_params["requested_start_inactive_time"];
                                row["end_inactive_time"] = (string) disable_condition_params["requested_end_inactive_time"];
                                row.EndEdit();
                            }
                            table2.Save();
                            WBTable table3 = new WBTable();
                            string[] textArray2 = new string[] { "select * from wb_token_disable_detail where Coy = '", str8, "' and Location_Code = '", str9, "' and Token_No = '", fToken.textBoxToken.Text, "'" };
                            table3.OpenTable("wb_token_disable_detail", string.Concat(textArray2), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DT.Rows[0].Delete();
                                table3.Save();
                            }
                        }
                    }
                }
            }
            else
            {
                tblTemp.DR["coy"] = WBData.sCoyCode;
                tblTemp.DR["location_code"] = WBData.sLocCode;
                tblTemp.DR["key_1"] = str;
                tblTemp.DR["key_2"] = str2;
                tblTemp.DR["completed"] = "N";
                tblTemp.DR["Token_No"] = fToken.textBoxToken.Text;
                tblTemp.DR["Token_Code"] = str3;
                if (baru)
                {
                    tblTemp.DT.Rows.Add(tblTemp.DR);
                }
                tblTemp.Save();
                if ((disable_condition_params != null) && (str3 == "DISABLE_CONDITION"))
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_token_disable_detail", "select * from wb_token_disable_detail where 1=2", WBData.conn);
                    foreach (string str4 in (List<string>) disable_condition_params["appliedLocation"])
                    {
                        char[] separator = new char[] { '-' };
                        string str5 = str4.Split(separator)[0];
                        char[] chArray2 = new char[] { '-' };
                        string str6 = str4.Split(chArray2)[1];
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = str5;
                        table.DR["Location_Code"] = str6;
                        table.DR["Token_No"] = fToken.textBoxToken.Text;
                        table.DR["requested_start_inactive_time"] = (string) disable_condition_params["requested_start_inactive_time"];
                        table.DR["requested_end_inactive_time"] = (string) disable_condition_params["requested_end_inactive_time"];
                        table.DT.Rows.Add(table.DR);
                    }
                    table.Save();
                }
                tblTemp.Dispose();
                strArray[0] = "process";
                return strArray;
            }
            strArray[0] = "completed";
            return strArray;
        }

        public string[] saveTokenCodeOrApp_WritetoErrorList(WBTable tblTemp, TokenOrAppModal TM, Dictionary<string, object> disable_condition_params, FormToken fToken)
        {
            string[] strArray = new string[3];
            string gatepassNo = TM.key_1;
            string str2 = TM.key_2;
            string tokenCode = TM.token_code;
            string remark = TM.error_msg;
            bool baru = TM.baru;
            if (!(fToken.saved && (fToken.completed == "N")))
            {
                if (!(fToken.saved && (fToken.completed == "Y")))
                {
                    strArray[0] = "cancel";
                    return strArray;
                }
                else
                {
                    if (!baru)
                    {
                        tblTemp.DR.BeginEdit();
                    }
                    tblTemp.DR["coy"] = WBData.sCoyCode;
                    tblTemp.DR["location_code"] = WBData.sLocCode;
                    tblTemp.DR["key_1"] = gatepassNo;
                    tblTemp.DR["key_2"] = str2;
                    tblTemp.DR["completed"] = "Y";
                    tblTemp.DR["Token_No"] = fToken.textBoxToken.Text;
                    tblTemp.DR["Token_Code"] = tokenCode;
                    if (tokenCode == "COMM_CONT_TOL")
                    {
                        tblTemp.DR["CountUsed"] = 0;
                        tblTemp.DR["UnitOfTrx"] = fToken.AllTrx;
                        tblTemp.DR["Tolerance"] = fToken.CommTol;
                        tblTemp.DR["datetime1"] = DateTime.Now;
                    }
                    else if (tokenCode == "OVER_TARE_FOR_NX_TRANSACTION")
                    {
                        tblTemp.DR["key_2"] = "USED";
                    }
                    if (baru)
                    {
                        tblTemp.DT.Rows.Add(tblTemp.DR);
                    }
                    else
                    {
                        tblTemp.DR.EndEdit();
                    }
                    tblTemp.Save();
                    tblTemp.Dispose();
                    if ((disable_condition_params != null) && (tokenCode == "DISABLE_CONDITION"))
                    {
                        foreach (string str8 in (List<string>) disable_condition_params["appliedLocation"])
                        {
                            char[] separator = new char[] { '-' };
                            string str9 = str8.Split(separator)[0];
                            char[] chArray4 = new char[] { '-' };
                            string str10 = str8.Split(chArray4)[1];
                            WBTable table2 = new WBTable();
                            string[] textArray1 = new string[] { "select * from wb_Condition where Coy = '", str9, "' and Location_code = '", str10, "' and Condition_code = '", (string) disable_condition_params["ToBeDisabledCondition"], "'" };
                            string sqltext = string.Concat(textArray1);
                            table2.OpenTable("wb_Condition", sqltext, WBData.conn);
                            foreach (DataRow row in table2.DT.Rows)
                            {
                                row.BeginEdit();
                                row["start_inactive_time"] = (string) disable_condition_params["requested_start_inactive_time"];
                                row["end_inactive_time"] = (string) disable_condition_params["requested_end_inactive_time"];
                                row.EndEdit();
                            }
                            table2.Save();
                            WBTable table3 = new WBTable();
                            string[] textArray2 = new string[] { "select * from wb_token_disable_detail where Coy = '", str9, "' and Location_Code = '", str10, "' and Token_No = '", fToken.textBoxToken.Text, "'" };
                            table3.OpenTable("wb_token_disable_detail", string.Concat(textArray2), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DT.Rows[0].Delete();
                                table3.Save();
                            }
                        }
                    }
                }
            }
            else
            {
                tblTemp.DR["coy"] = WBData.sCoyCode;
                tblTemp.DR["location_code"] = WBData.sLocCode;
                tblTemp.DR["key_1"] = gatepassNo;
                tblTemp.DR["key_2"] = str2;
                tblTemp.DR["completed"] = "N";
                tblTemp.DR["Token_No"] = fToken.textBoxToken.Text;
                tblTemp.DR["Token_Code"] = tokenCode;
                if (baru)
                {
                    tblTemp.DT.Rows.Add(tblTemp.DR);
                }
                tblTemp.Save();
                WBTokenAppHandler.addNewErrorList(WBData.sCoyCode, WBData.sLocCode, gatepassNo, "", tokenCode, WBData.sWBCode, remark, "");
                if ((disable_condition_params != null) && (tokenCode == "DISABLE_CONDITION"))
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_token_disable_detail", "select * from wb_token_disable_detail where 1=2", WBData.conn);
                    foreach (string str5 in (List<string>) disable_condition_params["appliedLocation"])
                    {
                        char[] separator = new char[] { '-' };
                        string str6 = str5.Split(separator)[0];
                        char[] chArray2 = new char[] { '-' };
                        string str7 = str5.Split(chArray2)[1];
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = str6;
                        table.DR["Location_Code"] = str7;
                        table.DR["Token_No"] = fToken.textBoxToken.Text;
                        table.DR["requested_start_inactive_time"] = (string) disable_condition_params["requested_start_inactive_time"];
                        table.DR["requested_end_inactive_time"] = (string) disable_condition_params["requested_end_inactive_time"];
                        table.DT.Rows.Add(table.DR);
                    }
                    table.Save();
                }
                tblTemp.Dispose();
                strArray[0] = "process";
                return strArray;
            }
            strArray[0] = "completed";
            return strArray;
        }

        public void SetCursor(DataGridView dataGridView1, int pos)
        {
            try
            {
                CurrencyManager manager = (CurrencyManager) dataGridView1.BindingContext[this.DS.Tables[0]];
                DataRowView current = (DataRowView) manager.Current;
                manager.Position = pos;
                current = (DataRowView) manager.Current;
                dataGridView1.Refresh();
            }
            catch
            {
            }
        }

        public bool shouldSaveToken(string pMode, bool tokenSaved, string email_code, DateTime email_date, DataModal DM)
        {
            bool flag3;
            bool flag = false;
            this.DA = DM.DA;
            this.DT = DM.DT;
            this.DS = DM.DS;
            this.tblname = this.DT.TableName;
            if (!tokenSaved)
            {
                flag3 = false;
            }
            else if ((this.DT.TableName.ToUpper().Trim() == "WB_TRANSACTION".ToUpper().Trim()) && (((pMode == "EDIT") || (pMode == "QTY")) && flag))
            {
                MessageBox.Show(Resource.Mes_539, Resource.Title_003);
                flag3 = false;
            }
            else
            {
                if (((this.DT.TableName.ToUpper().Trim() == "WB_CONTRACT".ToUpper().Trim()) || (this.DT.TableName.ToUpper().Trim() == "WB_TRANSACTION".ToUpper().Trim())) && (pMode != "MANUAL"))
                {
                    WBTable table = new WBTable();
                    string[] textArray1 = new string[] { " and email_code = '", email_code, "' and email_date = '", DateTime.Now.ToString("yyyy-MM-dd"), " 00:00:00' " };
                    table.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["COY"] = WBData.sCoyCode;
                        table.DR["LOCATION_CODE"] = WBData.sLocCode;
                        table.DR["Email_code"] = email_code;
                        table.DR["Email_date"] = email_date.ToString("dd/MM/yyyy");
                        table.DR["Status"] = "N";
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                    }
                    table.Dispose();
                }
                flag3 = true;
            }
            return flag3;
        }

        public DataGridView ToDGV(DataGridView pDGV)
        {
            foreach (DataRow row in this.DT.Rows)
            {
                this.nCurrRow = pDGV.Rows.Count;
                pDGV.Rows.Add();
                int num = 0;
                while (true)
                {
                    if (num >= this.DT.Columns.Count)
                    {
                        break;
                    }
                    pDGV.Rows[this.nCurrRow].Cells[num].Value = row[num];
                    num++;
                }
            }
            return pDGV;
        }

        public DataGridView ToDGV_uniq(DataGridView pDGV)
        {
            foreach (DataRow row in this.DT.Rows)
            {
                this.nCurrRow = pDGV.Rows.Count;
                pDGV.Rows.Add();
                int num = 0;
                while (true)
                {
                    if (num >= this.DT.Columns.Count)
                    {
                        break;
                    }
                    pDGV.Rows[this.nCurrRow].Cells[num].Value = row[num];
                    num++;
                }
            }
            return pDGV;
        }

        public string[] tokenOrApp(string key_1, string key_2, string token_code, string email_code, string otoObj, string otoAct, string email_msg, Dictionary<string, object> disable_condition_params = null)
        {
            string[] strArray = new string[3];
            string[] strArray2 = new string[4];
            if (Convert.ToInt16(WBUser.UserLevel) <= 1)
            {
                strArray[0] = "completed";
            }
            else if (WBSetting.Field("GM").ToString() != "Y")
            {
                strArray2 = Program.fillApproval(token_code, otoObj, otoAct);
                if (strArray2[0] == "N")
                {
                    MessageBox.Show("This Data not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    strArray[0] = "cancel";
                }
                else
                {
                    strArray[0] = "completed";
                    strArray[1] = strArray2[1];
                    strArray[2] = strArray2[3];
                }
            }
            else
            {
                bool flag3;
                FormToken fToken = new FormToken {
                    email_code = email_code
                };
                if (disable_condition_params != null)
                {
                    fToken.disable_condition_params = disable_condition_params;
                }
                WBTable tblTemp = new WBTable();
                string[] textArray1 = new string[] { " AND ( Token_Code ='", token_code, "' AND completed = 'N' AND key_1 = '", key_1, "' AND key_2 = '", key_2, "')" };
                tblTemp.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if (tblTemp.DT.Rows.Count <= 0)
                {
                    tblTemp.DR = tblTemp.DT.NewRow();
                    flag3 = true;
                }
                else
                {
                    fToken.oldToken = tblTemp.DT.Rows[0]["Token_No"].ToString().Trim();
                    fToken.textBoxToken.Text = tblTemp.DT.Rows[0]["Token_No"].ToString().Trim();
                    tblTemp.DR = tblTemp.DT.Rows[0];
                    flag3 = false;
                }
                if (token_code == "COMM_CONT_TOL")
                {
                    string[] tokenParams = new string[] { key_1, key_2 };
                    fToken.initData(tokenParams, token_code, "WB_TOKEN", key_1.Trim(), email_msg);
                }
                else
                {
                    string[] tokenParams = new string[] { key_1, key_2 };
                    fToken.initData(tokenParams, token_code, "WB_TOKEN", "0", email_msg);
                }
                TokenOrAppModal tM = new TokenOrAppModal {
                    key_1 = key_1,
                    key_2 = key_2,
                    token_code = token_code,
                    email_code = email_code,
                    otoObj = otoObj,
                    otoAct = otoAct,
                    email_msg = email_msg,
                    baru = flag3
                };
                fToken.TOAPM = tM;
                fToken.WB = tblTemp;
                fToken.type = "TOKEN_OR_APP";
                fToken.ShowDialog();
                strArray = this.saveTokenCodeOrApp(tblTemp, tM, disable_condition_params, fToken);
            }
            return strArray;
        }

        public string[] tokenOrApp_writeToErrorList(string key_1, string key_2, string token_code, string email_code, string otoObj, string otoAct, string email_msg, string errorMsg, Dictionary<string, object> disable_condition_params = null)
        {
            string[] strArray = new string[3];
            string[] strArray2 = new string[4];
            if (Convert.ToInt16(WBUser.UserLevel) <= 1)
            {
                strArray[0] = "completed";
            }
            else if (WBSetting.Field("GM").ToString() != "Y")
            {
                strArray2 = Program.fillApproval(token_code, otoObj, otoAct);
                if (strArray2[0] == "N")
                {
                    MessageBox.Show("This Data not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    strArray[0] = "cancel";
                }
                else
                {
                    strArray[0] = "completed";
                    strArray[1] = strArray2[1];
                    strArray[2] = strArray2[3];
                }
            }
            else
            {
                bool flag3;
                FormToken fToken = new FormToken {
                    email_code = email_code
                };
                if (disable_condition_params != null)
                {
                    fToken.disable_condition_params = disable_condition_params;
                }
                if (token_code == "COMM_CONT_TOL")
                {
                    string[] tokenParams = new string[] { key_1, key_2 };
                    fToken.initData(tokenParams, token_code, "WB_TOKEN", key_1.Trim(), email_msg);
                }
                else
                {
                    string[] tokenParams = new string[] { key_1, key_2 };
                    fToken.initData(tokenParams, token_code, "WB_TOKEN", "0", email_msg);
                }
                WBTable tblTemp = new WBTable();
                string[] textArray3 = new string[] { " AND ( Token_Code ='", token_code, "' AND completed = 'N' AND key_1 = '", key_1, "' AND key_2 = '", key_2, "')" };
                tblTemp.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(string.Concat(textArray3)), WBData.conn);
                if (tblTemp.DT.Rows.Count <= 0)
                {
                    tblTemp.DR = tblTemp.DT.NewRow();
                    flag3 = true;
                }
                else
                {
                    fToken.textBoxToken.Text = tblTemp.DT.Rows[0]["Token_No"].ToString().Trim();
                    tblTemp.DR = tblTemp.DT.Rows[0];
                    flag3 = false;
                }
                TokenOrAppModal tM = new TokenOrAppModal {
                    key_1 = key_1,
                    key_2 = key_2,
                    token_code = token_code,
                    email_code = email_code,
                    otoObj = otoObj,
                    otoAct = otoAct,
                    email_msg = email_msg,
                    error_msg = errorMsg,
                    baru = flag3
                };
                fToken.TOAPM = tM;
                fToken.WB = tblTemp;
                fToken.type = "TOKEN_OR_APP_WRITE_TO_ERROR_LIST";
                fToken.ShowDialog();
                strArray = this.saveTokenCodeOrApp_WritetoErrorList(tblTemp, tM, disable_condition_params, fToken);
            }
            return strArray;
        }

        public void UnLock()
        {
            this.RLock(this.lastUniq, false);
        }

        public bool ValidChecksum(DataRow row)
        {
            string s = "";
            string str2 = "";
            string str3 = "";
            foreach (DataColumn column in this.DT.Columns)
            {
                if (column.ColumnName.ToString().ToUpper() == "CHECKSUM")
                {
                    str3 = row[column.ColumnName].ToString().Trim();
                    continue;
                }
                if ((column.ColumnName.ToString().ToUpper() != "UNIQ") && (column.ColumnName.ToString().ToUpper() != "TOKEN"))
                {
                    string str4 = "";
                    str4 = (row[column.ColumnName].GetType().ToString() != "System.DateTime") ? row[column.ColumnName].ToString().Trim() : Program.DTOS(DateTime.Parse(row[column.ColumnName].ToString())).Trim();
                    s = s + str4;
                    str2 = str2 + "~" + column.ColumnName.ToString().ToUpper();
                }
            }
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            int index = 0;
            while (true)
            {
                if (index >= s.Length)
                {
                    num = (num * 0x13) / 4;
                    return (str3 == num.ToString().Trim());
                }
                num += bytes[index];
                index++;
            }
        }

        public bool ValidChecksum_Main(DataRow row)
        {
            bool flag2 = false;
            string s = "";
            string str2 = "";
            string str3 = "";
            foreach (DataColumn column in this.DT.Columns)
            {
                flag2 = false;
                string[] strArray = cField_from_other_table;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= strArray.Length)
                    {
                        if (!flag2)
                        {
                            if (column.ColumnName.ToString().ToUpper() == "CHECKSUM")
                            {
                                str3 = row[column.ColumnName].ToString().Trim();
                            }
                            else if ((column.ColumnName.ToString().ToUpper() != "UNIQ") && (column.ColumnName.ToString().ToUpper() != "TOKEN"))
                            {
                                string str5 = "";
                                str5 = (row[column.ColumnName].GetType().ToString() != "System.DateTime") ? row[column.ColumnName].ToString().Trim() : Program.DTOS(DateTime.Parse(row[column.ColumnName].ToString())).Trim();
                                s = s + str5;
                                str2 = str2 + "~" + column.ColumnName.ToString().ToUpper();
                            }
                        }
                        break;
                    }
                    string str4 = strArray[num2];
                    if (str4.ToUpper() == column.ColumnName.ToString().ToUpper())
                    {
                        flag2 = true;
                    }
                    num2++;
                }
            }
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            int index = 0;
            while (true)
            {
                if (index >= s.Length)
                {
                    num = (num * 0x13) / 4;
                    return (str3 == num.ToString().Trim());
                }
                num += bytes[index];
                index++;
            }
        }

        public string zValidChecksum(DataRow row)
        {
            bool flag = false;
            string s = "";
            string str2 = "";
            string str3 = "";
            foreach (DataColumn column in this.DT.Columns)
            {
                if (column.ColumnName.ToString().ToUpper() == "CHECKSUM")
                {
                    str3 = row[column.ColumnName].ToString().Trim();
                    continue;
                }
                if (column.ColumnName.ToString().ToUpper() != "UNIQ")
                {
                    string str4 = "";
                    str4 = (row[column.ColumnName].GetType().ToString() != "System.DateTime") ? row[column.ColumnName].ToString().Trim() : Program.DTOS(DateTime.Parse(row[column.ColumnName].ToString())).Trim();
                    s = s + str4;
                    str2 = str2 + "~" + column.ColumnName.ToString().ToUpper();
                }
            }
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            int index = 0;
            while (true)
            {
                if (index >= s.Length)
                {
                    num = (num * 0x13) / 4;
                    flag = str3 == num.ToString().Trim();
                    return num.ToString().Trim();
                }
                num += bytes[index];
                index++;
            }
        }
    }
}

