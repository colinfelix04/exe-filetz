﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDestination : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public string sentWX = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        public TextBox TextFind;
        public Panel panel1;
        public Button buttonFind;
        private DataGridView dataGridView2;
        private ToolStripMenuItem chooseToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public MenuStrip menuStrip1;

        public FormDestination()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView2, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView2.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            bool flag = !string.IsNullOrEmpty(this.ztable.DT.Rows[this.nCurrRow]["start_multiple"].ToString());
            if (this.sentWX != "1")
            {
                if (flag)
                {
                    MessageBox.Show(Resource.RegisGatepassMess_067, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            else if (!flag)
            {
                MessageBox.Show(Resource.RegisGatepassMess_066, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDestination_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDestination_Load(object sender, EventArgs e)
        {
            string[] textArray1 = new string[] { "Select s.checkpoint_code AS source_code, s.description, s.uniq AS uniq, s.start_multiple from wb_checkpoint s, wb_source_mapping m  WHERE s.checkpoint_code = m.source_code  AND Type = 'D'  AND Deleted = 'N'  AND m.Coy = '", WBData.sCoyCode, "' and m.Location_code = '", WBData.sLocCode, "'" };
            this.ztable.OpenTable("wb_source", string.Concat(textArray1), WBData.conn);
            this.dataGridView2.DataSource = this.ztable.DT;
            this.dataGridView2.Sort(this.dataGridView2.Columns["Description"], ListSortDirection.Ascending);
            this.dataGridView2.Columns["source_Code"].HeaderText = "Destination";
            this.dataGridView2.Columns["source_Code"].MinimumWidth = 100;
            this.dataGridView2.Columns["description"].HeaderText = "Description";
            this.dataGridView2.Columns["description"].MinimumWidth = 500;
            this.dataGridView2.Columns["uniq"].Visible = false;
            this.dataGridView2.Columns["start_multiple"].Visible = false;
            base.KeyPreview = true;
            if (this.pFind.Trim() != "")
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
        }

        private void InitializeComponent()
        {
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.buttonFind = new Button();
            this.dataGridView2 = new DataGridView();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView2).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0x12f, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x20c, 0x21);
            this.panel1.TabIndex = 11;
            this.buttonFind.Location = new Point(0x13a, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x38, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = DockStyle.Fill;
            this.dataGridView2.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView2.Location = new Point(0, 0x18);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.Size = new Size(0x20c, 0x148);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x20c, 0x18);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x20c, 0x181);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView2);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormDestination";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "List of Destination";
            base.Load += new EventHandler(this.FormDestination_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDestination_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView2).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void translate()
        {
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.buttonFind.Text = Resource.Menu_Find;
        }
    }
}

