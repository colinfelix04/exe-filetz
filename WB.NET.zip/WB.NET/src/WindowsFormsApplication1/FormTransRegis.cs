﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransRegis : Form
    {
        public string WX;
        public bool Regis = false;
        public bool pSave = false;
        private IContainer components = null;
        private Button button2x;
        private Button button4x;
        private Button buttonCancel;
        public Button buttonRegis;
        private Button button1x;

        public FormTransRegis()
        {
            this.InitializeComponent();
            if (WBSetting.Container == "Y")
            {
                this.button4x.Visible = true;
                this.button1x.Visible = true;
                base.Size = new Size(0x1d9, 0x115);
                this.buttonCancel.Location = new Point(0xc2, 0xb2);
            }
            else
            {
                this.button4x.Visible = false;
                this.button1x.Visible = false;
                base.Size = new Size(0x1d9, 0xce);
                this.buttonCancel.Location = new Point(0xbf, 0x65);
            }
            base.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.pSave = true;
            this.WX = "2X";
            base.Close();
        }

        private void button1x_Click(object sender, EventArgs e)
        {
            this.WX = "1X";
            this.pSave = true;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WX = "4X";
            this.pSave = true;
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.pSave = false;
            base.Close();
        }

        private void buttonRegis_Click(object sender, EventArgs e)
        {
            this.WX = "";
            this.pSave = true;
            this.Regis = true;
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransRegis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.pSave = false;
                base.Close();
            }
        }

        private void FormTransRegis_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.button2x = new Button();
            this.button4x = new Button();
            this.buttonCancel = new Button();
            this.buttonRegis = new Button();
            this.button1x = new Button();
            base.SuspendLayout();
            this.button2x.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2x.Location = new Point(0xee, 0x1f);
            this.button2x.Name = "button2x";
            this.button2x.Size = new Size(0xb0, 50);
            this.button2x.TabIndex = 0;
            this.button2x.Text = "&2x Weighing";
            this.button2x.UseVisualStyleBackColor = true;
            this.button2x.Click += new EventHandler(this.button1_Click);
            this.button4x.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button4x.Location = new Point(0x29, 0x62);
            this.button4x.Name = "button4x";
            this.button4x.Size = new Size(0xb0, 50);
            this.button4x.TabIndex = 1;
            this.button4x.Text = "&4x / Container Weighing In (1st && 2nd)";
            this.button4x.UseVisualStyleBackColor = true;
            this.button4x.Click += new EventHandler(this.button2_Click);
            this.buttonCancel.Location = new Point(0xc2, 0xb2);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x25);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.button3_Click);
            this.buttonRegis.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonRegis.Location = new Point(0x29, 0x1f);
            this.buttonRegis.Name = "buttonRegis";
            this.buttonRegis.Size = new Size(0xb0, 50);
            this.buttonRegis.TabIndex = 3;
            this.buttonRegis.Text = "Truck &Registration";
            this.buttonRegis.UseVisualStyleBackColor = true;
            this.buttonRegis.Click += new EventHandler(this.buttonRegis_Click);
            this.button1x.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1x.Location = new Point(0xee, 0x62);
            this.button1x.Name = "button1x";
            this.button1x.Size = new Size(0xb0, 50);
            this.button1x.TabIndex = 4;
            this.button1x.Text = "4x / Container Weighing &Out (3rd && 4th)";
            this.button1x.UseVisualStyleBackColor = true;
            this.button1x.Click += new EventHandler(this.button1x_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1c9, 0xee);
            base.ControlBox = false;
            base.Controls.Add(this.button1x);
            base.Controls.Add(this.buttonRegis);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.button4x);
            base.Controls.Add(this.button2x);
            base.Name = "FormTransRegis";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Register For Weighing.....";
            base.Load += new EventHandler(this.FormTransRegis_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransRegis_KeyPress);
            base.ResumeLayout(false);
        }
    }
}

