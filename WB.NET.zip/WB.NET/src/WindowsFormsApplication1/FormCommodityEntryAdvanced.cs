﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCommodityEntryAdvanced : Form
    {
        public string CommCode;
        public string Get_From_SAP;
        public bool CommStandard;
        public bool CommCopra;
        public bool UsingGunny;
        public WBTable tblComm;
        public WBTable tblCommDetail;
        public WBTable tblQC;
        public bool view;
        private IContainer components = null;
        private Button button1;
        private TabPage tabPage1;
        private SplitContainer splitContainer1;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button2;
        private TabControl tabControl1;
        private Button btnRangeDeduc;

        public FormCommodityEntryAdvanced()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnRangeDeduc_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count <= 0)
            {
                MessageBox.Show("Please Maintain Quality Control For This Commodity First !");
            }
            else if (this.dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select 1 Quality Control");
            }
            else
            {
                new FormRangeDeduction { 
                    QCode = this.dataGridView1.SelectedRows[0].Cells["Qcode"].Value.ToString(),
                    CommCode = this.CommCode,
                    view = this.view
                }.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.thisClose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormCommodityEntryAdvancedAddItem item = new FormCommodityEntryAdvancedAddItem {
                tblQC = this.tblQC,
                tblCommDetail = this.tblCommDetail,
                CommCode = this.CommCode
            };
            item.ShowDialog();
            this.tblCommDetail = item.tblCommDetail;
            this.tblQC = item.tblQC;
            item.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.RowCount > 0)
            {
                int index = this.dataGridView1.CurrentRow.Index;
                this.tblCommDetail.DR = this.tblCommDetail.DT.Rows[index];
                this.tblQC.DR = this.tblQC.DT.NewRow();
                this.tblQC.DR["Yield_Code"] = this.tblCommDetail.DR["QCode"].ToString();
                this.tblQC.DR["Yield_Name"] = this.tblCommDetail.DR["QName"].ToString();
                this.tblQC.DT.Rows.Add(this.tblQC.DR);
                this.tblCommDetail.DT.Rows.RemoveAt(index);
            }
        }

        private void dataGridView1_CellClicked(object sender, DataGridViewCellEventArgs e)
        {
            if ((e.ColumnIndex == this.dataGridView1.Columns["checked"].Index) && (e.RowIndex != -1))
            {
                string str = this.dataGridView1.CurrentRow.Cells["QCode"].Value.ToString();
                string sqltext = "SELECT * FROM wb_yield WHERE " + WBData.CompanyLocation(" AND Yield_Code = '" + str + "'");
                this.tblQC.OpenTable("wb_yield", sqltext, WBData.conn);
                this.tblQC.DR = this.tblQC.DT.Rows[0];
                if (this.tblQC.DR["type"].ToString() != "1")
                {
                    MessageBox.Show(this.dataGridView1.CurrentRow.Cells["QCode"].Value.ToString() + " " + Resource.Mes_Qcode_Not_Number, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.dataGridView1.EndEdit();
                    this.dataGridView1.CurrentRow.Cells["checked"].Value = false;
                }
                this.tblQC.OpenTable("wb_yield", "SELECT * FROM wb_yield", WBData.conn);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCommodityEntryAdvanced_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.thisClose();
            }
        }

        private void FormCommodityEntryAdvanced_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.dataGridView1.DataSource = this.tblCommDetail.DT;
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Comm_Code"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["checked"].HeaderText = Resource.Col_Warn_If_Outspec;
            this.dataGridView1.Columns["checked"].Width = 80;
            this.dataGridView1.Columns["checked"].DisplayIndex = 0;
            this.dataGridView1.Columns["deduct"].HeaderText = Resource.Col_Deduct_Net;
            this.dataGridView1.Columns["deduct"].Width = 50;
            this.dataGridView1.Columns["deduct"].DisplayIndex = 1;
            this.dataGridView1.Columns["QCode"].HeaderText = Resource.Trans_064;
            this.dataGridView1.Columns["QCode"].Width = 60;
            this.dataGridView1.Columns["QCode"].DisplayIndex = 2;
            this.dataGridView1.Columns["QCode"].ReadOnly = true;
            this.dataGridView1.Columns["QCode"].DefaultCellStyle.BackColor = Color.LightGray;
            this.dataGridView1.Columns["QCode"].DefaultCellStyle.ForeColor = Color.DarkGray;
            this.dataGridView1.Columns["QName"].HeaderText = Resource.Composite_007;
            this.dataGridView1.Columns["QName"].Width = 400;
            this.dataGridView1.Columns["QName"].DisplayIndex = 3;
            this.dataGridView1.Columns["QName"].ReadOnly = true;
            this.dataGridView1.Columns["QName"].DefaultCellStyle.BackColor = Color.LightGray;
            this.dataGridView1.Columns["QName"].DefaultCellStyle.ForeColor = Color.DarkGray;
            this.ProcessTabKey(true);
            if (this.view || (this.Get_From_SAP == "Y"))
            {
                this.dataGridView1.Enabled = true;
                if (this.view)
                {
                    this.dataGridView1.Columns["checked"].ReadOnly = true;
                    this.dataGridView1.Columns["checked"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dataGridView1.Columns["checked"].DefaultCellStyle.ForeColor = Color.DarkGray;
                }
                this.dataGridView1.Columns["deduct"].ReadOnly = true;
                this.dataGridView1.Columns["deduct"].DefaultCellStyle.BackColor = Color.LightGray;
                this.dataGridView1.Columns["deduct"].DefaultCellStyle.ForeColor = Color.DarkGray;
                this.button1.Text = Resource.Btn_Close;
                this.button1.Enabled = true;
                this.button2.Enabled = false;
                this.button3.Enabled = false;
            }
            if (this.CommCopra)
            {
                this.btnRangeDeduc.Visible = true;
            }
            else
            {
                this.btnRangeDeduc.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.tabPage1 = new TabPage();
            this.splitContainer1 = new SplitContainer();
            this.dataGridView1 = new DataGridView();
            this.button3 = new Button();
            this.button2 = new Button();
            this.tabControl1 = new TabControl();
            this.btnRangeDeduc = new Button();
            this.tabPage1.SuspendLayout();
            this.splitContainer1.BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.tabControl1.SuspendLayout();
            base.SuspendLayout();
            this.button1.Location = new Point(570, 0x147);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x25);
            this.button1.TabIndex = 3;
            this.button1.Text = "&Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x27c, 0x125);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quality Control";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.splitContainer1.Dock = DockStyle.Fill;
            this.splitContainer1.Location = new Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView1);
            this.splitContainer1.Panel2.Controls.Add(this.btnRangeDeduc);
            this.splitContainer1.Panel2.Controls.Add(this.button3);
            this.splitContainer1.Panel2.Controls.Add(this.button2);
            this.splitContainer1.Size = new Size(630, 0x11f);
            this.splitContainer1.SplitterDistance = 0x20c;
            this.splitContainer1.TabIndex = 0;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.Size = new Size(0x20c, 0x11f);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new DataGridViewCellEventHandler(this.dataGridView1_CellClicked);
            this.button3.Location = new Point(0x12, 0x49);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x43, 0x37);
            this.button3.TabIndex = 2;
            this.button3.Text = "&Remove";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.button2.Location = new Point(0x12, 14);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x43, 0x35);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Add Item";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new Point(1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x284, 0x13f);
            this.tabControl1.TabIndex = 0;
            this.btnRangeDeduc.Location = new Point(0x12, 0xd7);
            this.btnRangeDeduc.Name = "btnRangeDeduc";
            this.btnRangeDeduc.Size = new Size(0x43, 0x37);
            this.btnRangeDeduc.TabIndex = 3;
            this.btnRangeDeduc.Text = "Range Deduction";
            this.btnRangeDeduc.UseVisualStyleBackColor = true;
            this.btnRangeDeduc.Visible = false;
            this.btnRangeDeduc.Click += new EventHandler(this.btnRangeDeduc_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x289, 0x16f);
            base.ControlBox = false;
            base.Controls.Add(this.button1);
            base.Controls.Add(this.tabControl1);
            base.KeyPreview = true;
            base.Name = "FormCommodityEntryAdvanced";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Advanced Option for Commodity";
            base.Load += new EventHandler(this.FormCommodityEntryAdvanced_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommodityEntryAdvanced_KeyPress);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.tabControl1.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
        }

        public void thisClose()
        {
            base.Close();
        }

        private void translate()
        {
            this.button1.Text = Resource.Btn_Back;
            this.tabPage1.Text = Resource.Trans_062;
            this.button3.Text = Resource.Btn_Remove;
            this.button2.Text = Resource.Btn_Add_Item;
            this.Text = Resource.Title_Commodity_Entry_Advanced;
        }
    }
}

