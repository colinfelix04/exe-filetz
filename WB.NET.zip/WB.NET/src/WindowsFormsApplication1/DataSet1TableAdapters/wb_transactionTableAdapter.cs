﻿namespace WindowsFormsApplication1.DataSet1TableAdapters
{
    using System;

    public class wb_transactionTableAdapter
    {
    }
}

