﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class RepFFBYOP : Form
    {
        public bool zAuto = false;
        public string chckSQL;
        public string tipe;
        private string fName = "";
        private IContainer components = null;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public Label label3;
        public Button button1;
        public Button button2;
        public Label labelProses1;
        public Label labelProses2;

        public RepFFBYOP()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float num = 0f;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[] { " SELECT     dbo.wb_transaction.*, dbo.wb_commodity.Comm_Type, dbo.wb_divide_blockH.Total_BunchLF, dbo.wb_divide_blockH.LF_Weight,  dbo.wb_divide_blockH.Block_Bunch_Weight, dbo.wb_divide_blockH.Act_Bunch_Weight, dbo.wb_divide_blockH.Total_Bunch  FROM dbo.wb_commodity RIGHT OUTER JOIN  dbo.wb_transaction ON dbo.wb_commodity.Coy = dbo.wb_transaction.Coy AND dbo.wb_commodity.Location_Code = dbo.wb_transaction.Location_Code AND  dbo.wb_commodity.Comm_Code = dbo.wb_transaction.Comm_Code LEFT OUTER JOIN  dbo.wb_divide_blockH ON dbo.wb_transaction.Coy = dbo.wb_divide_blockH.coy AND dbo.wb_transaction.Location_Code = dbo.wb_divide_blockH.location_code AND  dbo.wb_transaction.Ref = dbo.wb_divide_blockH.Ref  Where dbo.wb_transaction.Coy = '", WBData.sCoyCode, "' and dbo.wb_transaction.Location_code = '", WBData.sLocCode, "'" };
            string sqltext = ((string.Concat(textArray1) + " and ((dbo.wb_transaction.report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and dbo.wb_transaction.report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00'))") + " and (dbo.wb_commodity.Type='F')" + " and (dbo.wb_transaction.deleted is null or dbo.wb_transaction.deleted = 'N') Order By dbo.wb_transaction.division_code,dbo.wb_transaction.source_code  Asc";
            table.OpenTable("vw_transFFB", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("No Data..");
            }
            else
            {
                this.labelProses1.Text = @"0\" + table.DT.Rows.Count;
                this.labelProses2.Visible = true;
                this.labelProses1.Refresh();
                this.labelProses2.Refresh();
                HTML pRep = new HTML();
                pRep.File = pRep.File + @"\" + WBUser.UserID + "_FFB_YOP.htm";
                pRep.Title = "FFB_YOP";
                pRep.Open();
                pRep.Write(pRep.Style());
                pRep.Write("<head><meta charset='UTF-8'></head>");
                pRep.Write("<b><br><font size=5>FFB Report by Year of Plantation</font>");
                pRep.Write("<br><font size=4>" + WBData.sCoyName + "</font>");
                pRep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font>");
                pRep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font>");
                pRep.Write("<br><font size=3>");
                pRep.Write("<br><font size=5><b>FFB REPORT BY YEAR OF PLANTATION</b></font><br>");
                string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                pRep.Write(string.Concat(textArray2));
                string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                pRep.Write(string.Concat(textArray3));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    pRep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    pRep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    pRep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
                pRep.Write("<br><br>");
                pRep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                pRep.Write("<tr class=bd>");
                pRep.Write("<td>Selected Date</td>");
                string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                pRep.Write(string.Concat(textArray4));
                pRep.Write("</tr>");
                pRep.Write("<tr class=bd>");
                pRep.Write("<td>Report Date</td>");
                pRep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                pRep.Write("</tr>");
                pRep.Write("</table>");
                pRep.Write("<br/><br/><br/>");
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_source", "select * from wb_source where " + WBData.CompanyLocation(" order by source_code"), WBData.conn);
                WBTable table4 = new WBTable();
                table4.OpenTable("wb_division", "select * from wb_Division where " + WBData.CompanyLocation(" order by division_code"), WBData.conn);
                pRep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                num = 0f;
                double num2 = 0.0;
                double num3 = 0.0;
                double num4 = 0.0;
                double num5 = 0.0;
                double num6 = 0.0;
                double num7 = 0.0;
                double num8 = 0.0;
                double num9 = 0.0;
                double num10 = 0.0;
                double num11 = 0.0;
                double num12 = 0.0;
                double num13 = 0.0;
                double num14 = 0.0;
                foreach (DataRow row in table4.DT.Rows)
                {
                    num2 = 0.0;
                    num3 = 0.0;
                    num4 = 0.0;
                    num5 = 0.0;
                    num6 = 0.0;
                    num14 = 0.0;
                    DataRow[] rowArray = table.DT.Select(" division_code = '" + row["division_code"].ToString() + "'");
                    if (rowArray.Length != 0)
                    {
                        pRep.Write("<tr class='bd'>");
                        pRep.Write("<td align=center><b>DIVISION</b></td>");
                        pRep.Write("<td colspan=6 align=left><b>" + pRep.strq(row["division_code"].ToString()) + "</b></td>");
                        pRep.Write("</tr>");
                        this.fillHeader(pRep);
                        DataRow[] rowArray2 = rowArray;
                        int index = 0;
                        while (true)
                        {
                            if (index >= rowArray2.Length)
                            {
                                pRep.Write("<tr class='bd'>");
                                pRep.Write("<td colspan = 2 align=left><b>Sub Total</b></td>");
                                pRep.Write("<td align=right><b>" + pRep.strq($"{num2:N0}") + "</b></td>");
                                pRep.Write("<td align=right><b>" + pRep.strq($"{num3:N0}") + "</b></td>");
                                num4 = num14 / num3;
                                pRep.Write("<td align=right><b>" + pRep.strq($"{num4:N0}") + "</b></td>");
                                pRep.Write("<td align=right><b>" + pRep.strq($"{num5:N0}") + "</b></td>");
                                pRep.Write("<td align=right><b>" + pRep.strq($"{num6:N0}") + "</b></td>");
                                pRep.Write("</tr>");
                                break;
                            }
                            DataRow row2 = rowArray2[index];
                            num++;
                            object[] objArray1 = new object[] { num, @"\", table.DT.Rows.Count, " ", row["Division_Code"].ToString(), "-", row2["Source_code"].ToString() };
                            this.labelProses1.Text = string.Concat(objArray1);
                            this.labelProses1.Refresh();
                            pRep.Write("<tr class='bd'>");
                            pRep.Write("<td align=right>" + pRep.strq(num.ToString()) + "</td>");
                            pRep.Write("<td align=left>" + pRep.strq(row2["Source_code"].ToString()) + "</td>");
                            pRep.Write("<td align=right>" + pRep.strq($"{Program.StrToDouble(row2["Net"].ToString(), 0):N0}") + "</td>");
                            num2 += Program.StrToDouble(row2["Net"].ToString(), 0);
                            num7 += Program.StrToDouble(row2["Net"].ToString(), 0);
                            pRep.Write("<td align=right>" + pRep.strq($"{Program.StrToDouble(row2["Total_Bunch"].ToString(), 0):N0}") + "</td>");
                            num3 += Program.StrToDouble(row2["Total_Bunch"].ToString(), 0);
                            num8 += Program.StrToDouble(row2["Total_Bunch"].ToString(), 0);
                            pRep.Write("<td align=right>" + pRep.strq($"{Program.StrToDouble(row2["Act_Bunch_Weight"].ToString(), 2):N2}") + "</td>");
                            num12 = Program.StrToDouble(row2["Total_Bunch"].ToString(), 0) * Program.StrToDouble(row2["Act_Bunch_Weight"].ToString(), 2);
                            num14 += num12;
                            num13 += num12;
                            pRep.Write("<td align=right>" + pRep.strq($"{Program.StrToDouble(row2["Total_BunchLF"].ToString(), 0):N0}") + "</td>");
                            num5 += Program.StrToDouble(row2["Total_BunchLF"].ToString(), 0);
                            num10 += Program.StrToDouble(row2["Total_BunchLF"].ToString(), 0);
                            pRep.Write("<td align=right>" + pRep.strq($"{Program.StrToDouble(row2["LF_Weight"].ToString(), 0):N0}") + "</td>");
                            num6 += Program.StrToDouble(row2["LF_Weight"].ToString(), 0);
                            num11 += Program.StrToDouble(row2["LF_Weight"].ToString(), 0);
                            pRep.Write("</tr>");
                            index++;
                        }
                    }
                }
                pRep.Write("<tr class='bd'>");
                pRep.Write("<td colspan = 2 align=left><b>Grand Total</b></td>");
                pRep.Write("<td align=right><b>" + pRep.strq($"{num7:N0}") + "</b></td>");
                pRep.Write("<td align=right><b>" + pRep.strq($"{num8:N0}") + "</b></td>");
                num9 = num13 / num8;
                pRep.Write("<td align=right><b>" + pRep.strq($"{num9:N0}") + "</b></td>");
                pRep.Write("<td align=right><b>" + pRep.strq($"{num10:N0}") + "</b></td>");
                pRep.Write("<td align=right><b>" + pRep.strq($"{num11:N0}") + "</b></td>");
                pRep.Write("</tr>");
                pRep.Write("</table>");
                pRep.Write("<br>");
                pRep.Write("<br>");
                pRep.writeSign();
                pRep.Close();
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + pRep.File) }
                };
                report.ShowDialog();
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
                pRep.Dispose();
                report.Dispose();
                table3.Dispose();
                table4.Dispose();
                table.Dispose();
                table2.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillHeader(HTML pRep)
        {
            pRep.Write("<tr class='bd'>");
            pRep.Write("<td align=center><b>No.</b></td>");
            pRep.Write("<td align=center><b>Year Of Plantation</b></td>");
            pRep.Write("<td align=center><b>Net</b></td>");
            pRep.Write("<td align=center><b>Bunches</b></td>");
            pRep.Write("<td align=center><b>ABW</b></td>");
            pRep.Write("<td align=center><b>Loose Fruits</b></td>");
            pRep.Write("<td align=center><b>Loose Fruits Weight</b></td>");
            pRep.Write("</tr>");
        }

        public HTML generateRep(WBTable vContLog)
        {
            this.labelProses1.Text = "0/" + vContLog.DT.Rows.Count;
            HTML html = new HTML();
            string path = html.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            html.File = html.File + @"\LogReport\REPFFBYOP_" + DateTime.Now.ToString("ddMMyyyy") + ".htm";
            html.Title = "Report FFB Year Of Plantation";
            html.Open();
            html.Write(html.Style());
            html.Write("<head><meta charset='UTF-8'></head>");
            html.Write("<font size=3>" + WBData.sCoyName + "</b></font>");
            html.Write("<br><font size=4><b>Report FFB Year Of Plantation</b></font>");
            html.Write("<br><font size=2>");
            html.Write("<br><font size=2>");
            string[] textArray1 = new string[] { "<br>Date : <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar1.Value.ToShortDateString(), "</b>" };
            html.Write(string.Concat(textArray1));
            html.writeSign();
            html.Close();
            return html;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.label3 = new Label();
            this.button1 = new Button();
            this.button2 = new Button();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(15, 0x43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x4f;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new EventHandler(this.groupBox1_Enter);
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.label6.Click += new EventHandler(this.label6_Click);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.monthCalendar2.ValueChanged += new EventHandler(this.monthCalendar2_ValueChanged);
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(11, 12);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x128, 20);
            this.label3.TabIndex = 0x57;
            this.label3.Text = "FFB REPORT by Year Of Plantation";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x1b9, 0x4d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x51;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1b9, 0x7c);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x52;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(340, 0x11);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x56;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x151, 30);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x55;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x233, 0xa8);
            base.ControlBox = false;
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.groupBox1);
            base.KeyPreview = true;
            base.Name = "RepFFBYOP";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report FFB by Year Of Plantation";
            base.Load += new EventHandler(this.RepFFBYOP_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void monthCalendar2_ValueChanged(object sender, EventArgs e)
        {
        }

        private void RepFFBYOP_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }

        private void textDoNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
        }

        private void textDoNo_TextChanged(object sender, EventArgs e)
        {
        }

        private void translate()
        {
            this.Text = Resource.Report10_001;
            this.label3.Text = Resource.Report10_002;
            this.label5.Text = Resource.Report10_004;
            this.label6.Text = Resource.Report10_005;
        }
    }
}

