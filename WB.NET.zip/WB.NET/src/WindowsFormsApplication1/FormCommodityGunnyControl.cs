﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCommodityGunnyControl : Form
    {
        public bool isSave = false;
        private IContainer components = null;
        public TextBox textGrossMin;
        public Label label1;
        public Label label2;
        public Label label3;
        public TextBox textGrossMax;
        public Label label4;
        public Label label5;
        public TextBox textNetto;
        public Label label6;
        public Button button2;
        public Button buttonSave;

        public FormCommodityGunnyControl()
        {
            this.InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textNetto, this.textGrossMin, this.textGrossMax };
            if (!Program.CheckEmpty(aText))
            {
                this.isSave = true;
                base.Close();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.textGrossMin = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.textGrossMax = new TextBox();
            this.label4 = new Label();
            this.label5 = new Label();
            this.textNetto = new TextBox();
            this.label6 = new Label();
            this.button2 = new Button();
            this.buttonSave = new Button();
            base.SuspendLayout();
            this.textGrossMin.CharacterCasing = CharacterCasing.Upper;
            this.textGrossMin.Location = new Point(0x76, 0x1a);
            this.textGrossMin.Name = "textGrossMin";
            this.textGrossMin.Size = new Size(100, 20);
            this.textGrossMin.TabIndex = 20;
            this.textGrossMin.Text = "0";
            this.textGrossMin.TextAlign = HorizontalAlignment.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x22, 0x1d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4e, 13);
            this.label1.TabIndex = 0x15;
            this.label1.Text = "Gross Minimum";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xe0, 30);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x16, 13);
            this.label2.TabIndex = 0x16;
            this.label2.Text = "KG";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1cd, 30);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x16, 13);
            this.label3.TabIndex = 0x19;
            this.label3.Text = "KG";
            this.textGrossMax.CharacterCasing = CharacterCasing.Upper;
            this.textGrossMax.Location = new Point(0x163, 0x1a);
            this.textGrossMax.Name = "textGrossMax";
            this.textGrossMax.Size = new Size(100, 20);
            this.textGrossMax.TabIndex = 0x17;
            this.textGrossMax.Text = "0";
            this.textGrossMax.TextAlign = HorizontalAlignment.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x10c, 0x1d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x51, 13);
            this.label4.TabIndex = 0x18;
            this.label4.Text = "Gross Maximum";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xe0, 0x4b);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x16, 13);
            this.label5.TabIndex = 0x1c;
            this.label5.Text = "KG";
            this.textNetto.CharacterCasing = CharacterCasing.Upper;
            this.textNetto.Location = new Point(0x76, 0x47);
            this.textNetto.Name = "textNetto";
            this.textNetto.Size = new Size(100, 20);
            this.textNetto.TabIndex = 0x1a;
            this.textNetto.Text = "0";
            this.textNetto.TextAlign = HorizontalAlignment.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x2a, 0x4a);
            this.label6.Name = "label6";
            this.label6.Size = new Size(70, 13);
            this.label6.TabIndex = 0x1b;
            this.label6.Text = "Netto Weight";
            this.button2.Location = new Point(0x198, 0x70);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 30;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonSave.Location = new Point(0x13b, 0x70);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x17);
            this.buttonSave.TabIndex = 0x1d;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x20d, 0x9e);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textNetto);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textGrossMax);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textGrossMin);
            base.Controls.Add(this.label1);
            base.Name = "FormCommodityGunnyControl";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormCommodityGunnyControl";
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

