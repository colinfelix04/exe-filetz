﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormVendorNegoEntry : Form
    {
        public WBTable tbl_vNego = new WBTable();
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public string rCode = "";
        public string sUniq = "";
        private IContainer components = null;
        private Label label1;
        private TextBox textRelation;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label3;
        private Label label4;
        private TextBox textNego;
        private Button button1;
        private Button button2;

        public FormVendorNegoEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textNego.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_486, Resource.Title_002);
            }
            else
            {
                this.Simpan();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private bool cekValid()
        {
            bool flag2;
            WBTable table = new WBTable();
            table = this.tbl_vNego;
            DateTime time3 = Convert.ToDateTime(this.dateTimePicker1.Value.ToShortDateString());
            DateTime time4 = Convert.ToDateTime(this.dateTimePicker2.Value.ToShortDateString());
            if (time3 <= time4)
            {
                using (IEnumerator enumerator = table.DT.Rows.GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        DataRow current = (DataRow) enumerator.Current;
                        DateTime time = Convert.ToDateTime(current["DateFrom"].ToString());
                        DateTime time2 = Convert.ToDateTime(current["DateTo"].ToString());
                        if ((time >= time3) && (time2 <= time4))
                        {
                            if (this.pMode == "ADD")
                            {
                                MessageBox.Show(Resource.Mes_484);
                                flag2 = false;
                            }
                            else
                            {
                                if (current["uniq"].ToString() == this.sUniq)
                                {
                                    continue;
                                }
                                MessageBox.Show(Resource.Mes_484);
                                flag2 = false;
                            }
                            return flag2;
                        }
                    }
                }
                flag2 = true;
            }
            else
            {
                MessageBox.Show(Resource.Mes_483, Resource.Title_002);
                flag2 = false;
            }
            return flag2;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormVendorNegoEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormVendorNegoEntry_Load(object sender, EventArgs e)
        {
            this.textRelation.Text = this.rCode;
            if (this.pMode == "ADD")
            {
                this.dateTimePicker1.Value = DateTime.Now;
                this.dateTimePicker2.Value = DateTime.Now;
                this.textNego.Text = "";
                this.Text = Resource.Title_Entry_Nego + " " + this.textRelation.Text;
            }
            else if (this.pMode == "EDIT")
            {
                this.Text = Resource.Title_Edit_Nego + " " + this.textRelation.Text;
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textRelation = new TextBox();
            this.label2 = new Label();
            this.dateTimePicker1 = new DateTimePicker();
            this.dateTimePicker2 = new DateTimePicker();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textNego = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            base.SuspendLayout();
            this.label1.Location = new Point(11, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Relation Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textRelation.Enabled = false;
            this.textRelation.Location = new Point(0x61, 0x11);
            this.textRelation.MaxLength = 20;
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0x8b, 20);
            this.textRelation.TabIndex = 0;
            this.label2.Location = new Point(11, 0x3a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(80, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Date From";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label2.Click += new EventHandler(this.label2_Click);
            this.dateTimePicker1.Location = new Point(0x61, 0x36);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x8b, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker2.Location = new Point(0x10c, 0x36);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x8b, 20);
            this.dateTimePicker2.TabIndex = 5;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xf2, 0x3a);
            this.label3.Name = "label3";
            this.label3.Size = new Size(20, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            this.label4.Location = new Point(11, 0x5f);
            this.label4.Name = "label4";
            this.label4.Size = new Size(80, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Nego No.";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.textNego.Location = new Point(0x61, 0x5c);
            this.textNego.MaxLength = 10;
            this.textNego.Name = "textNego";
            this.textNego.Size = new Size(0x4e, 20);
            this.textNego.TabIndex = 2;
            this.button1.Location = new Point(0xd8, 0x7d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 3;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x14c, 0x7d);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 4;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1af, 160);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textNego);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.dateTimePicker2);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.dateTimePicker1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormVendorNegoEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Nego Number Entry";
            base.Load += new EventHandler(this.FormVendorNegoEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormVendorNegoEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void Simpan()
        {
            if (this.cekValid())
            {
                Cursor.Current = Cursors.WaitCursor;
                if (this.pMode != "ADD")
                {
                    Cursor.Current = Cursors.Default;
                    if (this.pMode != "EDIT")
                    {
                        goto TR_0003;
                    }
                    else
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.VendorE_001 },
                            textRefNo = { Text = this.textRelation.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            goto TR_0003;
                        }
                    }
                    return;
                }
                else
                {
                    this.tbl_vNego.DR = this.tbl_vNego.DT.NewRow();
                    this.tbl_vNego.DR["Relation_code"] = this.rCode;
                    this.tbl_vNego.DR["datefrom"] = this.dateTimePicker1.Value.ToShortDateString();
                    this.tbl_vNego.DR["dateto"] = this.dateTimePicker1.Value.ToShortDateString();
                    this.tbl_vNego.DR["nego"] = this.textNego.Text;
                    this.tbl_vNego.DT.Rows.Add(this.tbl_vNego.DR);
                    this.tbl_vNego.Save();
                    string sqltext = ((("SELECT uniq FROM wb_relation_nego " + " WHERE relation_code = '" + this.rCode + "'") + " AND datefrom = '" + this.dateTimePicker1.Value.ToShortDateString() + "'") + " AND dateto = '" + this.dateTimePicker2.Value.ToShortDateString() + "'") + " AND nego = '" + this.textNego.Text + "'";
                    WBTable table = new WBTable();
                    table.OpenTable("wb_relation_nego", sqltext, WBData.conn);
                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                    table.Dispose();
                }
            }
            else
            {
                return;
            }
        TR_0001:
            string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
            Program.updateLogHeader("wb_relation_nego", this.logKey, textArray3, logValue);
            Cursor.Current = Cursors.Default;
            base.Close();
            return;
        TR_0003:
            Cursor.Current = Cursors.WaitCursor;
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.sUniq };
            int recNo = this.tbl_vNego.GetRecNo(aField, aFind);
            this.tbl_vNego.DR = this.tbl_vNego.DT.Rows[recNo];
            this.logKey = this.tbl_vNego.DR["uniq"].ToString();
            this.tbl_vNego.DR.BeginEdit();
            this.tbl_vNego.DR["datefrom"] = this.dateTimePicker1.Value.ToShortDateString();
            this.tbl_vNego.DR["dateto"] = this.dateTimePicker1.Value.ToShortDateString();
            this.tbl_vNego.DR["nego"] = this.textNego.Text;
            this.tbl_vNego.DR.EndEdit();
            this.tbl_vNego.Save();
            goto TR_0001;
        }

        private void translate()
        {
            this.label1.Text = Resource.VendorE_001;
            this.label2.Text = Resource.Lbl_Date_From;
            this.label3.Text = Resource.Setting_053;
            this.label4.Text = Resource.Lbl_Nego_No;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.Text = Resource.Title_Nego_Number_Entry;
        }
    }
}

