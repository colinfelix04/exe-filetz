﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormGradingEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceCode = false;
        public bool ReplaceVar = false;
        public DataGridView dataGridView1;
        public string OldCode;
        public string OldVar;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TextBox textBox4;
        private Label label4;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private Button button3;
        public TextBox textBox1;

        public FormGradingEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            WBTable table3;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2, this.textBox4 };
            if (!Program.CheckEmpty(aText))
            {
                Cursor.Current = Cursors.WaitCursor;
                WBTable table = new WBTable();
                table.OpenTable("wb_grading", "Select Uniq From wb_grading Where " + WBData.CompanyLocation(" and (grading_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.OpenTable("wb_grading", "Select Uniq From wb_grading Where " + WBData.CompanyLocation(" and (variable='" + this.textBox4.Text.Trim() + "')"), WBData.conn);
                    if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                    {
                        table.Dispose();
                        this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                        if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                        {
                            goto TR_0022;
                        }
                        else
                        {
                            table2 = new WBTable();
                            table2.OpenTable("wb_TransactionD", "Select uniq From wb_TransactionD where " + WBData.CompanyLocation("and (Code='" + this.OldCode.Trim() + "') and (Type='1' or Type='F')"), WBData.conn);
                            Cursor.Current = Cursors.Default;
                            if (table2.DT.Rows.Count <= 0)
                            {
                                goto TR_0023;
                            }
                            else
                            {
                                string[] textArray1 = new string[13];
                                textArray1[0] = Resource.Mes_172;
                                textArray1[1] = ": ";
                                textArray1[2] = this.OldCode;
                                textArray1[3] = " -> ";
                                textArray1[4] = this.textBox1.Text;
                                textArray1[5] = "\n\n";
                                textArray1[6] = Resource.Msg_Replace_Warning;
                                textArray1[7] = "  - ";
                                textArray1[8] = table2.DT.Rows.Count.ToString();
                                textArray1[9] = " ";
                                textArray1[10] = Resource.Mes_Records_In_Transaction;
                                textArray1[11] = "\n\n";
                                textArray1[12] = Resource.Msg_Continue;
                                if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    this.ReplaceCode = true;
                                    goto TR_0023;
                                }
                                else
                                {
                                    this.ReplaceCode = false;
                                    this.textBox1.Focus();
                                }
                            }
                        }
                    }
                    else
                    {
                        table.Dispose();
                        MessageBox.Show(Resource.Mes_173);
                        this.textBox4.Focus();
                        Cursor.Current = Cursors.Default;
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_171);
                    this.textBox1.Focus();
                    Cursor.Current = Cursors.Default;
                }
            }
            return;
        TR_001B:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Grade_001 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Grading_Code"] = this.textBox1.Text;
            this.zTable.DR["Grading_Name"] = this.textBox2.Text;
            this.zTable.DR["Formula"] = this.textBox3.Text;
            this.zTable.DR["Variable"] = this.textBox4.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_grading", "SELECT uniq FROM wb_grading WHERE " + WBData.CompanyLocation(" AND grading_code = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_grading", this.logKey, logField, logValue);
            }
            if (this.pMode == "EDIT")
            {
                if (this.ReplaceCode)
                {
                    string[] aField = new string[] { "Code", "Name", "Formula" };
                    string[] aNewValue = new string[] { this.textBox1.Text, this.textBox2.Text, this.textBox3.Text };
                    Program.ReplaceAll("wb_TransactionD", aField, aNewValue, " ((Code='" + this.OldCode.Trim() + "') and (Type='1' or Type='F'))", this.changeReason + " (Edit grading master data)");
                }
                if (this.ReplaceVar)
                {
                    string[] aField = new string[] { "Variable", "Name", "Formula" };
                    string[] aNewValue = new string[] { this.textBox4.Text, this.textBox2.Text, this.textBox3.Text };
                    Program.ReplaceAll("wb_TransactionD", aField, aNewValue, " ((Code='" + this.OldCode.Trim() + "') and (Type='1' or Type='F'))", this.changeReason + " (Edit grading master data)");
                }
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_001C:
            table3.Dispose();
            goto TR_001B;
        TR_0022:
            if ((this.pMode != "EDIT") || (this.textBox4.Text.Trim() == this.OldVar.Trim()))
            {
                goto TR_001B;
            }
            else
            {
                table3 = new WBTable();
                table3.OpenTable("wb_TransactionD", "Select uniq From wb_TransactionD where " + WBData.CompanyLocation("and (Variable='" + this.OldVar.Trim() + "') and (Type='1' or Type='F')"), WBData.conn);
                Cursor.Current = Cursors.Default;
                if (table3.DT.Rows.Count <= 0)
                {
                    goto TR_001C;
                }
                else
                {
                    string[] textArray2 = new string[13];
                    textArray2[0] = Resource.Mes_174;
                    textArray2[1] = ": ";
                    textArray2[2] = this.OldVar;
                    textArray2[3] = " -> ";
                    textArray2[4] = this.textBox4.Text;
                    textArray2[5] = "\n\n";
                    textArray2[6] = Resource.Msg_Replace_Warning;
                    textArray2[7] = "  - ";
                    textArray2[8] = table3.DT.Rows.Count.ToString();
                    textArray2[9] = " ";
                    textArray2[10] = Resource.Mes_Records_In_Transaction;
                    textArray2[11] = "\n\n";
                    textArray2[12] = Resource.Msg_Continue;
                    if (MessageBox.Show(string.Concat(textArray2), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.ReplaceCode = true;
                        goto TR_001C;
                    }
                    else
                    {
                        this.ReplaceCode = false;
                        this.textBox4.Focus();
                    }
                }
            }
            return;
        TR_0023:
            table2.Dispose();
            goto TR_0022;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExpressionVariabel owner = new ExpressionVariabel();
            string pStr = this.textBox3.Text.Trim() + " ~";
            foreach (DataRow row in this.zTable.DT.Rows)
            {
                pStr = ((this.pMode != "EDIT") || (row["Variable"].ToString() != this.OldVar)) ? pStr.Replace(row["Variable"].ToString().Trim() + " ", "1") : pStr.Replace(this.textBox4.Text.Trim() + " ", "1");
            }
            if (this.pMode == "ADD")
            {
                pStr = pStr.Replace(this.textBox4.Text.Trim() + " ", "1");
            }
            pStr = pStr.Replace("~", "");
            owner.NET = 1.0;
            if (Program.eval(pStr, owner) == -999999999.0)
            {
                this.textBox3.Focus();
            }
            else
            {
                MessageBox.Show(Resource.Mes_170);
                this.button1.Focus();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormGradingEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.button2.PerformClick();
            }
        }

        private void FormGradingEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Grading_Code"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Grading_Name"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Formula"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Variable"].Value.ToString();
                this.OldVar = this.textBox4.Text;
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = " &Close ";
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.textBox3 = new TextBox();
            this.groupBox1 = new GroupBox();
            this.groupBox2 = new GroupBox();
            this.button3 = new Button();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label8 = new Label();
            this.label7 = new Label();
            this.label6 = new Label();
            this.label5 = new Label();
            this.label3 = new Label();
            this.textBox4 = new TextBox();
            this.label4 = new Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(0x1c7, 0x173);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x164, 0x173);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 5;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x6d, 0x30);
            this.textBox2.MaxLength = 100;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x1a5, 20);
            this.textBox2.TabIndex = 1;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x6d, 0x18);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 0;
            this.label2.Location = new Point(0x12, 0x33);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x55, 13);
            this.label2.TabIndex = 0x4e;
            this.label2.Text = "Grading Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(0x12, 0x1b);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x55, 13);
            this.label1.TabIndex = 0x4d;
            this.label1.Text = "Grading Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textBox3.Location = new Point(6, 0x13);
            this.textBox3.MaxLength = 100;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x1f7, 20);
            this.textBox3.TabIndex = 0;
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Location = new Point(14, 0x6f);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x204, 0x34);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[ Formula for Grading ]";
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new Point(14, 0xa9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x204, 0xc4);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.button3.Location = new Point(0x1b2, 11);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x4b, 0x26);
            this.button3.TabIndex = 7;
            this.button3.Text = "Test Formula";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x1d, 0xa1);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x14e, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "~ Logical  :   And,  Or,   Xor,   Not,   =,  <>,  >,  <,  >=,  <=,  true,  false";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x1d, 0x8b);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0xb0, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "~ Arithmetic  :   +,  -,  *,  /,  ^,  %,  ( )";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(6, 0x75);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x4e, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "[ Operators ]";
            this.label7.AutoSize = true;
            this.label7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(6, 0x10);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x8b, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "[ Function && Variabels ]";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x2c, 0x52);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8e, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "~ IF( Condition, Exp1, Exp2 )";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x2c, 0x3b);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x71, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "~ ROUND( Exp, Dec )";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x2c, 0x24);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x75, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "~ NET - for Net Weight";
            this.textBox4.CharacterCasing = CharacterCasing.Upper;
            this.textBox4.Location = new Point(0x6d, 0x4a);
            this.textBox4.MaxLength = 10;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0x4f, 20);
            this.textBox4.TabIndex = 2;
            this.label4.Location = new Point(0x12, 0x4d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x55, 13);
            this.label4.TabIndex = 0x53;
            this.label4.Text = "As Variable";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x233, 0x198);
            base.ControlBox = false;
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormGradingEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormGradingEntry";
            base.Load += new EventHandler(this.FormGradingEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormGradingEntry_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Grade_001;
            this.label2.Text = Resource.Grade_002;
            this.label4.Text = Resource.Grade_003;
            this.groupBox1.Text = Resource.Grade_004;
            this.button3.Text = Resource.Grade_006;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
            this.label10.Text = "~ " + Resource.Lbl_Logical + "  :   And,  Or,   Xor,   Not,   =,  <>,  >,  <,  >=,  <=,  true,  false";
            this.label9.Text = "~ " + Resource.Lbl_Arithmetic + "  :   +,  -,  *,  /,  ^,  %,  ( )";
            this.label8.Text = "[ " + Resource.Lbl_Operators + " ]";
            this.label7.Text = "[ " + Resource.Lbl_Functions_Variables + " ]";
            this.label3.Text = "~ NET - " + Resource.Lbl_For_Net_Weight;
        }
    }
}

