﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormUploadSAP : Form
    {
        private DataTable tblTrans = new DataTable();
        private DataTable retTable = new DataTable();
        private WBTable tmpBatch = new WBTable();
        private WBTable tbl_transaction = new WBTable();
        private WBTable tbl_Gatepass = new WBTable();
        private WBTable tbl_templateSAP = new WBTable();
        private WBTable tbl_transactionType = new WBTable();
        private WBTable aTable = new WBTable();
        private WBTable bTable = new WBTable();
        private string[] retValue = new string[3];
        private string sapFunc;
        private string sapTable;
        private string sapReturn;
        private string sapType;
        public string tipeTrans = "";
        public string comm = "";
        public string Do_No = "";
        public string sapDest = "";
        public string uploadType = "";
        public string transpt = "";
        public string logKey = "";
        private Thread workerThread = null;
        private int jlhkolom;
        public bool showPosted;
        public bool showAll;
        public bool locked = false;
        public bool cTrans = false;
        public bool uplDate;
        public bool extractExcel = false;
        private string adopt = "N";
        public string module;
        public string type;
        public string sqlText;
        public string date1;
        public string date2;
        public char auto = 'N';
        public DateTime dateFrom;
        public DateTime dateTo;
        private int rCount;
        private WBTable cTable = new WBTable();
        private WBTable dTable = new WBTable();
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private string errValue = "";
        public string cField = "";
        private IContainer components = null;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem mnUpd;
        private ToolStripMenuItem excelToolStripMenuItem;
        private ProgressBar prgBar;
        public ToolStripMenuItem exitToolStripMenuItem;
        private Label labelTotalRecord3;
        private Label labelTotalRecord2;
        private Label labelTotalRecord1;
        private Button buttonSelectAll;
        private Button buttonUnSelect;
        private Panel panel2;
        private Panel panel1;
        private DataGridView dgTransFlag;
        private DataGridView dgTrans;
        private ToolStripMenuItem mnuExport;
        private Timer timer;

        public FormUploadSAP()
        {
            this.InitializeComponent();
            this.mnuExport.Visible = WBSetting.activeEncryptExport;
        }

        public void btnUpload()
        {
            bool flag = false;
            foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
            {
                if (this.auto == 'Y')
                {
                    row.Cells["select"].Value = true;
                }
                if (Convert.ToBoolean(row.Cells["select"].Value))
                {
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show("Please Select Record to Upload...", "WARNING...");
                }
            }
            else if (flag)
            {
                if (this.sapDest == "SALES UGI")
                {
                    this.uploadUGI();
                }
                else if (this.sapDest == "SALES UST")
                {
                    this.uploadUSTUPO();
                }
                else if (this.sapDest == "PURC UST")
                {
                    this.uploadUSTUPO();
                }
                else if (this.sapDest == "PURC UPO")
                {
                    this.uploadUSTUPO();
                }
                else if ((this.sapDest == "GPO/GST") || (this.sapDest == "GPO"))
                {
                    this.uploadGPOGST();
                }
                else if (this.sapDest == "MM")
                {
                    this.uploadMM();
                }
                else if (this.sapDest == "ESTATE OWN")
                {
                    this.uploadEstateOwn();
                }
                else if (this.sapDest == "PLASMA OWN")
                {
                    this.uploadPlasmaOwn();
                }
                else if (this.sapDest == "DIV BLOCK")
                {
                    this.uploadDivBlock();
                }
                else if (this.sapDest == "UTP")
                {
                    this.uploadUTP();
                }
                else if (this.sapDest == "ZMY_UPLOADFFB")
                {
                    if (WBSetting.activeMulesoftIntegration)
                    {
                        this.ZRFC_UPLOAD_FFB_MYMulesoft();
                    }
                    else
                    {
                        this.uploadZMYFFB();
                    }
                }
                else if (this.sapDest == "ZMM_UPLOADSTM")
                {
                    if (WBSetting.activeMulesoftIntegration)
                    {
                        this.ZMM_UPLOADSTMMulesoft();
                    }
                    else
                    {
                        this.uploadZMMSTM();
                    }
                }
                else if (this.sapDest != "ZMM_UPLOADSTM_RCV")
                {
                    this.uploadSAP();
                }
                else if (WBSetting.activeMulesoftIntegration)
                {
                    this.ZMM_UPLOADSTM_RCVMulesoft();
                }
                else
                {
                    this.uploadZMMSTM_RCV();
                }
            }
        }

        private void buttonSelectAll_Click(object sender, EventArgs e)
        {
            this.selectAll();
        }

        private void buttonUnSelect_Click(object sender, EventArgs e)
        {
            if (this.dgTrans.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = false;
                }
            }
        }

        private bool cekFlag(string pRef)
        {
            for (int i = 0; i < this.dgTransFlag.Rows.Count; i++)
            {
            }
            return false;
        }

        private void chkPosted_CheckedChanged(object sender, EventArgs e)
        {
            this.tblTrans.Rows.Clear();
            this.retTable.Rows.Clear();
            this.dgTrans.Rows.Clear();
            this.dgTrans.Refresh();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgTrans_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = this.dgTrans.CurrentCell.ColumnIndex;
            if (this.dgTrans.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
            {
                this.dgTrans.CurrentCell.Value = !Convert.ToBoolean(this.dgTrans.CurrentCell.Value);
            }
        }

        private void dgTrans_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgTrans_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgTrans.CurrentCell.ColumnIndex != 0)
            {
                this.ViewTimbang();
            }
        }

        private void dgvToTable(DataGridView aDgv, DataTable aTable)
        {
            try
            {
                aTable.Rows.Clear();
                foreach (DataGridViewRow row2 in (IEnumerable) aDgv.Rows)
                {
                    if (Convert.ToBoolean(row2.Cells["select"].Value))
                    {
                        DataRow row = aTable.NewRow();
                        int num = 0;
                        while (true)
                        {
                            if (num >= aTable.Columns.Count)
                            {
                                aTable.Rows.Add(row);
                                break;
                            }
                            row[aTable.Columns[num].ColumnName] = row2.Cells[aTable.Columns[num].ColumnName].Value;
                            num++;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                int num = 0;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.dgTrans.Rows.Count)
                    {
                        if (flag)
                        {
                            MessageBox.Show("Please select at least 1 transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            Cursor.Current = Cursors.WaitCursor;
                            string str = "";
                            str = (this.dateFrom.ToString("dd/MM/yyyy") != this.dateTo.ToString("dd/MM/yyyy")) ? (this.dateFrom.ToString("dd/MM/yyyy") + " - " + this.dateTo.ToString("dd/MM/yyyy")) : this.dateFrom.ToString("dd/MM/yyyy");
                            object[] objArray1 = new object[] { "WBNET_", WBSetting.CoySAP, "_", this.sapDest, "_", DateTime.Now.ToString("ddMMyyyy_HHmmss"), "_", num };
                            Program.export2Excel(this.dgTrans, this.sapDest, string.Concat(objArray1), false);
                            if (Program.excelSuccess)
                            {
                                WBTable table = new WBTable();
                                table.OpenTable("wb_templateSAP", "SELECT title_excel FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" AND modul = '" + this.sapDest + "' AND field_wb = 'ref' AND table_name = 'wb_transaction'"), WBData.conn);
                                string str2 = table.DT.Rows[0]["title_excel"].ToString();
                                table.Dispose();
                                int num3 = 0;
                                while (true)
                                {
                                    if (num3 >= this.dgTrans.Rows.Count)
                                    {
                                        Cursor.Current = Cursors.Default;
                                        object[] objArray2 = new object[] { "Data has been extracted to excel successfully!\n\nTotal data: ", num, " transactions\nReport date: ", str };
                                        MessageBox.Show(string.Concat(objArray2), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.f_load();
                                        break;
                                    }
                                    if ((this.dgTrans.Rows[num3].Cells[0].Value != null) && (this.dgTrans.Rows[num3].Cells[0].Value.ToString() == "True"))
                                    {
                                        string str3 = this.dgTrans.Rows[num3].Cells[str2].Value.ToString();
                                        WBTable table2 = new WBTable();
                                        table2.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + str3 + "'"), WBData.conn);
                                        table2.DR = table2.DT.Rows[0];
                                        this.logKey = table2.DR["uniq"].ToString();
                                        table2.DR.BeginEdit();
                                        table2.DR["posted"] = "Y";
                                        table2.DR["sync_return"] = "";
                                        table2.DR["lastUpload"] = DateTime.Now;
                                        table2.DR["checksum"] = table2.Checksum(table2.DR);
                                        table2.DR.EndEdit();
                                        table2.Save();
                                        table2.Dispose();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Extract transaction to Excel" };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    num3++;
                                }
                            }
                        }
                        break;
                    }
                    if ((this.dgTrans.Rows[num2].Cells[0].Value != null) && (this.dgTrans.Rows[num2].Cells[0].Value.ToString() == "True"))
                    {
                        flag = false;
                        num++;
                    }
                    num2++;
                }
            }
            catch
            {
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
            base.Dispose();
        }

        public void f_load()
        {
            Cursor.Current = Cursors.WaitCursor;
            this.Refresh();
            this.initTransFlag();
            this.initTable();
            this.cField = (WBData.sRegion != "1") ? WBTable.cFieldTrans : WBTable.cFieldTransAfrica;
            if (this.dgTrans.Rows.Count > 0)
            {
                if (!this.extractExcel && (this.auto != 'Y'))
                {
                    MessageBox.Show(Resource.Mes_436, Resource.Title_007);
                }
            }
            else if (this.auto != 'Y')
            {
                MessageBox.Show(Resource.Mes_592, Resource.Title_007);
            }
            Cursor.Current = Cursors.Default;
            this.mnUpd.Visible = (this.module != "ZPOM_SALES") ? ((WBSetting.region != "2") || WBUser.CheckTrustee("MD_SYNCH", "A")) : false;
            if (WBUser.CheckTrustee("MD_SYNCH", "A"))
            {
                this.mnUpd.Enabled = true;
                this.excelToolStripMenuItem.Enabled = true;
            }
            if (this.extractExcel)
            {
                this.selectAll();
                this.excelToolStripMenuItem.PerformClick();
                this.exitToolStripMenuItem.PerformClick();
            }
        }

        private void fillDG(bool showPosted, DataGridView zDgv, DataTable zTable)
        {
            if (this.cTrans)
            {
                this.sqlText = (this.auto != 'Y') ? ("select * from vw_trans where " + WBData.CompanyLocation("")) : ("select TOP(100) * from vw_trans where " + WBData.CompanyLocation(""));
                if (this.auto != 'Y')
                {
                    this.sqlText = this.sqlText + " and report_Date < '" + this.date2 + "' ";
                }
                this.sqlText = this.sqlText + " and (posted is null or posted ='N') ";
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                this.sqlText = this.sqlText + " and  postSAP = 'Y' ";
                this.sqlText = this.sqlText + " and  (NonContract is null or Noncontract = 'N' or NonContract ='') ";
                if (this.sapDest == "ZPOM_SALES")
                {
                    this.sqlText = this.sqlText + " and  (ZAuto = 'Y')";
                }
                else if (this.sapDest == "ZMY_UPLOADFFB")
                {
                    this.sqlText = this.sqlText + " and type = 'F' ";
                }
                else if (this.sapDest == "ZMM_UPLOADSTM")
                {
                    this.sqlText = this.sqlText + " and type = 'S'";
                }
                this.sqlText = this.sqlText + " order by Ref Desc";
            }
            else
            {
                this.sqlText = (this.auto != 'Y') ? ("select * from vw_trans where " + WBData.CompanyLocation(" ")) : ("select TOP(100) * from vw_trans where " + WBData.CompanyLocation(" "));
                if (this.uplDate && (this.auto != 'Y'))
                {
                    string[] textArray1 = new string[] { this.sqlText, " and report_date >= '", this.date1, "' and report_Date <= '", this.date2, "' " };
                    this.sqlText = string.Concat(textArray1);
                }
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                this.sqlText = this.sqlText + " and IO = '" + this.tipeTrans + "' ";
                if (!this.showAll)
                {
                    this.sqlText = (this.sapDest != "ZMM_UPLOADSTM_RCV") ? (this.sqlText + " and (posted is null or posted ='N') ") : (this.sqlText + " and (posted_opw ='N')");
                }
                if (this.comm.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Comm_code = '" + this.comm + "') ";
                }
                if (this.transpt.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Transporter_code = '" + this.transpt + "') ";
                }
                if (this.Do_No.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Do_No = '" + this.Do_No + "') ";
                }
                this.sqlText = this.sqlText + " and  postSAP = 'Y' ";
                this.sqlText = this.sqlText + " and  (NonContract is null or Noncontract = 'N' or NonContract ='') ";
                if (this.sapDest == "ZPOM_SALES")
                {
                    this.sqlText = this.sqlText + " and  (ZAuto = 'Y')";
                }
                else if (this.sapDest == "ZMY_UPLOADFFB")
                {
                    this.sqlText = this.sqlText + " and type = 'F' ";
                }
                else if (this.sapDest == "ZMM_UPLOADSTM")
                {
                    this.sqlText = this.sqlText + " and type = 'S'";
                }
                this.sqlText = this.sqlText + " order by Ref Desc";
            }
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.labelTotalRecord2.Text = this.rCount.ToString().Trim();
            this.prgBar.Value = 0;
            this.labelTotalRecord2.Refresh();
            this.labelTotalRecord1.Refresh();
            this.labelTotalRecord3.Refresh();
            zDgv.Rows.Clear();
            if (this.rCount > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.rCount)
                    {
                        break;
                    }
                    zDgv.Rows.Add();
                    this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[num];
                    int crRow = zDgv.Rows.Count - 1;
                    if (this.fillDGRow(this.tbl_transaction.DR, zDgv, crRow))
                    {
                        this.prgBar.Value++;
                    }
                    num++;
                }
            }
        }

        private void fillDGAfrica(bool showPosted, DataGridView zDgv, DataTable zTable)
        {
            if (this.cTrans)
            {
                this.sqlText = "select * from vw_trans where " + WBData.CompanyLocation("");
                if (this.auto != 'Y')
                {
                    this.sqlText = this.sqlText + " and report_Date < '" + this.date2 + "' ";
                }
                this.sqlText = this.sqlText + " and (posted is null or posted ='N') ";
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                this.sqlText = this.sqlText + " and  postSAP = 'Y' ";
                this.sqlText = this.sqlText + " and  (NonContract is null or Noncontract = 'N' or NonContract ='') ";
                this.sqlText = this.sqlText + " order by Ref";
            }
            else
            {
                this.sqlText = "select * from vw_trans where " + WBData.CompanyLocation(" ");
                if (this.auto != 'Y')
                {
                    string[] textArray1 = new string[] { this.sqlText, " and (report_date >= '", this.date1, "' and report_Date <= '", this.date2, "')" };
                    this.sqlText = string.Concat(textArray1);
                }
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                if (!this.showAll)
                {
                    this.sqlText = this.sqlText + " and (posted is null or posted ='N') ";
                }
                if (this.comm.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Comm_code = '" + this.comm + "') ";
                }
                if (this.transpt.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Transporter_code = '" + this.transpt + "') ";
                }
                if (this.Do_No.Length > 0)
                {
                    this.sqlText = this.sqlText + " and (Do_No = '" + this.Do_No + "') ";
                }
                this.sqlText = this.sqlText + " and  (postSAP = 'Y') ";
                this.sqlText = this.sqlText + " and  (NonContract is null or Noncontract = 'N' or NonContract ='') ";
                if (this.sapDest == "SALES UGI")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'UGI') ";
                    this.sqlText = this.sqlText + " and  (transaction_code = 'S') ";
                }
                else if (this.sapDest == "SALES UST")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'UST') ";
                    this.sqlText = this.sqlText + " and  (IO = 'O') ";
                }
                else if (this.sapDest == "PURC UPO")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'UPO') ";
                    this.sqlText = this.sqlText + " and  (IO = 'I') ";
                }
                else if (this.sapDest == "PURC UST")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'UST') ";
                    this.sqlText = this.sqlText + " and  (IO = 'I') ";
                }
                else if (this.sapDest == "GPO/GST")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'GST' or upload_Type = 'GPO') ";
                }
                else if (this.sapDest == "STP")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'STP') ";
                }
                else if (this.sapDest == "UTP")
                {
                    this.sqlText = this.sqlText + " and  (upload_Type = 'UTP') ";
                }
                this.sqlText = this.sqlText + " order by Ref";
            }
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.labelTotalRecord2.Text = this.rCount.ToString().Trim();
            this.prgBar.Value = 0;
            this.labelTotalRecord2.Refresh();
            this.labelTotalRecord1.Refresh();
            this.labelTotalRecord3.Refresh();
            zDgv.Rows.Clear();
            if (this.rCount > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.rCount)
                    {
                        break;
                    }
                    zDgv.Rows.Add();
                    this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[num];
                    int crRow = zDgv.Rows.Count - 1;
                    if (this.fillDGRowAfrica(this.tbl_transaction.DR, zDgv, crRow))
                    {
                        this.prgBar.Value++;
                    }
                    num++;
                }
            }
        }

        private void fillDGAfricaDivBlock(bool showPosted, DataGridView zDgv, DataTable zTable)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            int num3 = 0;
            string str10 = "N";
            int count = this.tbl_templateSAP.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            string[] textArray1 = new string[] { "SELECT * From wb_transaction TRANS WHERE divBlock = '1'  AND   TRANS.Deleted  is null AND   TRANS.Report_date is not null AND   Report_date >=('", this.date1, "') AND   report_date <=('", this.date2, "') ORDER BY Trans.Ref" };
            this.sqlText = string.Concat(textArray1);
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.labelTotalRecord2.Text = this.rCount.ToString().Trim();
            this.prgBar.Value = 0;
            this.labelTotalRecord2.Refresh();
            this.labelTotalRecord1.Refresh();
            this.labelTotalRecord3.Refresh();
            zDgv.Rows.Clear();
            count = this.tbl_templateSAP.DT.Rows.Count;
            num3 = 0;
            using (IEnumerator enumerator = this.tbl_transaction.DT.Rows.GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataRow current = (DataRow) enumerator.Current;
                    string str11 = current["Ref"].ToString();
                    string sqltext = "SELECT * From wb_divide_blockD WHERE Ref= '" + str11 + "' ORDER BY Block_code";
                    table2.OpenTable("wb_divBlock", sqltext, WBData.conn);
                    using (IEnumerator enumerator2 = table2.DT.Rows.GetEnumerator())
                    {
                        int num4;
                        string str8;
                        string str9;
                        DataRow row2;
                        goto TR_0038;
                    TR_0013:
                        if (str9.ToUpper() != "Number".ToUpper())
                        {
                            if (str9.ToUpper() == "Boolean".ToUpper())
                            {
                                strArray[num4] = (strArray[num4] != "Y") ? "" : "X";
                            }
                        }
                        else if (ReferenceEquals(strArray[num4], null))
                        {
                            strArray[num4] = "0";
                        }
                        else if (strArray[num4].Trim() == "")
                        {
                            strArray[num4] = "0";
                        }
                        if (str8 != "")
                        {
                            zDgv.Rows[num3].Cells[str8].Value = strArray[num4];
                        }
                        num4++;
                        goto TR_0035;
                    TR_001E:
                        if (strArray[num4] != "")
                        {
                            if (str9.ToUpper() == "DATE".ToUpper())
                            {
                                DateTime time = Convert.ToDateTime(strArray[num4]);
                                strArray[num4] = time.ToString("dd.MM.yyyy");
                            }
                            else if (str9.ToUpper() != "TIME".ToUpper())
                            {
                                if (str9.ToUpper() == "Formula".ToUpper())
                                {
                                    ExpressionVariabel owner = new ExpressionVariabel {
                                        NET = Convert.ToDouble(strArray[num4])
                                    };
                                    double num5 = Program.eval(this.tbl_templateSAP.DR["value"].ToString().Replace("VAL", strArray[num4]), owner);
                                    strArray[num4] = (num5 >= 1.0) ? Convert.ToString(num5) : "";
                                }
                            }
                            else
                            {
                                try
                                {
                                    strArray[num4] = Convert.ToDateTime(strArray[num4]).ToString("HH:mm");
                                    if (strArray[num4] == "00:00")
                                    {
                                        strArray[num4] = "00:01";
                                    }
                                }
                                catch
                                {
                                    strArray[num4] = "";
                                }
                            }
                        }
                        goto TR_0013;
                    TR_0035:
                        while (true)
                        {
                            if (num4 < count)
                            {
                                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[num4];
                                string tablename = this.tbl_templateSAP.DR["table_name"].ToString().Trim();
                                str8 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                                string str3 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                                string str4 = this.tbl_templateSAP.DR["Key_Field2"].ToString().Trim();
                                string str2 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                                str9 = this.tbl_templateSAP.DR["data_type"].ToString().Trim();
                                int num2 = Convert.ToInt16(this.tbl_templateSAP.DR["fixed"].ToString());
                                if (num2 != 0)
                                {
                                    strArray[num4] = this.tbl_templateSAP.DR["value"].ToString().Trim();
                                }
                                else if (((tablename.ToUpper() != "wb_transaction".ToUpper()) && ((tablename != "") && ((tablename.ToUpper() != "wb_transactiond".ToUpper()) && ((tablename.ToUpper() != "wb_transQC".ToUpper()) && ((tablename.ToUpper() != "wb_gatepass".ToUpper()) && (tablename.ToUpper() != "wb_transbatch".ToUpper())))))) && (tablename.ToUpper() != "wb_divide_blockD".ToUpper()))
                                {
                                    try
                                    {
                                        string[] textArray2 = new string[] { " And ", str3, "= '", current[str4].ToString(), "' " };
                                        table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        strArray[num4] = table.DR[str2].ToString().Trim();
                                    }
                                    catch
                                    {
                                        strArray[num4] = "";
                                    }
                                }
                                else if (tablename.ToUpper() == "wb_transaction".ToUpper())
                                {
                                    try
                                    {
                                        strArray[num4] = (!((str2.ToUpper() == "Received".ToUpper()) | (str2.ToUpper() == "terima".ToUpper())) || (this.module != "ZWB")) ? current[str2].ToString().Trim() : Convert.ToString(Math.Abs((double) (Convert.ToDouble(strArray[num4 - 2]) - Convert.ToDouble(strArray[num4 - 1]))));
                                    }
                                    catch
                                    {
                                        strArray[num4] = "";
                                    }
                                }
                                else if (tablename.ToUpper() == "wb_divide_blockD".ToUpper())
                                {
                                    strArray[num4] = row2[str2].ToString().Trim();
                                }
                                else if (tablename.ToUpper() != "wb_transactiond".ToUpper())
                                {
                                    try
                                    {
                                        strArray[num4] = current[str2].ToString().Trim();
                                    }
                                    catch
                                    {
                                        strArray[num4] = "";
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        string kode = this.tbl_templateSAP.DR["field_wb"].ToString().Trim();
                                        strArray[num4] = this.isiDeduc(kode, current["ref"].ToString().Trim(), this.tbl_templateSAP.DR["key_field2"].ToString().Trim());
                                    }
                                    catch
                                    {
                                        strArray[num4] = "0";
                                    }
                                }
                            }
                            else
                            {
                                zDgv.Rows[num3].Cells["posted"].Value = str10;
                                num3++;
                                goto TR_0038;
                            }
                            break;
                        }
                        goto TR_001E;
                    TR_0038:
                        while (true)
                        {
                            if (!enumerator2.MoveNext())
                            {
                                break;
                            }
                            row2 = (DataRow) enumerator2.Current;
                            zDgv.Rows.Add(1);
                            num4 = 0;
                            goto TR_0035;
                        }
                        continue;
                    }
                }
            }
            table2.Dispose();
            table.Dispose();
        }

        private void fillDGAfricaPOM(bool showPosted, DataGridView zDgv, DataTable zTable)
        {
            if (this.module == "MM")
            {
                string[] textArray1 = new string[] { "SELECT * FROM dbo.wb_transaction AS TRANS INNER JOIN  dbo.wb_commodity AS COMM ON TRANS.Comm_Code = COMM.Comm_Code AND TRANS.Coy = COMM.Coy AND  TRANS.Location_Code = COMM.Location_Code LEFT OUTER JOIN  dbo.wb_contract AS CONT ON TRANS.Location_Code = CONT.Location_Code AND TRANS.Coy = CONT.Coy AND TRANS.Do_No = CONT.Do_No LEFT OUTER JOIN dbo.wb_source AS SOUR ON TRANS.Coy = SOUR.Location_Code AND TRANS.Coy = SOUR.Coy AND SOUR.Source_Code = TRANS.Source_Code WHERE COMM.type = 'F'  AND   TRANS.Deleted  is null AND   TRANS.Report_date is not null AND   Report_date >=('", this.date1, "') AND   report_date <=('", this.date2, "') ORDER BY Trans.Ticket" };
                this.sqlText = string.Concat(textArray1);
            }
            else if (this.module == "ESTATE OWN")
            {
                string[] textArray2 = new string[] { "SELECT *  FROM dbo.wb_transaction AS TRANS LEFT OUTER JOIN  dbo.wb_source AS SOUR ON TRANS.Location_Code = SOUR.Location_Code AND TRANS.Coy = SOUR.Coy AND   SOUR.Source_Code = TRANS.Source_Code LEFT OUTER JOIN  dbo.wb_transDivision AS TDIV ON TRANS.Location_Code = TDIV.Location_Code AND TRANS.Coy = TDIV.Coy AND TDIV.Ref = TRANS.Ref LEFT OUTER JOIN   dbo.wb_contract AS CONT ON TRANS.Location_Code = CONT.Location_Code AND TRANS.Coy = CONT.Coy AND TRANS.Do_No = CONT.Do_No LEFT OUTER JOIN   dbo.wb_commodity AS COMM ON TRANS.Comm_Code = COMM.Comm_Code AND TRANS.Coy = COMM.Coy AND   TRANS.Location_Code = COMM.Location_Code WHERE COMM.type = 'F'  AND   SOUR.Estate_type = '0' AND   TRANS.Deleted  is null AND   TRANS.Report_date is not null AND   Report_date >=('", this.date1, "') AND   report_date <=('", this.date2, "') ORDER BY Trans.Ref" };
                this.sqlText = string.Concat(textArray2);
            }
            else if (this.module == "PLASMA OWN")
            {
                string[] textArray3 = new string[] { "SELECT *  FROM         dbo.wb_transaction AS TRANS INNER JOIN      dbo.wb_commodity AS COMM ON TRANS.Comm_Code = COMM.Comm_Code AND TRANS.Coy = COMM.Coy AND      TRANS.Location_Code = COMM.Location_Code LEFT OUTER JOIN      dbo.wb_relation AS RELA ON TRANS.Location_Code = RELA.Location_Code AND TRANS.Coy = RELA.Coy AND      TRANS.Relation_Code = RELA.Relation_Code LEFT OUTER JOIN      dbo.wb_transDivision AS TDIV ON TRANS.Location_Code = TDIV.Location_Code AND TRANS.Coy = TDIV.Coy AND TDIV.Ref = TRANS.Ref LEFT OUTER JOIN      dbo.wb_contract AS CONT ON TRANS.Location_Code = CONT.Location_Code AND TRANS.Coy = CONT.Coy AND TRANS.Do_No = CONT.Do_No LEFT OUTER JOIN      dbo.wb_source AS SOUR ON TRANS.Location_Code = SOUR.Location_Code AND TRANS.Coy = SOUR.Coy AND SOUR.Source_Code = TRANS.Source_Code  WHERE COMM.type = 'F'  AND   TRANS.Deleted  is null AND   SOUR.Estate_type = '1' AND   TRANS.Report_date is not null AND   Report_date >=('", this.date1, "') AND   report_date <=('", this.date2, "') ORDER BY Trans.Ref" };
                this.sqlText = string.Concat(textArray3);
            }
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.labelTotalRecord2.Text = this.rCount.ToString().Trim();
            this.prgBar.Value = 0;
            this.labelTotalRecord2.Refresh();
            this.labelTotalRecord1.Refresh();
            this.labelTotalRecord3.Refresh();
            zDgv.Rows.Clear();
            if (this.rCount > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.rCount)
                    {
                        break;
                    }
                    zDgv.Rows.Add();
                    this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[num];
                    int crRow = zDgv.Rows.Count - 1;
                    if (this.fillDGRowAfricaPOM(this.tbl_transaction.DR, zDgv, crRow))
                    {
                        this.prgBar.Value++;
                    }
                    num++;
                }
            }
        }

        private bool fillDGRow(DataRow aRow, DataGridView fDgv, int crRow)
        {
            string str9;
            string str10;
            string str = "N";
            WBTable table = new WBTable();
            int count = this.tbl_templateSAP.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            string str12 = "";
            string str13 = "";
            string str14 = "";
            str12 = aRow["ref"].ToString().Trim();
            str = aRow["Posted"].ToString().Trim();
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { aRow["Transaction_Code"].ToString() };
            str14 = this.tbl_transactionType.GetData(aField, aFind)["IO"].ToString();
            string[] strArray2 = new string[] { "" };
            string str15 = "";
            int index = 0;
            goto TR_00F1;
        TR_0054:
            if (strArray[index] != "")
            {
                DateTime time;
                if (str10.ToUpper() == "DATE".ToUpper())
                {
                    time = Convert.ToDateTime(strArray[index]);
                    strArray[index] = (((this.module != "UPLOAD_STO_PO") && ((this.module != "PURC UPO") && (this.module != "SALES UST"))) && (this.module != "ZMM_UPLOAD")) ? time.ToString("dd.MM.yyyy") : time.ToString("yyyyMMdd");
                }
                else if (str10.ToUpper() == "TIME".ToUpper())
                {
                    try
                    {
                        time = Convert.ToDateTime(strArray[index]);
                        if (((this.module == "UPLOAD_STO_PO") || (this.module == "ZMM_UPLOADSTM")) || (this.module == "ZMM_UPLOADSTM_RCV"))
                        {
                            strArray[index] = time.ToString("HH:mm:ss");
                            if (strArray[index] == "00:00:00")
                            {
                                strArray[index] = "00:00:01";
                            }
                        }
                        else
                        {
                            strArray[index] = time.ToString("HH:mm");
                            if (strArray[index] == "00:00")
                            {
                                strArray[index] = "00:01";
                            }
                        }
                    }
                    catch
                    {
                        strArray[index] = "";
                    }
                }
                else if (str10.ToUpper() == "Formula".ToUpper())
                {
                    ExpressionVariabel owner = new ExpressionVariabel {
                        NET = Convert.ToDouble(strArray[index])
                    };
                    double num12 = Program.eval(this.tbl_templateSAP.DR["value"].ToString().Replace("VAL", strArray[index]), owner);
                    strArray[index] = (num12 >= 1.0) ? Convert.ToString(num12) : "";
                }
                else if ((str10.ToUpper() == "HARDCODE") && (this.module == "ZPOM_SALES"))
                {
                    if (index == 4)
                    {
                        strArray[index] = "'9" + strArray[index];
                    }
                    if (index == 10)
                    {
                        strArray[index] = "'" + strArray[index];
                    }
                    else if (index == 14)
                    {
                        string str25 = strArray[index];
                        strArray[index] = (str25 == "LSK") ? "TS03" : ((str25 == "JUL") ? "TS05" : "");
                    }
                    else if (index == 15)
                    {
                        string str26 = Program.getFieldValue("wb_contract", "STO", "Do_No", aRow["Do_NO"].ToString());
                        string str27 = Program.getFieldValue("wb_contract", "SO", "Do_No", aRow["Do_NO"].ToString());
                        strArray[index] = (str26 == "") ? ((str27 == "") ? "" : str27) : str26;
                    }
                }
            }
            if (str10.ToUpper() != "Number".ToUpper())
            {
                if (str10.ToUpper() == "Boolean".ToUpper())
                {
                    strArray[index] = (strArray[index] != "Y") ? "" : "X";
                }
            }
            else if (ReferenceEquals(strArray[index], null))
            {
                strArray[index] = "0";
            }
            else if (strArray[index].Trim() == "")
            {
                strArray[index] = "0";
            }
            if (str9 != "")
            {
                fDgv.Rows[crRow].Cells[str9].Value = strArray[index];
            }
            index++;
        TR_00F1:
            while (true)
            {
                int num2;
                string str2;
                string str3;
                string str4;
                string str5;
                if (index >= count)
                {
                    if (this.module != "ZPOM_SALES")
                    {
                        fDgv.Rows[crRow].Cells["posted"].Value = str;
                    }
                    if (strArray2[0] != "")
                    {
                        WBTable table7 = new WBTable();
                        string[] textArray8 = new string[] { "select * from wb_transbatch where (ref = '", strArray2[0], "' or ref like '", strArray2[0], "%-%') and ", WBData.CompanyLocation("") };
                        table7.OpenTable("wb_transbatch", string.Concat(textArray8), WBData.conn);
                        foreach (DataRow row3 in table7.DT.Rows)
                        {
                            index = 0;
                            while (true)
                            {
                                if (index >= count)
                                {
                                    break;
                                }
                                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[index];
                                if (this.tbl_templateSAP.DR["table_name"].ToString().ToUpper() == "wb_transBatch".ToUpper())
                                {
                                    str2 = this.tbl_templateSAP.DR["table_name"].ToString().Trim();
                                    str9 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                                    str4 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                                    str5 = this.tbl_templateSAP.DR["Key_Field2"].ToString().Trim();
                                    str3 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                                    str10 = this.tbl_templateSAP.DR["data_type"].ToString().Trim();
                                    num2 = Convert.ToInt16(this.tbl_templateSAP.DR["fixed"].ToString());
                                    int num13 = this.findInGrid(fDgv, str4, row3["Ref"].ToString());
                                    int num14 = row3["Ref"].ToString().IndexOf("-");
                                    if ((num13 != -1) || (num14 < 0))
                                    {
                                        if (num13 == -1)
                                        {
                                            num13 = fDgv.Rows.Count;
                                        }
                                    }
                                    else
                                    {
                                        DataGridViewRow row4 = fDgv.Rows[crRow];
                                        fDgv.Rows.Add();
                                        num13 = fDgv.Rows.Count - 1;
                                        int num15 = 0;
                                        while (true)
                                        {
                                            if (num15 >= row4.Cells.Count)
                                            {
                                                break;
                                            }
                                            fDgv.Rows[num13].Cells[num15].Value = row4.Cells[num15].Value;
                                            num15++;
                                        }
                                    }
                                    fDgv.Rows[num13].Cells[str4].Value = row3["Ref"];
                                    fDgv.Rows[num13].Cells[str9].Value = row3[str3];
                                }
                                index++;
                            }
                        }
                        if (this.tbl_templateSAP.DR["table_name"].ToString().Trim().ToUpper() != "wb_transBatch".ToUpper())
                        {
                            str9 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                            str4 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                            str3 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                            this.tmpBatch.OpenTable("wb_transBatch", "select * from wb_transBatch where ref like '" + strArray2[0] + "%'", WBData.conn);
                            if (this.tmpBatch.DT.Rows.Count > 0)
                            {
                                int num16 = this.tmpBatch.DT.Rows.Count;
                                DataGridViewRow row5 = fDgv.Rows[crRow];
                                int num17 = 0;
                                while (true)
                                {
                                    if (num17 >= num16)
                                    {
                                        break;
                                    }
                                    this.tmpBatch.DR = this.tmpBatch.DT.Rows[num17];
                                    int num18 = this.findInGrid(fDgv, str4, this.tmpBatch.DR["Ref"].ToString());
                                    if (num18 == -1)
                                    {
                                        fDgv.Rows.Add(1);
                                        num18 = fDgv.Rows.Count - 1;
                                        int num19 = 0;
                                        while (true)
                                        {
                                            if (num19 >= row5.Cells.Count)
                                            {
                                                fDgv.Rows[num18].Cells[str4].Value = this.tmpBatch.DR["Ref"];
                                                fDgv.Rows[num18].Cells[str9].Value = this.tmpBatch.DR[str3];
                                                break;
                                            }
                                            fDgv.Rows[num18].Cells[num19].Value = row5.Cells[num19].Value;
                                            num19++;
                                        }
                                    }
                                    num17++;
                                }
                            }
                            this.tmpBatch.Dispose();
                        }
                    }
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                    if (table2.DT.Rows.Count <= 0)
                    {
                        this.locked = false;
                    }
                    else
                    {
                        table2.DR = table2.DT.Rows[0];
                        this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                    }
                    return !this.locked;
                }
                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[index];
                str2 = this.tbl_templateSAP.DR["table_name"].ToString().Trim();
                str9 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                str4 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                str5 = this.tbl_templateSAP.DR["Key_Field2"].ToString().Trim();
                str3 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                str10 = this.tbl_templateSAP.DR["data_type"].ToString().Trim();
                num2 = Convert.ToInt16(this.tbl_templateSAP.DR["fixed"].ToString());
                if (num2 != 0)
                {
                    strArray[index] = this.tbl_templateSAP.DR["value"].ToString().Trim();
                }
                else
                {
                    if (this.module == "ZMM_UPLOAD")
                    {
                        if (str9.ToUpper() == "UOM")
                        {
                            WBTable table3 = new WBTable();
                            string[] textArray3 = new string[6];
                            textArray3[0] = "select ";
                            textArray3[1] = str3;
                            textArray3[2] = " from ";
                            textArray3[3] = str2;
                            textArray3[4] = " where ";
                            string[] textArray4 = new string[] { " And ", str4, "= '", aRow[str5].ToString(), "' " };
                            textArray3[5] = WBData.CompanyLocation(string.Concat(textArray4));
                            table3.OpenTable(str2, string.Concat(textArray3), WBData.conn);
                            str15 = table3.DT.Rows[0][str3].ToString();
                        }
                        if (str9.ToUpper() == "GI_BLDAT")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Report_Date" : "Report_Date";
                        }
                        if (str9.ToUpper() == "GI_BUDAT")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Report_Date" : "Report_Date";
                        }
                        if (str9.ToUpper() == "GI_GROSS")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Gross_Estate" : "Gross";
                        }
                        if (str9.ToUpper() == "GI_PLANT")
                        {
                            str2 = "wb_location";
                            str3 = (str14 == "I") ? "Plant_Supp" : "Plant_Rcv";
                        }
                        if (str9.ToUpper() == "GI_TARE")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Tare_Estate" : "Tare";
                        }
                        if (str9.ToUpper() == "GI_TIME_IN")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "" : "time2";
                        }
                        if (str9.ToUpper() == "GI_TIME_OUT")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "" : "time2";
                        }
                        if (str9.ToUpper() == "GR_BLDAT")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Report_Date" : "Report_Date";
                        }
                        if (str9.ToUpper() == "GR_BUDAT")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Report_Date" : "Report_Date";
                        }
                        if (str9.ToUpper() == "GR_GROSS")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Gross" : "Gross_Estate";
                        }
                        if (str9.ToUpper() == "GR_TARE")
                        {
                            str2 = "wb_transaction";
                            str3 = (str14 == "I") ? "Tare" : "Tare_Estate";
                        }
                        if (str9.ToUpper() == "GR_WERKS")
                        {
                            str2 = "wb_location";
                            str3 = (str14 == "I") ? "Plant_Rcv" : "Plant_Supp";
                        }
                        if (((str9.ToUpper() == "QTY_TP") && (str3 == "Net")) && (str15.ToUpper() != "KG"))
                        {
                            str2 = "wb_transDO";
                            str3 = "LOADING_QTY";
                        }
                        if ((((str9.ToUpper() == "QTY_KIRIM") || (str9.ToUpper() == "QTY_TP")) ? (str3.ToUpper() == "NET") : false) && (str15.ToUpper() != "KG"))
                        {
                            if (str14 == "I")
                            {
                                str2 = "wb_transDO";
                                str3 = "LOADING_QTY_OPW";
                            }
                            else
                            {
                                str2 = "wb_transDO";
                                str3 = "LOADING_QTY";
                            }
                        }
                        if (((str9.ToUpper() == "QTY_TERIMA") && (str3.ToUpper() == "NET_ESTATE")) && (str15.ToUpper() != "KG"))
                        {
                            if (str14 == "I")
                            {
                                str2 = "wb_transDO";
                                str3 = "LOADING_QTY";
                            }
                            else
                            {
                                str2 = "wb_transDO";
                                str3 = "LOADING_QTY_OPW";
                            }
                        }
                        if ((str9.ToUpper() == "EBELN") && (((str13 == "PO") || (str13 == "STO")) || (str13 == "STI")))
                        {
                            str2 = "wb_contract";
                            str3 = (str13 == "PO") ? "PO" : "STO";
                        }
                        else if ((str9.ToUpper() == "EBELP") && (((str13 == "PO") || (str13 == "STO")) || (str13 == "STI")))
                        {
                            str2 = "wb_contract";
                            str3 = (str13 == "PO") ? "PO_Item" : "STO_Item";
                        }
                    }
                    if (((str2.ToUpper() != "wb_transaction".ToUpper()) && ((str2 != "") && ((str2.ToUpper() != "wb_transactiond".ToUpper()) && ((str2.ToUpper() != "wb_transQC".ToUpper()) && (str2.ToUpper() != "wb_gatepass".ToUpper()))))) && (str2.ToUpper() != "wb_transbatch".ToUpper()))
                    {
                        try
                        {
                            string[] textArray5 = new string[] { " And ", str4, "= '", aRow[str5].ToString(), "' " };
                            table.OpenTable(str2, ("select * from " + str2 + " where ") + WBData.CompanyLocation(string.Concat(textArray5)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            strArray[index] = table.DR[str3].ToString().Trim();
                            if ((this.module == "ZMM_UPLOAD") && (str9.ToUpper() == "UPDTY"))
                            {
                                str13 = table.DR[str3].ToString().Trim();
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                        if (str9.ToUpper() == "Type".ToUpper())
                        {
                            if ((aRow["Nego"].ToString().Length > 0) || (((aRow["Group_Type"].ToString() != "0") && (aRow["Group_Type"].ToString() != "5")) && (aRow["STO"].ToString().Length == 0)))
                            {
                                strArray[index] = "A01";
                            }
                            if (aRow["STO"].ToString().Length > 0)
                            {
                                strArray[index] = "A03";
                            }
                            if ((aRow["STO"].ToString().Length == 0) && (aRow["Group_Type"].ToString() == "0"))
                            {
                                strArray[index] = "A02";
                            }
                        }
                        if (str9.ToUpper() == "Plasma".ToUpper())
                        {
                            strArray[index] = (((aRow["STO"].ToString().Length != 0) || ((aRow["Plasma"].ToString() == "Y") && (aRow["Plasma"].ToString() != null))) || ((aRow["Group_Type"].ToString() != "0") && (aRow["Group_Type"].ToString() != "1"))) ? ((((aRow["Plasma"].ToString() != "Y") || (aRow["STO"].ToString().Length != 0)) || ((aRow["Group_Type"].ToString() != "0") && (aRow["Group_Type"].ToString() != "1"))) ? "" : "2") : "1";
                        }
                        if (str9.ToUpper() == "Incoterm".ToUpper())
                        {
                            strArray[index] = (strArray[index] != "0") ? "LCO" : "FRC";
                        }
                        if (str2.ToUpper() == "wb_contract".ToUpper())
                        {
                            this.adopt = aRow["zadp"].ToString().Trim();
                            if ((str3 == "po_item") && (this.module == "ZMY_UPLOADFFB"))
                            {
                                string sqltext = "SELECT po from wb_contract where " + WBData.CompanyLocation(" And  Do_No = '" + aRow["Do_No"].ToString() + "' ");
                                table.OpenTable("wb_contract", sqltext, WBData.conn);
                                table.DR = table.DT.Rows[0];
                                if ((table.DR["po"] != null) && (table.DR["po"] != ""))
                                {
                                    strArray[index] = Convert.ToInt16(aRow["report_date"].ToString().Substring(3, 2)).ToString();
                                }
                                table.Dispose();
                            }
                        }
                        if ((str2.ToUpper() == "wb_upload_type".ToUpper()) && (this.module == "ZMY_UPLOADFFB"))
                        {
                            string sqltext = "SELECT * from wb_contract where " + WBData.CompanyLocation(" And  Do_No = '" + aRow["Do_No"].ToString() + "' ");
                            table.OpenTable("wb_contract", sqltext, WBData.conn);
                            table.DR = table.DT.Rows[0];
                            if ((table.DR["PO"].ToString().Trim() != "") && (table.DR["PO"].ToString().Trim() != null))
                            {
                                strArray[index] = "101";
                            }
                            else
                            {
                                table.OpenTable(str2, "SELECT * from " + str2 + " where " + WBData.CompanyLocation(" And Upload_Type = '" + this.module + "' "), WBData.conn);
                                table.DR = table.DT.Rows[0];
                                strArray[index] = table.DR["Movement_Type"].ToString().Trim();
                            }
                        }
                        if ((str2.ToUpper() == "wb_estate".ToUpper()) && (this.module == "ZMY_UPLOADFFB"))
                        {
                            string sqltext = "SELECT * FROM wb_contract where " + WBData.CompanyLocation(" AND do_no = '" + aRow["do_no"] + "'");
                            table.OpenTable("wb_contract", sqltext, WBData.conn);
                            table.DR = table.DT.Rows[0];
                            string str19 = table.DR["estate1_code"].ToString().Trim();
                            sqltext = "SELECT * FROM wb_estate where estate_code = '" + str19 + "'";
                            table.OpenTable("wb_estate", sqltext, WBData.conn);
                            table.DR = table.DT.Rows[0];
                            strArray[index] = table.DR[str3].ToString().Trim();
                        }
                        if ((this.module == "ZWB") && ((str9.ToUpper() == "WJLHGONI".ToUpper()) && ((strArray[index] == "0") && (Program.StrToDouble(aRow["TotalBunch"].ToString(), 0) > 0.0))))
                        {
                            strArray[index] = aRow["totalbunch"].ToString().Trim();
                        }
                        if ((str2.ToUpper() == "wb_commodity".ToUpper()) && ((str9.ToUpper() == "MATNR".ToUpper()) || (str9.ToUpper() == "UOM".ToUpper())))
                        {
                            try
                            {
                                WBTable table4 = new WBTable();
                                WBTable table5 = new WBTable();
                                string str20 = "";
                                string str21 = "";
                                table4.OpenTable("wb_TransDO", "select * from wb_TransDO where " + WBData.CompanyLocation(" AND ref = '" + str12 + "'"), WBData.conn);
                                table4.DR = table4.DT.Rows[0];
                                str20 = table4.DR["do_no"].ToString();
                                str21 = Program.StrToDouble(table4.DR["so_item_detail"].ToString(), 0).ToString();
                                string[] textArray6 = new string[9];
                                textArray6[0] = "select b.* from wb_contract_sapinformation a\r\n                                        inner join wb_commodity b on\r\n                                        a.coy = b.coy and a.location_code = b.location_code and a.comm_code = b.comm_code\r\n                                        where a.coy = '";
                                textArray6[1] = WBData.sCoyCode;
                                textArray6[2] = "' and a.location_code = '";
                                textArray6[3] = WBData.sLocCode;
                                textArray6[4] = "' AND do_no = '";
                                textArray6[5] = str20;
                                textArray6[6] = "' AND so_item = '";
                                textArray6[7] = str21;
                                textArray6[8] = "'";
                                table5.OpenTable("wb_commodity", string.Concat(textArray6), WBData.conn);
                                if (table5.DT.Rows.Count > 0)
                                {
                                    table5.DR = table5.DT.Rows[0];
                                    if (str9.ToUpper() == "MATNR".ToUpper())
                                    {
                                        strArray[index] = table5.DR["material"].ToString();
                                    }
                                    else if (str9.ToUpper() == "UOM".ToUpper())
                                    {
                                        strArray[index] = table5.DR["Unit"].ToString();
                                    }
                                }
                                table4.Dispose();
                                table5.Dispose();
                            }
                            catch
                            {
                                strArray[index] = "";
                            }
                        }
                    }
                    else if (str2.ToUpper() == "wb_transaction".ToUpper())
                    {
                        try
                        {
                            strArray[index] = (!((str3.ToUpper() == "Received".ToUpper()) | (str3.ToUpper() == "terima".ToUpper())) || (this.module != "ZWB")) ? aRow[str3].ToString().Trim() : Convert.ToString(Math.Abs((double) (Convert.ToDouble(strArray[index - 2]) - Convert.ToDouble(strArray[index - 1]))));
                            if (str3.ToUpper() == "Deleted".ToUpper())
                            {
                                strArray[index] = aRow[str3].ToString().Trim();
                                if (strArray[index] == "Y")
                                {
                                    strArray[index] = "1";
                                }
                            }
                            if (str3.ToUpper() == "IO".ToUpper())
                            {
                                strArray[index] = (strArray[index] != "I") ? "S" : "P";
                            }
                            if ((str9.ToUpper() == "ZDLV_QTY".ToUpper()) && (strArray[index] == "0"))
                            {
                                strArray[index] = aRow["received"].ToString().Trim();
                            }
                            if (str9.ToUpper() == "STORAGE_CODE".ToUpper())
                            {
                                this.aTable.OpenTable("wb_transaction", "select ref, Source_code from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str12 + "'"), WBData.conn);
                                if (this.aTable.DT.Rows.Count > 0)
                                {
                                    this.aTable.DR = this.aTable.DT.Rows[0];
                                    if (this.aTable.DR["source_code"].ToString().Trim() != "")
                                    {
                                        this.bTable.OpenTable("wb_source", "select * from wb_source where " + WBData.CompanyLocation(" and source_code = '" + this.aTable.DR["source_code"].ToString() + "'"), WBData.conn);
                                        if (this.bTable.DT.Rows.Count <= 0)
                                        {
                                            strArray[index] = this.aTable.DR["source_code"].ToString().Trim();
                                        }
                                        else
                                        {
                                            this.bTable.DR = this.bTable.DT.Rows[0];
                                            strArray[index] = this.bTable.DR["storage_loc"].ToString().Trim();
                                        }
                                    }
                                }
                            }
                            if ((str9.ToUpper() == "REF".ToUpper()) && (this.module.ToUpper().Trim() == "TRANSPORT".ToUpper().Trim()))
                            {
                                int num6 = WBData.sCoyCode.Length + WBData.sLocCode.Length;
                                int num7 = 7;
                                if (WBSetting.Field("Ref6").ToString() == "Y")
                                {
                                    num7 = 6;
                                }
                                strArray[index] = strArray[index].Substring(0, num6 + num7);
                            }
                            if ((str9 == "CLM_0011") && (this.module == "ZMY_UPLOADFFB"))
                            {
                                strArray[index] = !(((aRow["NOPW"].ToString().Trim() == "") || (aRow["NOPW"].ToString().Trim() == "N")) || ReferenceEquals(aRow["NOPW"].ToString().Trim(), null)) ? aRow[this.tbl_templateSAP.DR["field_wb"].ToString().Trim()].ToString().Trim() : aRow["Net_Estate"].ToString().Trim();
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                            strArray[index] = "";
                        }
                    }
                    else if (str2.ToUpper() == "wb_transactiond".ToUpper())
                    {
                        try
                        {
                            string kode = this.tbl_templateSAP.DR["field_wb"].ToString().Trim();
                            strArray[index] = this.isiDeduc(kode, aRow["ref"].ToString().Trim(), this.tbl_templateSAP.DR["key_field2"].ToString().Trim());
                        }
                        catch
                        {
                            strArray[index] = "0";
                        }
                    }
                    else
                    {
                        string str7;
                        if (str2.ToUpper() == "wb_transQC".ToUpper())
                        {
                            WBTable table6 = new WBTable();
                            str7 = aRow["ref"].ToString().Trim();
                            string[] textArray7 = new string[] { "select * from wb_transQC where ref = '", str7, "' and  QCode = '", str4, "'" };
                            table6.OpenTable("wb_transQC", string.Concat(textArray7), WBData.conn);
                            strArray[index] = (table6.DT.Rows.Count <= 0) ? "00.00" : table6.DT.Rows[0][str3].ToString().Trim();
                            table6.Dispose();
                        }
                        else if (str2.ToUpper() != "wb_transBatch".ToUpper())
                        {
                            try
                            {
                                strArray[index] = aRow[str3].ToString().Trim();
                            }
                            catch
                            {
                                strArray[index] = "";
                            }
                            if (str9 == "VALUE".ToUpper())
                            {
                                string str23 = Program.getFieldValue("wb_contract", "agen", "Do_No", aRow["Do_NO"].ToString());
                                strArray[index] = ((Program.getFieldValue("wb_contract", "tolling", "Do_No", aRow["Do_NO"].ToString()) != "Y") || (str23 != "Y")) ? "1" : "2";
                            }
                        }
                        else
                        {
                            strArray2[0] = fDgv.Rows[crRow].Cells["DELNOTE"].Value.ToString().Trim();
                            str7 = aRow["ref"].ToString().Trim();
                            int columnIndex = fDgv.Rows[0].Cells["DELNOTE"].ColumnIndex;
                            this.tmpBatch.OpenTable("wb_transBatch", "select * from wb_transBatch where ref like '" + str7 + "%'", WBData.conn);
                            if (this.tmpBatch.DT.Rows.Count > 0)
                            {
                                int num9 = this.tmpBatch.DT.Rows.Count;
                                DataGridViewRow row2 = fDgv.Rows[crRow];
                                int num10 = 0;
                                while (true)
                                {
                                    if (num10 >= num9)
                                    {
                                        break;
                                    }
                                    this.tmpBatch.DR = this.tmpBatch.DT.Rows[num10];
                                    int num11 = this.findInGrid(fDgv, str4, this.tmpBatch.DR["Ref"].ToString());
                                    if (num11 != -1)
                                    {
                                        fDgv.Rows[num11].Cells[str9].Value = this.tmpBatch.DR[str3];
                                    }
                                    num10++;
                                }
                            }
                            this.tmpBatch.Dispose();
                        }
                    }
                }
                break;
            }
            if (this.module != "GAIN")
            {
                goto TR_0054;
            }
            else if (str9.ToUpper() == "Quantity".ToUpper())
            {
                try
                {
                    strArray[index] = Convert.ToString((double) (Convert.ToDouble(aRow["Netto"].ToString()) - Convert.ToDouble(aRow["Net_Estate"].ToString())));
                }
                catch
                {
                    strArray[index] = "0";
                }
            }
            if (str9.ToUpper() == "Mov_Type".ToUpper())
            {
                try
                {
                    strArray[index] = Convert.ToString((double) (Convert.ToDouble(aRow["Netto"].ToString()) - Convert.ToDouble(aRow["Net_Estate"].ToString())));
                }
                catch
                {
                    strArray[index] = "0";
                }
                strArray[index] = (Convert.ToDouble(strArray[index]) < 0.0) ? "902" : "901";
            }
            if (str9.ToUpper() == "Upload".ToUpper())
            {
                try
                {
                    strArray[index] = Convert.ToString((double) (Convert.ToDouble(aRow["Netto"].ToString()) - Convert.ToDouble(aRow["Net_Estate"].ToString())));
                }
                catch
                {
                    strArray[index] = "0";
                }
                strArray[index] = (Convert.ToDouble(strArray[index]) == 0.0) ? "N" : "Y";
            }
            goto TR_0054;
        }

        private bool fillDGRowAfrica(DataRow aRow, DataGridView fDgv, int crRow)
        {
            string str = "N";
            WBTable table = new WBTable();
            int count = this.tbl_templateSAP.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            string str12 = "";
            str12 = aRow["ref"].ToString().Trim();
            str = aRow["Posted"].ToString().Trim();
            string[] strArray2 = new string[] { "" };
            int index = 0;
            while (true)
            {
                string str9;
                string str10;
                while (true)
                {
                    if (index >= count)
                    {
                        fDgv.Rows[crRow].Cells["posted"].Value = str;
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.locked = false;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                        }
                        return !this.locked;
                    }
                    this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[index];
                    string tablename = this.tbl_templateSAP.DR["table_name"].ToString().Trim();
                    str9 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                    string str4 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                    string str5 = this.tbl_templateSAP.DR["Key_Field2"].ToString().Trim();
                    string str3 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                    str10 = this.tbl_templateSAP.DR["data_type"].ToString().Trim();
                    int num2 = Convert.ToInt16(this.tbl_templateSAP.DR["fixed"].ToString());
                    if (num2 != 0)
                    {
                        strArray[index] = this.tbl_templateSAP.DR["value"].ToString().Trim();
                    }
                    else if (((tablename.ToUpper() != "wb_transaction".ToUpper()) && ((tablename != "") && ((tablename.ToUpper() != "wb_transactiond".ToUpper()) && ((tablename.ToUpper() != "wb_transQC".ToUpper()) && (tablename.ToUpper() != "wb_gatepass".ToUpper()))))) && (tablename.ToUpper() != "wb_transbatch".ToUpper()))
                    {
                        try
                        {
                            string[] textArray1 = new string[] { " And ", str4, "= '", aRow[str5].ToString(), "' " };
                            table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            strArray[index] = table.DR[str3].ToString().Trim();
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (tablename.ToUpper() != "wb_transaction".ToUpper())
                    {
                        if (tablename.ToUpper() == "wb_transactiond".ToUpper())
                        {
                            try
                            {
                                string kode = this.tbl_templateSAP.DR["field_wb"].ToString().Trim();
                                strArray[index] = this.isiDeduc(kode, aRow["ref"].ToString().Trim(), this.tbl_templateSAP.DR["key_field2"].ToString().Trim());
                            }
                            catch
                            {
                                strArray[index] = "0";
                            }
                        }
                        else if (tablename.ToUpper() != "wb_transQC".ToUpper())
                        {
                            try
                            {
                                strArray[index] = aRow[str3].ToString().Trim();
                            }
                            catch
                            {
                                strArray[index] = "";
                            }
                        }
                        else
                        {
                            WBTable table3 = new WBTable();
                            string str7 = aRow["ref"].ToString().Trim();
                            string[] textArray2 = new string[] { "select * from wb_transQC where ref = '", str7, "' and  QCode = '", str4, "'" };
                            table3.OpenTable("wb_transQC", string.Concat(textArray2), WBData.conn);
                            strArray[index] = (table3.DT.Rows.Count <= 0) ? "00.00" : table3.DT.Rows[0][str3].ToString().Trim();
                            table3.Dispose();
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = (!((str3.ToUpper() == "Received".ToUpper()) | (str3.ToUpper() == "terima".ToUpper())) || (this.module != "ZWB")) ? aRow[str3].ToString().Trim() : Convert.ToString(Math.Abs((double) (Convert.ToDouble(strArray[index - 2]) - Convert.ToDouble(strArray[index - 1]))));
                            if (str3.ToUpper() == "Deleted".ToUpper())
                            {
                                strArray[index] = aRow[str3].ToString().Trim();
                                if (strArray[index] == "Y")
                                {
                                    strArray[index] = "1";
                                }
                            }
                            if (str9.ToUpper() == "STORAGE_CODE".ToUpper())
                            {
                                this.aTable.OpenTable("wb_transaction", "select ref, Source_code from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str12 + "'"), WBData.conn);
                                if (this.aTable.DT.Rows.Count > 0)
                                {
                                    this.aTable.DR = this.aTable.DT.Rows[0];
                                    if (this.aTable.DR["source_code"].ToString().Trim() != "")
                                    {
                                        this.bTable.OpenTable("wb_source", "select * from wb_source where " + WBData.CompanyLocation(" and source_code = '" + this.aTable.DR["source_code"].ToString() + "'"), WBData.conn);
                                        if (this.bTable.DT.Rows.Count <= 0)
                                        {
                                            strArray[index] = this.aTable.DR["source_code"].ToString().Trim();
                                        }
                                        else
                                        {
                                            this.bTable.DR = this.bTable.DT.Rows[0];
                                            strArray[index] = this.bTable.DR["storage_loc"].ToString().Trim();
                                        }
                                    }
                                }
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                            strArray[index] = "";
                        }
                    }
                    break;
                }
                if (strArray[index] != "")
                {
                    if (str10.ToUpper() == "DATE".ToUpper())
                    {
                        DateTime time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("yyyyMMdd");
                        if (this.module == "UTP")
                        {
                            strArray[index] = time.ToString("dd.MM.yyyy");
                        }
                    }
                    else if (str10.ToUpper() != "TIME".ToUpper())
                    {
                        if (str10.ToUpper() == "Formula".ToUpper())
                        {
                            ExpressionVariabel owner = new ExpressionVariabel {
                                NET = Convert.ToDouble(strArray[index])
                            };
                            double num4 = Program.eval(this.tbl_templateSAP.DR["value"].ToString().Replace("VAL", strArray[index]), owner);
                            strArray[index] = (num4 >= 1.0) ? Convert.ToString(num4) : "";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm:ss");
                            if (strArray[index] == "00:00:00")
                            {
                                strArray[index] = "00:00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if (str10.ToUpper() != "Number".ToUpper())
                {
                    if (str10.ToUpper() == "Boolean".ToUpper())
                    {
                        strArray[index] = (strArray[index] != "Y") ? "" : "X";
                    }
                }
                else if (ReferenceEquals(strArray[index], null))
                {
                    strArray[index] = "0";
                }
                else if (strArray[index].Trim() == "")
                {
                    strArray[index] = "0";
                }
                if (str9 != "")
                {
                    fDgv.Rows[crRow].Cells[str9].Value = strArray[index];
                }
                index++;
            }
        }

        private bool fillDGRowAfricaPOM(DataRow aRow, DataGridView fDgv, int crRow)
        {
            string str = "N";
            string str11 = "N";
            WBTable table = new WBTable();
            int count = this.tbl_templateSAP.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            string str13 = "";
            str13 = aRow["ref"].ToString().Trim();
            str = aRow["Posted"].ToString().Trim();
            string[] strArray2 = new string[] { "" };
            int index = 0;
            while (true)
            {
                string str9;
                string str10;
                while (true)
                {
                    if (index >= count)
                    {
                        fDgv.Rows[crRow].Cells["posted"].Value = str;
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.locked = false;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                        }
                        return !this.locked;
                    }
                    this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[index];
                    string tablename = this.tbl_templateSAP.DR["table_name"].ToString().Trim();
                    str9 = this.tbl_templateSAP.DR["title_excel"].ToString().Trim();
                    string str4 = this.tbl_templateSAP.DR["Key_Field"].ToString().Trim();
                    string str5 = this.tbl_templateSAP.DR["Key_Field2"].ToString().Trim();
                    string str3 = this.tbl_templateSAP.DR["Field_WB"].ToString().Trim();
                    str10 = this.tbl_templateSAP.DR["data_type"].ToString().Trim();
                    int num2 = Convert.ToInt16(this.tbl_templateSAP.DR["fixed"].ToString());
                    if (num2 != 0)
                    {
                        strArray[index] = this.tbl_templateSAP.DR["value"].ToString().Trim();
                        if ((((this.sapDest == "MM") || ((this.sapDest == "ESTATE OWN") || (this.sapDest == "PLASMA OWN"))) || (this.sapDest == "DIV BLOCK")) && ((str11 == "Y") && (str9.ToUpper().Trim() == "ITEM_NO".ToUpper().Trim())))
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (((tablename.ToUpper() != "wb_transaction".ToUpper()) && ((tablename != "") && ((tablename.ToUpper() != "wb_transactiond".ToUpper()) && ((tablename.ToUpper() != "wb_transQC".ToUpper()) && (tablename.ToUpper() != "wb_gatepass".ToUpper()))))) && (tablename.ToUpper() != "wb_transbatch".ToUpper()))
                    {
                        try
                        {
                            string[] textArray1 = new string[] { " And ", str4, "= '", aRow[str5].ToString(), "' " };
                            table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            strArray[index] = table.DR[str3].ToString().Trim();
                            if ((((this.sapDest == "MM") || ((this.sapDest == "ESTATE OWN") || (this.sapDest == "PLASMA OWN"))) || (this.sapDest == "DIV BLOCK")) && (str9.ToUpper() == "CONTRACT".ToUpper()))
                            {
                                if (strArray[index].Trim() == "-".Trim())
                                {
                                    strArray[index] = "";
                                    str11 = "Y";
                                }
                                if (strArray[index].Trim() == "")
                                {
                                    str11 = "Y";
                                }
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (tablename.ToUpper() == "wb_transaction".ToUpper())
                    {
                        try
                        {
                            strArray[index] = (!((str3.ToUpper() == "Received".ToUpper()) | (str3.ToUpper() == "terima".ToUpper())) || (this.module != "ZWB")) ? aRow[str3].ToString().Trim() : Convert.ToString(Math.Abs((double) (Convert.ToDouble(strArray[index - 2]) - Convert.ToDouble(strArray[index - 1]))));
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (tablename.ToUpper() != "wb_transactiond".ToUpper())
                    {
                        try
                        {
                            strArray[index] = aRow[str3].ToString().Trim();
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else
                    {
                        try
                        {
                            string kode = this.tbl_templateSAP.DR["field_wb"].ToString().Trim();
                            strArray[index] = this.isiDeduc(kode, aRow["ref"].ToString().Trim(), this.tbl_templateSAP.DR["key_field2"].ToString().Trim());
                        }
                        catch
                        {
                            strArray[index] = "0";
                        }
                    }
                    break;
                }
                if (strArray[index] != "")
                {
                    if (str10.ToUpper() == "DATE".ToUpper())
                    {
                        DateTime time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("dd.MM.yyyy");
                    }
                    else if (str10.ToUpper() != "TIME".ToUpper())
                    {
                        if (str10.ToUpper() == "Formula".ToUpper())
                        {
                            ExpressionVariabel owner = new ExpressionVariabel {
                                NET = Convert.ToDouble(strArray[index])
                            };
                            double num4 = Program.eval(this.tbl_templateSAP.DR["value"].ToString().Replace("VAL", strArray[index]), owner);
                            strArray[index] = (num4 >= 1.0) ? Convert.ToString(num4) : "";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm");
                            if (strArray[index] == "00:00")
                            {
                                strArray[index] = "00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if (str10.ToUpper() != "Number".ToUpper())
                {
                    if (str10.ToUpper() == "Boolean".ToUpper())
                    {
                        strArray[index] = (strArray[index] != "Y") ? "" : "X";
                    }
                }
                else if (ReferenceEquals(strArray[index], null))
                {
                    strArray[index] = "0";
                }
                else if (strArray[index].Trim() == "")
                {
                    strArray[index] = "0";
                }
                if (str9 != "")
                {
                    fDgv.Rows[crRow].Cells[str9].Value = strArray[index];
                }
                index++;
            }
        }

        private int findInGrid(DataGridView xdgv, string kolom, string data)
        {
            int index = -1;
            foreach (DataGridViewRow row in (IEnumerable) xdgv.Rows)
            {
                try
                {
                    if (row.Cells[kolom].Value.ToString().Trim() == data.Trim())
                    {
                        index = row.Index;
                    }
                }
                catch
                {
                    index = -1;
                }
            }
            return index;
        }

        private void formatDG(DataGridView zDgv, DataTable zTable)
        {
            this.rCount = this.tbl_templateSAP.DT.Rows.Count;
            this.jlhkolom = this.rCount;
            zTable.Columns.Clear();
            zDgv.Columns.Clear();
            if (zDgv.Name.ToUpper().Trim() == "DGTRANS")
            {
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "Select",
                    HeaderText = "Select",
                    ReadOnly = true
                };
                zDgv.Columns.Add(dataGridViewColumn);
            }
            int num = 0;
            while (true)
            {
                DataGridViewTextBoxColumn column;
                if (num >= this.rCount)
                {
                    if (this.module != "ZPOM_SALES")
                    {
                        column = new DataGridViewTextBoxColumn {
                            Name = "Posted",
                            HeaderText = "Posted",
                            ReadOnly = true
                        };
                        zDgv.Columns.Add(column);
                    }
                    return;
                }
                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[num];
                column = new DataGridViewTextBoxColumn();
                DataColumn column3 = new DataColumn();
                bool flag2 = this.tbl_templateSAP.DR["Title_Excel"].ToString().Trim() != "";
                column.Name = !flag2 ? ("Column_" + num.ToString().Trim()) : this.tbl_templateSAP.DR["Title_Excel"].ToString().Trim();
                column.HeaderText = this.tbl_templateSAP.DR["Title_Excel"].ToString().Trim();
                column.ReadOnly = true;
                column3.ColumnName = column.Name;
                zDgv.Columns.Add(column);
                zTable.Columns.Add(column3);
                num++;
            }
        }

        private void FormUploadSAP_Load(object sender, EventArgs e)
        {
            this.f_load();
            this.Text = this.Text + this.sapIDSYS;
        }

        private void FormUploadSAP_MouseHover(object sender, EventArgs e)
        {
        }

        private void getAllTransactionType()
        {
            this.sqlText = " select * from wb_transaction_type where " + WBData.CompanyLocation(" AND (deleted is null or deleted <> 'Y') ");
            this.tbl_transactionType.OpenTable("wb_transaction_type", this.sqlText, WBData.conn);
        }

        private void getTemplate(string ztype)
        {
            string[] textArray1 = new string[] { " AND modul = '", this.module, "'  and type ='", ztype, "' " };
            this.sqlText = "Select * from wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray1)) + " order by column_Numbering";
            this.tbl_templateSAP.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.mnUpd = new ToolStripMenuItem();
            this.mnuExport = new ToolStripMenuItem();
            this.excelToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.prgBar = new ProgressBar();
            this.labelTotalRecord3 = new Label();
            this.labelTotalRecord2 = new Label();
            this.labelTotalRecord1 = new Label();
            this.buttonSelectAll = new Button();
            this.buttonUnSelect = new Button();
            this.panel2 = new Panel();
            this.panel1 = new Panel();
            this.dgTransFlag = new DataGridView();
            this.dgTrans = new DataGridView();
            this.timer = new Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dgTransFlag).BeginInit();
            ((ISupportInitialize) this.dgTrans).BeginInit();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.mnUpd, this.mnuExport, this.excelToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3bc, 0x18);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.mnUpd.Name = "mnUpd";
            this.mnUpd.Size = new Size(0x39, 20);
            this.mnUpd.Text = "Upload";
            this.mnUpd.Click += new EventHandler(this.uploadToolStripMenuItem_Click);
            this.mnuExport.Name = "mnuExport";
            this.mnuExport.Size = new Size(0x34, 20);
            this.mnuExport.Text = "Export";
            this.mnuExport.Click += new EventHandler(this.mnuExport_Click);
            this.excelToolStripMenuItem.Name = "excelToolStripMenuItem";
            this.excelToolStripMenuItem.Size = new Size(0x2d, 20);
            this.excelToolStripMenuItem.Text = "Excel";
            this.excelToolStripMenuItem.Click += new EventHandler(this.excelToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.prgBar.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.prgBar.Location = new Point(0x2dd, 0x1c);
            this.prgBar.Name = "prgBar";
            this.prgBar.Size = new Size(0xd0, 14);
            this.prgBar.TabIndex = 7;
            this.labelTotalRecord3.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord3.AutoSize = true;
            this.labelTotalRecord3.Location = new Point(0x37e, 12);
            this.labelTotalRecord3.Name = "labelTotalRecord3";
            this.labelTotalRecord3.Size = new Size(0x2f, 13);
            this.labelTotalRecord3.TabIndex = 13;
            this.labelTotalRecord3.Text = "Records";
            this.labelTotalRecord2.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord2.AutoSize = true;
            this.labelTotalRecord2.Location = new Point(0x331, 12);
            this.labelTotalRecord2.Name = "labelTotalRecord2";
            this.labelTotalRecord2.Size = new Size(13, 13);
            this.labelTotalRecord2.TabIndex = 12;
            this.labelTotalRecord2.Text = "0";
            this.labelTotalRecord1.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord1.AutoSize = true;
            this.labelTotalRecord1.Location = new Point(730, 12);
            this.labelTotalRecord1.Name = "labelTotalRecord1";
            this.labelTotalRecord1.Size = new Size(0x51, 13);
            this.labelTotalRecord1.TabIndex = 11;
            this.labelTotalRecord1.Text = "Total Record = ";
            this.buttonSelectAll.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonSelectAll.Location = new Point(14, 4);
            this.buttonSelectAll.Name = "buttonSelectAll";
            this.buttonSelectAll.Size = new Size(0x4b, 0x1d);
            this.buttonSelectAll.TabIndex = 14;
            this.buttonSelectAll.Text = "Select All";
            this.buttonSelectAll.UseVisualStyleBackColor = true;
            this.buttonSelectAll.Click += new EventHandler(this.buttonSelectAll_Click);
            this.buttonUnSelect.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonUnSelect.Location = new Point(0x6a, 4);
            this.buttonUnSelect.Name = "buttonUnSelect";
            this.buttonUnSelect.Size = new Size(0x4b, 0x1d);
            this.buttonUnSelect.TabIndex = 15;
            this.buttonUnSelect.Text = "UnSelect All";
            this.buttonUnSelect.UseVisualStyleBackColor = true;
            this.buttonUnSelect.Click += new EventHandler(this.buttonUnSelect_Click);
            this.panel2.Controls.Add(this.buttonUnSelect);
            this.panel2.Controls.Add(this.labelTotalRecord3);
            this.panel2.Controls.Add(this.buttonSelectAll);
            this.panel2.Controls.Add(this.labelTotalRecord2);
            this.panel2.Controls.Add(this.prgBar);
            this.panel2.Controls.Add(this.labelTotalRecord1);
            this.panel2.Dock = DockStyle.Top;
            this.panel2.Location = new Point(0, 0x18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x3bc, 0x2e);
            this.panel2.TabIndex = 0x10;
            this.panel1.Controls.Add(this.dgTransFlag);
            this.panel1.Controls.Add(this.dgTrans);
            this.panel1.Dock = DockStyle.Fill;
            this.panel1.Location = new Point(0, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x3bc, 0x195);
            this.panel1.TabIndex = 0x11;
            this.dgTransFlag.AllowUserToAddRows = false;
            this.dgTransFlag.AllowUserToDeleteRows = false;
            this.dgTransFlag.AllowUserToResizeColumns = false;
            this.dgTransFlag.AllowUserToResizeRows = false;
            this.dgTransFlag.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransFlag.Location = new Point(14, 220);
            this.dgTransFlag.Name = "dgTransFlag";
            this.dgTransFlag.Size = new Size(0x153, 0x7c);
            this.dgTransFlag.TabIndex = 0x13;
            this.dgTransFlag.Visible = false;
            this.dgTrans.AllowUserToAddRows = false;
            this.dgTrans.AllowUserToDeleteRows = false;
            this.dgTrans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgTrans.ColumnHeadersDefaultCellStyle = style;
            this.dgTrans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgTrans.DefaultCellStyle = style2;
            this.dgTrans.Dock = DockStyle.Fill;
            this.dgTrans.Location = new Point(0, 0);
            this.dgTrans.MultiSelect = false;
            this.dgTrans.Name = "dgTrans";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgTrans.RowHeadersDefaultCellStyle = style3;
            this.dgTrans.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgTrans.Size = new Size(0x3bc, 0x195);
            this.dgTrans.TabIndex = 7;
            this.dgTrans.CellClick += new DataGridViewCellEventHandler(this.dgTrans_CellClick);
            this.dgTrans.CellContentClick += new DataGridViewCellEventHandler(this.dgTrans_CellContentClick);
            this.dgTrans.CellDoubleClick += new DataGridViewCellEventHandler(this.dgTrans_CellDoubleClick);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3bc, 0x1db);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.menuStrip1);
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormUploadSAP";
            base.ShowIcon = false;
            this.Text = "Upload ";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.FormUploadSAP_Load);
            base.MouseHover += new EventHandler(this.FormUploadSAP_MouseHover);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((ISupportInitialize) this.dgTransFlag).EndInit();
            ((ISupportInitialize) this.dgTrans).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void initTable()
        {
            this.date1 = Program.DTOC(this.dateFrom) + " 00:00:00";
            this.date2 = Program.DTOC(this.dateTo) + " 00:00:00";
            if (this.sapDest.Trim() != "")
            {
                this.module = this.sapDest;
                this.type = "1";
                if ((this.module == "TRANSPORT") && (this.tipeTrans == "O"))
                {
                    this.type = "2";
                }
            }
            this.getTemplate(this.type);
            this.getAllTransactionType();
            this.formatDG(this.dgTrans, this.tblTrans);
            this.showPosted = false;
            if ((WBSetting.region == "0") || (WBSetting.region == "2"))
            {
                this.fillDG(this.showPosted, this.dgTrans, this.tblTrans);
            }
            else if ((WBSetting.region == "1") && (WBSetting.locType == "0"))
            {
                this.fillDGAfrica(this.showPosted, this.dgTrans, this.tblTrans);
            }
            else if ((WBSetting.region == "1") && (WBSetting.locType == "1"))
            {
                if (this.module == "DIV BLOCK")
                {
                    this.fillDGAfricaDivBlock(this.showPosted, this.dgTrans, this.tblTrans);
                }
                else
                {
                    this.fillDGAfricaPOM(this.showPosted, this.dgTrans, this.tblTrans);
                }
            }
            this.setReturnTable();
            this.prgBar.Value = 0;
        }

        public void initTransFlag()
        {
            this.dgTransFlag.Columns.Clear();
            this.dgTransFlag.Rows.Clear();
            DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "ref",
                HeaderText = "REF"
            };
            this.dgTransFlag.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Adopt",
                HeaderText = "Adopt"
            };
            this.dgTransFlag.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
        }

        private string isiDeduc(string kode, string kdRef, string kValue)
        {
            string str = "0";
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "select * from wb_transactiond where ref ='", kdRef, "'  and code ='", kode, "'" };
            this.sqlText = string.Concat(textArray1);
            table.OpenTable("wb_transactiond", this.sqlText, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DR = table.DT.Rows[0];
                str = ((kValue != null) && (kValue != "")) ? table.DR[kValue].ToString().Trim() : table.DR["kgDeduc"].ToString().Trim();
            }
            table.Dispose();
            return str;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void mnuExport_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                if (string.IsNullOrEmpty(WBSetting.CoySAP))
                {
                    MessageBox.Show(this.sapIDSYS + " Location Code cannot be empty! Please contact BPM to resolve this problem.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    bool flag = true;
                    int num = 0;
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgTrans.Rows.Count)
                        {
                            if (flag)
                            {
                                MessageBox.Show("Please select at least 1 transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                            else
                            {
                                Cursor.Current = Cursors.WaitCursor;
                                string str = "";
                                str = (this.dateFrom.ToString("dd/MM/yyyy") != this.dateTo.ToString("dd/MM/yyyy")) ? (this.dateFrom.ToString("dd/MM/yyyy") + " - " + this.dateTo.ToString("dd/MM/yyyy")) : this.dateFrom.ToString("dd/MM/yyyy");
                                object[] objArray1 = new object[] { "WBNET_", WBSetting.CoySAP, "_", this.sapDest, "_", DateTime.Now.ToString("ddMMyyyy_HHmmss"), "_", num };
                                Program.export2Excel(this.dgTrans, this.sapDest, string.Concat(objArray1), true);
                                if (Program.excelSuccess)
                                {
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_templateSAP", "SELECT title_excel FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" AND modul = '" + this.sapDest + "' AND field_wb = 'ref' AND table_name = 'wb_transaction'"), WBData.conn);
                                    string str2 = table.DT.Rows[0]["title_excel"].ToString();
                                    table.Dispose();
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= this.dgTrans.Rows.Count)
                                        {
                                            Cursor.Current = Cursors.Default;
                                            object[] objArray2 = new object[] { "Data has been exported successfully!\n\nTotal data: ", num, " transactions\nReport date: ", str };
                                            MessageBox.Show(string.Concat(objArray2), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.f_load();
                                            break;
                                        }
                                        if ((this.dgTrans.Rows[num3].Cells[0].Value != null) && (this.dgTrans.Rows[num3].Cells[0].Value.ToString() == "True"))
                                        {
                                            string str3 = this.dgTrans.Rows[num3].Cells[str2].Value.ToString();
                                            WBTable table2 = new WBTable();
                                            table2.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + str3 + "'"), WBData.conn);
                                            table2.DR = table2.DT.Rows[0];
                                            this.logKey = table2.DR["uniq"].ToString();
                                            table2.DR.BeginEdit();
                                            table2.DR["posted"] = "Y";
                                            table2.DR["sync_return"] = "";
                                            table2.DR["lastUpload"] = DateTime.Now;
                                            table2.DR["checksum"] = table2.Checksum(table2.DR);
                                            table2.DR.EndEdit();
                                            table2.Save();
                                            table2.Dispose();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Extract transaction to Excel" };
                                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                        }
                                        num3++;
                                    }
                                }
                            }
                            break;
                        }
                        if ((this.dgTrans.Rows[num2].Cells[0].Value != null) && (this.dgTrans.Rows[num2].Cells[0].Value.ToString() == "True"))
                        {
                            flag = false;
                            num++;
                        }
                        num2++;
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("An error has occurred (" + exception.GetType().Name + ").", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void RefreshTable(string mulesoftID)
        {
            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                aTable = this.retTable
            };
            if (this.auto != 'Y')
            {
                return2.ShowDialog();
            }
            WBTable table = new WBTable();
            bool flag = false;
            int num = 0;
            while (true)
            {
                if (num >= this.retTable.Rows.Count)
                {
                    table.Dispose();
                    this.tblTrans.Dispose();
                    this.retTable.Dispose();
                    return2.Dispose();
                    if (flag)
                    {
                        this.f_load();
                    }
                    return;
                }
                DataRow row = this.retTable.Rows[num];
                string str = row[0].ToString().Trim();
                string str2 = "Y";
                if (this.module == "ZPOM")
                {
                    str2 = "S";
                }
                if (row[1].ToString() == str2)
                {
                    flag = true;
                    table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                    table.DR = table.DT.Rows[0];
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["posted"] = "Y";
                    table.DR["sync_return"] = "";
                    table.DR["lastUpload"] = DateTime.Now;
                    table.DR["lastMulesoftReturnID"] = mulesoftID;
                    table.DR["checksum"] = table.Checksum_Main(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                else
                {
                    flag = true;
                    table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                    table.DR = table.DT.Rows[0];
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["posted"] = "N";
                    table.DR["sync_return"] = row[2].ToString();
                    table.DR["lastUpload"] = DateTime.Now;
                    table.DR["lastMulesoftReturnID"] = mulesoftID;
                    table.DR["checksum"] = table.Checksum_Main(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                num++;
            }
        }

        public void selectAll()
        {
            if (this.dgTrans.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
        }

        private void setReturnTable()
        {
            this.retTable.Columns.Clear();
            DataColumn column = new DataColumn {
                ColumnName = "Ref1"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Stts2"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Rmrk3"
            };
            this.retTable.Columns.Add(column);
            column.Dispose();
        }

        private void uploadDivBlock()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_DIVIDE_BLOCK";
                this.sapTable = "TEMP_UPL";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPLOAD");
                            this.retValue[0] = table3.GetString("XBLNR");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadEstateOwn()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_TO_OWN_POM";
                this.sapTable = "UPLOAD_DATA";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPLOAD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadGPOGST()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_GST_GPO";
                this.sapTable = "UPL_ITAB";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RET_ITAB");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadMM()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_TO_ZUG_UPLOADFFB";
                this.sapTable = "TMP_UPLOAD";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPLOAD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadPlasmaOwn()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_PLASMA_TO_OWN_POM";
                this.sapTable = "UPLOAD_TAB4";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPLOAD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadSAP()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                WBSetting.OpenSetting();
                if (WBSetting.activeMulesoftIntegration)
                {
                    this.dgvToTable(this.dgTrans, this.tblTrans);
                    if (this.module == "UPLOAD_STO_PO")
                    {
                        this.UploadSTOPOMulesoft();
                    }
                    else if (this.module == "ZPOM")
                    {
                        this.ZPOMMulesoft();
                    }
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    WBSetting.OpenSetting();
                    RfcConfigParameters parameters = new RfcConfigParameters();
                    parameters = new RfcConfigParameters();
                    parameters.Add("NAME", "TEST_SAP");
                    parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                    parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                    parameters.Add("SYSNR", "00");
                    parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                    parameters.Add("IDLE_TIMEOUT", "10");
                    parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                    parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                    parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                    parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                    RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                    RfcRepository repository = destination.Repository;
                    if (this.module == "ZPOM")
                    {
                        this.sapFunc = "ZWB_UPLOAD_GRN";
                        this.sapTable = "GRPOM";
                        this.sapType = this.type;
                    }
                    if (this.module == "ZMM_UPLOAD")
                    {
                        this.sapFunc = "ZWB_MM_UPLOAD";
                        this.sapReturn = "RETURN_UPD";
                        this.sapTable = "TABUPD";
                        this.sapType = this.type;
                    }
                    if (this.module == "UPLOAD_STO_PO")
                    {
                        this.sapFunc = "ZRFC_UPLOAD_STO_PO";
                        this.sapReturn = "RETURN_UPD";
                        this.sapTable = "I_RECORD";
                        this.sapType = this.type;
                    }
                    IRfcFunction function = repository.CreateFunction(this.sapFunc);
                    IRfcTable table = function.GetTable(this.sapTable);
                    this.dgvToTable(this.dgTrans, this.tblTrans);
                    this.prgBar.Maximum = this.tblTrans.Rows.Count;
                    this.prgBar.Value = 0;
                    table.Append();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.tblTrans.Rows.Count)
                        {
                            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                aTable = this.retTable
                            };
                            if (this.auto != 'Y')
                            {
                                return2.ShowDialog();
                            }
                            WBTable table2 = new WBTable();
                            bool flag4 = false;
                            int num4 = 0;
                            while (true)
                            {
                                if (num4 >= this.retTable.Rows.Count)
                                {
                                    table2.Dispose();
                                    this.tblTrans.Dispose();
                                    this.retTable.Dispose();
                                    return2.Dispose();
                                    if (flag4)
                                    {
                                        this.f_load();
                                    }
                                    break;
                                }
                                DataRow row2 = this.retTable.Rows[num4];
                                string str = row2[0].ToString().Trim();
                                string str2 = "Y";
                                if (this.module == "ZPOM")
                                {
                                    str2 = "S";
                                }
                                if (this.module == "ZMM_UPLOAD")
                                {
                                    str2 = "0";
                                }
                                if (row2[1].ToString() == str2)
                                {
                                    flag4 = true;
                                    table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                    table2.DR = table2.DT.Rows[0];
                                    this.logKey = table2.DR["uniq"].ToString();
                                    table2.DR.BeginEdit();
                                    table2.DR["posted"] = "Y";
                                    table2.DR["sync_return"] = "";
                                    table2.DR["lastUpload"] = DateTime.Now;
                                    table2.DR["checksum"] = table2.Checksum_Main(table2.DR);
                                    table2.DR.EndEdit();
                                    table2.Save();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                }
                                else
                                {
                                    flag4 = true;
                                    table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                    table2.DR = table2.DT.Rows[0];
                                    this.logKey = table2.DR["uniq"].ToString();
                                    table2.DR.BeginEdit();
                                    table2.DR["posted"] = "N";
                                    table2.DR["sync_return"] = row2[2].ToString();
                                    table2.DR["lastUpload"] = DateTime.Now;
                                    table2.DR["checksum"] = table2.Checksum_Main(table2.DR);
                                    table2.DR.EndEdit();
                                    table2.Save();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                }
                                num4++;
                            }
                            break;
                        }
                        DataRow row = this.tblTrans.Rows[num2];
                        index = 0;
                        while (true)
                        {
                            if (index >= this.jlhkolom)
                            {
                                if (this.module == "ZPOM")
                                {
                                    function.SetValue("TIPE", row[this.jlhkolom - 1].ToString());
                                    table.SetValue("STATUS", "");
                                    table.SetValue("REMARK", "");
                                }
                                function.Invoke(destination);
                                if (this.module == "ZPOM")
                                {
                                    this.retValue[0] = "";
                                    this.retValue[1] = "";
                                    this.retValue[2] = "";
                                    this.retValue[0] = table.GetString("DEL_NOTE");
                                    this.retValue[1] = table.GetString("STATUS");
                                    this.retValue[2] = table.GetString("REMARK");
                                    this.retTable.Rows.Add(this.retValue);
                                    if (this.retValue[1] == "S")
                                    {
                                    }
                                }
                                else if (this.module == "ZMM_UPLOAD")
                                {
                                    IRfcTable table3 = function.GetTable(this.sapReturn);
                                    this.retValue[0] = table3.GetString("DELNOTE");
                                    this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                                    this.retValue[2] = table3.GetString("MESSAGE");
                                    this.retTable.Rows.Add(this.retValue);
                                }
                                else if (this.module == "UPLOAD_STO_PO")
                                {
                                    IRfcTable table4 = function.GetTable(this.sapReturn);
                                    this.retValue[0] = table4.GetString("DELNOTE");
                                    this.retValue[1] = table4.GetString("SUBRC").ToString().Trim();
                                    this.retValue[2] = table4.GetString("MESSAGE");
                                    this.retTable.Rows.Add(this.retValue);
                                }
                                if (this.uploadType != "")
                                {
                                    IRfcTable table5 = function.GetTable(this.sapReturn);
                                    this.retValue[0] = table5.GetString("DELNOTE");
                                    this.retValue[1] = table5.GetString("SUBRC").ToString().Trim();
                                    this.retValue[2] = table5.GetString("MESSAGE");
                                    this.retTable.Rows.Add(this.retValue);
                                }
                                this.prgBar.Value++;
                                num2++;
                                break;
                            }
                            string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index + 1].HeaderText };
                            this.errValue = string.Concat(textArray1);
                            if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                            {
                                table.SetValue(index, row[index].ToString().Trim());
                            }
                            else
                            {
                                table.SetValue(index, "".Trim());
                            }
                            index++;
                        }
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void UploadSTOPOMulesoft()
        {
            int count = this.tblTrans.Rows.Count;
            Cursor.Current = Cursors.WaitCursor;
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                auto = (this.auto == 'Y') ? "Y" : "N"
            };
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            int num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    integrator.prepareTable();
                    integrator.addTable(sentTable, "I_RECORD");
                    string url = integrator.getURL("ZRFC_UPLOAD_STO_PO");
                    if (url != "")
                    {
                        bool err = false;
                        string[] resultHeaderName = new string[] { "ERRORS", "RETURN_UPD", "MESSAGE_ID" };
                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                        if (!err)
                        {
                            if (dictionary["ERRORS"].Count > 0)
                            {
                                if (this.auto != 'Y')
                                {
                                    MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                string mulesoftID = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                foreach (Dictionary<string, string> dictionary3 in dictionary["RETURN_UPD"])
                                {
                                    object[] values = new object[] { dictionary3["DELNOTE"].ToString(), dictionary3["SUBRC"].ToString(), dictionary3["MESSAGE"].ToString() };
                                    this.retTable.Rows.Add(values);
                                }
                                this.RefreshTable(mulesoftID);
                            }
                        }
                    }
                    return;
                }
                this.prgBar.Refresh();
                Dictionary<string, string> item = new Dictionary<string, string>();
                int index = 0;
                while (true)
                {
                    if (index >= this.tblTrans.Columns.Count)
                    {
                        sentTable.Add(item);
                        this.prgBar.Value = num2;
                        num2++;
                        break;
                    }
                    item.Add(this.tblTrans.Columns[index].ToString(), this.tblTrans.Rows[num2].ItemArray[index].ToString());
                    index++;
                }
            }
        }

        private void uploadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.btnUpload();
        }

        private void uploadUGI()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_UGI";
                this.sapTable = "BULUPD_UGI";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadUSTUPO()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_UST_UPO";
                this.sapTable = "BULUPD";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadUTP()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_TO_ZSAP_MM_UPLOADTP";
                this.sapTable = "ITAB_TP";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    table.Clear();
                    table.Append();
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RETURN_UPLOAD");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadZMMSTM()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_STM";
                this.sapTable = "UPL_ITAB";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RET_ITAB");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadZMMSTM_RCV()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_STM_RCV";
                this.sapTable = "UPL_ITAB";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted_opw"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload other party weight to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted_opw"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload other party weight to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RET_ITAB");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void uploadZMYFFB()
        {
            int index = 0;
            this.retTable.Rows.Clear();
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                this.sapFunc = "ZRFC_UPLOAD_FFB_MY";
                this.sapTable = "UPL_ITAB";
                this.sapType = this.type;
                IRfcFunction function = repository.CreateFunction(this.sapFunc);
                IRfcTable table = function.GetTable(this.sapTable);
                this.dgvToTable(this.dgTrans, this.tblTrans);
                this.prgBar.Maximum = this.tblTrans.Rows.Count;
                this.prgBar.Value = 0;
                table.Append();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTrans.Rows.Count)
                    {
                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                            aTable = this.retTable
                        };
                        if (this.auto != 'Y')
                        {
                            return2.ShowDialog();
                        }
                        WBTable table2 = new WBTable();
                        bool flag = false;
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.retTable.Rows.Count)
                            {
                                table2.Dispose();
                                this.tblTrans.Dispose();
                                this.retTable.Dispose();
                                return2.Dispose();
                                if (flag)
                                {
                                    this.f_load();
                                }
                                break;
                            }
                            DataRow row2 = this.retTable.Rows[num4];
                            string str = row2[0].ToString().Trim();
                            if (row2[1].ToString() == "0")
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "Y";
                                table2.DR["sync_return"] = "";
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            else
                            {
                                flag = true;
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                table2.DR = table2.DT.Rows[0];
                                this.logKey = table2.DR["uniq"].ToString();
                                table2.DR.BeginEdit();
                                table2.DR["posted"] = "N";
                                table2.DR["sync_return"] = row2[2].ToString();
                                table2.DR["lastUpload"] = DateTime.Now;
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                                table2.DR.EndEdit();
                                table2.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                            }
                            num4++;
                        }
                        break;
                    }
                    DataRow row = this.tblTrans.Rows[num2];
                    index = 0;
                    while (true)
                    {
                        if (index >= this.jlhkolom)
                        {
                            function.Invoke(destination);
                            IRfcTable table3 = function.GetTable("RET_ITAB");
                            this.retValue[0] = table3.GetString("DELNOTE");
                            this.retValue[1] = table3.GetString("SUBRC").ToString().Trim();
                            this.retValue[2] = table3.GetString("MESSAGE");
                            this.retTable.Rows.Add(this.retValue);
                            this.prgBar.Value++;
                            num2++;
                            break;
                        }
                        string[] textArray1 = new string[] { index.ToString(), " : ", row[index].ToString(), " : ", this.dgTrans.Columns[index].HeaderText };
                        this.errValue = string.Concat(textArray1);
                        if ((row[index].ToString().Trim() != "") & (row[index].ToString().Trim() != null))
                        {
                            table.SetValue(index, row[index].ToString().Trim());
                        }
                        else
                        {
                            table.SetValue(index, "".Trim());
                        }
                        index++;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcCommunicationException exception2)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (RfcBaseException exception3)
            {
                if (this.auto != 'Y')
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch (Exception exception4)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void ViewTimbang()
        {
            try
            {
                WBTable table = new WBTable();
                string str4 = "REF";
                string zValue = this.dgTrans.CurrentRow.Cells[str4].Value.ToString().Trim();
                table.OpenTable("wb_transaction", "select * from wb_transaction where uniq ='" + Program.getFieldValue("wb_transaction", "uniq", "Ref", zValue) + "'", WBData.conn);
                FormTransaction transaction = new FormTransaction {
                    tblTrans = table,
                    tambahRecord = false,
                    pMode = "VIEW"
                };
                transaction.ShowDialog();
                Cursor.Current = Cursors.Default;
                transaction.Dispose();
                table.Dispose();
            }
            catch
            {
            }
        }

        private void ZMM_UPLOADSTM_RCVMulesoft()
        {
            this.retTable.Rows.Clear();
            this.dgvToTable(this.dgTrans, this.tblTrans);
            int count = this.tblTrans.Rows.Count;
            Cursor.Current = Cursors.WaitCursor;
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                auto = (this.auto == 'Y') ? "Y" : "N"
            };
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            int num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    integrator.prepareTable();
                    integrator.addTable(sentTable, "UPL_ITAB");
                    string url = integrator.getURL("ZRFC_UPLOAD_STM_RCV");
                    if (url != "")
                    {
                        bool err = false;
                        string[] resultHeaderName = new string[] { "ERRORS", "RET_ITAB", "MESSAGE_ID" };
                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                        if (!err)
                        {
                            if (dictionary["ERRORS"].Count > 0)
                            {
                                if (this.auto != 'Y')
                                {
                                    MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                string str2 = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                foreach (Dictionary<string, string> dictionary3 in dictionary["RET_ITAB"])
                                {
                                    object[] values = new object[] { dictionary3["DELNOTE"].ToString(), dictionary3["SUBRC"].ToString(), dictionary3["MESSAGE"].ToString() };
                                    this.retTable.Rows.Add(values);
                                }
                                WBTable table = new WBTable();
                                bool flag7 = false;
                                int num4 = 0;
                                while (true)
                                {
                                    if (num4 >= this.retTable.Rows.Count)
                                    {
                                        table.Dispose();
                                        this.tblTrans.Dispose();
                                        this.retTable.Dispose();
                                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                            aTable = this.retTable
                                        };
                                        if (this.auto != 'Y')
                                        {
                                            return2.ShowDialog();
                                        }
                                        return2.Dispose();
                                        if (flag7)
                                        {
                                            this.f_load();
                                        }
                                        break;
                                    }
                                    DataRow row = this.retTable.Rows[num4];
                                    string str3 = row[0].ToString().Trim();
                                    if (row[1].ToString() == "0")
                                    {
                                        flag7 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "Y";
                                        table.DR["sync_return"] = "";
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = str2;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    else
                                    {
                                        flag7 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "N";
                                        table.DR["sync_return"] = row[2].ToString();
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = str2;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    num4++;
                                }
                            }
                        }
                    }
                    return;
                }
                this.prgBar.Refresh();
                Dictionary<string, string> item = new Dictionary<string, string>();
                int index = 0;
                while (true)
                {
                    if (index >= this.tblTrans.Columns.Count)
                    {
                        sentTable.Add(item);
                        this.prgBar.Value = num2;
                        num2++;
                        break;
                    }
                    item.Add(this.tblTrans.Columns[index].ToString(), this.tblTrans.Rows[num2].ItemArray[index].ToString());
                    index++;
                }
            }
        }

        private void ZMM_UPLOADSTMMulesoft()
        {
            this.retTable.Rows.Clear();
            this.dgvToTable(this.dgTrans, this.tblTrans);
            int count = this.tblTrans.Rows.Count;
            Cursor.Current = Cursors.WaitCursor;
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                auto = (this.auto == 'Y') ? "Y" : "N"
            };
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            int num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    integrator.prepareTable();
                    integrator.addTable(sentTable, "UPL_ITAB");
                    string url = integrator.getURL("ZRFC_UPLOAD_STM");
                    if (url != "")
                    {
                        bool err = false;
                        string[] resultHeaderName = new string[] { "ERRORS", "RET_ITAB", "MESSAGE_ID" };
                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                        if (!err)
                        {
                            if (dictionary["ERRORS"].Count > 0)
                            {
                                if (this.auto != 'Y')
                                {
                                    MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                string str2 = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                foreach (Dictionary<string, string> dictionary3 in dictionary["RET_ITAB"])
                                {
                                    object[] values = new object[] { dictionary3["DELNOTE"].ToString(), dictionary3["SUBRC"].ToString(), dictionary3["MESSAGE"].ToString() };
                                    this.retTable.Rows.Add(values);
                                }
                                WBTable table = new WBTable();
                                bool flag7 = false;
                                int num4 = 0;
                                while (true)
                                {
                                    if (num4 >= this.retTable.Rows.Count)
                                    {
                                        table.Dispose();
                                        this.tblTrans.Dispose();
                                        this.retTable.Dispose();
                                        FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                            aTable = this.retTable
                                        };
                                        if (this.auto != 'Y')
                                        {
                                            return2.ShowDialog();
                                        }
                                        return2.Dispose();
                                        if (flag7)
                                        {
                                            this.f_load();
                                        }
                                        break;
                                    }
                                    DataRow row = this.retTable.Rows[num4];
                                    string str3 = row[0].ToString().Trim();
                                    if (row[1].ToString() == "0")
                                    {
                                        flag7 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "Y";
                                        table.DR["sync_return"] = "";
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = str2;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    else
                                    {
                                        flag7 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "N";
                                        table.DR["sync_return"] = row[2].ToString();
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = str2;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    num4++;
                                }
                            }
                        }
                    }
                    return;
                }
                this.prgBar.Refresh();
                Dictionary<string, string> item = new Dictionary<string, string>();
                int index = 0;
                while (true)
                {
                    if (index >= this.tblTrans.Columns.Count)
                    {
                        sentTable.Add(item);
                        this.prgBar.Value = num2;
                        num2++;
                        break;
                    }
                    item.Add(this.tblTrans.Columns[index].ToString(), this.tblTrans.Rows[num2].ItemArray[index].ToString());
                    index++;
                }
            }
        }

        private void ZPOMMulesoft()
        {
            int count = this.tblTrans.Rows.Count;
            Cursor.Current = Cursors.WaitCursor;
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                auto = (this.auto == 'Y') ? "Y" : "N"
            };
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            List<Dictionary<string, string>> list2 = new List<Dictionary<string, string>>();
            int num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    integrator.prepareTable();
                    integrator.addTable(list2, "TIPE");
                    integrator.addTable(sentTable, "GRPOM");
                    string url = integrator.getURL("ZWB_UPLOAD_GRN");
                    if (url != "")
                    {
                        bool err = false;
                        string[] resultHeaderName = new string[] { "ERRORS", "GRPOM", "MESSAGE_ID" };
                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                        if (!err)
                        {
                            if (dictionary["ERRORS"].Count > 0)
                            {
                                if (this.auto != 'Y')
                                {
                                    MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                string mulesoftID = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                foreach (Dictionary<string, string> dictionary4 in dictionary["GRPOM"])
                                {
                                    object[] values = new object[] { dictionary4["DEL_NOTE"].ToString(), dictionary4["STATUS"].ToString(), dictionary4["REMARK"].ToString() };
                                    this.retTable.Rows.Add(values);
                                }
                                this.RefreshTable(mulesoftID);
                            }
                        }
                    }
                    return;
                }
                this.prgBar.Refresh();
                Dictionary<string, string> item = new Dictionary<string, string>();
                int index = 0;
                while (true)
                {
                    if (index >= (this.tblTrans.Columns.Count - 2))
                    {
                        sentTable.Add(item);
                        Dictionary<string, string> dictionary3 = new Dictionary<string, string>();
                        int num4 = this.tblTrans.Columns.Count - 1;
                        while (true)
                        {
                            if (num4 > (this.tblTrans.Columns.Count - 1))
                            {
                                list2.Add(dictionary3);
                                this.prgBar.Value = num2;
                                num2++;
                                break;
                            }
                            dictionary3.Add(this.tblTrans.Columns[num4].ToString(), this.tblTrans.Rows[num2].ItemArray[num4].ToString());
                            num4++;
                        }
                        break;
                    }
                    item.Add(this.tblTrans.Columns[index].ToString(), this.tblTrans.Rows[num2].ItemArray[index].ToString());
                    index++;
                }
            }
        }

        private void ZRFC_UPLOAD_FFB_MYMulesoft()
        {
            this.retTable.Rows.Clear();
            try
            {
                this.dgvToTable(this.dgTrans, this.tblTrans);
                int count = this.tblTrans.Rows.Count;
                Cursor.Current = Cursors.WaitCursor;
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                    auto = (this.auto == 'Y') ? "Y" : "N"
                };
                List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= count)
                    {
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "UPL_ITAB");
                        string url = integrator.getURL("ZRFC_UPLOAD_FFB_MY");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "RET_ITAB", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    if (this.auto != 'Y')
                                    {
                                        MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                }
                                else
                                {
                                    string str2 = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["RET_ITAB"])
                                    {
                                        object[] values = new object[] { dictionary3["DELNOTE"].ToString(), dictionary3["SUBRC"].ToString(), dictionary3["MESSAGE"].ToString() };
                                        this.retTable.Rows.Add(values);
                                    }
                                    WBTable table = new WBTable();
                                    bool flag7 = false;
                                    int num4 = 0;
                                    while (true)
                                    {
                                        if (num4 >= this.retTable.Rows.Count)
                                        {
                                            table.Dispose();
                                            this.tblTrans.Dispose();
                                            this.retTable.Dispose();
                                            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                                aTable = this.retTable
                                            };
                                            if (this.auto != 'Y')
                                            {
                                                return2.ShowDialog();
                                            }
                                            return2.Dispose();
                                            if (flag7)
                                            {
                                                this.f_load();
                                            }
                                            break;
                                        }
                                        DataRow row = this.retTable.Rows[num4];
                                        string str3 = row[0].ToString().Trim();
                                        if (row[1].ToString() == "0")
                                        {
                                            flag7 = true;
                                            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                            table.DR = table.DT.Rows[0];
                                            this.logKey = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["posted"] = "Y";
                                            table.DR["sync_return"] = "";
                                            table.DR["lastUpload"] = DateTime.Now;
                                            table.DR["lastMulesoftReturnID"] = str2;
                                            table.DR["checksum"] = table.Checksum(table.DR);
                                            table.DR.EndEdit();
                                            table.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                        }
                                        else
                                        {
                                            flag7 = true;
                                            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str3 + "'", WBData.conn);
                                            table.DR = table.DT.Rows[0];
                                            this.logKey = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["posted"] = "N";
                                            table.DR["sync_return"] = row[2].ToString();
                                            table.DR["lastUpload"] = DateTime.Now;
                                            table.DR["lastMulesoftReturnID"] = str2;
                                            table.DR["checksum"] = table.Checksum(table.DR);
                                            table.DR.EndEdit();
                                            table.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to SAP" };
                                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                        }
                                        num4++;
                                    }
                                }
                            }
                        }
                        break;
                    }
                    this.prgBar.Refresh();
                    Dictionary<string, string> item = new Dictionary<string, string>();
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.tblTrans.Columns.Count)
                        {
                            sentTable.Add(item);
                            this.prgBar.Value = num2;
                            num2++;
                            break;
                        }
                        item.Add(this.tblTrans.Columns[index].ToString(), this.tblTrans.Rows[num2].ItemArray[index].ToString());
                        index++;
                    }
                }
            }
            catch (Exception exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show("Error " + exception.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }
    }
}

