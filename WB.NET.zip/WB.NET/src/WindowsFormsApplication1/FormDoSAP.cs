﻿namespace WindowsFormsApplication1
{
    using JR.Utils.GUI.Forms;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    public class FormDoSAP : Form
    {
        public string mode = "";
        public string doEntryMode = "";
        public string[,] map = new string[0x3e7, 0x18];
        public int num_of_do = 0;
        public int num_of_dr = 0;
        public int num_of_dotrx = 0;
        public string uniq = "";
        public string do_sap = "";
        public string do_sap_item = "";
        public string internal_number = "";
        public string internal_number_item = "";
        public string qty = "";
        public string unit = "";
        public string qty_kg = "";
        public string qty_base_uom = "";
        public string base_uom = "";
        public string wbdo = "";
        public string no_sto = "";
        public string no_sto_item = "";
        public string license_number = "";
        public string transporter = "";
        public string driver_name = "";
        public string truck_number = "";
        public string indic = "";
        public string mark_accident = "";
        public string reason_accident = "";
        public string RefNo = "";
        public string so_item_detail = "";
        public string spb_number = "";
        public string spb_number_item = "";
        public string customer_qq = "";
        private int idxFind = 0;
        public WBTable ztable = new WBTable();
        public string oldDOSAP = "";
        public string oldInternalNo = "";
        public string temRef = "";
        public DataGridView previousSelected_DOTable = new DataGridView();
        public DataGridView retTable_DO = new DataGridView();
        public DataGridView retTable_DR = new DataGridView();
        public DataGridView retTable_DOTRX = new DataGridView();
        public string gatepassNo = "";
        public bool flagRegistration;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private DataGridView dgv_do;
        public MenuStrip menuStrip1;
        private ToolStripMenuItem chooseStripMenuItem1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public Panel panel1;
        public TextBox TextFind;
        public Button buttonFind;

        public FormDoSAP()
        {
            this.InitializeComponent();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            string text = this.TextFind.Text;
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            bool flag4 = false;
            bool flag5 = false;
            bool flag7 = false;
            string str2 = "";
            int num = 0;
            while (true)
            {
                if (num >= text.Length)
                {
                    if (flag5 & flag7)
                    {
                        flag3 = true;
                    }
                    else if (flag7)
                    {
                        flag4 = true;
                    }
                    else if (flag5)
                    {
                        flag2 = true;
                    }
                    this.dgv_do.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    try
                    {
                        foreach (DataGridViewRow row in (IEnumerable) this.dgv_do.Rows)
                        {
                            if ((!flag2 && !flag3) && !flag4)
                            {
                                if (!row.Cells[0].Value.ToString().Equals(str2))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else if (flag2)
                            {
                                if (row.Cells[0].Value.ToString().IndexOf(str2) != 0)
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else if (flag3)
                            {
                                if ((row.Cells[0].Value.ToString().IndexOf(str2) <= 0) || (row.Cells[0].Value.ToString().IndexOf(str2) >= (row.Cells[0].Value.ToString().Length - 1)))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else
                            {
                                if (!flag4 || (row.Cells[0].Value.ToString().IndexOf(str2) != (row.Cells[0].Value.ToString().Length - str2.Length)))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            break;
                        }
                        if (!flag)
                        {
                            MessageBox.Show("Record is not found!");
                        }
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show("Searching: " + exception.Message);
                    }
                    return;
                }
                char ch = text[num];
                if (ch.ToString() != "*")
                {
                    str2 = str2 + text[num].ToString();
                }
                else if (num == 0)
                {
                    flag7 = true;
                }
                else if (num == (text.Length - 1))
                {
                    flag5 = true;
                }
                num++;
            }
        }

        public bool checkInUsedDoSapOrInternal(DataTable dt, out string mssg)
        {
            mssg = "";
            bool flag = false;
            string str = "";
            WBTable table = new WBTable();
            using (IEnumerator enumerator = dt.Rows.GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataRow current = (DataRow) enumerator.Current;
                    if ((((current["ref"].ToString() == "") && (current["gdeleted"].ToString() == "N")) && (current["submit_gatepass"].ToString() == "N")) && ((this.gatepassNo == "") || ((this.gatepassNo != "") && (current["gatepass_number"].ToString() != this.gatepassNo))))
                    {
                        mssg = "{0} in Gatepass Number " + current["gatepass_number"].ToString() + ".";
                        return true;
                    }
                }
            }
            foreach (DataRow row2 in dt.Rows)
            {
                str = row2["ref"].ToString();
                if (str.Length > 0)
                {
                    string[] textArray1 = new string[] { "Select gatepass_number from wb_transaction Where ref like '", str, "%' AND ((mark_accident IS NULL OR mark_accident = '') AND (Deleted IS NULL OR Deleted = ''  OR Deleted='N'))  and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "'" };
                    table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                    if ((table.DT.Rows.Count > 0) && ((this.RefNo == "") || ((this.RefNo != "") && (this.RefNo != str))))
                    {
                        mssg = "{0} in Ref " + str + ".";
                        flag = true;
                        break;
                    }
                }
            }
            return flag;
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            bool flag = true;
            bool flag2 = false;
            if (this.getCountSelectedData(this.dgv_do) == 0)
            {
                MessageBox.Show("Please select at least one new data.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                string str = "";
                bool flag3 = false;
                bool flag4 = false;
                string mssg = "";
                int num = 0;
                foreach (DataGridViewRow row in (IEnumerable) this.dgv_do.Rows)
                {
                    mssg = "";
                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) row.Cells["SELECTED_CHK"];
                    if (Convert.ToBoolean(cell.EditedFormattedValue.ToString()) && !cell.ReadOnly)
                    {
                        if (WBSetting.integrationIDSYS)
                        {
                            if (this.num_of_do > 0)
                            {
                                this.internal_number = row.Cells["do_"].Value.ToString();
                                this.internal_number_item = row.Cells["do_item"].Value.ToString();
                                this.qty_kg = row.Cells["qty_kg"].Value.ToString();
                                this.qty = row.Cells["qty_do"].Value.ToString();
                                this.unit = row.Cells["do_uom"].Value.ToString();
                                this.qty_base_uom = row.Cells["qty_base"].Value.ToString();
                                this.base_uom = row.Cells["base_uom"].Value.ToString();
                            }
                        }
                        else if (this.num_of_do > 0)
                        {
                            this.do_sap = row.Cells["VBELN"].Value.ToString();
                            this.do_sap_item = row.Cells["POSNR"].Value.ToString();
                            this.qty_kg = row.Cells["LFIMG_KG"].Value.ToString();
                            this.qty = row.Cells["LFIMG"].Value.ToString();
                            this.unit = row.Cells["VRKME"].Value.ToString();
                            this.qty_base_uom = row.Cells["LFIMG_BASE"].Value.ToString();
                            this.base_uom = row.Cells["BASE_UOM"].Value.ToString();
                            this.indic = row.Cells["ZZDO_INDICATOR"].Value.ToString();
                            this.mark_accident = row.Cells["ZZMARK_ACCIDENT"].Value.ToString();
                            this.reason_accident = row.Cells["ZZACCIDENT_REASON"].Value.ToString();
                            this.so_item_detail = row.Cells["POSNR_VA"].Value.ToString();
                        }
                        else if (this.num_of_dr > 0)
                        {
                            this.internal_number = row.Cells["ZDCONR"].Value.ToString();
                            this.internal_number_item = row.Cells["POSNR"].Value.ToString();
                            this.qty_kg = row.Cells["DLFIMG_NET"].Value.ToString();
                            this.qty = row.Cells["DLFIMG"].Value.ToString();
                            this.unit = row.Cells["VRKME"].Value.ToString();
                            this.qty_base_uom = row.Cells["DLFIMG_BASE"].Value.ToString();
                            this.base_uom = row.Cells["BASE_UOM"].Value.ToString();
                            this.so_item_detail = row.Cells["POSNR_VA"].Value.ToString();
                        }
                        else if (this.num_of_dotrx > 0)
                        {
                            this.internal_number = row.Cells["ZDCONR"].Value.ToString();
                            this.internal_number_item = row.Cells["DOPLINE"].Value.ToString();
                            this.mark_accident = row.Cells["XACCIDENT"].Value.ToString();
                            this.reason_accident = row.Cells["ACCIDENT_REASON"].Value.ToString();
                            this.so_item_detail = row.Cells["POSNR"].Value.ToString();
                            this.qty_kg = row.Cells["QTYKG"].Value.ToString();
                            this.qty = row.Cells["PLN_LFIMG"].Value.ToString();
                            this.unit = row.Cells["Q_VRKME"].Value.ToString();
                            this.qty_base_uom = row.Cells["QTYBUOM"].Value.ToString();
                            this.base_uom = row.Cells["BUOM"].Value.ToString();
                            this.indic = "";
                            this.wbdo = row.Cells["VBELN_REF"].Value.ToString();
                            this.no_sto = row.Cells["EBELN_REF"].Value.ToString();
                            this.no_sto_item = row.Cells["EBELP"].Value.ToString();
                            this.transporter = row.Cells["WANGKUTAN"].Value.ToString();
                            this.license_number = row.Cells["WNOSIM"].Value.ToString();
                            this.driver_name = row.Cells["WSUPIR"].Value.ToString();
                            this.truck_number = row.Cells["WNOPOLISI"].Value.ToString();
                            this.spb_number = row.Cells["SPBNO"].Value.ToString();
                            this.spb_number_item = row.Cells["SPBITEM"].Value.ToString();
                            this.customer_qq = row.Cells["SOKUN3RD"].Value.ToString();
                            if (((this.no_sto == "") && (this.wbdo == "")) && (this.spb_number == ""))
                            {
                                mssg = "There is no supporting document ( SO / STO / SPB )";
                                flag = false;
                            }
                        }
                        if (((this.do_sap != "") && (this.do_sap_item != "")) && (this.indic == ""))
                        {
                            flag3 = true;
                        }
                        else if (this.internal_number != "")
                        {
                            flag4 = true;
                        }
                        if (flag3 | flag4)
                        {
                            string sqltext = "SELECT do.gatepass_number, do.ref, trans.deleted, gate.submit_gatepass, gate.deleted as gdeleted FROM wb_transdo do LEFT JOIN wb_transaction trans ON trans.ref = Do.ref  LEFT JOIN wb_gatepass gate on do.gatepass_number = gate.gatepass_number WHERE (mark_accident IS NULL OR mark_accident = '')  ";
                            if (this.flagRegistration)
                            {
                                sqltext = sqltext + " AND ((gate.Deleted IS NULL OR gate.Deleted = '' OR gate.Deleted = 'N') or (gate.Submit_Gatepass IS NULL OR gate.Submit_Gatepass = '' OR gate.Submit_Gatepass = 'N')) ";
                            }
                            if (flag3)
                            {
                                string[] textArray1 = new string[] { sqltext, " AND do.do_sap = '", this.do_sap, "' AND do.do_sap_item = '", this.do_sap_item, "' " };
                                sqltext = string.Concat(textArray1);
                            }
                            else if (flag4)
                            {
                                string[] textArray2 = new string[] { sqltext, " AND do.internal_number = '", this.internal_number, "' AND do.internal_number_item = '", this.internal_number_item, "' " };
                                sqltext = string.Concat(textArray2);
                            }
                            if (this.RefNo != "")
                            {
                                sqltext = sqltext + " AND Do.ref <> '" + this.RefNo + "'";
                            }
                            sqltext = sqltext + " order by gate.gatepass_number desc ";
                            WBTable table = new WBTable();
                            table.OpenTable("wb_transDo", sqltext, WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                string str4 = table.DT.Rows[0]["ref"].ToString();
                                string str5 = table.DT.Rows[0]["gatepass_number"].ToString();
                                string str6 = table.DT.Rows[0]["submit_gatepass"].ToString();
                                if ((((table.DT.Rows[0]["Ref"].ToString() != "") && ((table.DT.Rows[0]["Deleted"].ToString() != "Y") || (table.DT.Rows[0]["submit_gatepass"].ToString() != "Y"))) || (table.DT.Rows[0]["submit_gatepass"].ToString() == "Y")) || (table.DT.Rows[0]["submit_gatepass"].ToString() == "N"))
                                {
                                    DataTable dT = table.DT;
                                    if (this.checkInUsedDoSapOrInternal(dT, out mssg))
                                    {
                                        if (flag3)
                                        {
                                            mssg = string.Format(mssg, this.do_sap + "/" + this.do_sap_item, this.do_sap + " Item " + this.do_sap_item);
                                        }
                                        else if (flag4)
                                        {
                                            mssg = !WBSetting.adopt_zdotrx ? string.Format(mssg, this.internal_number, "Internal Number") : string.Format(mssg, this.internal_number, "Loading Note");
                                        }
                                    }
                                }
                                else if (!flag3)
                                {
                                    if (flag4)
                                    {
                                        mssg = !WBSetting.adopt_zdotrx ? (this.internal_number + " in Ref " + table.DT.Rows[0]["Ref"].ToString() + ".") : (this.internal_number + " in Ref " + table.DT.Rows[0]["Ref"].ToString() + ".");
                                    }
                                }
                                else
                                {
                                    string[] textArray3 = new string[] { this.do_sap, "/", this.do_sap_item, " in Gatepass Number ", table.DT.Rows[0]["Gatepass_no"].ToString(), ".\nPlease check again, or use another DO ", this.sapIDSYS, ".\nThank you." };
                                    mssg = string.Concat(textArray3);
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(mssg))
                        {
                            string str7 = "";
                            if (flag3)
                            {
                                str7 = "DO Partial " + this.sapIDSYS;
                            }
                            else if (flag4)
                            {
                                str7 = !WBSetting.adopt_zdotrx ? "Internal Number" : "Loading Note";
                            }
                            if (!string.IsNullOrEmpty(str))
                            {
                                if (!string.IsNullOrEmpty(str))
                                {
                                    str = str + Environment.NewLine;
                                }
                            }
                            else
                            {
                                string[] textArray4 = new string[] { str, "The following selected ", str7, " has been used : ", Environment.NewLine };
                                str = string.Concat(textArray4);
                            }
                            num++;
                            object[] objArray1 = new object[] { str, num, ". ", mssg };
                            str = string.Concat(objArray1);
                        }
                    }
                }
                if (str != "")
                {
                    FlexibleMessageBox.Show(str, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2);
                    flag = false;
                }
                if (WBSetting.integrationIDSYS)
                {
                    if (this.num_of_do > 0)
                    {
                        DataGridViewRow row2 = this.getFirstRowSelectedData(this.dgv_do);
                        this.internal_number = row2.Cells["do_"].Value.ToString();
                        this.internal_number_item = row2.Cells["do_item"].Value.ToString();
                        this.qty_kg = row2.Cells["qty_kg"].Value.ToString();
                        this.qty = row2.Cells["qty_do"].Value.ToString();
                        this.unit = row2.Cells["do_uom"].Value.ToString();
                        this.qty_base_uom = row2.Cells["qty_base"].Value.ToString();
                        this.base_uom = row2.Cells["base_uom"].Value.ToString();
                        this.retTable_DO = this.getOnlySelectedData(this.dgv_do);
                    }
                }
                else if (this.num_of_do > 0)
                {
                    DataGridViewRow row3 = this.getFirstRowSelectedData(this.dgv_do);
                    this.do_sap = row3.Cells["VBELN"].Value.ToString();
                    this.do_sap_item = row3.Cells["POSNR"].Value.ToString();
                    this.qty_kg = row3.Cells["LFIMG_KG"].Value.ToString();
                    this.qty = row3.Cells["LFIMG"].Value.ToString();
                    this.unit = row3.Cells["VRKME"].Value.ToString();
                    this.qty_base_uom = row3.Cells["LFIMG_BASE"].Value.ToString();
                    this.base_uom = row3.Cells["BASE_UOM"].Value.ToString();
                    this.indic = row3.Cells["ZZDO_INDICATOR"].Value.ToString();
                    this.mark_accident = row3.Cells["ZZMARK_ACCIDENT"].Value.ToString();
                    this.reason_accident = row3.Cells["ZZACCIDENT_REASON"].Value.ToString();
                    this.so_item_detail = row3.Cells["POSNR_VA"].Value.ToString();
                    this.retTable_DO = this.getOnlySelectedData(this.dgv_do);
                }
                else if (this.num_of_dr > 0)
                {
                    DataGridViewRow row4 = this.getFirstRowSelectedData(this.dgv_do);
                    this.internal_number = row4.Cells["ZDCONR"].Value.ToString();
                    this.internal_number_item = row4.Cells["POSNR"].Value.ToString();
                    this.qty_kg = row4.Cells["DLFIMG_NET"].Value.ToString();
                    this.qty = row4.Cells["DLFIMG"].Value.ToString();
                    this.unit = row4.Cells["VRKME"].Value.ToString();
                    this.qty_base_uom = row4.Cells["DLFIMG_BASE"].Value.ToString();
                    this.base_uom = row4.Cells["BASE_UOM"].Value.ToString();
                    this.so_item_detail = row4.Cells["POSNR_VA"].Value.ToString();
                    this.retTable_DR = this.getOnlySelectedData(this.dgv_do);
                }
                else if (this.num_of_dotrx > 0)
                {
                    DataGridViewRow row5 = this.getFirstRowSelectedData(this.dgv_do);
                    this.internal_number = row5.Cells["ZDCONR"].Value.ToString();
                    this.internal_number_item = row5.Cells["DOPLINE"].Value.ToString();
                    this.mark_accident = row5.Cells["XACCIDENT"].Value.ToString();
                    this.reason_accident = row5.Cells["ACCIDENT_REASON"].Value.ToString();
                    this.so_item_detail = row5.Cells["POSNR"].Value.ToString();
                    this.qty_kg = row5.Cells["QTYKG"].Value.ToString();
                    this.qty = row5.Cells["PLN_LFIMG"].Value.ToString();
                    this.unit = row5.Cells["Q_VRKME"].Value.ToString();
                    this.qty_base_uom = row5.Cells["QTYBUOM"].Value.ToString();
                    this.base_uom = row5.Cells["BUOM"].Value.ToString();
                    this.indic = "";
                    this.wbdo = row5.Cells["VBELN_REF"].Value.ToString();
                    this.no_sto = row5.Cells["EBELN_REF"].Value.ToString();
                    this.no_sto_item = row5.Cells["EBELP"].Value.ToString();
                    this.transporter = row5.Cells["WANGKUTAN"].Value.ToString();
                    this.license_number = row5.Cells["WNOSIM"].Value.ToString();
                    this.driver_name = row5.Cells["WSUPIR"].Value.ToString();
                    this.truck_number = row5.Cells["WNOPOLISI"].Value.ToString();
                    this.spb_number = row5.Cells["SPBNO"].Value.ToString();
                    this.spb_number_item = row5.Cells["SPBITEM"].Value.ToString();
                    this.customer_qq = row5.Cells["SOKUN3RD"].Value.ToString();
                    this.retTable_DOTRX = this.getOnlySelectedData(this.dgv_do);
                    if (((this.no_sto == "") && (this.wbdo == "")) && (this.spb_number == ""))
                    {
                        MessageBox.Show("There is no supporting document ( SO / STO / SPB )");
                        flag = false;
                    }
                }
                if (flag)
                {
                    if (WBSetting.integrationIDSYS)
                    {
                        if (this.num_of_do > 0)
                        {
                            flag2 = this.promptNewDataSelected(true, false, false);
                        }
                    }
                    else if (this.num_of_do > 0)
                    {
                        flag2 = this.promptNewDataSelected(true, false, false);
                    }
                    else if (this.num_of_dr > 0)
                    {
                        flag2 = this.promptNewDataSelected(false, false, true);
                    }
                    else if (this.num_of_dotrx > 0)
                    {
                        flag2 = this.promptNewDataSelected(false, true, false);
                    }
                    if (flag2)
                    {
                        base.Close();
                    }
                }
                else if (this.num_of_do > 0)
                {
                    this.do_sap = "";
                    this.do_sap_item = "";
                    this.qty_kg = "";
                    this.qty = "";
                    this.unit = "";
                    this.qty_base_uom = "";
                    this.base_uom = "";
                    this.indic = "";
                    this.mark_accident = "";
                    this.reason_accident = "";
                    this.so_item_detail = "";
                    this.retTable_DO = new DataGridView();
                }
                else if ((this.num_of_dr > 0) || (this.num_of_dotrx > 0))
                {
                    this.internal_number = "";
                    this.internal_number_item = "";
                    this.qty_kg = "";
                    this.qty = "";
                    this.unit = "";
                    this.qty_base_uom = "";
                    this.base_uom = "";
                    this.so_item_detail = "";
                    this.spb_number = this.spb_number_item = "";
                    this.no_sto = this.no_sto_item = "";
                    this.customer_qq = "";
                    this.retTable_DR = new DataGridView();
                    this.retTable_DOTRX = new DataGridView();
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dgv_do_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if ((this.doEntryMode == "EDIT") && !this.dgv_do.Rows[e.RowIndex].Cells["SELECTED_CHK"].ReadOnly)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgv_do.Rows)
                {
                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) row.Cells["SELECTED_CHK"];
                    if (Convert.ToBoolean(cell.EditedFormattedValue.ToString()) && !cell.ReadOnly)
                    {
                        cell.Value = row.Index == e.RowIndex;
                    }
                }
            }
        }

        private void dgv_do_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0)
            {
            }
        }

        private void dgv_do_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0)
            {
            }
        }

        private void dgv_do_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (WBSetting.integrationIDSYS)
            {
                if (this.num_of_do > 0)
                {
                }
            }
            else if ((this.num_of_do > 0) && ((this.dgv_do.Rows[e.RowIndex].Cells["ZZDO_INDICATOR"].Value != null) && (this.dgv_do.Rows[e.RowIndex].Cells["ZZDO_INDICATOR"].Value.ToString() == "X")))
            {
                e.CellStyle.BackColor = Color.LimeGreen;
                e.CellStyle.SelectionBackColor = Color.PaleGreen;
                e.CellStyle.SelectionForeColor = Color.Green;
            }
        }

        private void dgv_do_SelectionChanged(object sender, EventArgs e)
        {
            this.dgv_do.ClearSelection();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDoSAP_Load(object sender, EventArgs e)
        {
            int o = 0;
            if (WBSetting.integrationIDSYS)
            {
                this.loadDataIDSYS(o);
            }
            else if (this.num_of_do > 0)
            {
                this.dgv_do.ColumnCount = 13;
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "SELECTED_CHK",
                    HeaderText = "",
                    Width = 50,
                    ReadOnly = false,
                    FillWeight = 10f
                };
                this.dgv_do.Columns.Add(dataGridViewColumn);
                this.dgv_do.Columns[o].Name = "VBELN";
                this.dgv_do.Columns[o].HeaderText = "Do SAP No";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "POSNR";
                this.dgv_do.Columns[o].HeaderText = "DO SAP Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "LFIMG_KG";
                this.dgv_do.Columns[o].HeaderText = "Quantity in KG";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "LFIMG";
                this.dgv_do.Columns[o].HeaderText = "Quantity";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "VRKME";
                this.dgv_do.Columns[o].HeaderText = "Unit";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "LFIMG_BASE";
                this.dgv_do.Columns[o].HeaderText = "Qty in Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "BASE_UOM";
                this.dgv_do.Columns[o].HeaderText = "Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "ZZDO_INDICATOR";
                this.dgv_do.Columns[o].HeaderText = "X = DO Besar";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "ZZMARK_ACCIDENT";
                this.dgv_do.Columns[o].HeaderText = "Mark Accident";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "ZZACCIDENT_REASON";
                this.dgv_do.Columns[o].HeaderText = "Reason";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "REASON_DESC";
                this.dgv_do.Columns[o].HeaderText = "Remarks";
                this.dgv_do.Columns[o].Visible = false;
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "POSNR_VA";
                this.dgv_do.Columns[o].HeaderText = "SO Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "MATNR";
                this.dgv_do.Columns[o].HeaderText = "Commodity Code";
                this.dgv_do.Columns[o].ReadOnly = true;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.num_of_do)
                    {
                        this.dgv_do.Sort(this.dgv_do.Columns["VBELN"], ListSortDirection.Ascending);
                        this.dgv_do.Columns["VBELN"].DisplayIndex = 2;
                        this.dgv_do.Columns["POSNR"].DisplayIndex = 3;
                        this.dgv_do.Columns["LFIMG_KG"].DisplayIndex = 5;
                        this.dgv_do.Columns["LFIMG"].DisplayIndex = 6;
                        this.dgv_do.Columns["VRKME"].DisplayIndex = 7;
                        this.dgv_do.Columns["LFIMG_BASE"].DisplayIndex = 8;
                        this.dgv_do.Columns["BASE_UOM"].DisplayIndex = 9;
                        this.dgv_do.Columns["ZZDO_INDICATOR"].DisplayIndex = 10;
                        this.dgv_do.Columns["ZZMARK_ACCIDENT"].DisplayIndex = 11;
                        this.dgv_do.Columns["ZZACCIDENT_REASON"].DisplayIndex = 12;
                        this.dgv_do.Columns["REASON_DESC"].DisplayIndex = 13;
                        this.dgv_do.Columns["POSNR_VA"].DisplayIndex = 1;
                        this.dgv_do.Columns["MATNR"].DisplayIndex = 4;
                        this.dgv_do.Columns["SELECTED_CHK"].DisplayIndex = 0;
                        this.tickDGVDOData(true, false, false);
                        break;
                    }
                    this.dgv_do.Rows.Add();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.dgv_do.ColumnCount)
                        {
                            num2++;
                            break;
                        }
                        this.dgv_do.Rows[num2].Cells[num3].Value = this.map[num2, num3];
                        num3++;
                    }
                }
            }
            else if (this.num_of_dr > 0)
            {
                this.dgv_do.ColumnCount = 10;
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "SELECTED_CHK",
                    HeaderText = "",
                    Width = 50,
                    ReadOnly = false,
                    FillWeight = 10f
                };
                this.dgv_do.Columns.Add(dataGridViewColumn);
                this.dgv_do.Columns[o].Name = "ZDCONR";
                this.dgv_do.Columns[o].HeaderText = "Internal Number";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "POSNR";
                this.dgv_do.Columns[o].HeaderText = "Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "DLFIMG";
                this.dgv_do.Columns[o].HeaderText = "Quantity";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "VRKME";
                this.dgv_do.Columns[o].HeaderText = "Unit";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "DLFIMG_NET";
                this.dgv_do.Columns[o].HeaderText = "Quantity  in KG";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "DLFIMG_BASE";
                this.dgv_do.Columns[o].HeaderText = "Qty in Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "BASE_UOM";
                this.dgv_do.Columns[o].HeaderText = "Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "EBELP";
                this.dgv_do.Columns[o].HeaderText = "Ebelp";
                this.dgv_do.Columns[o].Visible = false;
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "POSNR_VA";
                this.dgv_do.Columns[o].HeaderText = "SO Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "MATNR";
                this.dgv_do.Columns[o].HeaderText = "Commodity Code";
                this.dgv_do.Columns[o].ReadOnly = true;
                int num4 = 0;
                while (true)
                {
                    if (num4 >= this.num_of_dr)
                    {
                        this.dgv_do.Sort(this.dgv_do.Columns["ZDCONR"], ListSortDirection.Ascending);
                        this.dgv_do.Columns["ZDCONR"].DisplayIndex = 2;
                        this.dgv_do.Columns["POSNR"].DisplayIndex = 3;
                        this.dgv_do.Columns["DLFIMG"].DisplayIndex = 5;
                        this.dgv_do.Columns["VRKME"].DisplayIndex = 6;
                        this.dgv_do.Columns["DLFIMG_NET"].DisplayIndex = 7;
                        this.dgv_do.Columns["DLFIMG_BASE"].DisplayIndex = 8;
                        this.dgv_do.Columns["BASE_UOM"].DisplayIndex = 9;
                        this.dgv_do.Columns["EBELP"].DisplayIndex = 10;
                        this.dgv_do.Columns["POSNR_VA"].DisplayIndex = 1;
                        this.dgv_do.Columns["MATNR"].DisplayIndex = 4;
                        this.dgv_do.Columns["SELECTED_CHK"].DisplayIndex = 0;
                        this.tickDGVDOData(false, false, true);
                        break;
                    }
                    this.dgv_do.Rows.Add();
                    int num5 = 0;
                    while (true)
                    {
                        if (num5 >= this.dgv_do.ColumnCount)
                        {
                            num4++;
                            break;
                        }
                        this.dgv_do.Rows[num4].Cells[num5].Value = this.map[num4, num5];
                        num5++;
                    }
                }
            }
            else if (this.num_of_dotrx > 0)
            {
                this.dgv_do.ColumnCount = 0x17;
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "SELECTED_CHK",
                    HeaderText = "",
                    Width = 50,
                    ReadOnly = false,
                    FillWeight = 10f
                };
                this.dgv_do.Columns.Add(dataGridViewColumn);
                this.dgv_do.Columns[o].Name = "ZDCONR";
                this.dgv_do.Columns[o].HeaderText = "Loading Note No";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "VBELN_REF";
                this.dgv_do.Columns[o].HeaderText = "DO (VA01)";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "EBELN_REF";
                this.dgv_do.Columns[o].HeaderText = "STO 1";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "PUR_EBELN";
                this.dgv_do.Columns[o].HeaderText = "STO 2";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "PUR_EBELP";
                this.dgv_do.Columns[o].HeaderText = "STO 2 Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "WANGKUTAN";
                this.dgv_do.Columns[o].HeaderText = "Transporter";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "WNOSIM";
                this.dgv_do.Columns[o].HeaderText = "License No";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "WSUPIR";
                this.dgv_do.Columns[o].HeaderText = "Driver Name";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "WNOPOLISI";
                this.dgv_do.Columns[o].HeaderText = "Truck Number";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "DOPLINE";
                this.dgv_do.Columns[o].HeaderText = "DO SAP Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "POSNR";
                this.dgv_do.Columns[o].HeaderText = "Item DO (VA01)";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "EBELP";
                this.dgv_do.Columns[o].HeaderText = "STO 1 Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "MATNR";
                this.dgv_do.Columns[o].HeaderText = "Commodity Code";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "PLN_LFIMG";
                this.dgv_do.Columns[o].HeaderText = "Estimated Quantity";
                this.dgv_do.Columns["PLN_LFIMG"].DisplayIndex = 5;
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "Q_VRKME";
                this.dgv_do.Columns[o].HeaderText = "UOM DO SAP";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "QTYKG";
                this.dgv_do.Columns[o].HeaderText = "Quantity in KG";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "QTYBUOM";
                this.dgv_do.Columns[o].HeaderText = "Qty in Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "BUOM";
                this.dgv_do.Columns[o].HeaderText = "Base UoM";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "XACCIDENT";
                this.dgv_do.Columns[o].HeaderText = "Mark Accident";
                this.dgv_do.Columns[o].Visible = false;
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "ACCIDENT_REASON";
                this.dgv_do.Columns[o].HeaderText = "Reason";
                this.dgv_do.Columns[o].Visible = false;
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "SPBNO";
                this.dgv_do.Columns[o].HeaderText = "SPB No";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "SPBITEM";
                this.dgv_do.Columns[o].HeaderText = "SPB Item";
                this.dgv_do.Columns[o].ReadOnly = true;
                o++;
                this.dgv_do.Columns[o].Name = "SOKUN3RD";
                this.dgv_do.Columns[o].HeaderText = "Customer QQ";
                this.dgv_do.Columns[o].ReadOnly = true;
                int num6 = 0;
                while (true)
                {
                    if (num6 >= this.num_of_dotrx)
                    {
                        this.dgv_do.Sort(this.dgv_do.Columns["ZDCONR"], ListSortDirection.Ascending);
                        this.dgv_do.Columns["SELECTED_CHK"].DisplayIndex = 0;
                        this.dgv_do.Columns["POSNR"].DisplayIndex = 1;
                        this.dgv_do.Columns["ZDCONR"].DisplayIndex = 2;
                        this.dgv_do.Columns["DOPLINE"].DisplayIndex = 3;
                        this.dgv_do.Columns["MATNR"].DisplayIndex = 4;
                        this.dgv_do.Columns["QTYKG"].DisplayIndex = 5;
                        this.dgv_do.Columns["QTYBUOM"].DisplayIndex = 6;
                        this.dgv_do.Columns["BUOM"].DisplayIndex = 7;
                        this.dgv_do.Columns["WANGKUTAN"].DisplayIndex = 8;
                        this.dgv_do.Columns["WNOSIM"].DisplayIndex = 9;
                        this.dgv_do.Columns["WSUPIR"].DisplayIndex = 10;
                        this.dgv_do.Columns["WNOPOLISI"].DisplayIndex = 11;
                        this.dgv_do.Columns["Q_VRKME"].DisplayIndex = 12;
                        this.dgv_do.Columns["VBELN_REF"].DisplayIndex = 13;
                        this.dgv_do.Columns["EBELN_REF"].DisplayIndex = 14;
                        this.dgv_do.Columns["EBELP"].DisplayIndex = 15;
                        this.dgv_do.Columns["PUR_EBELN"].DisplayIndex = 0x10;
                        this.dgv_do.Columns["PUR_EBELP"].DisplayIndex = 0x11;
                        this.dgv_do.Columns["XACCIDENT"].DisplayIndex = 0x12;
                        this.dgv_do.Columns["ACCIDENT_REASON"].DisplayIndex = 0x13;
                        this.dgv_do.Columns["SPBNO"].DisplayIndex = 20;
                        this.dgv_do.Columns["SPBITEM"].DisplayIndex = 0x15;
                        this.dgv_do.Columns["SOKUN3RD"].DisplayIndex = 0x16;
                        this.tickDGVDOData(false, true, false);
                        break;
                    }
                    this.dgv_do.Rows.Add();
                    int num7 = 0;
                    while (true)
                    {
                        if (num7 >= this.dgv_do.ColumnCount)
                        {
                            num6++;
                            break;
                        }
                        this.dgv_do.Rows[num6].Cells[num7].Value = this.map[num6, num7];
                        num7++;
                    }
                }
            }
            this.chooseStripMenuItem1.Visible = this.mode == "CHOOSE";
            this.TextFind.Focus();
        }

        private int getCountSelectedData(DataGridView _dgv)
        {
            int num = 0;
            foreach (DataGridViewRow row in (IEnumerable) _dgv.Rows)
            {
                DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) row.Cells["SELECTED_CHK"];
                if (Convert.ToBoolean(cell.EditedFormattedValue.ToString()) && !cell.ReadOnly)
                {
                    num++;
                }
            }
            return num;
        }

        private DataGridViewRow getFirstRowSelectedData(DataGridView _dgv)
        {
            DataGridViewRow objA = null;
            using (IEnumerator enumerator = ((IEnumerable) _dgv.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                    if (Convert.ToBoolean(cell.EditedFormattedValue.ToString()) && !cell.ReadOnly)
                    {
                        objA = current;
                        return current;
                    }
                }
            }
            if (ReferenceEquals(objA, null))
            {
                _dgv.Rows.Add();
                objA = _dgv.Rows[_dgv.Rows.Count - 1];
            }
            return objA;
        }

        private DataGridView getOnlySelectedData(DataGridView _dgv)
        {
            DataGridView view = new DataGridView {
                AllowUserToAddRows = false
            };
            List<DataGridViewRow> list = new List<DataGridViewRow>();
            foreach (DataGridViewRow row in (IEnumerable) _dgv.Rows)
            {
                DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) row.Cells["SELECTED_CHK"];
                if ((!row.IsNewRow && Convert.ToBoolean(cell.EditedFormattedValue.ToString())) && !cell.ReadOnly)
                {
                    DataGridViewRow item = (DataGridViewRow) row.Clone();
                    foreach (DataGridViewCell cell2 in row.Cells)
                    {
                        item.Cells[cell2.ColumnIndex].Value = cell2.Value;
                    }
                    list.Add(item);
                }
            }
            view.Columns.Clear();
            foreach (DataGridViewColumn column in _dgv.Columns)
            {
                view.Columns.Add((DataGridViewColumn) column.Clone());
            }
            view.Rows.AddRange(list.ToArray());
            return view;
        }

        private void InitializeComponent()
        {
            this.dgv_do = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            ((ISupportInitialize) this.dgv_do).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dgv_do.AllowUserToAddRows = false;
            this.dgv_do.AllowUserToDeleteRows = false;
            this.dgv_do.AllowUserToResizeRows = false;
            this.dgv_do.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_do.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgv_do.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_do.Dock = DockStyle.Fill;
            this.dgv_do.Location = new Point(0, 0x18);
            this.dgv_do.MultiSelect = false;
            this.dgv_do.Name = "dgv_do";
            this.dgv_do.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgv_do.Size = new Size(0x30a, 0x176);
            this.dgv_do.TabIndex = 0x13;
            this.dgv_do.CellContentClick += new DataGridViewCellEventHandler(this.dgv_do_CellContentClick);
            this.dgv_do.CellContentDoubleClick += new DataGridViewCellEventHandler(this.dgv_do_CellContentDoubleClick);
            this.dgv_do.CellDoubleClick += new DataGridViewCellEventHandler(this.dgv_do_CellDoubleClick);
            this.dgv_do.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgv_do_CellFormatting);
            this.dgv_do.SelectionChanged += new EventHandler(this.dgv_do_SelectionChanged);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x30a, 0x18);
            this.menuStrip1.TabIndex = 0x15;
            this.menuStrip1.Text = "menuStrip1";
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18e);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x30a, 0x21);
            this.panel1.TabIndex = 20;
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x30a, 0x1af);
            base.Controls.Add(this.dgv_do);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormDoSAP";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Do SAP";
            base.Load += new EventHandler(this.FormDoSAP_Load);
            ((ISupportInitialize) this.dgv_do).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void loadDataIDSYS(int o)
        {
            if (this.num_of_do > 0)
            {
                this.dgv_do.ColumnCount = 7;
                this.dgv_do.Columns[o].Name = "do_";
                this.dgv_do.Columns[o].HeaderText = "Do";
                o++;
                this.dgv_do.Columns[o].Name = "do_item";
                this.dgv_do.Columns[o].HeaderText = "DO Item";
                o++;
                this.dgv_do.Columns[o].Name = "qty_base";
                this.dgv_do.Columns[o].HeaderText = "Qty Base UoM";
                o++;
                this.dgv_do.Columns[o].Name = "base_uom";
                this.dgv_do.Columns[o].HeaderText = "Base UoM";
                o++;
                this.dgv_do.Columns[o].Name = "qty_do";
                this.dgv_do.Columns[o].HeaderText = "Qty DO";
                o++;
                this.dgv_do.Columns[o].Name = "do_uom";
                this.dgv_do.Columns[o].HeaderText = "DO UoM";
                o++;
                this.dgv_do.Columns[o].Name = "qty_kg";
                this.dgv_do.Columns[o].HeaderText = "Qty in KG";
                int num = 0;
                while (true)
                {
                    if (num >= this.num_of_do)
                    {
                        this.dgv_do.Sort(this.dgv_do.Columns["do_"], ListSortDirection.Ascending);
                        this.dgv_do.Columns["do_"].DisplayIndex = 0;
                        this.dgv_do.Columns["do_item"].DisplayIndex = 1;
                        this.dgv_do.Columns["qty_base"].DisplayIndex = 2;
                        this.dgv_do.Columns["base_uom"].DisplayIndex = 3;
                        this.dgv_do.Columns["qty_do"].DisplayIndex = 4;
                        this.dgv_do.Columns["do_uom"].DisplayIndex = 6;
                        this.dgv_do.Columns["qty_kg"].DisplayIndex = 5;
                        this.tickDGVDOData(true, false, false);
                        break;
                    }
                    this.dgv_do.Rows.Add();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgv_do.ColumnCount)
                        {
                            num++;
                            break;
                        }
                        this.dgv_do.Rows[num].Cells[num2].Value = this.map[num, num2];
                        num2++;
                    }
                }
            }
        }

        private void manualEntryDOSAPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text = "";
            text = (WBSetting.Field("GM").ToString() != "Y") ? "Manual Entry will need Password Manager to be saved.\nPress OK to proceed." : "Manual Entry will need TOKEN to be saved.\nPress OK to proceed.";
            if (MessageBox.Show(text, "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand) == DialogResult.OK)
            {
                FormDoSapEntry entry = new FormDoSapEntry();
                entry.ShowDialog();
                entry.Dispose();
            }
        }

        private bool promptNewDataSelected(bool from_do, bool from_dotrx, bool from_dr)
        {
            string str = "";
            string str2 = "";
            int num = 0;
            float num2 = 0f;
            foreach (DataGridViewRow row in (IEnumerable) this.dgv_do.Rows)
            {
                DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) row.Cells["SELECTED_CHK"];
                if (Convert.ToBoolean(cell.EditedFormattedValue.ToString()) && !cell.ReadOnly)
                {
                    num++;
                    if (num > 1)
                    {
                        str2 = str2 + Environment.NewLine;
                    }
                    str2 = str2 + num + ". ";
                    if (WBSetting.integrationIDSYS)
                    {
                        str2 = str2 + row.Cells["do_"].Value.ToString() + " / " + row.Cells["do_no"].Value.ToString();
                        num2 += float.Parse(row.Cells["qty_kg"].Value.ToString());
                    }
                    else if (from_do)
                    {
                        str2 = str2 + row.Cells["VBELN"].Value.ToString() + " / " + row.Cells["POSNR"].Value.ToString();
                        num2 += float.Parse(row.Cells["LFIMG_KG"].Value.ToString());
                    }
                    else if (from_dr)
                    {
                        str2 = str2 + row.Cells["ZDCONR"].Value.ToString() + " / " + row.Cells["POSNR"].Value.ToString();
                        num2 += float.Parse(row.Cells["DLFIMG_NET"].Value.ToString());
                    }
                    else if (from_dotrx)
                    {
                        str2 = str2 + row.Cells["ZDCONR"].Value.ToString() + " / " + row.Cells["DOPLINE"].Value.ToString();
                        num2 += float.Parse(row.Cells["QTYKG"].Value.ToString());
                    }
                }
            }
            str = "Are you sure want to choose " + num;
            if (WBSetting.integrationIDSYS)
            {
                string[] textArray1 = new string[] { str, " DO Partial ", this.sapIDSYS, "(s) : ", Environment.NewLine };
                str = string.Concat(textArray1);
            }
            else if (from_do)
            {
                string[] textArray2 = new string[] { str, " DO Partial ", this.sapIDSYS, "(s) : ", Environment.NewLine };
                str = string.Concat(textArray2);
            }
            else if (from_dr)
            {
                str = str + " Internal Number(s) : " + Environment.NewLine;
            }
            else if (from_dotrx)
            {
                str = str + " Loading Note(s) : " + Environment.NewLine;
            }
            return (FlexibleMessageBox.Show(str + str2, "N O T I C E", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes);
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void tickDGVDOData(bool from_do, bool from_dotrx, bool from_dr)
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgv_do.Rows).GetEnumerator())
            {
                DataGridViewRow current;
                bool flag;
                goto TR_008F;
            TR_000D:
                if (flag)
                {
                }
                goto TR_008F;
            TR_003D:
                if (!flag)
                {
                    if (WBSetting.integrationIDSYS)
                    {
                        foreach (DataGridViewRow row6 in (IEnumerable) this.retTable_DO.Rows)
                        {
                            if ((row6.Cells["do_"].Value.ToString() == current.Cells["do_"].Value.ToString()) && (row6.Cells["do_item"].Value.ToString() == current.Cells["do_item"].Value.ToString()))
                            {
                                ((DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"]).Value = true;
                                flag = true;
                                break;
                            }
                        }
                    }
                    else if (from_do)
                    {
                        foreach (DataGridViewRow row7 in (IEnumerable) this.retTable_DO.Rows)
                        {
                            if (((row7.Cells["VBELN"].Value.ToString() == current.Cells["VBELN"].Value.ToString()) && (row7.Cells["POSNR"].Value.ToString() == current.Cells["POSNR"].Value.ToString())) && (row7.Cells["POSNR_VA"].Value.ToString() == current.Cells["POSNR_VA"].Value.ToString()))
                            {
                                DataGridViewCheckBoxCell cell6 = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                                if ((current.Cells["ZZDO_INDICATOR"].Value.ToString() != null) && (current.Cells["ZZDO_INDICATOR"].Value.ToString() == ""))
                                {
                                    cell6.Value = true;
                                }
                                flag = true;
                                break;
                            }
                        }
                    }
                    else if (from_dr)
                    {
                        foreach (DataGridViewRow row8 in (IEnumerable) this.retTable_DO.Rows)
                        {
                            if (((row8.Cells["ZDCONR"].Value.ToString() == current.Cells["ZDCONR"].Value.ToString()) && (row8.Cells["POSNR"].Value.ToString() == current.Cells["POSNR"].Value.ToString())) && (row8.Cells["POSNR_VA"].Value.ToString() == current.Cells["POSNR_VA"].Value.ToString()))
                            {
                                ((DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"]).Value = true;
                                flag = true;
                                break;
                            }
                        }
                    }
                    else if (from_dotrx)
                    {
                        foreach (DataGridViewRow row9 in (IEnumerable) this.retTable_DO.Rows)
                        {
                            if (((row9.Cells["ZDCONR"].Value.ToString() == current.Cells["ZDCONR"].Value.ToString()) && (row9.Cells["DOPLINE"].Value.ToString() == current.Cells["DOPLINE"].Value.ToString())) && (row9.Cells["POSNR"].Value.ToString() == current.Cells["POSNR"].Value.ToString()))
                            {
                                ((DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"]).Value = true;
                                flag = true;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    goto TR_008F;
                }
                goto TR_000D;
            TR_008F:
                while (true)
                {
                    if (enumerator.MoveNext())
                    {
                        current = (DataGridViewRow) enumerator.Current;
                        flag = false;
                        if (WBSetting.integrationIDSYS)
                        {
                            foreach (DataGridViewRow row2 in (IEnumerable) this.previousSelected_DOTable.Rows)
                            {
                                if ((row2.Cells["internal_number"].Value.ToString() == current.Cells["do_"].Value.ToString()) && (row2.Cells["internal_number_item"].Value.ToString() == current.Cells["do_item"].Value.ToString()))
                                {
                                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                                    cell.Value = true;
                                    if ((this.doEntryMode != "EDIT") || (this.previousSelected_DOTable.CurrentRow.Index != row2.Index))
                                    {
                                        cell.ReadOnly = true;
                                        int num = 0;
                                        while (true)
                                        {
                                            if (num >= this.dgv_do.ColumnCount)
                                            {
                                                break;
                                            }
                                            this.dgv_do[num, current.Index].Style.BackColor = Color.Gray;
                                            num++;
                                        }
                                    }
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        else if (from_do)
                        {
                            foreach (DataGridViewRow row3 in (IEnumerable) this.previousSelected_DOTable.Rows)
                            {
                                if (((row3.Cells["do_sap"].Value.ToString() == current.Cells["VBELN"].Value.ToString()) && (row3.Cells["do_sap_item"].Value.ToString() == current.Cells["POSNR"].Value.ToString())) && (row3.Cells["so_item_detail"].Value.ToString() == current.Cells["POSNR_VA"].Value.ToString()))
                                {
                                    DataGridViewCheckBoxCell cell2 = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                                    if ((current.Cells["ZZDO_INDICATOR"].Value.ToString() != null) && (current.Cells["ZZDO_INDICATOR"].Value.ToString() == ""))
                                    {
                                        if ((this.doEntryMode != "EDIT") || (this.previousSelected_DOTable.CurrentRow.Index != row3.Index))
                                        {
                                            cell2.Value = true;
                                            cell2.ReadOnly = true;
                                            int num2 = 0;
                                            while (true)
                                            {
                                                if (num2 >= this.dgv_do.ColumnCount)
                                                {
                                                    break;
                                                }
                                                this.dgv_do[num2, current.Index].Style.BackColor = Color.Gray;
                                                num2++;
                                            }
                                        }
                                    }
                                    else if ((current.Cells["ZZDO_INDICATOR"].Value.ToString() != null) && (current.Cells["ZZDO_INDICATOR"].Value.ToString() == "X"))
                                    {
                                        int num3 = 0;
                                        while (true)
                                        {
                                            if (num3 >= this.dgv_do.ColumnCount)
                                            {
                                                break;
                                            }
                                            this.dgv_do[num3, current.Index].Style.BackColor = Color.LimeGreen;
                                            this.dgv_do[num3, current.Index].Style.SelectionBackColor = Color.PaleGreen;
                                            this.dgv_do[num3, current.Index].Style.SelectionForeColor = Color.Green;
                                            num3++;
                                        }
                                    }
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        else if (from_dr)
                        {
                            foreach (DataGridViewRow row4 in (IEnumerable) this.previousSelected_DOTable.Rows)
                            {
                                if (((row4.Cells["internal_number"].Value.ToString() == current.Cells["ZDCONR"].Value.ToString()) && (row4.Cells["internal_number_item"].Value.ToString() == current.Cells["POSNR"].Value.ToString())) && (row4.Cells["so_item_detail"].Value.ToString() == current.Cells["POSNR_VA"].Value.ToString()))
                                {
                                    DataGridViewCheckBoxCell cell3 = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                                    if ((this.doEntryMode != "EDIT") || (this.previousSelected_DOTable.CurrentRow.Index != row4.Index))
                                    {
                                        cell3.Value = true;
                                        cell3.ReadOnly = true;
                                        int num4 = 0;
                                        while (true)
                                        {
                                            if (num4 >= this.dgv_do.ColumnCount)
                                            {
                                                break;
                                            }
                                            this.dgv_do[num4, current.Index].Style.BackColor = Color.Gray;
                                            num4++;
                                        }
                                    }
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        else if (from_dotrx)
                        {
                            foreach (DataGridViewRow row5 in (IEnumerable) this.previousSelected_DOTable.Rows)
                            {
                                if (((row5.Cells["internal_number"].Value.ToString() == current.Cells["ZDCONR"].Value.ToString()) && (row5.Cells["internal_number_item"].Value.ToString() == current.Cells["DOPLINE"].Value.ToString())) && (row5.Cells["so_item_detail"].Value.ToString() == current.Cells["POSNR"].Value.ToString()))
                                {
                                    DataGridViewCheckBoxCell cell4 = (DataGridViewCheckBoxCell) current.Cells["SELECTED_CHK"];
                                    if ((this.doEntryMode != "EDIT") || (this.previousSelected_DOTable.CurrentRow.Index != row5.Index))
                                    {
                                        cell4.Value = true;
                                        cell4.ReadOnly = true;
                                        int num5 = 0;
                                        while (true)
                                        {
                                            if (num5 >= this.dgv_do.ColumnCount)
                                            {
                                                break;
                                            }
                                            this.dgv_do[num5, current.Index].Style.BackColor = Color.Gray;
                                            num5++;
                                        }
                                    }
                                    flag = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                    break;
                }
                goto TR_003D;
            }
        }
    }
}

