﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepEmailRecipient : Form
    {
        private IContainer components = null;
        public Label labelProses2;
        public Label labelProses1;
        public Label labelHeader;
        private GroupBox groupBox1;
        private RadioButton radioAll;
        private RadioButton radioCurrent;
        public Button buttonClose;
        public Button buttonProcess;

        public RepEmailRecipient()
        {
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            WBTable data = this.getQuery();
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_EmailRecipient.htm";
            rep.Title = "Email Recipient Report";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>EMAIL RECIPIENT REPORT</b></font><br>");
            if (this.radioAll.Checked)
            {
                rep.Write("<br><font size=3><b>For All Company & Location</b></b></font><br>");
            }
            else if (this.radioCurrent.Checked)
            {
                string[] textArray1 = new string[] { "<br><font size=4>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", WBData.sCoyCode, ")</font>" };
                rep.Write(string.Concat(textArray1));
                string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                rep.Write(string.Concat(textArray2));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
            }
            rep.Write("<br/><br/>");
            rep.Write("<font size=2>Report Date : <b>" + DateTime.Now.ToShortDateString() + "</b></font>");
            rep.Write("<br/><br/><br/>");
            this.generateReport(rep, data);
            rep.writeSign();
            rep.Close();
            if (rep != null)
            {
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                };
                report.ShowDialog();
                rep.Dispose();
                report.Dispose();
            }
            this.labelProses1.Text = "";
            this.labelProses1.Refresh();
            this.labelProses2.Text = "";
            this.labelProses2.Refresh();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void generateReport(HTML rep, WBTable data)
        {
            int num = 1;
            string str = "";
            string str2 = "";
            int num2 = 0;
            while (num2 < data.DT.Rows.Count)
            {
                DataRow row = data.DT.Rows[num2];
                if ((str != row["coy"].ToString()) || (str2 != row["location_code"].ToString()))
                {
                    if (this.radioAll.Checked)
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        table.OpenTable("wb_company", "SELECT coy_name FROM wb_company WHERE coy_code='" + row["coy"].ToString() + "'", WBData.conn);
                        string[] textArray1 = new string[] { "SELECT location_name FROM wb_location WHERE coy = '", row["coy"].ToString(), "' AND location_code = '", row["location_code"].ToString(), "'" };
                        table2.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            rep.Write("<br><br><font size=3><b>(" + row["coy"].ToString() + ")</b></font>");
                        }
                        else
                        {
                            string[] textArray2 = new string[] { "<br><br><font size=3><b>", table.DT.Rows[0]["Coy_Name"].ToString(), " (", row["coy"].ToString(), ")</b></font>" };
                            rep.Write(string.Concat(textArray2));
                        }
                        if (table2.DT.Rows.Count <= 0)
                        {
                            rep.Write("<br><font size=3><b>(" + row["location_code"].ToString() + ")</b></font><br><br>");
                        }
                        else
                        {
                            string[] textArray3 = new string[] { "<br><font size=3><b>", table2.DT.Rows[0]["Location_Name"].ToString(), " (", row["location_code"].ToString(), ")</b></font><br><br>" };
                            rep.Write(string.Concat(textArray3));
                        }
                        table.Dispose();
                        table2.Dispose();
                    }
                    rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    rep.Write("<tr class=bd>");
                    rep.Write("<th rowspan=2>No.</th>");
                    rep.Write("<th rowspan=2>Email Code</th>");
                    rep.Write("<th rowspan=2>Subject</th>");
                    rep.Write("<th colspan=2>Email Recipient</th>");
                    rep.Write("</tr>");
                    rep.Write("<tr class=bd>");
                    rep.Write("<th>To</th>");
                    rep.Write("<th>Cc</th>");
                    rep.Write("</tr>");
                    str = row["coy"].ToString();
                    str2 = row["location_code"].ToString();
                    num = 1;
                }
                this.labelProses1.Text = data.DT.Rows.Count.ToString();
                this.labelProses1.Refresh();
                this.labelProses2.Text = row["email_code"].ToString();
                this.labelProses2.Refresh();
                rep.Write("<tr class=bd>");
                rep.Write("<td valign=top>" + num + "</td>");
                rep.Write("<td valign=top>" + row["email_code"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["subject"].ToString() + "</td>");
                char[] separator = new char[] { ',' };
                string[] strArray = row["email_to"].ToString().Split(separator);
                rep.Write("<td valign=top nowrap>");
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        rep.Write("</td>");
                        char[] chArray2 = new char[] { ',' };
                        string[] strArray2 = row["email_cc"].ToString().Split(chArray2);
                        rep.Write("<td valign=top nowrap>");
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= strArray2.Length)
                            {
                                rep.Write("</td>");
                                rep.Write("</tr>");
                                num++;
                                DataRow row2 = null;
                                if (num2 >= (data.DT.Rows.Count - 1))
                                {
                                    if (num2 == (data.DT.Rows.Count - 1))
                                    {
                                        rep.Write("</table><br><br>");
                                    }
                                }
                                else
                                {
                                    row2 = data.DT.Rows[num2 + 1];
                                    if ((row["coy"].ToString() != row2["coy"].ToString()) || (row["location_code"].ToString() != row2["location_code"].ToString()))
                                    {
                                        rep.Write("</table><br><br>");
                                    }
                                }
                                num2++;
                                break;
                            }
                            if (strArray2[num5] != "")
                            {
                                object[] objArray2 = new object[] { num5 + 1, ". ", strArray2[num5], "<br>" };
                                rep.Write(string.Concat(objArray2));
                            }
                            num5++;
                        }
                        break;
                    }
                    if (strArray[index] != "")
                    {
                        object[] objArray1 = new object[] { index + 1, ". ", strArray[index], "<br>" };
                        rep.Write(string.Concat(objArray1));
                    }
                    index++;
                }
            }
        }

        private WBTable getQuery()
        {
            WBTable table = new WBTable();
            string sqltext = "" + " SELECT * FROM wb_email_master ";
            if (this.radioCurrent.Checked)
            {
                sqltext = sqltext + " WHERE " + WBData.CompanyLocation("");
            }
            else if (this.radioAll.Checked)
            {
                sqltext = sqltext + " WHERE 1 = 1 ";
            }
            sqltext = sqltext + " ORDER BY coy, location_code, email_code ";
            table.OpenTable("wb_email_master", sqltext, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.labelHeader = new Label();
            this.groupBox1 = new GroupBox();
            this.radioCurrent = new RadioButton();
            this.radioAll = new RadioButton();
            this.buttonClose = new Button();
            this.buttonProcess = new Button();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0xfe, 0x1b);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xb2, 0x15);
            this.labelProses2.TabIndex = 0x58;
            this.labelProses2.Text = "Progress . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x101, 10);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xaf, 20);
            this.labelProses1.TabIndex = 0x59;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(12, 14);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0xd7, 20);
            this.labelHeader.TabIndex = 90;
            this.labelHeader.Text = "Report of Email Recipient";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.groupBox1.Controls.Add(this.radioAll);
            this.groupBox1.Controls.Add(this.radioCurrent);
            this.groupBox1.Location = new Point(0x23, 0x49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x174, 0x3e);
            this.groupBox1.TabIndex = 0x5b;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Generate report for";
            this.radioCurrent.AutoSize = true;
            this.radioCurrent.Checked = true;
            this.radioCurrent.Location = new Point(20, 0x1d);
            this.radioCurrent.Name = "radioCurrent";
            this.radioCurrent.Size = new Size(0x99, 0x11);
            this.radioCurrent.TabIndex = 0;
            this.radioCurrent.TabStop = true;
            this.radioCurrent.Text = "Current Compay && Location";
            this.radioCurrent.UseVisualStyleBackColor = true;
            this.radioAll.AutoSize = true;
            this.radioAll.Location = new Point(0xce, 0x1d);
            this.radioAll.Name = "radioAll";
            this.radioAll.Size = new Size(0x88, 0x11);
            this.radioAll.TabIndex = 1;
            this.radioAll.Text = "All Company && Location";
            this.radioAll.UseVisualStyleBackColor = true;
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x142, 0xa5);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x5d;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0xce, 0xa5);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 0x5c;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1c3, 0xd9);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelHeader);
            base.Name = "RepEmailRecipient";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "RepEmailRecipient";
            base.Load += new EventHandler(this.RepEmailRecipient_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepEmailRecipient_Load(object sender, EventArgs e)
        {
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }
    }
}

