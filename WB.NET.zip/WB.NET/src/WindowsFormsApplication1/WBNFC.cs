﻿namespace WindowsFormsApplication1
{
    using NFCLibrary;
    using System;
    using System.ComponentModel;

    public class WBNFC : Component
    {
        private string lastError = "";
        private reader nfcReader = new reader();

        public bool connected() => 
            this.nfcReader.connected();

        public string getAddiInfo() => 
            this.nfcReader.c_AddiInfo;

        public string getAllChar() => 
            (this.nfcReader.allChar() != "0") ? "No Data or Read All Character Error" : this.nfcReader.allCharacter;

        public string getAVG()
        {
            float num;
            return (float.TryParse(this.nfcReader.c_AVG, out num) ? this.nfcReader.c_AVG : "0");
        }

        public string getCardCode() => 
            this.nfcReader.card_code;

        public string getDeliveryDate()
        {
            DateTime now = DateTime.Now;
            if ((this.nfcReader.c_Delivery_Date != null) && (this.nfcReader.c_Delivery_Date.ToString().Trim() != ""))
            {
                try
                {
                    now = Convert.ToDateTime(this.nfcReader.c_Delivery_Date);
                }
                catch
                {
                    now = DateTime.Now;
                }
            }
            return now.ToString("dd/MM/yyyy");
        }

        public string getDeliveryTime()
        {
            DateTime now = DateTime.Now;
            if ((this.nfcReader.c_Delivery_Time != null) && (this.nfcReader.c_Delivery_Time.ToString().Trim() != ""))
            {
                try
                {
                    now = Convert.ToDateTime(this.nfcReader.c_Delivery_Time);
                }
                catch
                {
                    now = DateTime.Now;
                }
            }
            return now.ToString("HH:mm");
        }

        public string getDriverID() => 
            this.nfcReader.c_driver_id;

        public string getDriverName() => 
            this.nfcReader.c_driver_name;

        public string getEstate() => 
            this.nfcReader.c_estate;

        public string getGrossOPW()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Gross_OPW, out num) ? this.nfcReader.c_Gross_OPW : "0");
        }

        public string getNetOPW()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Net_OPW, out num) ? this.nfcReader.c_Net_OPW : "0");
        }

        public string getRegisterDate()
        {
            DateTime now = DateTime.Now;
            if ((this.nfcReader.c_Register_Date != null) && (this.nfcReader.c_Register_Date.ToString().Trim() != ""))
            {
                try
                {
                    now = Convert.ToDateTime(this.nfcReader.c_Register_Date);
                }
                catch
                {
                    now = DateTime.Now;
                }
            }
            return now.ToString("dd/MM/yyyy");
        }

        public string getRegisterTime()
        {
            DateTime now = DateTime.Now;
            if ((this.nfcReader.c_Register_Time != null) && (this.nfcReader.c_Register_Time.ToString().Trim() != ""))
            {
                try
                {
                    now = Convert.ToDateTime(this.nfcReader.c_Register_Time);
                }
                catch
                {
                    now = DateTime.Now;
                }
            }
            return now.ToString("HH:mm");
        }

        public string getRemarkReport() => 
            this.nfcReader.c_remark_report;

        public string getRemarkTicket() => 
            this.nfcReader.c_remark_ticket;

        public string getRendCPO()
        {
            float num;
            return (float.TryParse(this.nfcReader.c_RendCPO, out num) ? this.nfcReader.c_RendCPO : "0");
        }

        public string getSeal() => 
            this.nfcReader.c_SEAL;

        public string getSPB() => 
            this.nfcReader.c_spb;

        public string getTareOPW()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Tare_OPW, out num) ? this.nfcReader.c_Tare_OPW : "0");
        }

        public string getTBSRejectBunch()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Reject_FFB_Bunch, out num) ? this.nfcReader.c_Reject_FFB_Bunch : "0");
        }

        public string getTBSRejectKG()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Reject_KG, out num) ? this.nfcReader.c_Reject_KG : "0");
        }

        public string getTBSRejectReason() => 
            this.nfcReader.c_Reject_Reason;

        public string getTotalBunch()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Total_Bunch, out num) ? this.nfcReader.c_Total_Bunch : "0");
        }

        public string getTotalBunchDeduc()
        {
            double num;
            return (double.TryParse(this.nfcReader.c_Total_Bunch_Deduc, out num) ? this.nfcReader.c_Total_Bunch_Deduc : "0");
        }

        public string getTransporter() => 
            this.nfcReader.c_transporter;

        public string getTruck() => 
            this.nfcReader.c_truck_number;

        public string readCard() => 
            this.nfcReader.resultOutput();
    }
}

