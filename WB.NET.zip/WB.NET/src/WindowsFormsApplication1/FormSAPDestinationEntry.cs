﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSAPDestinationEntry : Form
    {
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public WBTable zTable;
        public int nCurrRow;
        public bool saved;
        public string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button button2;
        private Button button1;
        public TextBox textSAPDest;
        private Label label3;
        private GroupBox groupExcel;
        private Panel panel1;
        private Label label2;
        private RadioButton radioExcelYes;
        private RadioButton radioExcelNo;
        private Label label1;
        private CheckBox checkPassword;
        public TextBox textExcelPassword;
        private GroupBox groupBox1;
        private Label label4;
        private Panel panel2;
        private Label label5;
        private RadioButton radioUploadYes;
        private RadioButton radioUploadNo;
        private Label label7;
        public TextBox textUploadInterval;
        private Label label6;
        private MaskedTextBox textUploadTime;

        public FormSAPDestinationEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textSAPDest.Text.Trim() != "")
            {
                if (!(this.radioExcelYes.Checked && (this.textExcelPassword.Text.Trim() == "")))
                {
                    if (!(this.radioUploadYes.Checked && ((this.textUploadTime.Text.Trim() == "") || (this.textUploadTime.Text.Trim() == ":"))))
                    {
                        if (!(this.radioUploadYes.Checked && (this.textUploadInterval.Text.Trim() == "")))
                        {
                            if (this.pMode == "EDIT")
                            {
                                FormTransCancel cancel = new FormTransCancel {
                                    label1 = { Text = this.sapIDSYS + Resource.Menu_073 },
                                    textRefNo = { Text = this.textSAPDest.Text },
                                    Text = Resource.Title_Change_Reason,
                                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                                };
                                cancel.textReason.Focus();
                                cancel.ShowDialog();
                                if (cancel.Saved)
                                {
                                    this.changeReason = cancel.textReason.Text;
                                    cancel.Dispose();
                                }
                                else
                                {
                                    return;
                                }
                            }
                            Cursor.Current = Cursors.WaitCursor;
                            if (this.pMode == "ADD")
                            {
                                this.zTable.DR = this.zTable.DT.NewRow();
                            }
                            else
                            {
                                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                                this.logKey = this.zTable.DR["uniq"].ToString();
                                this.zTable.DR.BeginEdit();
                            }
                            this.zTable.DR["Coy"] = WBData.sCoyCode;
                            this.zTable.DR["Location_Code"] = WBData.sLocCode;
                            this.zTable.DR["SAPDest"] = this.textSAPDest.Text.Trim();
                            this.zTable.DR["protectExcel"] = this.radioExcelYes.Checked ? "Y" : "N";
                            this.zTable.DR["passwordExcel"] = Program.shoot(this.textExcelPassword.Text.Trim(), true);
                            this.zTable.DR["automaticUpload"] = this.radioUploadYes.Checked ? "Y" : "N";
                            this.zTable.DR["automaticTime"] = this.textUploadTime.Text;
                            this.zTable.DR["automaticInterval"] = this.textUploadInterval.Text;
                            if (this.pMode == "ADD")
                            {
                                this.zTable.DR["Create_By"] = WBUser.UserID;
                                this.zTable.DR["Create_Date"] = DateTime.Now;
                                this.zTable.DT.Rows.Add(this.zTable.DR);
                            }
                            else
                            {
                                this.zTable.DR["Change_By"] = WBUser.UserID;
                                this.zTable.DR["Change_Date"] = DateTime.Now;
                                this.zTable.DR.EndEdit();
                            }
                            this.zTable.Save();
                            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                            {
                                if (this.pMode == "ADD")
                                {
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_SAPDest", "SELECT uniq FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND SAPDest = '" + this.textSAPDest.Text + "'"), WBData.conn);
                                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                    table.Dispose();
                                }
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_sapDest", this.logKey, logField, logValue);
                            }
                            Cursor.Current = Cursors.Default;
                            this.saved = true;
                            base.Close();
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Warning_Upload_Interval, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textUploadInterval.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Warning_Start_Time, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.textUploadTime.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Warning_Protect_Excel, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textExcelPassword.Focus();
                }
            }
            else
            {
                MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_Warning_SAP_Destination_IDSYS : Resource.Mes_Warning_SAP_Destination, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textSAPDest.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void checkPassword_CheckedChanged(object sender, EventArgs e)
        {
            this.textExcelPassword.UseSystemPasswordChar = !this.checkPassword.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSAPDestinationEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode == "ADD")
            {
                this.textSAPDest.Text = "";
                this.radioExcelNo.Checked = true;
                this.textExcelPassword.Text = "";
                this.checkPassword.Checked = false;
                this.radioUploadNo.Checked = true;
                this.textUploadTime.Text = "0800";
                this.textUploadInterval.Text = "0.5";
                this.panel1.Enabled = false;
                this.panel2.Enabled = false;
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.textSAPDest.Text = this.zTable.DR["SAPDest"].ToString();
                if (this.zTable.DR["protectExcel"].ToString() == "Y")
                {
                    this.radioExcelYes.Checked = true;
                }
                else
                {
                    this.radioExcelNo.Checked = true;
                }
                this.panel1.Enabled = this.zTable.DR["protectExcel"].ToString() == "Y";
                this.textExcelPassword.Text = Program.shoot(this.zTable.DR["passwordExcel"].ToString(), false);
                if (this.zTable.DR["automaticUpload"].ToString() == "Y")
                {
                    this.radioUploadYes.Checked = true;
                }
                else
                {
                    this.radioUploadNo.Checked = true;
                }
                this.panel2.Enabled = this.zTable.DR["automaticUpload"].ToString() == "Y";
                this.textUploadTime.Text = (this.zTable.DR["automaticTime"].ToString() == "") ? "0800" : this.zTable.DR["automaticTime"].ToString();
                this.textUploadInterval.Text = (this.zTable.DR["automaticInterval"].ToString() == "") ? "0.5" : this.zTable.DR["automaticInterval"].ToString();
                if ((this.pMode == "EDIT") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                {
                    this.textSAPDest.Enabled = false;
                }
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
            }
            this.label3.Text = this.sapIDSYS + this.label3.Text;
            this.Text = "Entry " + this.sapIDSYS + " Destination";
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textSAPDest = new TextBox();
            this.label3 = new Label();
            this.groupExcel = new GroupBox();
            this.panel1 = new Panel();
            this.checkPassword = new CheckBox();
            this.textExcelPassword = new TextBox();
            this.label2 = new Label();
            this.radioExcelYes = new RadioButton();
            this.radioExcelNo = new RadioButton();
            this.label1 = new Label();
            this.groupBox1 = new GroupBox();
            this.panel2 = new Panel();
            this.label7 = new Label();
            this.textUploadInterval = new TextBox();
            this.label6 = new Label();
            this.textUploadTime = new MaskedTextBox();
            this.label5 = new Label();
            this.radioUploadYes = new RadioButton();
            this.radioUploadNo = new RadioButton();
            this.label4 = new Label();
            this.groupExcel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(310, 0x128);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x37;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0xd8, 0x128);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x36;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textSAPDest.CharacterCasing = CharacterCasing.Upper;
            this.textSAPDest.Location = new Point(140, 0x13);
            this.textSAPDest.Name = "textSAPDest";
            this.textSAPDest.Size = new Size(0xf5, 20);
            this.textSAPDest.TabIndex = 0x3a;
            this.label3.Location = new Point(0x16, 0x16);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x65, 0x11);
            this.label3.TabIndex = 0x3b;
            this.label3.Text = " Destination";
            this.groupExcel.Controls.Add(this.panel1);
            this.groupExcel.Controls.Add(this.radioExcelYes);
            this.groupExcel.Controls.Add(this.radioExcelNo);
            this.groupExcel.Controls.Add(this.label1);
            this.groupExcel.Location = new Point(0x19, 0x43);
            this.groupExcel.Name = "groupExcel";
            this.groupExcel.Size = new Size(360, 0x63);
            this.groupExcel.TabIndex = 60;
            this.groupExcel.TabStop = false;
            this.groupExcel.Text = "Excel Template Configuration";
            this.panel1.Controls.Add(this.checkPassword);
            this.panel1.Controls.Add(this.textExcelPassword);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new Point(12, 0x35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x14b, 0x20);
            this.panel1.TabIndex = 0x3e;
            this.checkPassword.AutoSize = true;
            this.checkPassword.Location = new Point(0xe0, 9);
            this.checkPassword.Name = "checkPassword";
            this.checkPassword.Size = new Size(0x66, 0x11);
            this.checkPassword.TabIndex = 0x40;
            this.checkPassword.Text = "Show Password";
            this.checkPassword.UseVisualStyleBackColor = true;
            this.checkPassword.CheckedChanged += new EventHandler(this.checkPassword_CheckedChanged);
            this.textExcelPassword.Location = new Point(0x47, 6);
            this.textExcelPassword.Name = "textExcelPassword";
            this.textExcelPassword.Size = new Size(0x89, 20);
            this.textExcelPassword.TabIndex = 0x3d;
            this.textExcelPassword.UseSystemPasswordChar = true;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(3, 9);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 0x3f;
            this.label2.Text = "Password";
            this.radioExcelYes.AutoSize = true;
            this.radioExcelYes.Location = new Point(0x110, 0x1c);
            this.radioExcelYes.Name = "radioExcelYes";
            this.radioExcelYes.Size = new Size(0x2b, 0x11);
            this.radioExcelYes.TabIndex = 0x3d;
            this.radioExcelYes.Text = "Yes";
            this.radioExcelYes.UseVisualStyleBackColor = true;
            this.radioExcelYes.CheckedChanged += new EventHandler(this.radioExcelYes_CheckedChanged);
            this.radioExcelNo.AutoSize = true;
            this.radioExcelNo.Checked = true;
            this.radioExcelNo.Location = new Point(0xd9, 0x1c);
            this.radioExcelNo.Name = "radioExcelNo";
            this.radioExcelNo.Size = new Size(0x27, 0x11);
            this.radioExcelNo.TabIndex = 0x3d;
            this.radioExcelNo.TabStop = true;
            this.radioExcelNo.Text = "No";
            this.radioExcelNo.UseVisualStyleBackColor = true;
            this.radioExcelNo.CheckedChanged += new EventHandler(this.radioExcelNo_CheckedChanged);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x10, 30);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0xb6, 13);
            this.label1.TabIndex = 0x3d;
            this.label1.Text = "Protect excel template with password";
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.radioUploadYes);
            this.groupBox1.Controls.Add(this.radioUploadNo);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new Point(0x19, 0xb5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(360, 0x63);
            this.groupBox1.TabIndex = 0x3d;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Automatic Upload Configuration";
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textUploadInterval);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textUploadTime);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new Point(12, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x14b, 0x21);
            this.panel2.TabIndex = 0x41;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x71, 9);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x55, 13);
            this.label7.TabIndex = 0x42;
            this.label7.Text = "with interval time";
            this.textUploadInterval.CharacterCasing = CharacterCasing.Upper;
            this.textUploadInterval.Location = new Point(0xd0, 6);
            this.textUploadInterval.Name = "textUploadInterval";
            this.textUploadInterval.Size = new Size(0x24, 20);
            this.textUploadInterval.TabIndex = 0x41;
            this.textUploadInterval.Text = "0.5";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(250, 9);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x1c, 13);
            this.label6.TabIndex = 0x42;
            this.label6.Text = "hour";
            this.textUploadTime.Location = new Point(0x47, 6);
            this.textUploadTime.Mask = "00:00";
            this.textUploadTime.Name = "textUploadTime";
            this.textUploadTime.Size = new Size(0x24, 20);
            this.textUploadTime.TabIndex = 0x41;
            this.textUploadTime.Text = "0800";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(3, 9);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x29, 13);
            this.label5.TabIndex = 0x3f;
            this.label5.Text = "Start at";
            this.radioUploadYes.AutoSize = true;
            this.radioUploadYes.Location = new Point(0xf7, 0x1a);
            this.radioUploadYes.Name = "radioUploadYes";
            this.radioUploadYes.Size = new Size(0x2b, 0x11);
            this.radioUploadYes.TabIndex = 0x3f;
            this.radioUploadYes.Text = "Yes";
            this.radioUploadYes.UseVisualStyleBackColor = true;
            this.radioUploadYes.CheckedChanged += new EventHandler(this.radioUploadYes_CheckedChanged);
            this.radioUploadNo.AutoSize = true;
            this.radioUploadNo.Checked = true;
            this.radioUploadNo.Location = new Point(0xbf, 0x1a);
            this.radioUploadNo.Name = "radioUploadNo";
            this.radioUploadNo.Size = new Size(0x27, 0x11);
            this.radioUploadNo.TabIndex = 0x3f;
            this.radioUploadNo.TabStop = true;
            this.radioUploadNo.Text = "No";
            this.radioUploadNo.UseVisualStyleBackColor = true;
            this.radioUploadNo.CheckedChanged += new EventHandler(this.radioUploadNo_CheckedChanged);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x10, 0x1c);
            this.label4.Name = "label4";
            this.label4.Size = new Size(160, 13);
            this.label4.TabIndex = 0x3f;
            this.label4.Text = "Upload transaction automatically";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x19e, 340);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.groupExcel);
            base.Controls.Add(this.textSAPDest);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormSAPDestinationEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry SAP Destination";
            base.Load += new EventHandler(this.FormSAPDestinationEntry_Load);
            this.groupExcel.ResumeLayout(false);
            this.groupExcel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioExcelNo_CheckedChanged(object sender, EventArgs e)
        {
            this.panel1.Enabled = false;
        }

        private void radioExcelYes_CheckedChanged(object sender, EventArgs e)
        {
            this.panel1.Enabled = true;
        }

        private void radioUploadNo_CheckedChanged(object sender, EventArgs e)
        {
            this.panel2.Enabled = false;
        }

        private void radioUploadYes_CheckedChanged(object sender, EventArgs e)
        {
            this.panel2.Enabled = true;
        }

        private void translate()
        {
            this.label3.Text = this.sapIDSYS + Resource.Menu_073;
            this.groupExcel.Text = Resource.Gbx_Excel_Config;
            this.label1.Text = Resource.Col_Protect_Excel;
            this.radioExcelYes.Text = Resource.Setting_095;
            this.radioExcelNo.Text = Resource.Setting_094;
            this.label2.Text = Resource.User_006;
            this.checkPassword.Text = Resource.Chk_Show_Password;
            this.groupBox1.Text = Resource.Gbx_Auto_Upload_Config;
            this.label4.Text = Resource.Lbl_Auto_Upload;
            this.radioUploadYes.Text = Resource.Setting_095;
            this.radioUploadNo.Text = Resource.Setting_094;
            this.label5.Text = Resource.Setting_156;
            this.label7.Text = Resource.Lbl_With_Interval;
            this.label6.Text = Resource.Setting_100;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.Text = WBSetting.integrationIDSYS ? Resource.Title_SAP_Destination_Entry_IDSYS : Resource.Title_SAP_Destination_Entry;
        }
    }
}

