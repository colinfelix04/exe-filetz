﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormCommTrx : Form
    {
        public WBTable tContractGRCust = new WBTable();
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private PageSetupDialog pageSetupDialog1;
        private MenuStrip menuStrip1;
        private DataGridView dgContractGRCust;
        private ToolStripMenuItem synchToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;

        public FormCommTrx()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCommTrx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCommTrx_Load(object sender, EventArgs e)
        {
            this.tContractGRCust.OpenTable("wb_ContractGrCust", "Select * From wb_contract_GRCust where 1=1", WBData.conn);
            this.dgContractGRCust.DataSource = this.tContractGRCust.DV;
            this.dgContractGRCust.Columns["uniq"].Visible = false;
            this.synchToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
        }

        private void InitializeComponent()
        {
            this.pageSetupDialog1 = new PageSetupDialog();
            this.menuStrip1 = new MenuStrip();
            this.synchToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dgContractGRCust = new DataGridView();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgContractGRCust).BeginInit();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.synchToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x1f6, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.synchToolStripMenuItem.Name = "synchToolStripMenuItem";
            this.synchToolStripMenuItem.Size = new Size(0x33, 20);
            this.synchToolStripMenuItem.Text = "Synch";
            this.synchToolStripMenuItem.Click += new EventHandler(this.synchToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dgContractGRCust.AllowUserToAddRows = false;
            this.dgContractGRCust.AllowUserToDeleteRows = false;
            this.dgContractGRCust.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgContractGRCust.Dock = DockStyle.Fill;
            this.dgContractGRCust.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgContractGRCust.Location = new Point(0, 0x18);
            this.dgContractGRCust.MultiSelect = false;
            this.dgContractGRCust.Name = "dgContractGRCust";
            this.dgContractGRCust.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgContractGRCust.Size = new Size(0x1f6, 0x163);
            this.dgContractGRCust.TabIndex = 1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f6, 0x17b);
            base.ControlBox = false;
            base.Controls.Add(this.dgContractGRCust);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormCommTrx";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Comm - Trx Type for GR Cust Required";
            base.Load += new EventHandler(this.FormCommTrx_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommTrx_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgContractGRCust).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void synchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WBSAP.connect())
            {
                try
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_MAP_COMM_TRX");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    WBSAP.sendZWB();
                    int num = 0;
                    this.tContractGRCust.ReOpen();
                    foreach (DataRow row in this.tContractGRCust.DT.Rows)
                    {
                        row.Delete();
                        num++;
                    }
                    this.tContractGRCust.Save();
                    if (WBSAP.rfcTable.RowCount <= 0)
                    {
                        MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                    }
                    else
                    {
                        this.tContractGRCust.ReOpen();
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 < WBSAP.rfcTable.RowCount)
                            {
                                if (WBSAP.rfcTable[num2].GetValue("NOT_EXIST").ToString() != "X")
                                {
                                    this.tContractGRCust.DR = this.tContractGRCust.DT.NewRow();
                                    this.tContractGRCust.DR["Comm_code"] = WBSAP.rfcTable[num2].GetValue("COMM").ToString();
                                    this.tContractGRCust.DR["Transaction_code"] = WBSAP.rfcTable[num2].GetValue("STATUS").ToString();
                                    this.tContractGRCust.DT.Rows.Add(this.tContractGRCust.DR);
                                    num2++;
                                    continue;
                                }
                                MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                                return;
                            }
                            else
                            {
                                this.tContractGRCust.Save();
                                this.tContractGRCust.ReOpen();
                            }
                            break;
                        }
                    }
                    this.dgContractGRCust.DataSource = this.tContractGRCust.DV;
                    this.dgContractGRCust.Refresh();
                    if (!WBSetting.activeMulesoftIntegration)
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_SYNC_SET");
                        WBSAP.rfcFunction.SetValue("P_BUKRS", WBData.sCoyCode);
                        WBSAP.rfcFunction.SetValue("P_ZWB_LOC", WBData.sLocCode);
                        WBSAP.rfcFunction.SetValue("P_CDESC", WBData.sCoyName + " " + WBSetting.sLocName);
                        WBSAP.sendZWB();
                        MessageBox.Show(Resource.Mes_223);
                    }
                    else
                    {
                        WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                        List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                        Dictionary<string, string> item = new Dictionary<string, string> {
                            { 
                                "P_BUKRS",
                                WBData.sCoyCode
                            },
                            { 
                                "P_ZWB_LOC",
                                WBData.sLocCode
                            },
                            { 
                                "P_CDESC",
                                WBData.sCoyName + " " + WBSetting.sLocName
                            }
                        };
                        sentTable.Add(item);
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_SYNC_SET");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary2 = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary2["ERRORS"].Count <= 0)
                                {
                                    MessageBox.Show(Resource.Mes_223);
                                }
                                else
                                {
                                    MessageBox.Show("Error from SAP : \n\n" + dictionary2["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                        }
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception2)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception4)
                {
                    MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void translate()
        {
            this.synchToolStripMenuItem.Text = Resource.Menu_Synch;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.Text = Resource.Title_Comm_Trx;
        }
    }
}

