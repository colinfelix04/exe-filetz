﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSPBEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string pDo_No;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public DataGridView dataGridView1;
        public int sUniq = 0;
        private IContainer components = null;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox3;
        private Label label3;
        private Button button2;
        private Button button1;

        public FormSPBEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.Compare(this.textBox2.Text.Trim(), this.textBox3.Text.Trim()) <= 0)
            {
                if (this.pMode == "EDIT")
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Lbl_DO_Delivery_Note },
                        textRefNo = { Text = this.textBox1.Text },
                        Text = Resource.Title_Change_Reason,
                        label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                    }
                    else
                    {
                        return;
                    }
                }
                Cursor.Current = Cursors.WaitCursor;
                WBTable table = new WBTable();
                table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note Where ( uniq='" + this.sUniq.ToString() + "')", WBData.conn);
                if (this.pMode == "ADD")
                {
                    table.DR = table.DT.NewRow();
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                }
                table.DR["Do_No"] = this.textBox1.Text;
                table.DR["Delivery_Note_From"] = this.textBox2.Text;
                table.DR["Delivery_Note_To"] = this.textBox3.Text;
                if (this.pMode == "ADD")
                {
                    table.DR["Create_By"] = WBUser.UserID;
                    table.DR["Create_Date"] = DateTime.Now;
                    table.DT.Rows.Add(table.DR);
                }
                else
                {
                    table.DR["Change_By"] = WBUser.UserID;
                    table.DR["Change_Date"] = DateTime.Now;
                    table.DR.EndEdit();
                }
                table.Save();
                if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                {
                    if (this.pMode == "ADD")
                    {
                        string sqltext = (("SELECT uniq FROM wb_delivery_note" + " WHERE do_no = '" + this.textBox1.Text + "'") + " AND delivery_note_from = '" + this.textBox2.Text + "'") + " AND delivery_note_to = '" + this.textBox3.Text + "'";
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_delivery_note", sqltext, WBData.conn);
                        this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                        table2.Dispose();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_delivery_note", this.logKey, logField, logValue);
                }
                table.Dispose();
                Cursor.Current = Cursors.Default;
                this.saved = true;
                base.Close();
            }
            else
            {
                this.textBox3.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSPBEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSPBEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.textBox1.Text = this.pDo_No;
            if (this.pMode != "ADD")
            {
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Delivery_Note_From"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Delivery_Note_To"].Value.ToString();
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.label2 = new Label();
            this.textBox3 = new TextBox();
            this.label3 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            base.SuspendLayout();
            this.label1.Location = new Point(0x12, 0x18);
            this.label1.Name = "label1";
            this.label1.Size = new Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "DO No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textBox1.Location = new Point(0x54, 0x15);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new Size(0xd9, 20);
            this.textBox1.TabIndex = 1;
            this.textBox2.Location = new Point(0x54, 0x2f);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x72, 20);
            this.textBox2.TabIndex = 3;
            this.label2.Location = new Point(0x12, 50);
            this.label2.Name = "label2";
            this.label2.Size = new Size(60, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "From";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.textBox3.Location = new Point(0x54, 0x49);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x72, 20);
            this.textBox3.TabIndex = 5;
            this.label3.Location = new Point(0x12, 0x4c);
            this.label3.Name = "label3";
            this.label3.Size = new Size(60, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.button2.Location = new Point(0xe2, 0x74);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 10;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x7f, 0x74);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 9;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x13d, 0x94);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label1);
            base.Name = "FormSPBEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormSPBEntry";
            base.Load += new EventHandler(this.FormSPBEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSPBEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Main_018;
            this.label2.Text = Resource.Setting_046;
            this.label3.Text = Resource.Setting_053;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
            this.Text = Resource.Title_Form_SPB_Entry;
        }
    }
}

