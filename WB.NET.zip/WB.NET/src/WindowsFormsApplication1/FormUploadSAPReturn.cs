﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUploadSAPReturn : Form
    {
        public DataTable aTable;
        private DataRow aRow;
        private string[] retValue = new string[5];
        public string sortBy = "ASC";
        private IContainer components = null;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem exportExcelToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;

        public FormUploadSAPReturn()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
            base.Dispose();
        }

        private void exportExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.export2Excel(this.dataGridView1, "", "", false);
        }

        private void fillDG()
        {
            int num = 0;
            while (num < this.aTable.Rows.Count)
            {
                this.aRow = this.aTable.Rows[num];
                int index = 0;
                while (true)
                {
                    if (index >= this.aTable.Columns.Count)
                    {
                        this.dataGridView1.Sort(this.dataGridView1.Columns[0], (this.sortBy == "DESC") ? ListSortDirection.Descending : ListSortDirection.Ascending);
                        this.dataGridView1.Rows.Add(this.retValue);
                        num++;
                        break;
                    }
                    try
                    {
                        this.retValue[index] = this.aRow[index].ToString();
                    }
                    catch (Exception)
                    {
                    }
                    index++;
                }
            }
        }

        private void FormReturnSAP_Load(object sender, EventArgs e)
        {
            this.setDG();
            this.fillDG();
        }

        private void FormUploadSAPReturn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
                base.Dispose();
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.exportExcelToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new Size(0x214, 0x141);
            this.dataGridView1.TabIndex = 0;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.exportExcelToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x214, 0x18);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.exportExcelToolStripMenuItem.Name = "exportExcelToolStripMenuItem";
            this.exportExcelToolStripMenuItem.Size = new Size(0x51, 20);
            this.exportExcelToolStripMenuItem.Text = "Export Excel";
            this.exportExcelToolStripMenuItem.Click += new EventHandler(this.exportExcelToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x214, 0x159);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormUploadSAPReturn";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormReturnSAP";
            base.Load += new EventHandler(this.FormReturnSAP_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUploadSAPReturn_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void setDG()
        {
            DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Ref",
                HeaderText = "Ref"
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Stts",
                HeaderText = "Status"
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Rmrk",
                HeaderText = "Remark"
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "rpst",
                HeaderText = "Repost"
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "MsgID",
                HeaderText = "Mulesosft Return ID",
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
        }
    }
}

