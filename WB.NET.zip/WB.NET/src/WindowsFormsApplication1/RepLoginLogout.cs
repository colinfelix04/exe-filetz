﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class RepLoginLogout : Form
    {
        private IContainer components = null;
        public Label labelHeader;
        public Label labelProses2;
        public Label labelProses1;
        private Panel panel1;
        public RadioButton radioMenu;
        public RadioButton radioCode;
        public GroupBox groupBox3;
        public DateTimePicker monthCalendar1;
        public Label labelFromDate;
        public Label labelToDate;
        public DateTimePicker monthCalendar2;
        private TextBox textCode;
        private Button buttonCode;
        public Button buttonClose;
        public Button buttonProcess;

        public RepLoginLogout()
        {
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonCode_Click(object sender, EventArgs e)
        {
            FormUser user = new FormUser {
                pMode = "CHOOSE"
            };
            user.ShowDialog();
            if (user.ReturnRow != null)
            {
                this.textCode.Text = user.ReturnRow["User_ID"].ToString();
                this.textCode.Focus();
            }
            user.Dispose();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.radioCode.Checked && (this.textCode.Text == ""))
            {
                MessageBox.Show("Please enter user ID!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textCode.Focus();
            }
            else if (Math.Abs((this.monthCalendar1.Value - this.monthCalendar2.Value).Days) > Math.Abs(90))
            {
                MessageBox.Show("Date interval must be less than 3 months", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(this.radioMenu.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textCode.Text, WBData.sCoyCode, WBData.sLocCode);
                if (html != null)
                {
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(bool byDate, DateTime dateFrom, DateTime dateTo, string code, string coy, string loc)
        {
            HTML html2;
            WBTable table = this.getSQL(byDate, dateFrom, dateTo, code, coy, loc);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                html2 = null;
            }
            else
            {
                HTML html = new HTML();
                string path = html.File + @"\LogReport";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                HTML html3 = html;
                string[] textArray1 = new string[] { html3.File, @"\LogReport\", coy, loc, "USERLOGINLOGOUT_", dateFrom.ToString("ddMMyyyy"), ".htm" };
                html3.File = string.Concat(textArray1);
                html.Title = "Log of User Login/Logout";
                html.Open();
                html.Write(html.Style());
                html.Write("<br><font size=5><b>LOG OF USER LOGIN/LOGOUT</b></font><br>");
                string[] textArray2 = new string[] { "<br><font size=4><b>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", coy, ")</b></font>" };
                html.Write(string.Concat(textArray2));
                string[] textArray3 = new string[] { "<br><font size=4><b>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", loc, ")</b></font><br>" };
                html.Write(string.Concat(textArray3));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
                html.Write("<br><br>");
                html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                if (this.radioCode.Checked && (this.textCode.Text.Trim() != ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>User ID</td>");
                    html.Write("<td>: <b>" + this.textCode.Text + "</b></td>");
                    html.Write("</tr>");
                }
                else if (this.radioMenu.Checked)
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Selected Date</td>");
                    string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                    html.Write(string.Concat(textArray4));
                    html.Write("</tr>");
                }
                html.Write("<tr class=bd>");
                html.Write("<td>Report Date</td>");
                html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                html.Write("</tr>");
                html.Write("</table>");
                html.Write("<br/><br/><br/>");
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class=bd>");
                html.Write("<th>No</th>");
                html.Write("<th>User ID</th>");
                html.Write("<th>Purpose</th>");
                html.Write("<th>Result</th>");
                html.Write("<th>Fail Reason</th>");
                html.Write("<th>IP</th>");
                html.Write("<th>Computer Name</th>");
                html.Write("<th>Date/time</th>");
                html.Write("</tr>");
                int num = 1;
                foreach (DataRow row in table.DT.Rows)
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td align='right'>" + num + "</td>");
                    WBTable table2 = new WBTable();
                    string[] textArray5 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND uniq = '", row["keyField"].ToString(), "'" };
                    table2.OpenTable("wb_user", string.Concat(textArray5), WBData.conn);
                    html.Write("<td>" + table2.DT.Rows[0]["user_id"].ToString() + "</td>");
                    this.labelProses1.Text = num.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = table2.DT.Rows[0]["user_id"].ToString();
                    this.labelProses2.Refresh();
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE keyHeader = '" + row["uniq"].ToString() + "'", WBData.conn);
                    bool flag8 = false;
                    foreach (DataRow row2 in table3.DT.Rows)
                    {
                        if (row2["fieldName"].ToString().ToLower() == "lastlogin")
                        {
                            flag8 = true;
                            break;
                        }
                    }
                    if (!flag8)
                    {
                        string[] aField = new string[] { "fieldName" };
                        string[] aFind = new string[] { "lastlogoutip" };
                        DataRow data = table3.GetData(aField, aFind);
                        string[] textArray18 = new string[] { "fieldName" };
                        string[] textArray19 = new string[] { "lastlogoutcompname" };
                        DataRow row9 = table3.GetData(textArray18, textArray19);
                        string[] textArray20 = new string[] { "fieldName" };
                        string[] textArray21 = new string[] { "lastlogout" };
                        DataRow row10 = table3.GetData(textArray20, textArray21);
                        html.Write("<td align='center'>Logout</td>");
                        html.Write("<td align='center'>Success</td>");
                        html.Write("<td align='center'>-</td>");
                        html.Write("<td align='center'>" + data["newValue"].ToString().Substring(8) + "</td>");
                        html.Write("<td align='center'>" + row9["newValue"].ToString().Substring(8) + "</td>");
                        html.Write("<td>" + row10["newValue"].ToString() + "</td>");
                    }
                    else
                    {
                        string[] aField = new string[] { "fieldName" };
                        string[] aFind = new string[] { "lastloginresult" };
                        DataRow data = table3.GetData(aField, aFind);
                        string[] textArray8 = new string[] { "fieldName" };
                        string[] textArray9 = new string[] { "lastloginip" };
                        DataRow row4 = table3.GetData(textArray8, textArray9);
                        string[] textArray10 = new string[] { "fieldName" };
                        string[] textArray11 = new string[] { "lastlogincompname" };
                        DataRow row5 = table3.GetData(textArray10, textArray11);
                        string[] textArray12 = new string[] { "fieldName" };
                        string[] textArray13 = new string[] { "lastlogin" };
                        DataRow row6 = table3.GetData(textArray12, textArray13);
                        string[] textArray14 = new string[] { "fieldName" };
                        string[] textArray15 = new string[] { "lastloginfailedreason" };
                        DataRow objA = table3.GetData(textArray14, textArray15);
                        html.Write("<td align='center'>Login</td>");
                        if (data["newValue"].ToString().Substring(8) == "S")
                        {
                            html.Write("<td align='center'>Success</td>");
                        }
                        else if (data["newValue"].ToString().Substring(8) == "F")
                        {
                            html.Write("<td align='center'>Fail</td>");
                        }
                        if (ReferenceEquals(objA, null))
                        {
                            html.Write("<td align='center'>-</td>");
                        }
                        else
                        {
                            html.Write("<td align='center'>" + objA["newValue"].ToString().Substring(8) + "</td>");
                        }
                        html.Write("<td align='center'>" + row4["newValue"].ToString().Substring(8) + "</td>");
                        html.Write("<td align='center'>" + row5["newValue"].ToString().Substring(8) + "</td>");
                        html.Write("<td>" + row6["newValue"].ToString() + "</td>");
                    }
                    html.Write("</tr>");
                    num++;
                    table2.Dispose();
                    table3.Dispose();
                }
                html.Write("</table>");
                html.Write("<br><br>");
                html.Write("<br>");
                html.Write("<br>");
                html.writeSign();
                html.Close();
                html2 = html;
            }
            return html2;
        }

        public WBTable getSQL(bool byDate, DateTime dateFrom, DateTime dateTo, string code, string coy, string loc)
        {
            string sqltext = "";
            string[] textArray1 = new string[] { "SELECT * FROM wb_log_header WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
            sqltext = ((string.Concat(textArray1) + " AND TableName = 'wb_user' " + " AND Type = 'U' ") + " AND PMode is not null " + " AND UserID is not null ") + " AND ChangeReason is not null " + " AND pMode = 'LOGSYS' ";
            if (byDate)
            {
                sqltext = ((sqltext + " AND (substring(convert(varchar, logDate, 120), 0, 11)>='" + dateFrom.ToString("yyyy-MM-dd") + "'") + " AND substring(convert(varchar, logdate, 120), 0, 11)<='" + dateTo.ToString("yyyy-MM-dd") + "')") + " ORDER BY keyField, logDate, uniq ASC";
            }
            else
            {
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_user", "SELECT uniq FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + code.Trim() + "'"), WBData.conn);
                sqltext = (sqltext + " AND keyField = '" + table2.DT.Rows[0]["uniq"].ToString() + "'") + " ORDER BY keyField, uniq ASC";
                table2.Dispose();
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_log_header", sqltext, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            this.labelHeader = new Label();
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.panel1 = new Panel();
            this.radioMenu = new RadioButton();
            this.radioCode = new RadioButton();
            this.groupBox3 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.labelFromDate = new Label();
            this.labelToDate = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.textCode = new TextBox();
            this.buttonCode = new Button();
            this.buttonClose = new Button();
            this.buttonProcess = new Button();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            base.SuspendLayout();
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(12, 13);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0xd5, 20);
            this.labelHeader.TabIndex = 0x58;
            this.labelHeader.Text = "Log of User Login/Logout";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0xe4, 0x19);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x59;
            this.labelProses2.Text = "Progress . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0xe7, 12);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 90;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.panel1.Controls.Add(this.radioMenu);
            this.panel1.Controls.Add(this.radioCode);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.textCode);
            this.panel1.Controls.Add(this.buttonCode);
            this.panel1.Location = new Point(0x10, 0x39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x1aa, 0x6d);
            this.panel1.TabIndex = 0x63;
            this.radioMenu.AutoSize = true;
            this.radioMenu.Checked = true;
            this.radioMenu.Location = new Point(3, 3);
            this.radioMenu.Name = "radioMenu";
            this.radioMenu.Size = new Size(0x3f, 0x11);
            this.radioMenu.TabIndex = 0x59;
            this.radioMenu.TabStop = true;
            this.radioMenu.Text = "By Date";
            this.radioMenu.UseVisualStyleBackColor = true;
            this.radioMenu.CheckedChanged += new EventHandler(this.radioMenu_CheckedChanged);
            this.radioCode.AutoSize = true;
            this.radioCode.Location = new Point(3, 0x52);
            this.radioCode.Name = "radioCode";
            this.radioCode.Size = new Size(0x4c, 0x11);
            this.radioCode.TabIndex = 90;
            this.radioCode.Text = "By User ID";
            this.radioCode.UseVisualStyleBackColor = true;
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.labelFromDate);
            this.groupBox3.Controls.Add(this.labelToDate);
            this.groupBox3.Controls.Add(this.monthCalendar2);
            this.groupBox3.Location = new Point(0x11, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x187, 0x2c);
            this.groupBox3.TabIndex = 80;
            this.groupBox3.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x56, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelFromDate.AutoSize = true;
            this.labelFromDate.Location = new Point(14, 0x12);
            this.labelFromDate.Name = "labelFromDate";
            this.labelFromDate.Size = new Size(0x3e, 13);
            this.labelFromDate.TabIndex = 3;
            this.labelFromDate.Text = "From Date :";
            this.labelToDate.AutoSize = true;
            this.labelToDate.Location = new Point(0xd3, 0x12);
            this.labelToDate.Name = "labelToDate";
            this.labelToDate.Size = new Size(0x34, 13);
            this.labelToDate.TabIndex = 4;
            this.labelToDate.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x10d, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.textCode.Enabled = false;
            this.textCode.Location = new Point(0x55, 0x51);
            this.textCode.Name = "textCode";
            this.textCode.Size = new Size(0x98, 20);
            this.textCode.TabIndex = 0x58;
            this.buttonCode.Enabled = false;
            this.buttonCode.Location = new Point(0xef, 0x4f);
            this.buttonCode.Name = "buttonCode";
            this.buttonCode.Size = new Size(0x19, 0x17);
            this.buttonCode.TabIndex = 0x58;
            this.buttonCode.Text = "...";
            this.buttonCode.UseVisualStyleBackColor = true;
            this.buttonCode.Click += new EventHandler(this.buttonCode_Click);
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x14c, 0xbc);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x65;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0xd8, 0xbc);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 100;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1cf, 0xf2);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelHeader);
            base.Name = "RepLoginLogout";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "User Login/Logout Log Report";
            base.Load += new EventHandler(this.RepLoginLogout_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioMenu_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioMenu.Checked)
            {
                this.textCode.Text = "";
                this.textCode.Enabled = false;
                this.buttonCode.Enabled = false;
                this.groupBox3.Enabled = true;
            }
            else
            {
                this.textCode.Text = "";
                this.textCode.Enabled = true;
                this.buttonCode.Enabled = true;
                this.groupBox3.Enabled = false;
            }
        }

        private void RepLoginLogout_Load(object sender, EventArgs e)
        {
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_user", "Select user_id from wb_user WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(tbl, "user_id", this.textCode);
            tbl.Dispose();
        }
    }
}

