﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransQCItem : Form
    {
        public bool pSave = false;
        private IContainer components = null;
        public Button button2;
        public Button button1;
        public TextBox textBox2;
        public TextBox textBox1;
        public Label label2;
        public Label label1;
        public TextBox textEstateVal;
        public Label label3;
        public TextBox textFactoryVal;
        public Label label4;

        public FormTransQCItem()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.pSave = true;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransQCItem_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransQCItem_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.textEstateVal.Text.Trim() == "")
            {
                this.textEstateVal.Text = "0";
            }
            if (this.textFactoryVal.Text.Trim() == "")
            {
                this.textFactoryVal.Text = "0";
            }
            if (!WBUser.CheckTrustee("TRANS_QC", "E"))
            {
                this.textEstateVal.Enabled = true;
                this.textFactoryVal.Enabled = false;
            }
            else
            {
                this.textEstateVal.Enabled = false;
                this.textFactoryVal.Enabled = true;
            }
            if (Convert.ToInt16(WBUser.UserLevel) < 3)
            {
                this.textEstateVal.Enabled = true;
                this.textFactoryVal.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.textEstateVal = new TextBox();
            this.label3 = new Label();
            this.textFactoryVal = new TextBox();
            this.label4 = new Label();
            base.SuspendLayout();
            this.button2.Location = new Point(0x150, 0x73);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0xed, 0x73);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x4e, 0x24);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x14d, 20);
            this.textBox2.TabIndex = 1;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x4e, 12);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 0;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x13, 0x27);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 0x4e;
            this.label2.Text = "QC Name";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x16, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(50, 13);
            this.label1.TabIndex = 0x4d;
            this.label1.Text = "QC Code";
            this.textEstateVal.CharacterCasing = CharacterCasing.Upper;
            this.textEstateVal.Location = new Point(0x4e, 0x3e);
            this.textEstateVal.MaxLength = 20;
            this.textEstateVal.Name = "textEstateVal";
            this.textEstateVal.Size = new Size(0x3e, 20);
            this.textEstateVal.TabIndex = 2;
            this.textEstateVal.Text = "0";
            this.textEstateVal.TextAlign = HorizontalAlignment.Right;
            this.textEstateVal.Leave += new EventHandler(this.textBox3_Leave);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x23, 0x41);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x25, 13);
            this.label3.TabIndex = 80;
            this.label3.Text = "Estate";
            this.textFactoryVal.CharacterCasing = CharacterCasing.Upper;
            this.textFactoryVal.Location = new Point(0x4e, 0x58);
            this.textFactoryVal.MaxLength = 20;
            this.textFactoryVal.Name = "textFactoryVal";
            this.textFactoryVal.Size = new Size(0x3e, 20);
            this.textFactoryVal.TabIndex = 3;
            this.textFactoryVal.Text = "0";
            this.textFactoryVal.TextAlign = HorizontalAlignment.Right;
            this.textFactoryVal.Leave += new EventHandler(this.textBox4_Leave);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x23, 0x5b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2a, 13);
            this.label4.TabIndex = 0x52;
            this.label4.Text = "Factory";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1b2, 0x95);
            base.ControlBox = false;
            base.Controls.Add(this.textFactoryVal);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textEstateVal);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormTransQCItem";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTransQCItem";
            base.Load += new EventHandler(this.FormTransQCItem_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransQCItem_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textEstateVal);
            this.textEstateVal.Text = $"{Convert.ToDouble(this.textEstateVal.Text):N3}";
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textFactoryVal);
            this.textFactoryVal.Text = $"{Convert.ToDouble(this.textFactoryVal.Text):N3}";
        }
    }
}

