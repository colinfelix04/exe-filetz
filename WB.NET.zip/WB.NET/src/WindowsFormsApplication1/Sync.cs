﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class Sync : Component
    {
        public static string where_con = WBData.CompanyLocation(" AND (zwb IS NULL OR zwb <> 'Y')");

        public static string[] get_OPW_fromSAP(string no_ref, bool zAuto)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable table3 = new DataTable();
            string[] values = new string[2];
            string[] strArray2 = new string[3];
            DataColumn column = new DataColumn {
                ColumnName = "WREF"
            };
            updTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "STAT"
            };
            updTable.Columns.Add(column);
            DataColumn column2 = new DataColumn {
                ColumnName = "WREF"
            };
            table3.Columns.Add(column2);
            column2 = new DataColumn {
                ColumnName = "Status"
            };
            table3.Columns.Add(column2);
            column2 = new DataColumn {
                ColumnName = "Remark"
            };
            table3.Columns.Add(column2);
            string[] strArray3 = new string[10];
            column.Dispose();
            column2.Dispose();
            updTable.Rows.Clear();
            table3.Rows.Clear();
            WBSAP.connect();
            try
            {
                WBSAP.setImportReturn();
                WBSAP.setReturnTable();
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_GET_OPW_ZDOTRX");
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                if (no_ref != "")
                {
                    WBSAP.rfcFunction.SetValue("ZWREF", no_ref);
                }
                WBSAP.sendZWB();
                WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("ITAB_RESULT");
                if (WBSAP.rfcTable.RowCount < 1)
                {
                    if (!zAuto)
                    {
                        MessageBox.Show("No Data Found", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= WBSAP.rfcTable.RowCount)
                        {
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("ITAB_OPW");
                            WBSAP.sendZWB();
                            WBSAP.sendTable(updTable);
                            WBSAP.sendZWB();
                            if (!zAuto)
                            {
                                MessageBox.Show("Sync OPW Sucess", "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                            break;
                        }
                        if (WBSAP.rfcTable[num].GetValue("RFC_TEXT").ToString() == "")
                        {
                            string str2 = WBSAP.rfcTable[num].GetValue("WREF").ToString();
                            string str3 = WBSAP.rfcTable[num].GetValue("WBRUTOKB").ToString();
                            string str4 = WBSAP.rfcTable[num].GetValue("WTARRAKB").ToString();
                            string str5 = WBSAP.rfcTable[num].GetValue("WNETTOKB").ToString();
                            string str6 = WBSAP.rfcTable[num].GetValue("WQTY_KB").ToString();
                            string str8 = WBSAP.rfcTable[num].GetValue("WQTYRET_KG").ToString();
                            string str9 = WBSAP.rfcTable[num].GetValue("WQTYRET_PC").ToString();
                            string str10 = WBSAP.rfcTable[num].GetValue("WTGLOTHER").ToString();
                            string[] textArray1 = new string[] { "Gross_Estate= ", str3, ", Tare_Estate = ", str4, ", Net_Estate = ", str5 };
                            string str11 = string.Concat(textArray1);
                            string[] textArray2 = new string[] { "Estate_qty= ", str5, ", LOADING_QTY_OPW = ", str6, ", Return_Qty_KG= ", str8, ", Return_Qty_Pack= ", str9 };
                            string str12 = string.Concat(textArray2) ?? "";
                            table.OpenTable("wb_transaction", " SELECT * from wb_transaction where ref='" + str2 + "'", WBData.conn);
                            if (table.DT.Rows.Count < 1)
                            {
                                strArray2[0] = str2;
                                strArray2[1] = "X";
                                strArray2[2] = "Data Not Found";
                                table3.Rows.Add(strArray2);
                            }
                            else
                            {
                                foreach (DataRow row in table.DT.Rows)
                                {
                                    row.BeginEdit();
                                    row["Gross_Estate"] = str3;
                                    row["Tare_Estate"] = str4;
                                    row["Net_Estate"] = str5;
                                    row["delivery_date"] = str10;
                                    row["posted_opw"] = "N";
                                    row["checksum"] = table.Checksum(row);
                                    row.EndEdit();
                                }
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT_OPW", "SYSTEM", "SCHEDULER AUTOMATIC" };
                                Program.updateLogHeader("wb_transaction", table.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                                table.OpenTable("wb_transDo", "update wb_transDo set " + str12 + " where " + WBData.CompanyLocation(" and Ref='" + str2 + "'"), WBData.conn);
                                values[0] = str2;
                                values[1] = "Y";
                                updTable.Rows.Add(values);
                                strArray2[0] = str2;
                                strArray2[1] = "Y";
                                strArray2[2] = "Insert Success";
                                table3.Rows.Add(strArray2);
                            }
                        }
                        num++;
                    }
                }
                if (!zAuto)
                {
                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                        aTable = table3
                    };
                    return2.ShowDialog();
                    return2.Dispose();
                }
                if (no_ref == "")
                {
                    WBSAP.showReturn();
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.Message);
            }
            table.Dispose();
            updTable.Dispose();
            table3.Dispose();
            return strArray3;
        }

        public static string[] get_zdo_fromSAP(string condition, bool zAuto)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable table3 = new DataTable();
            string str2 = "coy, location_code, internal_number, so, STO1, STO2, STO2_Item,transporter, License_No, Driver_name, truck_number, internal_number_item,DO_Item, STO1_item, Comm_Code, DO_QTY, DO_UoM, DO_QTY_KG, Qty_Base_UOM, DO_base_UOM, Mark_accident, Reason, customer_qq";
            string[] values = new string[3];
            string[] strArray2 = new string[3];
            DataColumn column = new DataColumn {
                ColumnName = "ZDCONR"
            };
            updTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "DOPLINE"
            };
            updTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "STAT"
            };
            updTable.Columns.Add(column);
            DataColumn column2 = new DataColumn {
                ColumnName = "Internal Number"
            };
            table3.Columns.Add(column2);
            column2 = new DataColumn {
                ColumnName = "Status"
            };
            table3.Columns.Add(column2);
            column2 = new DataColumn {
                ColumnName = "Remark"
            };
            table3.Columns.Add(column2);
            string[] strArray3 = new string[10];
            column.Dispose();
            column2.Dispose();
            updTable.Rows.Clear();
            table3.Rows.Clear();
            WBSAP.connect();
            try
            {
                WBSAP.setImportReturn();
                WBSAP.setReturnTable();
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_SYNC_ZDOTRX");
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                WBSAP.sendZWB();
                WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("ITAB_RESULT");
                if (WBSAP.rfcTable.RowCount < 1)
                {
                    if (!zAuto)
                    {
                        MessageBox.Show("No Data Found", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= WBSAP.rfcTable.RowCount)
                        {
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("ITAB_ZDOTRX");
                            WBSAP.sendZWB();
                            WBSAP.sendTable(updTable);
                            WBSAP.sendZWB();
                            if (!zAuto)
                            {
                                MessageBox.Show("Sync ZDO Sucess", "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                            break;
                        }
                        string str3 = WBSAP.rfcTable[num].GetValue("ZDCONR").ToString();
                        string str4 = WBSAP.rfcTable[num].GetValue("VBELN_REF").ToString();
                        string str5 = WBSAP.rfcTable[num].GetValue("EBELN_REF").ToString();
                        string str6 = WBSAP.rfcTable[num].GetValue("PUR_EBELN").ToString();
                        string str7 = WBSAP.rfcTable[num].GetValue("PUR_EBELP").ToString();
                        string str8 = WBSAP.rfcTable[num].GetValue("WANGKUTAN").ToString();
                        string str9 = WBSAP.rfcTable[num].GetValue("WNOSIM").ToString();
                        string str10 = WBSAP.rfcTable[num].GetValue("WSUPIR").ToString();
                        string str11 = WBSAP.rfcTable[num].GetValue("WNOPOLISI").ToString();
                        string str12 = WBSAP.rfcTable[num].GetValue("DOPLINE").ToString();
                        string str13 = WBSAP.rfcTable[num].GetValue("POSNR").ToString();
                        string str14 = WBSAP.rfcTable[num].GetValue("EBELP").ToString();
                        string str15 = WBSAP.rfcTable[num].GetValue("MATNR").ToString();
                        string str16 = WBSAP.rfcTable[num].GetValue("PLN_LFIMG").ToString();
                        string str17 = WBSAP.rfcTable[num].GetValue("Q_VRKME").ToString();
                        string str18 = WBSAP.rfcTable[num].GetValue("QTYKG").ToString();
                        string str19 = WBSAP.rfcTable[num].GetValue("QTYBUOM").ToString();
                        string str20 = WBSAP.rfcTable[num].GetValue("BUOM").ToString();
                        string str21 = WBSAP.rfcTable[num].GetValue("XACCIDENT").ToString();
                        string str22 = WBSAP.rfcTable[num].GetValue("ACCIDENT_REASON").ToString();
                        string str23 = WBSAP.rfcTable[num].GetValue("SOKUN3RD").ToString();
                        string[] textArray1 = new string[0x15];
                        textArray1[0] = "'";
                        textArray1[1] = WBData.sCoyCode;
                        textArray1[2] = "','";
                        textArray1[3] = WBData.sLocCode;
                        textArray1[4] = "','";
                        textArray1[5] = str3;
                        textArray1[6] = "','";
                        textArray1[7] = str4;
                        textArray1[8] = "','";
                        textArray1[9] = str5;
                        textArray1[10] = "','";
                        textArray1[11] = str6;
                        textArray1[12] = "','";
                        textArray1[13] = str7;
                        textArray1[14] = "','";
                        textArray1[15] = str8;
                        textArray1[0x10] = "','";
                        textArray1[0x11] = str9;
                        textArray1[0x12] = "','";
                        textArray1[0x13] = str10;
                        textArray1[20] = "',";
                        string str24 = string.Concat(textArray1);
                        string[] textArray2 = new string[14];
                        textArray2[0] = str24;
                        textArray2[1] = "'";
                        textArray2[2] = str11;
                        textArray2[3] = "','";
                        textArray2[4] = str12;
                        textArray2[5] = "','";
                        textArray2[6] = str13;
                        textArray2[7] = "','";
                        textArray2[8] = str14;
                        textArray2[9] = "','";
                        textArray2[10] = str15;
                        textArray2[11] = "',";
                        textArray2[12] = str16;
                        textArray2[13] = ",";
                        str24 = string.Concat(textArray2);
                        string[] textArray3 = new string[0x10];
                        textArray3[0] = str24;
                        textArray3[1] = "'";
                        textArray3[2] = str17;
                        textArray3[3] = "',";
                        textArray3[4] = str18;
                        textArray3[5] = ",";
                        textArray3[6] = str19;
                        textArray3[7] = ",'";
                        textArray3[8] = str20;
                        textArray3[9] = "','";
                        textArray3[10] = str21;
                        textArray3[11] = "','";
                        textArray3[12] = str22;
                        textArray3[13] = "','";
                        textArray3[14] = str23;
                        textArray3[15] = "'";
                        str24 = string.Concat(textArray3);
                        string[] textArray4 = new string[0x11];
                        textArray4[0] = "internal_number= '";
                        textArray4[1] = str3;
                        textArray4[2] = "', so = '";
                        textArray4[3] = str4;
                        textArray4[4] = "', STO1='";
                        textArray4[5] = str5;
                        textArray4[6] = "', STO2='";
                        textArray4[7] = str6;
                        textArray4[8] = "', STO2_Item='";
                        textArray4[9] = str7;
                        textArray4[10] = "', transporter='";
                        textArray4[11] = str8;
                        textArray4[12] = "', License_No='";
                        textArray4[13] = str9;
                        textArray4[14] = "', Driver_name='";
                        textArray4[15] = str10;
                        textArray4[0x10] = "',";
                        string str25 = string.Concat(textArray4);
                        string[] textArray5 = new string[14];
                        textArray5[0] = str25;
                        textArray5[1] = " truck_number='";
                        textArray5[2] = str11;
                        textArray5[3] = "', internal_number_item='";
                        textArray5[4] = str12;
                        textArray5[5] = "', DO_Item='";
                        textArray5[6] = str13;
                        textArray5[7] = "', STO1_item='";
                        textArray5[8] = str14;
                        textArray5[9] = "', Comm_Code='";
                        textArray5[10] = str15;
                        textArray5[11] = "', DO_QTY=";
                        textArray5[12] = str16;
                        textArray5[13] = ",";
                        str25 = string.Concat(textArray5);
                        string[] textArray6 = new string[14];
                        textArray6[0] = str25;
                        textArray6[1] = " DO_UoM='";
                        textArray6[2] = str17;
                        textArray6[3] = "', DO_QTY_KG=";
                        textArray6[4] = str18;
                        textArray6[5] = ", Qty_Base_UOM=";
                        textArray6[6] = str19;
                        textArray6[7] = ", DO_base_UOM='";
                        textArray6[8] = str20;
                        textArray6[9] = "', Mark_accident='";
                        textArray6[10] = str21;
                        textArray6[11] = "', Reason='";
                        textArray6[12] = str22;
                        textArray6[13] = "'";
                        str25 = string.Concat(textArray6);
                        string[] textArray7 = new string[9];
                        textArray7[0] = "SELECT * FROM wb_zdo WHERE";
                        textArray7[1] = WBData.CompanyLocation("");
                        textArray7[2] = " and internal_number = '";
                        textArray7[3] = str3;
                        textArray7[4] = "' and internal_number_item = '";
                        textArray7[5] = str12;
                        textArray7[6] = "' and customer_qq = '";
                        textArray7[7] = str23;
                        textArray7[8] = "'";
                        table.OpenTable("wb_zdo", string.Concat(textArray7), WBData.conn);
                        if (table.DT.Rows.Count < 1)
                        {
                            string[] textArray8 = new string[] { "Insert into wb_zdo (", str2, ") values (", str24, ")" };
                            table.OpenTable("wb_zdo", string.Concat(textArray8), WBData.conn);
                            values[0] = str3;
                            values[1] = str12;
                            values[2] = "Y";
                            updTable.Rows.Add(values);
                            strArray2[0] = str3;
                            strArray2[1] = "Y";
                            strArray2[2] = "Insert Success";
                            table3.Rows.Add(strArray2);
                        }
                        else
                        {
                            string[] textArray9 = new string[] { " and internal_number='", str3, "' and internal_number_item='", str12, "'" };
                            table.OpenTable("wb_transDo", "update wb_zdo set " + str25 + " where " + WBData.CompanyLocation(string.Concat(textArray9)), WBData.conn);
                            values[0] = str3;
                            values[1] = str12;
                            values[2] = "Y";
                            updTable.Rows.Add(values);
                            strArray2[0] = str3;
                            strArray2[1] = "Y";
                            strArray2[2] = "Update Success";
                            table3.Rows.Add(strArray2);
                        }
                        num++;
                    }
                }
                if (!zAuto)
                {
                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                        aTable = table3
                    };
                    return2.ShowDialog();
                    return2.Dispose();
                }
                if (condition != "")
                {
                    WBSAP.showReturn();
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.Message);
            }
            table.Dispose();
            updTable.Dispose();
            table3.Dispose();
            return strArray3;
        }

        public static unsafe string[] sync_commodity(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x17];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x17)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + where_con + " ORDER BY comm_code", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + condition + " ORDER BY comm_code", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_COMM");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "CCOMM");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "comm_code" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["comm_code"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_commodity", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["comm_code"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["comm_name"].ToString().Trim();
                            values[3] = (table.DR["Type"].ToString().Trim() == "S") ? "1" : ((table.DR["Type"].ToString().Trim() == "F") ? "2" : ((table.DR["Type"].ToString().Trim() == "C") ? "3" : ((table.DR["Type"].ToString().Trim() == "G") ? "4" : "")));
                            values[4] = ((table.DR["Tolerance"].ToString().Trim() != null) && (table.DR["Tolerance"].ToString().Trim() != "")) ? table.DR["Tolerance"].ToString().Trim() : "0";
                            values[5] = "0";
                            values[6] = !ReferenceEquals(table.DR["Form_Iso"].ToString().Trim(), null) ? table.DR["Form_Iso"].ToString().Trim() : "";
                            values[7] = !ReferenceEquals(table.DR["Material"].ToString().Trim(), null) ? table.DR["Material"].ToString().Trim() : "";
                            values[8] = (table.DR["Trade"].ToString().Trim() == "T") ? "1" : "2";
                            values[9] = !ReferenceEquals(table.DR["Material_type"].ToString().Trim(), null) ? table.DR["Material_type"].ToString().Trim() : "";
                            values[10] = (table.DR["PostSAP"].ToString().Trim() == "Y") ? "X" : "";
                            values[11] = (table.DR["Deleted"].ToString().Trim() == "Y") ? "X" : "";
                            values[12] = WBUser.UserID;
                            values[13] = "";
                            values[14] = "";
                            values[15] = WBUser.UserID;
                            values[0x10] = "";
                            values[0x11] = "";
                            values[0x12] = "";
                            values[0x13] = "";
                            values[20] = !ReferenceEquals(table.DR["BulkPack"].ToString().Trim(), null) ? table.DR["BulkPack"].ToString().Trim() : "";
                            values[0x15] = ((table.DR["Netto_Weight"].ToString().Trim() != null) && (table.DR["Netto_Weight"].ToString().Trim() != "")) ? table.DR["Netto_Weight"].ToString().Trim() : "0";
                            values[0x16] = ((table.DR["Gross_Weight"].ToString().Trim() != null) && (table.DR["Gross_Weight"].ToString().Trim() != "")) ? table.DR["Gross_Weight"].ToString().Trim() : "0";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception exception1)
                    {
                        MessageBox.Show(exception1.Message);
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_commodity_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] strArray2 = new string[0x17];
            string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 0x17)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + where_con + " ORDER BY comm_code", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + condition + " ORDER BY comm_code", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            Dictionary<string, string> item = new Dictionary<string, string> {
                                { 
                                    "CCOMM",
                                    table.DR["comm_code"].ToString().Trim()
                                },
                                { 
                                    "ZWB_LOC",
                                    WBSetting.CoySAP
                                },
                                { 
                                    "CNAMA",
                                    table.DR["comm_name"].ToString().Trim()
                                }
                            };
                            string str4 = (table.DR["Type"].ToString().Trim() == "S") ? "1" : ((table.DR["Type"].ToString().Trim() == "F") ? "2" : ((table.DR["Type"].ToString().Trim() == "C") ? "3" : ((table.DR["Type"].ToString().Trim() == "G") ? "4" : "")));
                            item.Add("CTYPE", str4);
                            if ((table.DR["Tolerance"].ToString().Trim() == null) || (table.DR["Tolerance"].ToString().Trim() == ""))
                            {
                                item.Add("CTOL1", "0");
                            }
                            else
                            {
                                item.Add("CTOL1", table.DR["Tolerance"].ToString().Trim());
                            }
                            item.Add("CTOL2", "0");
                            if (ReferenceEquals(table.DR["Form_Iso"].ToString().Trim(), null))
                            {
                                item.Add("CISO", "");
                            }
                            else
                            {
                                item.Add("CISO", table.DR["Form_Iso"].ToString().Trim());
                            }
                            if (ReferenceEquals(table.DR["Material"].ToString().Trim(), null))
                            {
                                item.Add("MATNR", "");
                            }
                            else
                            {
                                item.Add("MATNR", table.DR["Material"].ToString().Trim());
                            }
                            item.Add("CTRADE", (table.DR["Trade"].ToString().Trim() == "T") ? "1" : "2");
                            if (ReferenceEquals(table.DR["Material_type"].ToString().Trim(), null))
                            {
                                item.Add("MTART", "");
                            }
                            else
                            {
                                item.Add("MTART", table.DR["Material_type"].ToString().Trim());
                            }
                            item.Add("CPOST", (table.DR["PostSAP"].ToString().Trim() == "Y") ? "X" : "");
                            item.Add("LOEKZ", (table.DR["Deleted"].ToString().Trim() == "Y") ? "X" : "");
                            item.Add("ERNAM", WBUser.UserID);
                            item.Add("ERDAT", "");
                            item.Add("ERZET", "");
                            item.Add("AENAM", WBUser.UserID);
                            item.Add("AEDAT", "");
                            item.Add("AEZET", "");
                            item.Add("STAT", "");
                            item.Add("RFC_TEXT", "");
                            if (ReferenceEquals(table.DR["BulkPack"].ToString().Trim(), null))
                            {
                                item.Add("CFORM", "");
                            }
                            else
                            {
                                item.Add("CFORM", table.DR["BulkPack"].ToString().Trim());
                            }
                            if ((table.DR["Netto_Weight"].ToString().Trim() == null) || (table.DR["Netto_Weight"].ToString().Trim() == ""))
                            {
                                item.Add("NETWEIGHT", "0");
                            }
                            else
                            {
                                item.Add("NETWEIGHT", table.DR["Netto_Weight"].ToString().Trim());
                            }
                            if ((table.DR["Gross_Weight"].ToString().Trim() == null) || (table.DR["Gross_Weight"].ToString().Trim() == ""))
                            {
                                item.Add("GROSSWEIGHT", "0");
                            }
                            else
                            {
                                item.Add("GROSSWEIGHT", table.DR["Gross_Weight"].ToString().Trim());
                            }
                            sentTable.Add(item);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        string url = integrator.getURL("ZRFC_DNET_WB_COMM");
                        if (url != "")
                        {
                            integrator.prepareTable();
                            integrator.addTable(sentTable, "I_RECORD");
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str2 + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["CCOMM"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(values);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "comm_code" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["comm_code"].ToString() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str5 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str5 };
                                            Program.updateLogHeader("wb_commodity", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }

        public static unsafe string[] sync_contract(string condition)
        {
            string[] strArray3;
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x38];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x38)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + where_con + " ORDER BY DO_NO", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + condition + " ORDER BY DO_NO", WBData.conn);
                    }
                    strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CONTRACT");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        goto TR_001F;
                    TR_000F:
                        try
                        {
                            values[50] = table.DR["MILL"].ToString().Trim();
                        }
                        catch
                        {
                            values[50] = "";
                        }
                        values[0x33] = table.DR["Franco"].ToString().Trim();
                        values[0x34] = "X";
                        values[0x35] = (table.DR["PO_Item"].ToString().Trim() == "*") ? "" : table.DR["PO_Item"].ToString().Trim();
                        values[0x36] = table.DR["SPB_No"].ToString().Trim();
                        values[0x37] = table.DR["SPB_Item"].ToString().Trim();
                        updTable.Rows.Add(values);
                        num2++;
                        goto TR_001F;
                    TR_0012:
                        try
                        {
                            values[0x21] = table.DR["STR_LOC"].ToString().Trim();
                        }
                        catch
                        {
                            values[0x21] = "";
                        }
                        goto TR_000F;
                    TR_001F:
                        while (true)
                        {
                            if (num2 < table.DT.Rows.Count)
                            {
                                table.DR = table.DT.Rows[num2];
                                string zValue = table.DR["DO_NO"].ToString().Trim();
                                if (table.DR["zAuto"].ToString().Trim() != "Y")
                                {
                                    values[0] = WBSetting.CoySAP;
                                }
                                else if (zValue.Substring(zValue.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                                {
                                    zValue = table.DR["DO_NO"].ToString().Trim();
                                }
                                else
                                {
                                    zValue = zValue.Substring(0, zValue.Length - 1);
                                    values[0] = Program.getFieldValue("wb_contract", "Coy_tolling", "DO_NO", zValue);
                                }
                                values[1] = zValue.Trim();
                                values[2] = (table.DR["Do_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(table.DR["Do_Date"].ToString().Trim()));
                                values[3] = table.DR["Transaction_code"].ToString().Trim();
                                values[4] = table.DR["Relation_code"].ToString().Trim();
                                values[5] = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", values[4]);
                                values[6] = table.DR["Comm_code"].ToString().Trim();
                                values[7] = table.DR["Remark"].ToString().Trim();
                                values[9] = (table.DR["Berikat"].ToString().Trim() == "Y") ? "X" : "";
                                values[8] = (values[9] != "X") ? "NOKB" : "DPIL";
                                values[10] = "";
                                values[11] = table.DR["Contract"].ToString().Trim();
                                values[12] = (table.DR["Contract_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(table.DR["Contract_Date"].ToString().Trim()));
                                values[13] = table.DR["Transporter_code"].ToString().Trim();
                                values[14] = table.DR["Estate1_code"].ToString().Trim();
                                values[15] = table.DR["Quantity"].ToString().Trim();
                                values[0x10] = "WB1";
                                values[0x11] = (table.DR["langsir_type"].ToString().Trim() != "") ? table.DR["langsir_type"].ToString().Trim() : ((Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", table.DR["transaction_code"].ToString().Trim()) != "I") ? "S" : "P");
                                values[0x12] = table.DR["Vessel"].ToString().Trim();
                                values[0x13] = table.DR["Tolerance"].ToString().Trim();
                                values[20] = table.DR["Estate2_code"].ToString().Trim();
                                values[0x15] = (table.DR["DeductedBy"].ToString().Trim() != "0") ? "1" : "2";
                                values[0x16] = (table.DR["Confirmation_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(table.DR["Confirmation_Date"].ToString().Trim()));
                                values[0x17] = table.DR["PO"].ToString().Trim();
                                values[0x18] = table.DR["GR"].ToString().Trim();
                                values[0x19] = table.DR["STO"].ToString().Trim();
                                values[0x1a] = (table.DR["STO1DO"].ToString().Trim() == "Y") ? "X" : "";
                                values[0x1b] = table.DR["SO"].ToString().Trim();
                                values[0x1c] = (table.DR["SO_Item"].ToString().Trim() == "*") ? "" : table.DR["SO_Item"].ToString().Trim();
                                values[0x1d] = "";
                                values[30] = table.DR["PI_No"].ToString().Trim();
                                values[0x1f] = table.DR["tolling"].ToString().Trim();
                                values[0x20] = "";
                                values[0x21] = "";
                                values[0x22] = table.DR["Batch"].ToString().Trim();
                                values[0x23] = (table.DR["gain_loss"].ToString().Trim() == "Y") ? "X" : "";
                                values[0x24] = Convert.ToString((int) (Convert.ToInt16(table.DR["Group_Type"].ToString().Trim()) + 1));
                                values[0x25] = "";
                                values[0x26] = table.DR["Create_by"].ToString().Trim();
                                values[0x27] = Program.DTOCSAP2(DateTime.Now);
                                values[40] = DateTime.Now.ToString("HH:mm");
                                values[0x29] = table.DR["Change_by"].ToString().Trim();
                                values[0x2a] = Program.DTOCSAP2(DateTime.Now);
                                values[0x2b] = DateTime.Now.ToString("HH:mm");
                                values[0x2c] = "";
                                values[0x2d] = "";
                                values[0x2e] = table.DR["GR_Cust"].ToString().Trim();
                                values[0x30] = table.DR["Qstandard"].ToString().Trim();
                                values[0x31] = (table.DR["STO_ITEM"].ToString().Trim() == "*") ? "" : table.DR["STO_ITEM"].ToString().Trim();
                                try
                                {
                                    values[0x20] = table.DR["PLANT"].ToString().Trim();
                                }
                                catch
                                {
                                    values[0x20] = "";
                                }
                            }
                            else
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "STDO");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "DO_NO" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["DO_NO"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str3 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str3 };
                                        Program.updateLogHeader("wb_contract", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            break;
                        }
                        goto TR_0012;
                    }
                    catch (Exception)
                    {
                    }
                    break;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
            table.Dispose();
            updTable.Dispose();
            zReturn.Dispose();
            return strArray3;
        }

        public static unsafe string[] sync_contract_with_mulesoft(string condition)
        {
            string[] strArray3;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string keyField = "";
            string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            string[] strArray = new string[3];
            string[] strArray2 = new string[0x35];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x35)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    table3.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    table3.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    table3.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + where_con + " ORDER BY DO_NO", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + condition + " ORDER BY DO_NO", WBData.conn);
                    }
                    strArray3 = new string[table.DT.Rows.Count];
                    table2.Rows.Clear();
                    table3.Rows.Clear();
                    try
                    {
                        Dictionary<string, string> dictionary2;
                        WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                        List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                        int num2 = 0;
                        goto TR_004D;
                    TR_0027:
                        try
                        {
                            dictionary2.Add("STR_LOC", table.DR["STR_LOC"].ToString().Trim());
                        }
                        catch
                        {
                            dictionary2.Add("STR_LOC", "");
                        }
                        dictionary2.Add("STBATCH", table.DR["Batch"].ToString().Trim());
                        dictionary2.Add("STGLDEST", (table.DR["gain_loss"].ToString().Trim() == "Y") ? "X" : "");
                        try
                        {
                            dictionary2.Add("STGROUP", Convert.ToString((int) (Convert.ToInt16(table.DR["Group_Type"].ToString().Trim()) + 1)));
                        }
                        catch
                        {
                            dictionary2.Add("STGROUP", "");
                        }
                        dictionary2.Add("STTUTUPDA", "");
                        dictionary2.Add("ERNAM", table.DR["Create_by"].ToString().Trim());
                        dictionary2.Add("ERDAT", Program.DTOCSAP2(DateTime.Now));
                        dictionary2.Add("ERZET", DateTime.Now.ToString("HH:mm"));
                        dictionary2.Add("AENAM", table.DR["Change_by"].ToString().Trim());
                        dictionary2.Add("AEDAT", Program.DTOCSAP2(DateTime.Now));
                        dictionary2.Add("AEZET", DateTime.Now.ToString("HH:mm"));
                        dictionary2.Add("STAT", "");
                        dictionary2.Add("RFC_TEXT", "");
                        dictionary2.Add("GRPO2", table.DR["GR_Cust"].ToString().Trim());
                        string str5 = "";
                        str5 = ((table.DR["completedGRCust"].ToString().Trim() != "N") && (table.DR["completedGRCust"].ToString().Trim() != "X")) ? "" : table.DR["TokenGRCust"].ToString().Trim();
                        dictionary2.Add("TOKEN", str5);
                        dictionary2.Add("ZZISCC", table.DR["Qstandard"].ToString().Trim());
                        dictionary2.Add("EBELP_STO", table.DR["STO_ITEM"].ToString().Trim());
                        try
                        {
                            dictionary2.Add("MILL", table.DR["MILL"].ToString().Trim());
                        }
                        catch
                        {
                            dictionary2.Add("MILL", "");
                        }
                        dictionary2.Add("INCO1", table.DR["Franco"].ToString().Trim());
                        dictionary2.Add("LOCK_POVAT", "");
                        sentTable.Add(dictionary2);
                        num2++;
                    TR_004D:
                        while (true)
                        {
                            if (num2 < table.DT.Rows.Count)
                            {
                                table.DR = table.DT.Rows[num2];
                                string zValue = table.DR["DO_NO"].ToString().Trim();
                                dictionary2 = new Dictionary<string, string>();
                                if (table.DR["zAuto"].ToString().Trim() != "Y")
                                {
                                    dictionary2.Add("ZWB_LOC", WBSetting.CoySAP);
                                }
                                else if (zValue.Substring(zValue.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                                {
                                    zValue = table.DR["DO_NO"].ToString().Trim();
                                }
                                else
                                {
                                    zValue = zValue.Substring(0, zValue.Length - 1);
                                    dictionary2.Add("ZWB_LOC", Program.getFieldValue("wb_contract", "Coy_tolling", "DO_NO", zValue));
                                }
                                dictionary2.Add("STDO", zValue.Trim());
                                if (table.DR["Do_Date"].ToString().Trim().Length > 0)
                                {
                                    dictionary2.Add("STDADO", Program.DTOCSAP2(Convert.ToDateTime(table.DR["Do_Date"].ToString().Trim())));
                                }
                                else
                                {
                                    dictionary2.Add("STDADO", "");
                                }
                                dictionary2.Add("STSTATUS", table.DR["Transaction_code"].ToString().Trim());
                                dictionary2.Add("STRELASI", table.DR["Relation_code"].ToString().Trim());
                                dictionary2.Add("STCU", Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", table.DR["Relation_code"].ToString().Trim()));
                                dictionary2.Add("STCOMM", table.DR["Comm_code"].ToString().Trim());
                                dictionary2.Add("STKET", table.DR["Remark"].ToString().Trim());
                                dictionary2.Add("STKB", (table.DR["Berikat"].ToString().Trim() == "Y") ? "X" : "");
                                if (table.DR["Berikat"].ToString().Trim() == "X")
                                {
                                    dictionary2.Add("SBL", "DPIL");
                                }
                                else
                                {
                                    dictionary2.Add("SBL", "NOKB");
                                }
                                dictionary2.Add("STMC", "");
                                dictionary2.Add("STKONT", table.DR["Contract"].ToString().Trim());
                                if (table.DR["Contract_Date"].ToString().Trim().Length > 0)
                                {
                                    dictionary2.Add("STDAKONT", Program.DTOCSAP2(Convert.ToDateTime(table.DR["Contract_Date"].ToString().Trim())));
                                }
                                else
                                {
                                    dictionary2.Add("STDAKONT", "");
                                }
                                dictionary2.Add("STANGKUT", table.DR["Transporter_code"].ToString().Trim());
                                dictionary2.Add("STKEBUN", table.DR["Estate1_code"].ToString().Trim());
                                dictionary2.Add("STQTY", table.DR["Quantity"].ToString().Trim());
                                dictionary2.Add("STREF", "WB1");
                                if (table.DR["langsir_type"].ToString().Trim() != "")
                                {
                                    dictionary2.Add("STTYPE", table.DR["langsir_type"].ToString().Trim());
                                }
                                else if (Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", table.DR["transaction_code"].ToString().Trim()) == "I")
                                {
                                    dictionary2.Add("STTYPE", "P");
                                }
                                else
                                {
                                    dictionary2.Add("STTYPE", "S");
                                }
                                dictionary2.Add("STVESSEL", table.DR["Vessel"].ToString().Trim());
                                dictionary2.Add("STTOL", table.DR["Tolerance"].ToString().Trim());
                                dictionary2.Add("STTOPRMK", table.DR["Estate2_code"].ToString().Trim());
                                if (table.DR["DeductedBy"].ToString().Trim() == "0")
                                {
                                    dictionary2.Add("STTOP", "2");
                                }
                                else
                                {
                                    dictionary2.Add("STTOP", "1");
                                }
                                if (table.DR["Confirmation_Date"].ToString().Trim().Length > 0)
                                {
                                    dictionary2.Add("STDAKONF", Program.DTOCSAP2(Convert.ToDateTime(table.DR["Confirmation_Date"].ToString().Trim())));
                                }
                                else
                                {
                                    dictionary2.Add("STDAKONF", "");
                                }
                                dictionary2.Add("STGRPO", table.DR["PO"].ToString().Trim());
                                dictionary2.Add("STPO", table.DR["GR"].ToString().Trim());
                                dictionary2.Add("STSTO", table.DR["STO"].ToString().Trim());
                                dictionary2.Add("ST1STO", (table.DR["STO1DO"].ToString().Trim() == "Y") ? "X" : "");
                                dictionary2.Add("STSO", table.DR["SO"].ToString().Trim());
                                dictionary2.Add("POSNR", (table.DR["SO_Item"].ToString().Trim() == "*") ? "" : table.DR["SO_Item"].ToString().Trim());
                                dictionary2.Add("INT_DO", "");
                                dictionary2.Add("PI_NO", table.DR["PI_No"].ToString().Trim());
                                dictionary2.Add("STLANGSIR", table.DR["tolling"].ToString().Trim());
                                try
                                {
                                    dictionary2.Add("STPLANT", table.DR["PLANT"].ToString().Trim());
                                }
                                catch
                                {
                                    dictionary2.Add("STPLANT", "");
                                }
                            }
                            else
                            {
                                table.Dispose();
                                integrator.prepareTable();
                                integrator.addTable(sentTable, "I_RECORD");
                                string url = integrator.getURL("ZRFC_DNET_WB_CONTRACT");
                                if (url != "")
                                {
                                    bool err = false;
                                    string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                                    Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                                    if (!err)
                                    {
                                        if (dictionary["ERRORS"].Count > 0)
                                        {
                                            MessageBox.Show("Error from " + str2 + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                        else
                                        {
                                            foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                            {
                                                object[] values = new object[] { dictionary3["STDO"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                                table3.Rows.Add(values);
                                            }
                                            int index = 0;
                                            while (true)
                                            {
                                                if (index >= table3.Rows.Count)
                                                {
                                                    break;
                                                }
                                                DataRow row = table3.Rows[index];
                                                string* textPtr1 = &(strArray3[index]);
                                                textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                                string[] aField = new string[] { "DO_NO" };
                                                string[] aFind = new string[] { table.DT.Rows[index]["DO_NO"].ToString() };
                                                int recNo = table.GetRecNo(aField, aFind);
                                                if (recNo > -1)
                                                {
                                                    table.DR = table.DT.Rows[recNo];
                                                    keyField = table.DR["uniq"].ToString();
                                                    table.DR.BeginEdit();
                                                    table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                                    table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                                    table.DR.EndEdit();
                                                    table.Save();
                                                    string str6 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str6 };
                                                    Program.updateLogHeader("wb_contract", keyField, logField, logValue);
                                                }
                                                index++;
                                            }
                                        }
                                        if ((condition != "") && (table3.Rows.Count > 0))
                                        {
                                            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                                aTable = table3
                                            };
                                            return2.ShowDialog();
                                            return2.Dispose();
                                        }
                                    }
                                    else
                                    {
                                        return null;
                                    }
                                }
                                else
                                {
                                    return null;
                                }
                                break;
                            }
                            break;
                        }
                        goto TR_0027;
                    }
                    catch (Exception)
                    {
                    }
                    break;
                }
                column = new DataColumn();
                table2.Columns.Add(column);
                column.Dispose();
                num++;
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            return strArray3;
        }

        public static unsafe string[] sync_driver(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x16];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x16)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_driver", "SELECT * FROM wb_driver WHERE " + where_con + " ORDER BY license_no", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_driver", "SELECT * FROM wb_driver WHERE " + condition + " ORDER BY license_no", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_SIM");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "SNOSIM");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "License_no" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["License_No"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_driver", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["License_no"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Name"].ToString().Trim();
                            values[3] = "";
                            values[4] = table.DR["Address"].ToString().Trim();
                            values[5] = "";
                            values[6] = "";
                            values[7] = "";
                            values[8] = "";
                            bool flag3 = table.DR["Birth_date"].ToString().Trim() != "";
                            values[9] = !flag3 ? "" : Program.DTOCSAP2(Convert.ToDateTime(table.DR["Birth_date"].ToString().Trim()));
                            values[10] = table.DR["birth_place"].ToString().Trim();
                            values[11] = (table.DR["Black_list"].ToString().Trim() == "Y") ? "X" : "";
                            values[12] = table.DR["Reason"].ToString().Trim();
                            values[13] = (table.DR["Deleted"].ToString().Trim() == "Y") ? "X" : "";
                            values[14] = "";
                            values[15] = "";
                            values[0x10] = "";
                            values[0x11] = "";
                            values[0x12] = "";
                            values[0x13] = "";
                            values[20] = "";
                            values[0x15] = "";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_driver_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] strArray2 = new string[0x16];
            string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 0x16)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_driver", "SELECT * FROM wb_driver WHERE " + where_con + " ORDER BY license_no", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_driver", "SELECT * FROM wb_driver WHERE " + condition + " ORDER BY license_no", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            Dictionary<string, string> item = new Dictionary<string, string> {
                                { 
                                    "SNOSIM",
                                    table.DR["License_No"].ToString().Trim()
                                },
                                { 
                                    "ZWB_LOC",
                                    WBSetting.CoySAP
                                },
                                { 
                                    "SNAMA",
                                    table.DR["Name"].ToString().Trim()
                                },
                                { 
                                    "SNOPOLISI",
                                    ""
                                },
                                { 
                                    "SALAMAT1",
                                    table.DR["Address"].ToString().Trim()
                                },
                                { 
                                    "SALAMAT2",
                                    ""
                                },
                                { 
                                    "SALAMAT3",
                                    ""
                                },
                                { 
                                    "SKOTA",
                                    ""
                                },
                                { 
                                    "STELP",
                                    ""
                                }
                            };
                            if (table.DR["Birth_date"].ToString().Trim() != "")
                            {
                                item.Add("STGLLAHIR", Program.DTOCSAP2(Convert.ToDateTime(table.DR["Birth_date"].ToString().Trim())));
                            }
                            else
                            {
                                item.Add("STGLLAHIR", "");
                            }
                            item.Add("STMPLAHIR", table.DR["birth_place"].ToString().Trim());
                            item.Add("SBLIST", (table.DR["Black_list"].ToString().Trim() == "Y") ? "X" : "");
                            item.Add("SKET", table.DR["Reason"].ToString().Trim());
                            item.Add("LOEKZ", (table.DR["Deleted"].ToString().Trim() == "Y") ? "X" : "");
                            item.Add("ERNAM", "");
                            item.Add("ERDAT", "");
                            item.Add("ERZET", "");
                            item.Add("AENAM", "");
                            item.Add("AEDAT", "");
                            item.Add("AEZET", "");
                            item.Add("STAT", "");
                            item.Add("RFC_TEXT", "");
                            item.Add("BLIST_LOC", "");
                            item.Add("BLIST_UNAME", "");
                            item.Add("BLIST_DATE", "");
                            item.Add("BLIST_TIME", "");
                            sentTable.Add(item);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_SIM");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str2 + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["SNOSIM"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(values);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "License_no" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["License_No"].ToString() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str4 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str4 };
                                            Program.updateLogHeader("wb_driver", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }

        public static unsafe string[] sync_estate(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x10];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x10)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_estate", "SELECT * FROM wb_estate WHERE " + where_con + " ORDER BY estate_code", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_estate", "SELECT * FROM wb_estate WHERE " + condition + " ORDER BY estate_code", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_ESTATE");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "KKEBUN");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "Estate_code" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["Estate_code"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_estate", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["Estate_code"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Estate_name"].ToString().Trim();
                            values[3] = table.DR["Address"].ToString().Trim();
                            values[4] = "";
                            values[5] = "";
                            values[6] = table.DR["City"].ToString().Trim();
                            values[7] = table.DR["SAP_Code"].ToString().Trim();
                            values[8] = "";
                            values[9] = "";
                            values[10] = "";
                            values[11] = "";
                            values[12] = "";
                            values[13] = "";
                            values[14] = "";
                            values[15] = "";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_estate_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string str = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            string keyField = "";
            string[] strArray = new string[3];
            string[] strArray2 = new string[0x10];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 0x10)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_estate", "SELECT * FROM wb_estate WHERE " + where_con + " ORDER BY estate_code", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_estate", "SELECT * FROM wb_estate WHERE " + condition + " ORDER BY estate_code", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            Dictionary<string, string> item = new Dictionary<string, string> {
                                { 
                                    "KKEBUN",
                                    table.DR["Estate_code"].ToString().Trim()
                                },
                                { 
                                    "ZWB_LOC",
                                    WBSetting.CoySAP
                                },
                                { 
                                    "KNAMA",
                                    table.DR["Estate_name"].ToString().Trim()
                                },
                                { 
                                    "KALAMAT1",
                                    table.DR["Address"].ToString().Trim()
                                },
                                { 
                                    "KALAMAT2",
                                    ""
                                },
                                { 
                                    "KALAMAT3",
                                    ""
                                },
                                { 
                                    "KKOTA",
                                    table.DR["City"].ToString().Trim()
                                },
                                { 
                                    "KPORT",
                                    table.DR["SAP_Code"].ToString().Trim()
                                },
                                { 
                                    "ERNAM",
                                    ""
                                },
                                { 
                                    "ERDAT",
                                    ""
                                },
                                { 
                                    "ERZET",
                                    ""
                                },
                                { 
                                    "AENAM",
                                    ""
                                },
                                { 
                                    "AEDAT",
                                    ""
                                },
                                { 
                                    "AEZET",
                                    ""
                                },
                                { 
                                    "STAT",
                                    ""
                                },
                                { 
                                    "RFC_TEXT",
                                    ""
                                }
                            };
                            sentTable.Add(item);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_ESTATE");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["KKEBUN"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(values);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "Estate_code" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["Estate_code"].ToString() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str4 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str4 };
                                            Program.updateLogHeader("wb_estate", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }

        public static unsafe string[] sync_relation(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[20];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 20)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_relation", "SELECT * FROM wb_relation WHERE " + where_con + " ORDER BY Relation_Code", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_relation", "SELECT * FROM wb_relation WHERE " + condition + " ORDER BY Relation_Code", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CUSTVEN");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "RRELASI");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "Relation_code" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["Relation_code"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_relation", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["Relation_code"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Relation_name"].ToString().Trim();
                            values[3] = table.DR["Estate_code"].ToString().Trim();
                            values[4] = (table.DR["ISCC"].ToString().Trim() == "Y") ? "X" : "";
                            values[5] = table.DR["Address"].ToString().Trim();
                            values[6] = "";
                            values[7] = "";
                            values[8] = table.DR["City"].ToString().Trim();
                            values[9] = table.DR["Phone"].ToString().Trim();
                            values[10] = table.DR["Fax"].ToString().Trim();
                            values[11] = "";
                            values[12] = "";
                            values[13] = "";
                            values[14] = "";
                            values[15] = "";
                            values[0x10] = "";
                            values[0x11] = "";
                            values[0x12] = "";
                            values[0x13] = "";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_relation_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] strArray2 = new string[20];
            string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 20)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_relation", "SELECT * FROM wb_relation WHERE " + where_con + " ORDER BY Relation_Code", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_relation", "SELECT * FROM wb_relation WHERE " + condition + " ORDER BY Relation_Code", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            Dictionary<string, string> item = new Dictionary<string, string> {
                                { 
                                    "RRELASI",
                                    table.DR["Relation_code"].ToString().Trim()
                                },
                                { 
                                    "ZWB_LOC",
                                    WBSetting.CoySAP
                                },
                                { 
                                    "RNAMA",
                                    table.DR["Relation_name"].ToString().Trim()
                                },
                                { 
                                    "RKEBUN",
                                    table.DR["Estate_code"].ToString().Trim()
                                },
                                { 
                                    "RISCC",
                                    (table.DR["ISCC"].ToString().Trim() == "Y") ? "X" : ""
                                },
                                { 
                                    "RALAMAT1",
                                    table.DR["Address"].ToString().Trim()
                                },
                                { 
                                    "RALAMAT2",
                                    ""
                                },
                                { 
                                    "RALAMAT3",
                                    ""
                                },
                                { 
                                    "RKOTA",
                                    table.DR["City"].ToString().Trim()
                                },
                                { 
                                    "RTELP",
                                    table.DR["Phone"].ToString().Trim()
                                },
                                { 
                                    "RFAX",
                                    table.DR["Fax"].ToString().Trim()
                                },
                                { 
                                    "RATTN",
                                    ""
                                },
                                { 
                                    "ERNAM",
                                    ""
                                },
                                { 
                                    "ERDAT",
                                    ""
                                },
                                { 
                                    "ERZET",
                                    ""
                                },
                                { 
                                    "AENAM",
                                    ""
                                },
                                { 
                                    "AEDAT",
                                    ""
                                },
                                { 
                                    "AEZET",
                                    ""
                                },
                                { 
                                    "STAT",
                                    ""
                                },
                                { 
                                    "RFC_TEXT",
                                    ""
                                }
                            };
                            sentTable.Add(item);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_CUSTVEN");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str2 + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["RRELASI"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(values);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "Relation_code" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["Relation_code"].ToString() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str4 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str4 };
                                            Program.updateLogHeader("wb_relation", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }

        public static unsafe string[] sync_transporter(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[20];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 20)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_transporter", "SELECT * FROM wb_transporter WHERE " + where_con + " ORDER BY transporter_code", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_transporter", "SELECT * FROM wb_transporter WHERE " + condition + " ORDER BY transporter_code", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRANSPORTER");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "AANGKUTAN");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "Transporter_code" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["Transporter_code"].ToString() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_transporter", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["Transporter_code"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Transporter_Name"].ToString().Trim();
                            values[3] = table.DR["Address"].ToString().Trim();
                            values[4] = "";
                            values[5] = "";
                            values[6] = "";
                            values[7] = "";
                            values[8] = table.DR["Phone"].ToString().Trim();
                            values[9] = table.DR["Fax"].ToString().Trim();
                            values[10] = (table.DR["Black_List"].ToString().Trim() == "Y") ? "X" : "";
                            values[11] = table.DR["SAP_Code"].ToString().Trim();
                            values[12] = "";
                            values[13] = "";
                            values[14] = "";
                            values[15] = "";
                            values[0x10] = "";
                            values[0x11] = "";
                            values[0x12] = "";
                            values[0x13] = "";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_transporter_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] strArray2 = new string[20];
            string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 20)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_transporter", "SELECT * FROM wb_transporter WHERE " + where_con + " ORDER BY transporter_code", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_transporter", "SELECT * FROM wb_transporter WHERE " + condition + " ORDER BY transporter_code", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            Dictionary<string, string> item = new Dictionary<string, string> {
                                { 
                                    "AANGKUTAN",
                                    table.DR["Transporter_code"].ToString().Trim()
                                },
                                { 
                                    "ZWB_LOC",
                                    WBSetting.CoySAP
                                },
                                { 
                                    "ANAMA",
                                    table.DR["Transporter_Name"].ToString().Trim()
                                },
                                { 
                                    "AALAMAT1",
                                    table.DR["Address"].ToString().Trim()
                                },
                                { 
                                    "AALAMAT2",
                                    ""
                                },
                                { 
                                    "AALAMAT3",
                                    ""
                                },
                                { 
                                    "ACITY",
                                    ""
                                },
                                { 
                                    "AATTN",
                                    ""
                                },
                                { 
                                    "ATELP",
                                    table.DR["Phone"].ToString().Trim()
                                },
                                { 
                                    "AFAX",
                                    table.DR["Fax"].ToString().Trim()
                                },
                                { 
                                    "ABLIST",
                                    (table.DR["Black_List"].ToString().Trim() == "Y") ? "X" : ""
                                },
                                { 
                                    "ASAP_CODE",
                                    table.DR["SAP_Code"].ToString().Trim()
                                },
                                { 
                                    "ERNAM",
                                    ""
                                },
                                { 
                                    "ERDAT",
                                    ""
                                },
                                { 
                                    "ERZET",
                                    ""
                                },
                                { 
                                    "AENAM",
                                    ""
                                },
                                { 
                                    "AEDAT",
                                    ""
                                },
                                { 
                                    "AEZET",
                                    ""
                                },
                                { 
                                    "STAT",
                                    ""
                                },
                                { 
                                    "RFC_TEXT",
                                    ""
                                }
                            };
                            sentTable.Add(item);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_TRANSPORTER");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str2 + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                    {
                                        object[] values = new object[] { dictionary3["AANGKUTAN"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(values);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "Transporter_code" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["Transporter_code"].ToString() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str4 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str4 };
                                            Program.updateLogHeader("wb_transporter", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }

        public static unsafe string[] sync_truck(string condition)
        {
            WBTable table = new WBTable();
            DataTable updTable = new DataTable();
            DataTable zReturn = new DataTable();
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x12];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x12)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    zReturn.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    zReturn.Columns.Add(column);
                    column.Dispose();
                    if (condition == "")
                    {
                        table.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + where_con + " ORDER BY truck_number", WBData.conn);
                    }
                    else
                    {
                        table.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + condition + " ORDER BY truck_number", WBData.conn);
                    }
                    string[] strArray3 = new string[table.DT.Rows.Count];
                    updTable.Rows.Clear();
                    zReturn.Rows.Clear();
                    WBSAP.connect();
                    try
                    {
                        WBSAP.setImportReturn();
                        WBSAP.setReturnTable();
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRUCK");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                WBSAP.sendTable(updTable);
                                WBSAP.sendZWB();
                                WBSAP.getAllResult(updTable, zReturn, "NNOPOLISI");
                                int index = 0;
                                while (true)
                                {
                                    if (index >= zReturn.Rows.Count)
                                    {
                                        if (condition != "")
                                        {
                                            WBSAP.showReturn();
                                        }
                                        break;
                                    }
                                    DataRow row = zReturn.Rows[index];
                                    string* textPtr1 = &(strArray3[index]);
                                    textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                    string[] aField = new string[] { "Truck_Number" };
                                    string[] aFind = new string[] { table.DT.Rows[index]["Truck_Number"].ToString().Trim() };
                                    int recNo = table.GetRecNo(aField, aFind);
                                    if (recNo > -1)
                                    {
                                        table.DR = table.DT.Rows[recNo];
                                        keyField = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                        table.DR["sync_return"] = (row[1].ToString() != "Y") ? row[2].ToString() : "";
                                        table.DR.EndEdit();
                                        table.Save();
                                        string str2 = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str2 };
                                        Program.updateLogHeader("wb_truck", keyField, logField, logValue);
                                    }
                                    index++;
                                }
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["Truck_Number"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Transporter_Code"].ToString().Trim();
                            values[3] = table.DR["Description"].ToString().Trim();
                            values[4] = table.DR["Min_Tare"].ToString().Trim();
                            values[5] = table.DR["Max_Tare"].ToString().Trim();
                            values[6] = (table.DR["Black_List"].ToString().Trim() == "Y") ? "X" : "";
                            values[7] = table.DR["Reason"].ToString().Trim();
                            values[8] = "";
                            values[9] = table.DR["Tipe"].ToString().Trim();
                            values[10] = "";
                            values[11] = "";
                            values[12] = "";
                            values[13] = "";
                            values[14] = "";
                            values[15] = "";
                            values[0x10] = "";
                            values[0x11] = "";
                            updTable.Rows.Add(values);
                            num2++;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    table.Dispose();
                    updTable.Dispose();
                    zReturn.Dispose();
                    return strArray3;
                }
                column = new DataColumn();
                updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        public static unsafe string[] sync_truck_with_mulesoft(string condition)
        {
            string[] strArray4;
            WBTable table = new WBTable();
            DataTable table2 = new DataTable();
            DataTable table3 = new DataTable();
            string str = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            string keyField = "";
            string[] strArray = new string[3];
            string[] values = new string[0x12];
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num < 0x12)
                {
                    column = new DataColumn();
                    table2.Columns.Add(column);
                    column.Dispose();
                    num++;
                    continue;
                }
                column = new DataColumn {
                    ColumnName = "Ref1"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Stts2"
                };
                table3.Columns.Add(column);
                column = new DataColumn {
                    ColumnName = "Rmrk3"
                };
                table3.Columns.Add(column);
                column.Dispose();
                if (condition == "")
                {
                    table.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + where_con + " ORDER BY truck_number", WBData.conn);
                }
                else
                {
                    table.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + condition + " ORDER BY truck_number", WBData.conn);
                }
                string[] strArray3 = new string[table.DT.Rows.Count];
                table2.Rows.Clear();
                table3.Rows.Clear();
                try
                {
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < table.DT.Rows.Count)
                        {
                            table.DR = table.DT.Rows[num2];
                            values[0] = table.DR["Truck_Number"].ToString().Trim();
                            values[1] = WBSetting.CoySAP;
                            values[2] = table.DR["Transporter_Code"].ToString().Trim();
                            values[3] = table.DR["Description"].ToString().Trim();
                            values[4] = table.DR["Min_Tare"].ToString().Trim();
                            values[5] = table.DR["Max_Tare"].ToString().Trim();
                            values[6] = (table.DR["Black_List"].ToString().Trim() == "Y") ? "X" : "";
                            values[7] = table.DR["Reason"].ToString().Trim();
                            values[8] = "";
                            values[9] = table.DR["Tipe"].ToString().Trim();
                            values[10] = "";
                            values[11] = "";
                            values[12] = "";
                            values[13] = "";
                            values[14] = "";
                            values[15] = "";
                            values[0x10] = "";
                            values[0x11] = "";
                            table2.Rows.Add(values);
                            num2++;
                            continue;
                        }
                        table.Dispose();
                        integrator.prepareTable();
                        integrator.addTable(sentTable, "I_RECORD");
                        string url = integrator.getURL("ZRFC_DNET_WB_TRUCK");
                        if (url != "")
                        {
                            bool err = false;
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    foreach (Dictionary<string, string> dictionary2 in dictionary["I_RECORD"])
                                    {
                                        object[] objArray1 = new object[] { dictionary2["NNOPOLISI"].ToString(), dictionary2["STAT"].ToString(), dictionary2["RFC_TEXT"].ToString() };
                                        table3.Rows.Add(objArray1);
                                    }
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= table3.Rows.Count)
                                        {
                                            break;
                                        }
                                        DataRow row = table3.Rows[index];
                                        string* textPtr1 = &(strArray3[index]);
                                        textPtr1 = (string*) (((string) textPtr1) + row[0].ToString() + " : " + row[2].ToString());
                                        string[] aField = new string[] { "Truck_Number" };
                                        string[] aFind = new string[] { table.DT.Rows[index]["Truck_Number"].ToString().Trim() };
                                        int recNo = table.GetRecNo(aField, aFind);
                                        if (recNo > -1)
                                        {
                                            table.DR = table.DT.Rows[recNo];
                                            keyField = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["zwb"] = (row[1].ToString() == "Y") ? "Y" : "N";
                                            table.DR["sync_return"] = (row[1].ToString() == "Y") ? "" : row[2].ToString();
                                            table.DR.EndEdit();
                                            table.Save();
                                            string str4 = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + str4 };
                                            Program.updateLogHeader("wb_truck", keyField, logField, logValue);
                                        }
                                        index++;
                                    }
                                }
                                if ((condition != "") && (table3.Rows.Count > 0))
                                {
                                    FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                        aTable = table3
                                    };
                                    return2.ShowDialog();
                                    return2.Dispose();
                                }
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                strArray4 = strArray3;
                break;
            }
            return strArray4;
        }
    }
}

