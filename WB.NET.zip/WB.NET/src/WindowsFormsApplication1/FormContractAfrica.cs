﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContractAfrica : Form
    {
        private int idxFind = 0;
        public WBTable tblContract_log = new WBTable();
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string flagTimbun = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private string sqlShow = "";
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private WBTable tblContractGRCust = new WBTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x30];
        public string sField;
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Panel panel1;
        public Button buttonFind;
        private Label Garis1;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem chooseStripMenuItem3;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;
        private ToolStripMenuItem copyRecordToolStripMenuItem;
        private ToolStripMenuItem filterToolStripMenuItem;
        private ToolStripMenuItem unfilterToolStripMenuItem;
        private ToolStripMenuItem diagnosticMasterDataToolStripMenuItem;
        private ToolStripMenuItem closeDOToolStripMenuItem;
        private CheckBox checkClosed;
        private Label labelCount;

        public FormContractAfrica()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.closeDOToolStripMenuItem.Text = (this.dataGridView1.CurrentRow.Cells["Closed"].Value.ToString() != "X") ? "Close DO" : "Open DO";
            }
        }

        private void activitiesToolStripMenuItem_LocationChanged(object sender, EventArgs e)
        {
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContractEntryAfrica africa = new FormContractEntryAfrica();
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                africa.pMode = "ADD";
                africa.zTable = this.ztable;
                africa.Text = "Add New Record of DO/Contract/Confirmation";
                africa.dataGridView1 = this.dataGridView1;
                africa.ShowDialog();
                if (africa.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(africa.pMode);
                    string[] aField = new string[] { "Do_no" };
                    string[] aFind = new string[] { africa.textDO.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                africa.Dispose();
                this.ztable.UnLock();
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void checkClosed_CheckedChanged(object sender, EventArgs e)
        {
            this.sqlShow = "";
            this.sqlShow = this.checkClosed.Checked ? "" : " and (closed is null or closed <> 'X' or closed = 'N')";
            if (this.pFilter != "")
            {
                this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract Where " + WBData.CompanyLocation(this.pFilter + this.sqlShow), WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract where " + WBData.CompanyLocation(this.sqlShow), WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
            this.labelCount.Text = "Total Record = " + this.ztable.DT.Rows.Count.ToString();
            this.labelCount.Refresh();
        }

        private void chooseStripMenuItem3_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            if (this.ztable.DT.Rows[this.nCurrRow]["closed"].ToString() == "X")
            {
                MessageBox.Show(Resource.Mes_063, Resource.Title_002);
            }
            else if (this.ztable.DT.Rows[this.nCurrRow]["zAuto"].ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_062, Resource.Title_002);
            }
            else if ((this.flagTimbun == "6") && (this.ztable.DT.Rows[this.nCurrRow]["tolling"].ToString() != "6"))
            {
                MessageBox.Show(Resource.Mes_061, Resource.Title_002);
            }
            else if ((WBSetting.Field("GM") == "Y") && (this.ztable.DT.Rows[this.nCurrRow]["completed"].ToString() == "N"))
            {
                MessageBox.Show(Resource.Mes_064, Resource.Title_002);
            }
            else
            {
                this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void closeDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_065, Resource.Title_002);
            }
            else if ((WBSetting.Field("GM") == "Y") && (this.ztable.DT.Rows[this.nCurrRow]["completed"].ToString() == "N"))
            {
                MessageBox.Show(Resource.Mes_066, Resource.Title_002);
            }
            else if (this.ztable.BeforeEdit(this.dataGridView1, "CLOSED"))
            {
                string str = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString();
                FormContractStatus status = new FormContractStatus {
                    doNo = str,
                    sUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()
                };
                status.ShowDialog();
                this.ztable.AfterEdit("CLOSED");
                if (status.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("CLOSED");
                    string[] aField = new string[] { "Do_no" };
                    string[] aFind = new string[] { str };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                status.Dispose();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void ContractToLog(WBTable tLog, DataRow aRow)
        {
            tLog.OpenTable("wb_contract_log", "SELECT * FROM wb_contract_log where deleted = '9' ", WBData.conn);
            tLog.DR = tLog.DT.NewRow();
            using (IEnumerator enumerator = tLog.DT.Columns.GetEnumerator())
            {
                DataColumn current;
                goto TR_0012;
            TR_000C:
                if (current.ColumnName.ToUpper() == "log_Date".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("dd/MM/yyyy");
                }
                else if (current.ColumnName.ToUpper() == "log_time".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (current.ColumnName.ToUpper() == "sUniq".ToUpper())
                {
                    tLog.DR[current.ColumnName] = aRow["uniq"];
                }
                if (current.ColumnName.ToUpper() == "Deleted".ToUpper())
                {
                    tLog.DR[current.ColumnName] = "Y";
                }
            TR_0012:
                while (true)
                {
                    if (enumerator.MoveNext())
                    {
                        current = (DataColumn) enumerator.Current;
                        if (current.ColumnName.ToUpper() != "UNIQ")
                        {
                            try
                            {
                                tLog.DR[current.ColumnName] = aRow[current.ColumnName];
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        goto TR_0004;
                    }
                    break;
                }
                goto TR_000C;
            }
        TR_0004:
            tLog.DT.Rows.Add(tLog.DR);
        }

        private void copyRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_067, Resource.Title_002);
                }
                else if ((WBSetting.Field("GM") == "Y") && (this.ztable.DT.Rows[this.nCurrRow]["completed"].ToString() != "Y"))
                {
                    MessageBox.Show(Resource.Mes_068, Resource.Title_002);
                }
                else if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
                {
                    FormContractEntryAfrica africa = new FormContractEntryAfrica {
                        pMode = "COPY",
                        zTable = this.ztable,
                        Text = "Add New Record of DO/Contract/Confirmation",
                        dataGridView1 = this.dataGridView1,
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString())
                    };
                    africa.ShowDialog();
                    if (africa.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(africa.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { africa.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    africa.Dispose();
                    this.ztable.UnLock();
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem3.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["closed"].Value.ToString() == "X")
            {
                e.CellStyle.BackColor = Color.Gray;
                e.CellStyle.SelectionBackColor = Color.Black;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["zAuto"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Yellow;
                e.CellStyle.SelectionBackColor = Color.YellowGreen;
            }
            if ((WBSetting.Field("GM") == "Y") && (this.dataGridView1.Rows[e.RowIndex].Cells["completed"].Value.ToString() == "N"))
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.PaleVioletRed;
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem3.PerformClick();
            }
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string pUniq = "";
            string str2 = "N";
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
            {
                if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                {
                    this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transDO", "Select ref From wb_transDO where " + WBData.CompanyLocation(" and (Do_No='" + this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString() + "')"), WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        if (MessageBox.Show(Resource.Mes_384 + this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString(), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            if (this.dataGridView1.CurrentRow.Cells["tolling"].Value.ToString() == "6")
                            {
                                pUniq = this.findTimbun();
                                str2 = "T";
                            }
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = "DO No" },
                                textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["do_no"].ToString() },
                                Text = "DELETE REASON",
                                label2 = { Text = "Delete Reason : " }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                this.ztable.ReOpen();
                                this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
                                this.logKey = this.ztable.DR["uniq"].ToString();
                                this.ztable.ReOpen();
                                this.ztable.DT.Rows[this.nCurrRow].Delete();
                                if ((str2 == "T") && (pUniq != ""))
                                {
                                    this.nCurrRow = this.ztable.GetPosRec(pUniq);
                                    this.ztable.DT.Rows[this.nCurrRow].Delete();
                                }
                                this.ztable.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                                this.ztable.ReOpen();
                                this.ztable.AfterEdit("DELETE");
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_047A + "\n ( " + table.DT.Rows.Count.ToString() + Resource.Mes_047B, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    table.Dispose();
                    table.UnLock();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_070, Resource.Title_002);
            }
        }

        private void diagnosticMasterDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormContractDiag { 
                textBox1 = { Text = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() },
                textBox2 = { Text = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() }
            }.ShowDialog();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.DT.Rows.Count != 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_060, Resource.Title_002);
                }
                else if (this.dataGridView1.CurrentRow.Cells["closed"].Value.ToString() == "X")
                {
                    MessageBox.Show(Resource.Mes_072, Resource.Title_002);
                }
                else if (!this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1') && this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
                {
                    FormContractEntryAfrica africa = new FormContractEntryAfrica {
                        pMode = "EDIT",
                        zTable = this.ztable,
                        Text = "Edit Record of DO/Contract/Confirmation",
                        nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                        dataGridView1 = this.dataGridView1
                    };
                    africa.ShowDialog();
                    if (africa.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(africa.pMode);
                        string[] aField = new string[] { "Do_no" };
                        string[] aFind = new string[] { africa.textDO.Text };
                        this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    africa.Dispose();
                    this.ztable.UnLock();
                }
            }
        }

        private void filterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContractFilter filter = new FormContractFilter();
            filter.ShowDialog();
            if (filter.saved)
            {
                try
                {
                    this.pFilter = filter.pFilter;
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract ", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_077, Resource.Title_002);
                    this.unfilterToolStripMenuItem.PerformClick();
                    return;
                }
                this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
                this.dataGridView1.Refresh();
                filter.Dispose();
            }
        }

        private string findTimbun()
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contractTTB", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_NO = '" + this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString().Trim() + "T' and tolling = 'T'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = "";
            }
            else
            {
                table.DR = table.DT.Rows[0];
                str = table.DR["uniq"].ToString();
            }
            table.Dispose();
            return str;
        }

        private void FormContract_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContract_Load(object sender, EventArgs e)
        {
            this.translate();
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x30)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    DataGridViewCellStyle style = new DataGridViewCellStyle {
                        Format = "d"
                    };
                    this.sField = "Coy,Location_Code,Berikat,Do_No,Do_Date,Comm_Code,Transaction_Code,Relation_Code,PI_No,Quantity,QtyAdopt,Contract,Contract_Date,Confirmation,Agen,Confirmation_Date,Estate1_Code,Estate2_Code,Transporter_Code,Vessel,STO,STO_Item,GR,GR_Cust, SO,SO_Item,Nego,PO,PO_Item,Coy_Tolling,Mov_Type,Remark,Group_Type,Franco,DeductedBy,UnGraded,Control_Os,Status_Do,Close_Do_Date,CheckPeriod, Do_Date2,Big_Fruit1,Big_Fruit2,Mid_Fruit1,Mid_Fruit2,Sml_Fruit1,Sml_Fruit2,Scout1,Scout2,Loose1,Loose2,Upd_Est,Upd_Fact,Entry_Est,ISCC,Entry_Fact,Type_Estate,check_qty,closed,closed_date,Tolerance,Upload_Type, Batch_GI, Batch_GR, Bag_Batch_GI, Bag_Batch_GR, QualityInfo,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date, Convertion,ConvertionUnit,ConvertionTolerance,ConvertionCheck ,Deleted,STO1DO,zadp,zwb,tolling,zAuto,token, completed, tokenGRCust, completedGrcust,uniq";
                    base.KeyPreview = true;
                    Cursor.Current = Cursors.WaitCursor;
                    this.sqlShow = "";
                    this.sqlShow = this.checkClosed.Checked ? "" : " and (closed is null or closed <> 'X' or closed = 'N')";
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract Where " + WBData.CompanyLocation(this.pFilter + this.sqlShow), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract where " + WBData.CompanyLocation(this.sqlShow), WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
                    this.labelCount.Text = "Total Record = " + this.ztable.DT.Rows.Count.ToString();
                    this.labelCount.Refresh();
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["Control_Os"].Visible = false;
                    this.dataGridView1.Columns["Tolling"].Visible = false;
                    this.dataGridView1.Columns["zAuto"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["completedGRCust"].Visible = false;
                    this.dataGridView1.Columns["Do_NO"].HeaderText = Resource.Contract_002;
                    this.dataGridView1.Columns["Do_NO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    this.dataGridView1.Columns["Do_Date"].HeaderText = Resource.Contract_003;
                    this.dataGridView1.Columns["Do_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Contract"].HeaderText = Resource.Contract_010;
                    this.dataGridView1.Columns["Contract_Date"].HeaderText = Resource.Contract_011;
                    this.dataGridView1.Columns["Contract_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Confirmation"].HeaderText = Resource.Contract_012;
                    this.dataGridView1.Columns["Confirmation_Date"].HeaderText = Resource.Contract_014;
                    this.dataGridView1.Columns["Confirmation_Date"].DefaultCellStyle = style;
                    this.dataGridView1.Columns["Relation_Code"].HeaderText = Resource.Contract_006;
                    this.dataGridView1.Columns["Estate1_Code"].HeaderText = Resource.Contract_015;
                    this.dataGridView1.Columns["Estate2_Code"].HeaderText = Resource.Contract_016;
                    this.dataGridView1.Columns["Comm_Code"].HeaderText = Resource.Contract_004;
                    this.dataGridView1.Columns["Coy_Tolling"].HeaderText = Resource.Contract_028;
                    this.dataGridView1.Columns["Transaction_Code"].HeaderText = Resource.Contract_005;
                    this.dataGridView1.Columns["Transaction_Code"].ToolTipText = "Transaction Type \n S-Sales\n P-Purchase\n O-Others";
                    this.dataGridView1.Columns["Mov_Type"].HeaderText = Resource.Contract_029;
                    this.dataGridView1.Columns["Group_Type"].HeaderText = Resource.Contract_031;
                    this.dataGridView1.Columns["Franco"].HeaderText = Resource.Contract_032;
                    this.dataGridView1.Columns["closed"].HeaderText = Resource.Contract_053;
                    this.dataGridView1.Columns["berikat"].HeaderText = Resource.Contract_001;
                    this.dataGridView1.Columns["berikat"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["berikat"].ToolTipText = "Y = KB, N = Non KB";
                    this.dataGridView1.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dataGridView1.Columns["Quantity"].DefaultCellStyle.Format = "N0";
                    this.dataGridView1.Columns["PI_No"].HeaderText = Resource.Contract_007;
                    this.dataGridView1.Columns["Quantity"].HeaderText = Resource.Contract_008;
                    this.dataGridView1.Columns["QtyAdopt"].HeaderText = Resource.Contract_009;
                    this.dataGridView1.Columns["Agen"].HeaderText = Resource.Contract_013;
                    this.dataGridView1.Columns["Transporter_Code"].HeaderText = Resource.Contract_017;
                    this.dataGridView1.Columns["Vessel"].HeaderText = Resource.Contract_018;
                    this.dataGridView1.Columns["STO"].HeaderText = Resource.Contract_019;
                    this.dataGridView1.Columns["STO_Item"].HeaderText = Resource.Contract_020;
                    this.dataGridView1.Columns["GR"].HeaderText = Resource.Contract_021;
                    this.dataGridView1.Columns["GR_Cust"].HeaderText = Resource.Contract_022;
                    this.dataGridView1.Columns["SO"].HeaderText = Resource.Contract_023;
                    this.dataGridView1.Columns["SO_Item"].HeaderText = Resource.Contract_024;
                    this.dataGridView1.Columns["Nego"].HeaderText = Resource.Contract_025;
                    this.dataGridView1.Columns["PO"].HeaderText = Resource.Contract_026;
                    this.dataGridView1.Columns["PO_Item"].HeaderText = Resource.Contract_027;
                    this.dataGridView1.Columns["Remark"].HeaderText = Resource.Contract_030;
                    this.dataGridView1.Columns["DeductedBy"].HeaderText = Resource.Contract_033;
                    this.dataGridView1.Columns["Ungraded"].HeaderText = Resource.Contract_034;
                    this.dataGridView1.Columns["Status_DO"].HeaderText = Resource.Contract_035;
                    this.dataGridView1.Columns["Close_Do_Date"].HeaderText = Resource.Contract_036;
                    this.dataGridView1.Columns["CheckPeriod"].HeaderText = Resource.Contract_037;
                    this.dataGridView1.Columns["Do_Date2"].HeaderText = Resource.Contract_038;
                    this.dataGridView1.Columns["Big_Fruit1"].HeaderText = Resource.Contract_039;
                    this.dataGridView1.Columns["Big_Fruit2"].HeaderText = Resource.Contract_040;
                    this.dataGridView1.Columns["Mid_Fruit1"].HeaderText = Resource.Contract_041;
                    this.dataGridView1.Columns["Mid_Fruit2"].HeaderText = Resource.Contract_042;
                    this.dataGridView1.Columns["Scout1"].HeaderText = Resource.Contract_043;
                    this.dataGridView1.Columns["Scout2"].HeaderText = Resource.Contract_044;
                    this.dataGridView1.Columns["Loose1"].HeaderText = Resource.Contract_045;
                    this.dataGridView1.Columns["Loose2"].HeaderText = Resource.Contract_046;
                    this.dataGridView1.Columns["Upd_Est"].HeaderText = Resource.Contract_047;
                    this.dataGridView1.Columns["Entry_est"].HeaderText = Resource.Contract_048;
                    this.dataGridView1.Columns["ISCC"].HeaderText = Resource.Contract_049;
                    this.dataGridView1.Columns["Entry_Fact"].HeaderText = Resource.Contract_050;
                    this.dataGridView1.Columns["Type_Estate"].HeaderText = Resource.Contract_051;
                    this.dataGridView1.Columns["Check_Qty"].HeaderText = Resource.Contract_052;
                    this.dataGridView1.Columns["Closed_date"].HeaderText = Resource.Contract_054;
                    this.dataGridView1.Columns["Tolerance"].HeaderText = Resource.Contract_055;
                    this.dataGridView1.Columns["Upload_Type"].HeaderText = Resource.Contract_056;
                    this.dataGridView1.Columns["QualityInfo"].HeaderText = Resource.Contract_057;
                    this.dataGridView1.Columns["Create_By"].HeaderText = Resource.Contract_058;
                    this.dataGridView1.Columns["Create_Date"].HeaderText = Resource.Contract_059;
                    this.dataGridView1.Columns["Change_By"].HeaderText = Resource.Contract_060;
                    this.dataGridView1.Columns["Change_Date"].HeaderText = Resource.Contract_061;
                    this.dataGridView1.Columns["Convertion"].HeaderText = Resource.Contract_062;
                    this.dataGridView1.Columns["ConvertionUnit"].HeaderText = Resource.Contract_063;
                    this.dataGridView1.Columns["ConvertionTolerance"].HeaderText = Resource.Contract_064;
                    this.dataGridView1.Columns["ConvertionCheck"].HeaderText = Resource.Contract_065;
                    this.dataGridView1.Columns["STO1DO"].HeaderText = Resource.Contract_066;
                    this.dataGridView1.Columns["Zadp"].HeaderText = Resource.Contract_067;
                    this.dataGridView1.Columns["Zwb"].HeaderText = Resource.Contract_068;
                    this.dataGridView1.Columns["Token"].HeaderText = Resource.Contract_069;
                    this.dataGridView1.Columns["Completed"].HeaderText = Resource.Contract_070;
                    if (!WBUser.CheckTrustee("MD_CONTRACT", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                        this.copyRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTRACT", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTRACT", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTRACT", "P"))
                    {
                        this.printToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    this.Garis1.Width = 2;
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    Cursor.Current = Cursors.Default;
                    this.chooseStripMenuItem3.Visible = this.pMode != "";
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.closeDOToolStripMenuItem = new ToolStripMenuItem();
            this.copyRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.diagnosticMasterDataToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem3 = new ToolStripMenuItem();
            this.filterToolStripMenuItem = new ToolStripMenuItem();
            this.unfilterToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.labelCount = new Label();
            this.checkClosed = new CheckBox();
            this.progressBar1 = new ProgressBar();
            this.Garis1 = new Label();
            this.buttonFind = new Button();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x39e, 0x193);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.dataGridView1.KeyPress += new KeyPressEventHandler(this.dataGridView1_KeyPress);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem3, this.filterToolStripMenuItem, this.unfilterToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x39e, 0x18);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[11];
            itemArray2[0] = this.addNewRecordToolStripMenuItem;
            itemArray2[1] = this.viewRecordToolStripMenuItem;
            itemArray2[2] = this.editRecordToolStripMenuItem;
            itemArray2[3] = this.closeDOToolStripMenuItem;
            itemArray2[4] = this.copyRecordToolStripMenuItem;
            itemArray2[5] = this.deleteToolStripMenuItem;
            itemArray2[6] = this.toolStripMenuItem1;
            itemArray2[7] = this.printToolStripMenuItem;
            itemArray2[8] = this.toolStripMenuItem2;
            itemArray2[9] = this.zWBToolStripMenuItem;
            itemArray2[10] = this.diagnosticMasterDataToolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.activitiesToolStripMenuItem.LocationChanged += new EventHandler(this.activitiesToolStripMenuItem_LocationChanged);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.closeDOToolStripMenuItem.Name = "closeDOToolStripMenuItem";
            this.closeDOToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.closeDOToolStripMenuItem.Text = "Close/Open DO";
            this.closeDOToolStripMenuItem.Click += new EventHandler(this.closeDOToolStripMenuItem_Click);
            this.copyRecordToolStripMenuItem.Name = "copyRecordToolStripMenuItem";
            this.copyRecordToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.copyRecordToolStripMenuItem.Text = "Copy Record";
            this.copyRecordToolStripMenuItem.Click += new EventHandler(this.copyRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xc1, 6);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.printToolStripMenuItem.Text = "Delivery Note";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0xc1, 6);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.zWBToolStripMenuItem.Click += new EventHandler(this.zWBToolStripMenuItem_Click);
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            this.diagnosticMasterDataToolStripMenuItem.Name = "diagnosticMasterDataToolStripMenuItem";
            this.diagnosticMasterDataToolStripMenuItem.Size = new Size(0xc4, 0x16);
            this.diagnosticMasterDataToolStripMenuItem.Text = "Diagnostic Master Data";
            this.diagnosticMasterDataToolStripMenuItem.Click += new EventHandler(this.diagnosticMasterDataToolStripMenuItem_Click);
            this.chooseStripMenuItem3.Name = "chooseStripMenuItem3";
            this.chooseStripMenuItem3.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem3.Text = "Choose";
            this.chooseStripMenuItem3.Click += new EventHandler(this.chooseStripMenuItem3_Click);
            this.filterToolStripMenuItem.Name = "filterToolStripMenuItem";
            this.filterToolStripMenuItem.Size = new Size(0x2d, 20);
            this.filterToolStripMenuItem.Text = "Filter";
            this.filterToolStripMenuItem.Click += new EventHandler(this.filterToolStripMenuItem_Click);
            this.unfilterToolStripMenuItem.Name = "unfilterToolStripMenuItem";
            this.unfilterToolStripMenuItem.Size = new Size(0x3a, 20);
            this.unfilterToolStripMenuItem.Text = "Unfilter";
            this.unfilterToolStripMenuItem.Click += new EventHandler(this.unfilterToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 7);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.labelCount);
            this.panel1.Controls.Add(this.checkClosed);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x1ab);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x39e, 0x26);
            this.panel1.TabIndex = 11;
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new Point(0x1b6, 11);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new Size(0x57, 13);
            this.labelCount.TabIndex = 0x16;
            this.labelCount.Text = "Total Record = 0";
            this.checkClosed.AutoSize = true;
            this.checkClosed.Location = new Point(0x129, 11);
            this.checkClosed.Name = "checkClosed";
            this.checkClosed.Size = new Size(0x58, 0x11);
            this.checkClosed.TabIndex = 0x15;
            this.checkClosed.Text = "Show Closed";
            this.checkClosed.UseVisualStyleBackColor = true;
            this.checkClosed.CheckedChanged += new EventHandler(this.checkClosed_CheckedChanged);
            this.progressBar1.Location = new Point(0x2bb, 10);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xe0, 0x11);
            this.progressBar1.TabIndex = 20;
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0x112, -8);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(10, 0x2d);
            this.Garis1.TabIndex = 5;
            this.buttonFind.Location = new Point(0xc3, 7);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x39e, 0x1d1);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormContract";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Contract";
            base.Load += new EventHandler(this.FormContract_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContract_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_069, Resource.Title_002);
            }
            else
            {
                new FormSPB { 
                    pDo_No = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString(),
                    Text = "Range of Delivery Note Number for DO No. : " + this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString()
                }.ShowDialog();
            }
        }

        private void send1ZWB(DataRow sRow)
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            this.zwbRow[0] = (sRow["zAuto"].ToString() == "Y") ? this.dataGridView1.CurrentRow.Cells["Coy_tolling"].Value.ToString() : WBSetting.CoySAP;
            str = this.zwbRow[0];
            this.zwbRow[1] = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString();
            str2 = this.zwbRow[1];
            this.zwbRow[2] = (sRow["Do_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Do_Date"].ToString().Trim()));
            this.zwbRow[3] = sRow["Transaction_code"].ToString().Trim();
            this.zwbRow[4] = sRow["Relation_code"].ToString().Trim();
            this.zwbRow[5] = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", this.zwbRow[4]);
            this.zwbRow[6] = sRow["Comm_code"].ToString().Trim();
            this.zwbRow[7] = sRow["Remark"].ToString().Trim();
            this.zwbRow[9] = (sRow["Berikat"].ToString().Trim() == "Y") ? "X" : "";
            this.zwbRow[8] = (this.zwbRow[9] != "X") ? "NOKB" : "DPIL";
            this.zwbRow[10] = "";
            this.zwbRow[11] = sRow["Contract"].ToString().Trim();
            this.zwbRow[12] = (sRow["Contract_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Contract_Date"].ToString().Trim()));
            this.zwbRow[13] = sRow["Transporter_code"].ToString().Trim();
            this.zwbRow[14] = sRow["Estate1_code"].ToString().Trim();
            this.zwbRow[15] = sRow["Quantity"].ToString().Trim();
            this.zwbRow[0x10] = "WB1";
            this.zwbRow[0x11] = (Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", sRow["transaction_code"].ToString().Trim()) != "I") ? "S" : "P";
            this.zwbRow[0x12] = sRow["Vessel"].ToString().Trim();
            this.zwbRow[0x13] = sRow["Tolerance"].ToString().Trim();
            this.zwbRow[20] = sRow["Estate2_code"].ToString().Trim();
            this.zwbRow[0x15] = (sRow["Franco"].ToString().Trim() == "1") ? "1" : "2";
            this.zwbRow[0x16] = (sRow["Confirmation_Date"].ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(sRow["Confirmation_Date"].ToString().Trim()));
            this.zwbRow[0x17] = sRow["PO"].ToString().Trim();
            this.zwbRow[0x18] = sRow["GR"].ToString().Trim();
            this.zwbRow[0x19] = sRow["STO"].ToString().Trim();
            this.zwbRow[0x1a] = (sRow["STO1DO"].ToString().Trim() == "Y") ? "X" : "";
            this.zwbRow[0x1b] = sRow["SO"].ToString().Trim();
            this.zwbRow[0x1c] = sRow["SO_Item"].ToString().Trim();
            this.zwbRow[0x1d] = "";
            this.zwbRow[30] = "";
            this.zwbRow[0x1f] = sRow["tolling"].ToString().Trim();
            this.zwbRow[0x20] = "";
            this.zwbRow[0x21] = "";
            this.zwbRow[0x22] = "";
            this.zwbRow[0x23] = "";
            this.zwbRow[0x24] = Convert.ToString((int) (Convert.ToInt16(sRow["Group_Type"].ToString().Trim()) + 1));
            this.zwbRow[0x25] = "";
            this.zwbRow[0x26] = sRow["Create_BY"].ToString();
            this.zwbRow[0x27] = Program.DTOCSAP2(DateTime.Now);
            this.zwbRow[40] = DateTime.Now.ToString("HH:mm");
            this.zwbRow[0x29] = sRow["Change_By"].ToString();
            this.zwbRow[0x2a] = Program.DTOCSAP2(DateTime.Now);
            this.zwbRow[0x2b] = DateTime.Now.ToString("HH:mm");
            this.zwbRow[0x2c] = "";
            this.zwbRow[0x2d] = "";
            this.zwbRow[0x2e] = sRow["GR_Cust"].ToString().Trim();
            this.zwbRow[0x2f] = sRow["TokenGRCust"].ToString().Trim();
            str3 = this.zwbRow[0x2e];
            str5 = this.zwbRow[0x2f];
            if (WBSAP.connect())
            {
                try
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CONTRACT");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    WBSAP.appendTable(this.zwbRow);
                    WBSAP.sendZWB();
                    this.zwbResult = WBSAP.getResult();
                    str4 = WBSAP.rfcTable[0].GetString("GRPO2").ToString();
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { sRow["uniq"].ToString() };
                    this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
                    this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
                    this.ztable.DR.BeginEdit();
                    this.logKey = this.ztable.DR["uniq"].ToString();
                    this.ztable.DR["zwb"] = (this.zwbResult[1].ToUpper().Trim() == "Y") ? "Y" : "N";
                    this.ztable.DR.EndEdit();
                    this.ztable.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to ZWB" };
                    Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                    if (this.zwbResult[1].ToUpper().Trim() == "Y")
                    {
                        string[] textArray6 = new string[] { Resource.Mes_080, " ", this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString(), " - ", str };
                        MessageBox.Show(string.Concat(textArray6), Resource.Title_006);
                    }
                    else
                    {
                        string[] textArray5 = new string[] { Resource.Mes_078, " ", this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString(), " - ", str, " \n", this.zwbResult[2] };
                        MessageBox.Show(string.Concat(textArray5), Resource.Title_006);
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception2)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception4)
                {
                    MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            if (MessageBox.Show(Resource.Mes_084 + " " + this.dataGridView1.Rows.Count.ToString() + Resource.Mes_047B, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSAP.connect())
                {
                    WBSAP.setReturnTable();
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CONTRACT");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= count)
                        {
                            WBSAP.setImportReturn();
                            WBSAP.sendTable(this.updTable);
                            WBSAP.sendZWB();
                            WBSAP.getAllResult(this.updTable, this.retTable, "STDO");
                            WBSAP.showReturn();
                            this.progressBar1.Visible = false;
                            break;
                        }
                        this.progressBar1.Refresh();
                        string zValue = this.dataGridView1.Rows[num3].Cells["DO_NO"].Value.ToString().Trim();
                        string str = this.dataGridView1.Rows[num3].Cells["uniq"].Value.ToString().Trim();
                        if (this.dataGridView1.Rows[num3].Cells["zAuto"].Value.ToString() != "Y")
                        {
                            this.zwbRow[0] = WBSetting.CoySAP;
                        }
                        else if (zValue.Substring(zValue.Length - 1, 1) != "T")
                        {
                            zValue = this.dataGridView1.Rows[num3].Cells["DO_NO"].Value.ToString().Trim();
                        }
                        else
                        {
                            zValue = zValue.Substring(0, zValue.Length - 1);
                            this.zwbRow[0] = Program.getFieldValue("wb_contract", "Coy_tolling", "DO_NO", zValue);
                        }
                        this.zwbRow[1] = zValue.Trim();
                        this.zwbRow[2] = (this.dataGridView1.Rows[num3].Cells["Do_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Do_Date"].Value.ToString().Trim()));
                        this.zwbRow[3] = this.dataGridView1.Rows[num3].Cells["Transaction_code"].Value.ToString().Trim();
                        this.zwbRow[4] = this.dataGridView1.Rows[num3].Cells["Relation_code"].Value.ToString().Trim();
                        this.zwbRow[5] = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", this.zwbRow[4]);
                        this.zwbRow[6] = this.dataGridView1.Rows[num3].Cells["Comm_code"].Value.ToString().Trim();
                        this.zwbRow[7] = this.dataGridView1.Rows[num3].Cells["Remark"].Value.ToString().Trim();
                        this.zwbRow[9] = (this.dataGridView1.Rows[num3].Cells["Berikat"].Value.ToString().Trim() == "Y") ? "X" : "";
                        this.zwbRow[8] = (this.zwbRow[9] != "X") ? "NOKB" : "DPIL";
                        this.zwbRow[10] = "";
                        this.zwbRow[11] = this.dataGridView1.Rows[num3].Cells["Contract"].Value.ToString().Trim();
                        this.zwbRow[12] = (this.dataGridView1.Rows[num3].Cells["Contract_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Contract_Date"].Value.ToString().Trim()));
                        this.zwbRow[13] = this.dataGridView1.Rows[num3].Cells["Transporter_code"].Value.ToString().Trim();
                        this.zwbRow[14] = this.dataGridView1.Rows[num3].Cells["Estate1_code"].Value.ToString().Trim();
                        this.zwbRow[15] = this.dataGridView1.Rows[num3].Cells["Quantity"].Value.ToString().Trim();
                        this.zwbRow[0x10] = "WB1";
                        this.zwbRow[0x11] = (Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", this.dataGridView1.Rows[num3].Cells["transaction_code"].Value.ToString().Trim()) != "I") ? "S" : "P";
                        this.zwbRow[0x12] = this.dataGridView1.Rows[num3].Cells["Vessel"].Value.ToString().Trim();
                        this.zwbRow[0x13] = this.dataGridView1.Rows[num3].Cells["Tolerance"].Value.ToString().Trim();
                        this.zwbRow[20] = this.dataGridView1.Rows[num3].Cells["Estate2_code"].Value.ToString().Trim();
                        this.zwbRow[0x15] = (this.dataGridView1.Rows[num3].Cells["Franco"].Value.ToString().Trim() == "1") ? "1" : "2";
                        this.zwbRow[0x16] = (this.dataGridView1.Rows[num3].Cells["Confirmation_Date"].Value.ToString().Trim().Length <= 0) ? "" : Program.DTOCSAP2(Convert.ToDateTime(this.dataGridView1.Rows[num3].Cells["Confirmation_Date"].Value.ToString().Trim()));
                        this.zwbRow[0x17] = this.dataGridView1.Rows[num3].Cells["PO"].Value.ToString().Trim();
                        this.zwbRow[0x18] = this.dataGridView1.Rows[num3].Cells["GR"].Value.ToString().Trim();
                        this.zwbRow[0x19] = this.dataGridView1.Rows[num3].Cells["STO"].Value.ToString().Trim();
                        this.zwbRow[0x1a] = (this.dataGridView1.Rows[num3].Cells["STO1DO"].Value.ToString().Trim() == "Y") ? "X" : "";
                        this.zwbRow[0x1b] = this.dataGridView1.Rows[num3].Cells["SO"].Value.ToString().Trim();
                        this.zwbRow[0x1c] = this.dataGridView1.Rows[num3].Cells["SO_Item"].Value.ToString().Trim();
                        this.zwbRow[0x1d] = "";
                        this.zwbRow[30] = "";
                        this.zwbRow[0x1f] = this.dataGridView1.Rows[num3].Cells["tolling"].Value.ToString().Trim();
                        this.zwbRow[0x20] = "";
                        this.zwbRow[0x21] = "";
                        this.zwbRow[0x22] = "";
                        this.zwbRow[0x23] = "";
                        this.zwbRow[0x24] = Convert.ToString((int) (Convert.ToInt16(this.dataGridView1.Rows[num3].Cells["Group_Type"].Value.ToString().Trim()) + 1));
                        this.zwbRow[0x25] = "";
                        this.zwbRow[0x26] = this.dataGridView1.Rows[num3].Cells["Create_by"].Value.ToString().Trim();
                        this.zwbRow[0x27] = Program.DTOCSAP2(DateTime.Now);
                        this.zwbRow[40] = DateTime.Now.ToString("HH:mm");
                        this.zwbRow[0x29] = this.dataGridView1.Rows[num3].Cells["Change_by"].Value.ToString().Trim();
                        this.zwbRow[0x2a] = Program.DTOCSAP2(DateTime.Now);
                        this.zwbRow[0x2b] = DateTime.Now.ToString("HH:mm");
                        this.zwbRow[0x2c] = "";
                        this.zwbRow[0x2d] = "";
                        this.zwbRow[0x2e] = this.dataGridView1.Rows[num3].Cells["GR_Cust"].Value.ToString().Trim();
                        this.progressBar1.Value = num3;
                        this.updTable.Rows.Add(this.zwbRow);
                        num3++;
                    }
                }
            }
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_073, Resource.Title_002);
            }
            else
            {
                DataRow sRow = null;
                DataRow data = null;
                string str2 = this.dataGridView1.CurrentRow.Cells["Do_no"].Value.ToString().Trim();
                string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
                string[] aField = new string[] { "DO_NO", "uniq" };
                string[] aFind = new string[] { str2, str };
                sRow = this.ztable.GetData(aField, aFind);
                string str3 = this.dataGridView1.CurrentRow.Cells["tolling"].Value.ToString().Trim();
                if (str3 == "6")
                {
                    string[] textArray3 = new string[] { "DO_NO", "zAuto" };
                    string[] textArray4 = new string[] { str2 + "T", "Y" };
                    data = this.ztable.GetData(textArray3, textArray4);
                }
                if (MessageBox.Show(Resource.Mes_034 + " " + str2, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.send1ZWB(sRow);
                    if ((str3 == "6") && (data != null))
                    {
                        this.send1ZWB(data);
                    }
                }
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem3.Text = Resource.Menu_Choose;
            this.filterToolStripMenuItem.Text = Resource.Menu_Filter;
            this.unfilterToolStripMenuItem.Text = Resource.Menu_Unfilter;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.buttonFind.Text = Resource.Menu_Find;
        }

        private void unfilterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.OpenTable("wb_contract", "SELECT " + this.sField + " FROM wb_contract ", WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
            this.dataGridView1.Refresh();
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormContractEntryAfrica africa = new FormContractEntryAfrica {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = "View Record of DO/Contract/Confirmation",
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                africa.ShowDialog();
                africa.Dispose();
                this.ztable.UnLock();
            }
        }

        private void zWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
    }
}

