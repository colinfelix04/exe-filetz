﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDLEntryDetail : Form
    {
        public WBTable DataDetail;
        public bool lSave;
        public string pMode;
        public string cSJ_No;
        public int nCurrRow;
        public DataGridView sdataGrid;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        public TextBox textItem;
        public TextBox textBatch;
        public TextBox textQty;
        public TextBox textUOM;
        public TextBox textQtyInKG;
        public Button button1;
        public Button button2;

        public FormDLEntryDetail()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.sdataGrid.Rows.Count > 0)
            {
                this.nCurrRow = this.sdataGrid.CurrentRow.Index;
            }
            if (this.pMode == "ADD")
            {
                this.sdataGrid.Rows.Add(1);
                this.nCurrRow = this.sdataGrid.RowCount - 1;
            }
            this.sdataGrid.Rows[this.nCurrRow].Cells["coy"].Value = WBData.sCoyCode;
            this.sdataGrid.Rows[this.nCurrRow].Cells["Location_Code"].Value = WBData.sLocCode;
            this.sdataGrid.Rows[this.nCurrRow].Cells["SJ_No"].Value = this.cSJ_No;
            this.sdataGrid.Rows[this.nCurrRow].Cells["Item_No"].Value = this.textItem.Text;
            this.sdataGrid.Rows[this.nCurrRow].Cells["Batch_No"].Value = this.textBatch.Text;
            this.sdataGrid.Rows[this.nCurrRow].Cells["Qty"].Value = this.textQty.Text;
            this.sdataGrid.Rows[this.nCurrRow].Cells["UOM"].Value = this.textUOM.Text;
            this.sdataGrid.Rows[this.nCurrRow].Cells["QtyKG"].Value = this.textQtyInKG.Text;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDLEntryDetail_Load(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.label5 = new Label();
            this.textItem = new TextBox();
            this.textBatch = new TextBox();
            this.textQty = new TextBox();
            this.textUOM = new TextBox();
            this.textQtyInKG = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x1b, 0x1d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2c, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item No";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1b, 0x37);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Batch No";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1b, 0x51);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x2e, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x1b, 0x6b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x20, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "UOM";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x1b, 0x85);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x34, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Qty in KG";
            this.textItem.Location = new Point(0x62, 0x1a);
            this.textItem.MaxLength = 3;
            this.textItem.Name = "textItem";
            this.textItem.Size = new Size(0x3d, 20);
            this.textItem.TabIndex = 5;
            this.textBatch.Location = new Point(0x62, 0x34);
            this.textBatch.Name = "textBatch";
            this.textBatch.Size = new Size(0x8b, 20);
            this.textBatch.TabIndex = 6;
            this.textQty.Location = new Point(0x62, 0x4e);
            this.textQty.Name = "textQty";
            this.textQty.Size = new Size(0x8b, 20);
            this.textQty.TabIndex = 7;
            this.textQty.TextAlign = HorizontalAlignment.Right;
            this.textUOM.CharacterCasing = CharacterCasing.Upper;
            this.textUOM.Location = new Point(0x62, 0x68);
            this.textUOM.Name = "textUOM";
            this.textUOM.Size = new Size(0x8b, 20);
            this.textUOM.TabIndex = 8;
            this.textQtyInKG.Location = new Point(0x62, 130);
            this.textQtyInKG.Name = "textQtyInKG";
            this.textQtyInKG.Size = new Size(0x8b, 20);
            this.textQtyInKG.TabIndex = 9;
            this.textQtyInKG.TextAlign = HorizontalAlignment.Right;
            this.button1.Location = new Point(0x13b, 0x18);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 10;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x13b, 50);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 11;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ba, 0xc2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textQtyInKG);
            base.Controls.Add(this.textUOM);
            base.Controls.Add(this.textQty);
            base.Controls.Add(this.textBatch);
            base.Controls.Add(this.textItem);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormDLEntryDetail";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Delivery Letter Item Entry";
            base.Load += new EventHandler(this.FormDLEntryDetail_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

