﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormWBCalibrationEntry : Form
    {
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public string uniqDB = "";
        public string oldValid = "";
        public string oldFlag = "";
        public WBTable zTable;
        public WBTable getWBCode;
        public int nCurrRow;
        public bool saved;
        public bool changeLock = false;
        public bool showWarning = false;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        public TextBox textCertNo;
        private Label label3;
        private Label label1;
        private Label label2;
        private Label label4;
        public DateTimePicker calibrationDate;
        public DateTimePicker validDate;
        public ComboBox comboWBCode;
        private GroupBox groupLock;
        private RadioButton radioNo;
        private RadioButton radioYes;

        public FormWBCalibrationEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.comboWBCode.Text.Trim() != "")
            {
                if (this.textCertNo.Text.Trim() != "")
                {
                    if ((Convert.ToDateTime(Convert.ToDateTime(this.validDate.Value).ToShortDateString()) - Convert.ToDateTime(Convert.ToDateTime(this.calibrationDate.Value).ToShortDateString())).Days > 0)
                    {
                        if (Convert.ToDateTime(Convert.ToDateTime(this.validDate.Value).ToShortDateString()) <= Convert.ToDateTime(Convert.ToDateTime(DateTime.Now.ToShortDateString())))
                        {
                            DateTime time = Convert.ToDateTime(this.validDate.Value);
                            if (Convert.ToDateTime(Convert.ToDateTime(this.oldValid).ToShortDateString()) != Convert.ToDateTime(time.ToShortDateString()))
                            {
                                MessageBox.Show(Resource.Mes_Invalid_Valid_Date, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.validDate.Focus();
                                return;
                            }
                        }
                        WBTable table = new WBTable();
                        string[] textArray1 = new string[] { "SELECT * FROM wb_calibration where WBCode = '", this.comboWBCode.Text.Trim(), "' AND uniq != '", this.uniqDB, "'" };
                        table.OpenTable("wb_calibration", string.Concat(textArray1), WBData.conn);
                        using (IEnumerator enumerator = table.DT.Rows.GetEnumerator())
                        {
                            while (true)
                            {
                                if (!enumerator.MoveNext())
                                {
                                    break;
                                }
                                DataRow current = (DataRow) enumerator.Current;
                                DateTime time2 = Convert.ToDateTime(Convert.ToDateTime(this.calibrationDate.Value).ToShortDateString());
                                DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(current["calibration_date"].ToString()).ToShortDateString());
                                DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(current["valid_date"].ToString()).ToShortDateString());
                                if ((time2 >= time3) && (time2 <= time4))
                                {
                                    string[] textArray2 = new string[9];
                                    textArray2[0] = Resource.Mes_Calibration_Valid_Date_Intersect;
                                    textArray2[1] = " (";
                                    textArray2[2] = current["certification_no"].ToString();
                                    textArray2[3] = ": ";
                                    textArray2[4] = Convert.ToDateTime(current["calibration_date"].ToString()).ToString("dd/MM/yyyy");
                                    textArray2[5] = " - ";
                                    textArray2[6] = Convert.ToDateTime(current["valid_date"].ToString()).ToString("dd/MM/yyyy");
                                    textArray2[7] = ")\n\n";
                                    textArray2[8] = Resource.Mes_Calibration_Valid_Date_Intersect_2;
                                    MessageBox.Show(string.Concat(textArray2), Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                        }
                        table.Dispose();
                        if (this.pMode == "EDIT")
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = Resource.Lbl_WB_Calibration },
                                textRefNo = { Text = this.textCertNo.Text },
                                Text = Resource.Title_Change_Reason,
                                label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                            }
                            else
                            {
                                return;
                            }
                        }
                        Cursor.Current = Cursors.WaitCursor;
                        if (this.pMode == "ADD")
                        {
                            this.zTable.DR = this.zTable.DT.NewRow();
                        }
                        else
                        {
                            this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                            this.logKey = this.zTable.DR["uniq"].ToString();
                            this.zTable.DR.BeginEdit();
                        }
                        this.zTable.DR["WBCode"] = this.comboWBCode.Text.Trim();
                        this.zTable.DR["Certification_No"] = this.textCertNo.Text.Trim();
                        this.zTable.DR["Calibration_Date"] = this.calibrationDate.Text;
                        this.zTable.DR["Valid_Date"] = this.validDate.Text;
                        this.zTable.DR["Lock_Weighing"] = !this.radioYes.Checked ? (!this.radioNo.Checked ? "" : "N") : "Y";
                        if (this.pMode == "ADD")
                        {
                            this.zTable.DR["Create_By"] = WBUser.UserID;
                            this.zTable.DR["Create_Date"] = DateTime.Now;
                            this.zTable.DT.Rows.Add(this.zTable.DR);
                        }
                        else
                        {
                            this.zTable.DR["Change_By"] = WBUser.UserID;
                            this.zTable.DR["Change_Date"] = DateTime.Now;
                            this.zTable.DR.EndEdit();
                        }
                        this.zTable.Save();
                        if (this.radioNo.Checked && ((this.oldFlag == "") || (this.oldFlag == "Y")))
                        {
                            this.sendMail();
                        }
                        Cursor.Current = Cursors.Default;
                        this.saved = true;
                        base.Close();
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Invalid_Calibration_Valid_Date, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.calibrationDate.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Certification_No_Empty, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textCertNo.Focus();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_WB_Code_Empty, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboWBCode.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormWBCalibrationEntry_Load(object sender, EventArgs e)
        {
            this.uniqDB = "";
            this.changeLock = false;
            if (this.pMode == "ADD")
            {
                this.textCertNo.Text = "";
                this.comboWBCode.Items.Add("");
                this.comboWBCode.Text = "";
            }
            this.getWBCode = new WBTable();
            this.getWBCode.OpenTable("wb_setting", "SELECT distinct(wbcode) FROM wb_setting WHERE usedForWeighing = 'Y'", WBData.conn);
            foreach (DataRow row in this.getWBCode.DT.Rows)
            {
                this.comboWBCode.Items.Add(row["WBCode"].ToString());
            }
            if (this.pMode != "ADD")
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.textCertNo.Text = this.zTable.DR["Certification_No"].ToString();
                this.comboWBCode.Text = this.zTable.DR["WBCode"].ToString();
                this.calibrationDate.Text = this.zTable.DR["Calibration_Date"].ToString();
                this.validDate.Text = this.zTable.DR["Valid_Date"].ToString();
                this.uniqDB = this.zTable.DR["uniq"].ToString();
                if (this.zTable.DR["lock_weighing"].ToString() == "Y")
                {
                    this.radioYes.Checked = true;
                }
                else if (this.zTable.DR["lock_weighing"].ToString() == "N")
                {
                    this.radioNo.Checked = true;
                }
                if (Convert.ToDateTime(Convert.ToDateTime(this.validDate.Value).ToShortDateString()) <= Convert.ToDateTime(Convert.ToDateTime(DateTime.Now).ToShortDateString()))
                {
                    this.groupLock.Enabled = true;
                }
                this.oldValid = this.zTable.DR["Valid_Date"].ToString();
                this.oldFlag = this.zTable.DR["lock_weighing"].ToString();
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textCertNo = new TextBox();
            this.label3 = new Label();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label4 = new Label();
            this.calibrationDate = new DateTimePicker();
            this.validDate = new DateTimePicker();
            this.comboWBCode = new ComboBox();
            this.groupLock = new GroupBox();
            this.radioNo = new RadioButton();
            this.radioYes = new RadioButton();
            this.groupLock.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(0x18e, 230);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x37;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(300, 230);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x36;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textCertNo.CharacterCasing = CharacterCasing.Upper;
            this.textCertNo.Location = new Point(140, 0x3a);
            this.textCertNo.Name = "textCertNo";
            this.textCertNo.Size = new Size(0x10a, 20);
            this.textCertNo.TabIndex = 0x3a;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1d, 0x21);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x35, 13);
            this.label3.TabIndex = 0x3e;
            this.label3.Text = "WB Code";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x1d, 0x3d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4f, 13);
            this.label1.TabIndex = 0x3f;
            this.label1.Text = "Certification No";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1d, 0x57);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x52, 13);
            this.label2.TabIndex = 0x40;
            this.label2.Text = "Calibration Date";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x1d, 0x72);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x38, 13);
            this.label4.TabIndex = 0x41;
            this.label4.Text = "Valid Date";
            this.calibrationDate.Format = DateTimePickerFormat.Short;
            this.calibrationDate.Location = new Point(140, 0x54);
            this.calibrationDate.Name = "calibrationDate";
            this.calibrationDate.Size = new Size(0x69, 20);
            this.calibrationDate.TabIndex = 0x54;
            this.validDate.Format = DateTimePickerFormat.Short;
            this.validDate.Location = new Point(140, 110);
            this.validDate.Name = "validDate";
            this.validDate.Size = new Size(0x69, 20);
            this.validDate.TabIndex = 0x55;
            this.validDate.ValueChanged += new EventHandler(this.validDate_ValueChanged);
            this.comboWBCode.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboWBCode.FormattingEnabled = true;
            this.comboWBCode.Location = new Point(140, 30);
            this.comboWBCode.Name = "comboWBCode";
            this.comboWBCode.Size = new Size(0x99, 0x15);
            this.comboWBCode.TabIndex = 0x68;
            this.groupLock.Controls.Add(this.radioNo);
            this.groupLock.Controls.Add(this.radioYes);
            this.groupLock.Enabled = false;
            this.groupLock.Location = new Point(0x20, 0x99);
            this.groupLock.Name = "groupLock";
            this.groupLock.Size = new Size(0x13e, 0x2d);
            this.groupLock.TabIndex = 0x69;
            this.groupLock.TabStop = false;
            this.groupLock.Text = "Lock weighing if certification is expired";
            this.radioNo.AutoSize = true;
            this.radioNo.Location = new Point(0x6c, 0x13);
            this.radioNo.Name = "radioNo";
            this.radioNo.Size = new Size(0x27, 0x11);
            this.radioNo.TabIndex = 1;
            this.radioNo.TabStop = true;
            this.radioNo.Text = "No";
            this.radioNo.UseVisualStyleBackColor = true;
            this.radioYes.AutoSize = true;
            this.radioYes.Location = new Point(0x15, 20);
            this.radioYes.Name = "radioYes";
            this.radioYes.Size = new Size(0x2b, 0x11);
            this.radioYes.TabIndex = 0;
            this.radioYes.TabStop = true;
            this.radioYes.Text = "Yes";
            this.radioYes.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f2, 0x109);
            base.ControlBox = false;
            base.Controls.Add(this.groupLock);
            base.Controls.Add(this.comboWBCode);
            base.Controls.Add(this.validDate);
            base.Controls.Add(this.calibrationDate);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textCertNo);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormWBCalibrationEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry WB Calibration Certification";
            base.Load += new EventHandler(this.FormWBCalibrationEntry_Load);
            this.groupLock.ResumeLayout(false);
            this.groupLock.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void sendMail()
        {
            string str2 = "";
            WBMail mail = new WBMail();
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_setting", "SELECT * FROM wb_setting WHERE " + WBData.CompanyLocation(" AND WBCode = '" + this.comboWBCode.Text.Trim() + "' "), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                str2 = table2.DT.Rows[0]["compName"].ToString();
            }
            table2.Dispose();
            string sqltext = "SELECT * FROM wb_email_master WHERE " + WBData.CompanyLocation("") + "AND email_code = 'WB_CALIBRATION_PASS_WEIGHING' ";
            table.OpenTable("Wb_email_master", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                DataRow row = table.DT.Rows[0];
                string[] textArray1 = new string[] { "WB.NET WARNING – ALLOW EXPIRED WEIGHBRIDGE CALIBRATION TO DO WEIGHING   ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                mail.Subject = string.Concat(textArray1);
                mail.To = row["email_to"].ToString().Trim();
                mail.CC = row["email_cc"].ToString().Trim();
                object[] objArray1 = new object[] { (((((("Dear All, <br><br>Weighbridge with information below:<br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBData.sLocName) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + this.comboWBCode.Text.Trim()) + "</tr><tr class='bd'><td nowrap>Computer Name</td><td nowrap> : " + str2) + "</tr><tr class='bd'><td nowrap>Certification No</td><td nowrap> : " + this.textCertNo.Text.Trim()) + "</tr><tr class='bd'><td nowrap>Calibration Date</td><td nowrap> : " + Convert.ToDateTime(this.calibrationDate.Value).ToShortDateString()) + "</tr><tr class='bd'><td nowrap>Valid Date</td><td nowrap> : " + Convert.ToDateTime(this.validDate.Value).ToShortDateString(), "</tr></table><br>on ", DateTime.Now, ", ", WBUser.UserName, " allows weighbridge with expired calibration to do weighing.<br>Since calibration certification has expired, weighbridge should not be used for weighing.<br><br>Thank You. " };
                mail.Body = string.Concat(objArray1);
                mail.SendMail();
            }
            table.Dispose();
            mail.Dispose();
        }

        private void translate()
        {
            this.label3.Text = Resource.Main_033;
            this.label1.Text = Resource.Col_Certification_No;
            this.label2.Text = Resource.Col_Calibration_Date;
            this.label4.Text = Resource.Setting_064;
            this.groupLock.Text = Resource.Gbx_Lock_Weighing;
            this.radioNo.Text = Resource.Setting_094;
            this.radioYes.Text = Resource.Setting_095;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
            this.Text = Resource.Title_WB_Calibration_Entry;
        }

        private void validDate_ValueChanged(object sender, EventArgs e)
        {
            this.radioNo.Checked = false;
            this.radioYes.Checked = false;
            if (Convert.ToDateTime(Convert.ToDateTime(this.validDate.Value).ToShortDateString()) > Convert.ToDateTime(Convert.ToDateTime(DateTime.Now.ToShortDateString())))
            {
                this.groupLock.Enabled = false;
            }
        }
    }
}

