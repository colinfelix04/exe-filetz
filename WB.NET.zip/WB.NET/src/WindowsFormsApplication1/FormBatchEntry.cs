﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBatchEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private IContainer components = null;
        public TextBox textBatch;
        private Label label1;
        private Label label2;
        private Label label3;
        private Panel panel1;
        public TextBox textDescription;
        public TextBox textValueType;
        private RadioButton radioBoth;
        private RadioButton radioNonTrade;
        private RadioButton radioTrade;
        private Button button2;
        private Button button1;

        public FormBatchEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBatch };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_Batch", "Select Uniq From wb_Batch Where " + WBData.CompanyLocation(" and ( batch='" + this.textBatch.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textBatch.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        string[] textArray1 = new string[] { " and (( Batch_GI ='", this.zTable.DT.Rows[this.nCurrRow]["batch"].ToString(), "') or ( Batch_GR='", this.zTable.DT.Rows[this.nCurrRow]["batch"].ToString(), "'))" };
                        table2.OpenTable("wb_contract", "Select uniq From wb_contract where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray2 = new string[] { "The source Code will be change, from ", this.OldCode, " to ", this.textBatch.Text, "\n\nSystem will replace all the contract with the new code, it takes a longer time.\n  - ", table2.DT.Rows.Count.ToString(), " records in contracts\nAre you want to continue . . ?" };
                            if (MessageBox.Show(string.Concat(textArray2), "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBatch.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show("The Code is already exist !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textBatch.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Batch" },
                    textRefNo = { Text = this.textBatch.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Batch"] = this.textBatch.Text;
            this.zTable.DR["Description"] = this.textDescription.Text;
            this.zTable.DR["Trade"] = this.radioTrade.Checked ? "T" : (this.radioNonTrade.Checked ? "N" : (this.radioBoth.Checked ? "B" : "T"));
            this.zTable.DR["ValueType"] = this.textValueType.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_batch", "SELECT uniq FROM wb_batch WHERE " + WBData.CompanyLocation(" AND batch = '" + this.textBatch.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_batch", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "batch_GI" };
                string[] aNewValue = new string[] { this.textBatch.Text };
                Program.ReplaceAll("wb_contract", aField, aNewValue, " batch='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit batch master data)");
                string[] textArray7 = new string[] { "batch_GR" };
                string[] textArray8 = new string[] { this.textBatch.Text };
                Program.ReplaceAll("wb_contract", textArray7, textArray8, " batch='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit batch master data)");
            }
            this.saved = true;
            base.Close();
            Cursor.Current = Cursors.Default;
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormBatchEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBatch.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Batch"].Value.ToString();
                this.OldCode = this.textBatch.Text;
                this.textValueType.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["ValueType"].Value.ToString();
                this.textDescription.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Description"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Trade"].Value.ToString() == "T")
                {
                    this.radioTrade.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Trade"].Value.ToString() == "N")
                {
                    this.radioNonTrade.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Trade"].Value.ToString() == "B")
                {
                    this.radioBoth.Checked = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.textBatch = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.panel1 = new Panel();
            this.textDescription = new TextBox();
            this.textValueType = new TextBox();
            this.radioTrade = new RadioButton();
            this.radioNonTrade = new RadioButton();
            this.radioBoth = new RadioButton();
            this.button2 = new Button();
            this.button1 = new Button();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.textBatch.CharacterCasing = CharacterCasing.Upper;
            this.textBatch.Location = new Point(0x59, 13);
            this.textBatch.MaxLength = 20;
            this.textBatch.Name = "textBatch";
            this.textBatch.Size = new Size(0xa5, 20);
            this.textBatch.TabIndex = 4;
            this.textBatch.KeyPress += new KeyPressEventHandler(this.textBatch_KeyPress);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x27, 0x10);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x23, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Batch";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(13, 0x44);
            this.label2.Name = "label2";
            this.label2.Size = new Size(60, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Description";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(13, 0x2a);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3d, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Value Type";
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.radioBoth);
            this.panel1.Controls.Add(this.radioNonTrade);
            this.panel1.Controls.Add(this.radioTrade);
            this.panel1.Location = new Point(0x59, 0x67);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x113, 0x2b);
            this.panel1.TabIndex = 7;
            this.textDescription.CharacterCasing = CharacterCasing.Upper;
            this.textDescription.Location = new Point(0x59, 0x41);
            this.textDescription.MaxLength = 50;
            this.textDescription.Name = "textDescription";
            this.textDescription.Size = new Size(0x1d2, 20);
            this.textDescription.TabIndex = 8;
            this.textValueType.CharacterCasing = CharacterCasing.Upper;
            this.textValueType.Location = new Point(0x59, 0x27);
            this.textValueType.MaxLength = 10;
            this.textValueType.Name = "textValueType";
            this.textValueType.Size = new Size(0xa5, 20);
            this.textValueType.TabIndex = 9;
            this.textValueType.KeyPress += new KeyPressEventHandler(this.textValueType_KeyPress);
            this.radioTrade.AutoSize = true;
            this.radioTrade.Checked = true;
            this.radioTrade.Location = new Point(0x12, 13);
            this.radioTrade.Name = "radioTrade";
            this.radioTrade.Size = new Size(0x35, 0x11);
            this.radioTrade.TabIndex = 0;
            this.radioTrade.TabStop = true;
            this.radioTrade.Text = "Trade";
            this.radioTrade.UseVisualStyleBackColor = true;
            this.radioNonTrade.AutoSize = true;
            this.radioNonTrade.Location = new Point(0x62, 13);
            this.radioNonTrade.Name = "radioNonTrade";
            this.radioNonTrade.Size = new Size(0x4c, 0x11);
            this.radioNonTrade.TabIndex = 1;
            this.radioNonTrade.Text = "Non Trade";
            this.radioNonTrade.UseVisualStyleBackColor = false;
            this.radioBoth.AutoSize = true;
            this.radioBoth.Location = new Point(0xc6, 13);
            this.radioBoth.Name = "radioBoth";
            this.radioBoth.Size = new Size(0x2f, 0x11);
            this.radioBoth.TabIndex = 2;
            this.radioBoth.Text = "Both";
            this.radioBoth.UseVisualStyleBackColor = true;
            this.button2.Location = new Point(0x109, 0xa5);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x63, 30);
            this.button2.TabIndex = 0x10;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(160, 0xa5);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x63, 30);
            this.button1.TabIndex = 15;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x238, 0xd7);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textValueType);
            base.Controls.Add(this.textDescription);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textBatch);
            base.Controls.Add(this.label1);
            base.Name = "FormBatchEntry";
            this.Text = "FormBatchEntry";
            base.Load += new EventHandler(this.FormBatchEntry_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBatch_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textValueType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }
    }
}

