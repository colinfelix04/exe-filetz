﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.TCSUtility;

    public class FormRefreshQC : Form
    {
        private IContainer components = null;
        public GroupBox groupBox3;
        public DateTimePicker monthCalendar1;
        public Label labelFromDate;
        public Label labelToDate;
        public DateTimePicker monthCalendar2;
        public Label label1;
        public Label label2;
        private TextBox textRef;
        private TextBox textComm;
        private Button button1;
        public GroupBox groupBox1;
        public Label label3;
        private TextBox List_Status;
        public Label labelHeader;
        public Button buttonClose;
        public Button buttonProcess;

        public FormRefreshQC()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.textComm.Focus();
            }
            commodity.Dispose();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if (!WBSetting.getQCfromTCS)
            {
                MessageBox.Show("Setting of retrieving QC from TCS has not been activated yet!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.List_Status.Text = "";
                string[] textArray1 = new string[] { "SELECT * FROM WB_TRANSACTION WHERE ", WBData.CompanyLocation(""), " AND report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), "'  AND report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), "' " };
                string sqltext = string.Concat(textArray1);
                if (this.textComm.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND comm_code = '" + this.textComm.Text.Trim() + "' ";
                }
                if (this.textRef.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND ref = '" + this.textRef.Text.Trim() + "' ";
                }
                sqltext = sqltext + " ORDER BY ref ";
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No records found!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else if (MessageBox.Show(table.DT.Rows.Count + " transaction(s) found.\nDo you want to continue? ", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    TextBox box = this.List_Status;
                    object[] objArray1 = new object[] { box.Text, table.DT.Rows.Count, " transaction(s) found.", Environment.NewLine, Environment.NewLine };
                    box.Text = string.Concat(objArray1);
                    int num = 1;
                    foreach (DataRow row in table.DT.Rows)
                    {
                        WBTable table2 = new WBTable();
                        string[] textArray2 = new string[] { "SELECT * FROM wb_transQC WHERE ", WBData.CompanyLocation(""), " AND ref = '", row["ref"].ToString(), "'  AND deduct = 'Y' " };
                        table2.OpenTable("wb_transQC", string.Concat(textArray2), WBData.conn);
                        if (table2.DT.Rows.Count > 0)
                        {
                            box = this.List_Status;
                            object[] objArray4 = new object[] { box.Text, num, ". ", row["ref"].ToString(), " can't be updated (QC deducts net).", Environment.NewLine };
                            box.Text = string.Concat(objArray4);
                        }
                        else
                        {
                            string str2 = TCS_GetQC.refreshQC(row["ref"].ToString());
                            if (str2.ToLower() != "has been updated")
                            {
                                box = this.List_Status;
                                object[] objArray3 = new object[] { box.Text, num, ". ", row["ref"].ToString(), " ", str2, Environment.NewLine };
                                box.Text = string.Concat(objArray3);
                            }
                            else
                            {
                                string keyField = row["uniq"].ToString();
                                row.BeginEdit();
                                row["reposted"] = "N";
                                row["checksum"] = table.Checksum(row);
                                row.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Refresh QC from TCS" };
                                Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                                box = this.List_Status;
                                object[] objArray2 = new object[] { box.Text, num, ". ", row["ref"].ToString(), " ", str2, Environment.NewLine };
                                box.Text = string.Concat(objArray2);
                            }
                        }
                        num++;
                        table2.Dispose();
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRefreshQC_Load(object sender, EventArgs e)
        {
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_commodity", "SELECT comm_code FROM wb_commodity WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(tbl, "Comm_code", this.textComm);
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_transaction", "SELECT ref FROM wb_transaction WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(table2, "ref", this.textRef);
        }

        private void InitializeComponent()
        {
            this.groupBox3 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.labelFromDate = new Label();
            this.labelToDate = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.textRef = new TextBox();
            this.textComm = new TextBox();
            this.button1 = new Button();
            this.groupBox1 = new GroupBox();
            this.label3 = new Label();
            this.List_Status = new TextBox();
            this.labelHeader = new Label();
            this.buttonClose = new Button();
            this.buttonProcess = new Button();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.labelFromDate);
            this.groupBox3.Controls.Add(this.labelToDate);
            this.groupBox3.Controls.Add(this.monthCalendar2);
            this.groupBox3.Location = new Point(0x10, 0x13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1a7, 0x3d);
            this.groupBox3.TabIndex = 0x51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Report Date";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x63, 0x1a);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelFromDate.AutoSize = true;
            this.labelFromDate.Location = new Point(0x1b, 0x1d);
            this.labelFromDate.Name = "labelFromDate";
            this.labelFromDate.Size = new Size(0x3e, 13);
            this.labelFromDate.TabIndex = 3;
            this.labelFromDate.Text = "From Date :";
            this.labelToDate.AutoSize = true;
            this.labelToDate.Location = new Point(0xee, 0x1d);
            this.labelToDate.Name = "labelToDate";
            this.labelToDate.Size = new Size(0x34, 13);
            this.labelToDate.TabIndex = 4;
            this.labelToDate.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x128, 0x1a);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(13, 0x61);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x56, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Commodity Code";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(13, 0x7b);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x29, 13);
            this.label2.TabIndex = 0x52;
            this.label2.Text = "Ref No";
            this.textRef.Location = new Point(0x73, 120);
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0xd1, 20);
            this.textRef.TabIndex = 0x53;
            this.textComm.Location = new Point(0x73, 0x5e);
            this.textComm.Name = "textComm";
            this.textComm.Size = new Size(0xb2, 20);
            this.textComm.TabIndex = 0x54;
            this.button1.Location = new Point(0x12b, 0x5c);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x19, 0x17);
            this.button1.TabIndex = 0x55;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textComm);
            this.groupBox1.Controls.Add(this.textRef);
            this.groupBox1.Location = new Point(15, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1c3, 0x98);
            this.groupBox1.TabIndex = 0x52;
            this.groupBox1.TabStop = false;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(12, 0xdb);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x79, 13);
            this.label3.TabIndex = 0x56;
            this.label3.Text = "Status of Refreshing QC";
            this.List_Status.Location = new Point(15, 0xeb);
            this.List_Status.Multiline = true;
            this.List_Status.Name = "List_Status";
            this.List_Status.ReadOnly = true;
            this.List_Status.ScrollBars = ScrollBars.Vertical;
            this.List_Status.Size = new Size(0x1c3, 0x70);
            this.List_Status.TabIndex = 0x57;
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(11, 0x12);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0xb7, 20);
            this.labelHeader.TabIndex = 0x67;
            this.labelHeader.Text = "Refresh QC from TCS";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x164, 0x16b);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x6d;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(240, 0x16b);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 0x6c;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ec, 0x1a3);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.labelHeader);
            base.Controls.Add(this.List_Status);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.groupBox1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormRefreshQC";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Refresh QC from TCS";
            base.Load += new EventHandler(this.FormRefreshQC_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

