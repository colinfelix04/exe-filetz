﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMillEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private IContainer components = null;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private Button button2;
        private Button button1;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label8;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        public TextBox textBox1;

        public FormMillEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_Mill", "Select Uniq From wb_Mill Where " + WBData.CompanyLocation(" and ( Mill_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.CompanyLocation(" and ( Mill_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray1 = new string[13];
                            textArray1[0] = Resource.Mes_152;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textBox1.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "\n\nTransaction  : ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Mes_047B;
                            textArray1[11] = "\n\n\n";
                            textArray1[12] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Mill Code" },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Mill_Code"] = this.textBox1.Text;
            this.zTable.DR["Mill_Name"] = this.textBox2.Text;
            this.zTable.DR["Address"] = this.textBox3.Text;
            this.zTable.DR["City"] = this.textBox4.Text;
            this.zTable.DR["SAP_Code"] = this.textBox5.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_mill", "SELECT uniq FROM wb_mill WHERE " + WBData.CompanyLocation(" AND mill_code = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_mill", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Mill_Code" };
                string[] aNewValue = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Mill_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit mill master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMillEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMillEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Mill_Code"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Mill_Name"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Address"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["City"].Value.ToString();
                this.textBox5.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
            }
            this.label8.Text = this.sapIDSYS + this.label8.Text;
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox5 = new TextBox();
            this.textBox4 = new TextBox();
            this.textBox3 = new TextBox();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label8 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.label1 = new Label();
            base.SuspendLayout();
            this.button2.Location = new Point(0x1a6, 0xa7);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x21);
            this.button2.TabIndex = 8;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x142, 0xa7);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x21);
            this.button1.TabIndex = 7;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox5.Location = new Point(0x65, 0x86);
            this.textBox5.MaxLength = 0x1c;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Size(0xa5, 20);
            this.textBox5.TabIndex = 5;
            this.textBox4.Location = new Point(0x65, 0x6c);
            this.textBox4.MaxLength = 50;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0xa5, 20);
            this.textBox4.TabIndex = 4;
            this.textBox3.Location = new Point(0x65, 0x40);
            this.textBox3.MaxLength = 150;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x180, 0x26);
            this.textBox3.TabIndex = 3;
            this.textBox2.Location = new Point(0x65, 0x26);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x180, 20);
            this.textBox2.TabIndex = 2;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x65, 12);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 1;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x27, 0x89);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x38, 13);
            this.label8.TabIndex = 0x1b;
            this.label8.Text = " Code";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x47, 0x6f);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x18, 13);
            this.label4.TabIndex = 0x17;
            this.label4.Text = "City";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(50, 0x43);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x2d, 13);
            this.label3.TabIndex = 0x16;
            this.label3.Text = "Address";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x2a, 0x29);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 0x15;
            this.label2.Text = "Mill Name";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x2d, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(50, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Mill Code";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1fd, 0xd6);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox5);
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormMillEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Mill";
            base.Load += new EventHandler(this.FormMillEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMillEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

