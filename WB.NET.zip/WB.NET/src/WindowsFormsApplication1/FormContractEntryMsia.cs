﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormContractEntryMsia : Form
    {
        public WBTable zTable;
        public string pMode;
        public string spMode;
        public string grCust = "";
        public string qst = "";
        public string changeReason = "";
        public string logKey = "";
        public string qst_desc = "";
        public string origin = "";
        public int nCurrRow;
        public int SO_ITEM_COUNT;
        public bool saved = false;
        public bool ReplaceAll = false;
        public bool HasBeenClosed = false;
        public DataGridView dataGridView1;
        public string OldCode = "";
        private WBTable tmpContract = new WBTable();
        private DataRow contractBefore;
        private DataRow row_comm;
        private DataRow row_type;
        public WBTable tblTransType = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblRelation = new WBTable();
        public WBTable tblEstate = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblRefCode = new WBTable();
        public WBTable tblLocation = new WBTable();
        public WBTable tblLocation_timbun = new WBTable();
        public WBTable tblContract_log = new WBTable();
        public WBTable tblIscc = new WBTable();
        public WBTable tblIncoterm = new WBTable();
        public WBTable tblDeductedBy = new WBTable();
        public WBTable t_plant = new WBTable();
        public WBTable t_sloc = new WBTable();
        public WBTable t_typ = new WBTable();
        public string needAdoptNego = "N";
        public WBTable tblContractGRCust = new WBTable();
        private FormContractEntryMsia fTimbun;
        public string close = "N";
        public string adopt = "N";
        public string uniq_contract = "";
        private string[] hasil = new string[3];
        private IRfcStructure ISReturn;
        private string oldDo = "";
        private string oldComm = "";
        private string oldrelation = "";
        private string oldTransporter = "";
        private string oldEstate = "";
        private string oldTransType = "";
        private string oldPI_No = "";
        private string old_STO = "";
        private string old_gr_gust = "";
        private string oldTolling = "";
        private string oldISCC = "";
        private string oldRemark = "";
        private string sapComm = "";
        private string sapVend = "";
        private string sapTranspt = "";
        private string sapEstate = "";
        private string screen = "";
        private string GRPO_Cust = "";
        private string timbunCoy;
        private string timbunBatch;
        private string Std;
        private string Bulk;
        private string IO;
        private string trade = "T";
        private bool timbunSave;
        private bool tokenGRCust = false;
        private bool IsSugar = false;
        private bool is_vessel = false;
        public string timbunUniq = "";
        public string noToken = "";
        public string vTokenGRCust = "";
        public string completeGRtoken = "";
        private string TimbunCoy_beforeEdit;
        public int num_of_do = 0;
        public int num_of_do2 = 0;
        public string[,] map = new string[0x3e7, 20];
        private string approve_type = "";
        private string approveBy1 = "";
        private string Approve_Reason = "";
        public int num_of_mill = 0;
        public string[,] map_mill = new string[0x3e7, 14];
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        public int MillMulesoft;
        private IContainer components = null;
        private Label label1;
        public TextBox textDO;
        private Label label2;
        private DateTimePicker dateTimeDO;
        private DateTimePicker dateTimeContract;
        private Label label3;
        private TextBox textContract;
        private Label label4;
        private Label label7;
        private Label label8;
        private Label relationName;
        private Label CommodityName;
        private Label label9;
        private Label label10;
        private CheckBox checkQuantity;
        private TabControl tabControl1;
        private TabPage tabPageRef;
        private TabPage tabPagePOM;
        private Label label15;
        private TextBox textVessel;
        private Label label14;
        private Label label12;
        private Label label23;
        private TextBox textNEGO;
        private Label label21;
        private TextBox textGRPO;
        private Label label20;
        private TextBox textSTO;
        private Label label25;
        private TextBox textRemark;
        private Button buttonSave;
        private Button buttonCancel;
        private Label label39;
        private TextBox textScout2;
        private Label label40;
        private TextBox textScout1;
        private Label label37;
        private TextBox textLoose2;
        private Label label38;
        private TextBox textLoose1;
        private Label label35;
        private TextBox textSmall2;
        private Label label36;
        private TextBox textSmall1;
        private Label label33;
        private TextBox textMid2;
        private Label label34;
        private TextBox textMid1;
        private Label label32;
        private TextBox textLarge2;
        private Label label31;
        private TextBox textLarge1;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label45;
        private CheckBox checkISCC;
        private Label labelEstateADM;
        private Button btnAdopt;
        private Label labelPO;
        private TextBox textPO;
        private Label label46;
        private TextBox textTransporter;
        public TextBox textType;
        private Button buttonType;
        private TextBox textCommodity;
        private Button button1;
        private TextBox textVend;
        private Button button2;
        private Button button3;
        private Label TransporterName;
        private Label labelTransTypeName;
        private CheckBox checkBerikat;
        private Label label48;
        private TextBox textPI_No;
        private GroupBox groupBoxConversion;
        public Label labelConvValue;
        public TextBox textConvValue;
        public Label label50;
        public TextBox textConvUnit;
        public Label label51;
        private Label label49;
        private Label label52;
        private TextBox textTolerance;
        private Label label53;
        private ComboBox comboUploadType;
        private Button btnEstate;
        private Label label54;
        private TextBox textPOItem;
        private TextBox textQuantity;
        private Label label58;
        private TextBox textSTO_Item;
        private GroupBox groupBox4;
        private RadioButton radioRamp;
        private RadioButton radioKebAgen;
        private RadioButton radioAgen;
        private RadioButton radioOthers;
        private RadioButton radioOtherGroup;
        private RadioButton radioGroupEstate;
        private DateTimePicker dateDO_period;
        private CheckBox checkPeriod;
        private CheckBox checkSTO1DO;
        private TabPage tabPage3;
        private TextBox textSTO1;
        private Label label13;
        private CheckBox checkAgen;
        private Label labelRefDes;
        private Label label41;
        private ComboBox comboRefCode;
        private ComboBox comboBillOfLading;
        private Label label24;
        private Label label43;
        private Label labelFactoryOpening;
        private Label labelKG3rd;
        private Label label3rdOpening;
        private TextBox textOpnEntryEstate;
        private TextBox textOpnEntryFactory;
        private GroupBox groupBoxFruit;
        private GroupBox groupBoxEntry;
        private TextBox textEstate;
        private TextBox textGRPO_Cust;
        private Label label5;
        private CheckBox checkTolling;
        private Button buttonAdopt2;
        private ToolTip toolTip1;
        private TabPage tabPageOpening;
        private Label labelPO1;
        private TextBox textPO1;
        private RadioButton radioBuyer;
        private RadioButton radioSeller;
        private GroupBox groupBoxDeducted;
        private Label label18;
        private Label label44;
        private Label label42;
        private Label label19;
        private Label labelQualityInfo;
        private RichTextBox textQualityInfo;
        private TextBox textToken;
        private Label labelPO1Item;
        private TextBox textPO1Item;
        private TextBox txtQStandard;
        private Label lblQstandard;
        private Label labelIncotermCode;
        private ComboBox comboIncoterm;
        private Button buttonCheckOS;
        private TextBox textBoxOS;
        private Label label11;
        private Panel panelCheckOS;
        private Label labelSlash;
        private TextBox textSTOItem;
        private GroupBox panelLangsir;
        private Panel panel_TP;
        private Label label_tp_desc;
        public RadioButton radioLangsir2;
        public RadioButton radioLangsir;
        public RadioButton radioLangsirTransfer;
        public RadioButton radioLangsirTtb;
        private Button buttonPreview;
        private TextBox textTimbunCoy;
        private Button buttonLocation;
        public RadioButton radioLangsirNone;
        private TextBox textBatch;
        private ComboBox cb_sloc;
        private ComboBox cb_plant;
        private TextBox txt_mill;
        private Label label6;
        private Button btn_mill;
        private CheckBox cb_gain_loss;
        private Label label16;
        private ComboBox cb_langsir_type;
        private Label label_langsir_desc;
        private ComboBox comboUploadType1;
        private Label label17;
        private TextBox textQstDesc;
        private TextBox textQst;
        private Label labelQStandard;
        private TextBox textOrigin;
        private Label labelOrigin;

        public FormContractEntryMsia()
        {
            this.InitializeComponent();
        }

        private void actTrade()
        {
        }

        public void adoptContractWithMulesoft()
        {
            bool flag = false;
            try
            {
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                string str = "";
                string str2 = "";
                string str3 = "";
                string str4 = "";
                string str5 = "";
                string str6 = "";
                string str7 = "";
                if (WBSetting.locType == "0")
                {
                    str = this.textSTO.Text.Trim();
                    str2 = this.textGRPO.Text.Trim();
                    str4 = this.textNEGO.Text.Trim();
                    if (this.IO == "I")
                    {
                        str3 = this.textPO.Text.Trim();
                        str5 = "";
                    }
                    else if (this.IO == "O")
                    {
                        str3 = "";
                        str5 = this.textPO.Text.Trim();
                    }
                    str6 = this.textPOItem.Text.Trim();
                    str7 = this.textSTOItem.Text.Trim();
                }
                else
                {
                    str = this.textSTO1.Text.Trim();
                    str2 = this.textGRPO.Text.Trim();
                    str4 = this.textNEGO.Text.Trim();
                    if (this.IO == "I")
                    {
                        str3 = this.textPO1.Text.Trim();
                        str5 = "";
                    }
                    else if (this.IO == "O")
                    {
                        str3 = "";
                        str5 = this.textPO1.Text.Trim();
                    }
                    str6 = this.textPO1Item.Text.Trim();
                    str7 = this.textSTO_Item.Text.Trim();
                }
                string str8 = integrator.getURL("ZWB_GET_POSO");
                if (str8 != "")
                {
                    string[] textArray1 = new string[15];
                    textArray1[0] = str8;
                    textArray1[1] = "?sto=";
                    textArray1[2] = str;
                    textArray1[3] = "&grpo=";
                    textArray1[4] = str2;
                    textArray1[5] = "&po=";
                    textArray1[6] = str3;
                    textArray1[7] = "&nego=";
                    textArray1[8] = str4;
                    textArray1[9] = "&so=";
                    textArray1[10] = str5;
                    textArray1[11] = "&ebelp=";
                    textArray1[12] = str6;
                    textArray1[13] = "&ebelp_sto=";
                    textArray1[14] = str7;
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    string[] resultHeaderName = new string[] { "ERRORS", "DOC_DETAIL", "REASON", "MESSAGE_ID" };
                    dictionary = integrator.getDataFromMulesoft(string.Concat(textArray1), resultHeaderName, out err);
                    if (!err)
                    {
                        if (dictionary["ERRORS"].Count > 0)
                        {
                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            foreach (Dictionary<string, string> dictionary2 in dictionary["DOC_DETAIL"])
                            {
                                if (dictionary2["NOT_EXIST"] == "X")
                                {
                                    MessageBox.Show("Adopt Failed. No Data From SAP!", "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    string str9 = "";
                                    string str10 = "";
                                    string str11 = "";
                                    string str12 = "";
                                    string str13 = "";
                                    string str14 = "";
                                    string str15 = "";
                                    string str16 = "";
                                    string str17 = "";
                                    string incoterm = "";
                                    string str19 = "";
                                    string str20 = "";
                                    string str21 = "";
                                    string str22 = "";
                                    str9 = dictionary2["TYPE"];
                                    str10 = dictionary2["DOCNO"];
                                    str12 = dictionary2["MATNR"];
                                    str11 = dictionary2["RELATION"];
                                    str13 = dictionary2["TRANSPORTER"];
                                    str14 = dictionary2["QTY"];
                                    str15 = dictionary2["UEBTO"];
                                    str16 = dictionary2["UEBTK"];
                                    str17 = dictionary2["UNTTO"];
                                    str19 = dictionary2["KB"];
                                    str20 = dictionary2["AGENT"];
                                    incoterm = dictionary2["INCO1"].ToUpper();
                                    str21 = dictionary2["MILL"].ToUpper();
                                    try
                                    {
                                        str22 = dictionary2["POSNR"].ToUpper();
                                    }
                                    catch
                                    {
                                        str22 = "";
                                    }
                                    this.textQuantity.Text = str14;
                                    this.checkBerikat.Checked = str19 == "X";
                                    this.checkAgen.Checked = str20 == "X";
                                    this.textTolerance.Text = str15;
                                    this.checkQuantity.Checked = str16 != "X";
                                    this.comboIncoterm.Text = incoterm;
                                    if (this.txt_mill.Text.Trim() == "")
                                    {
                                        this.txt_mill.Text = str21;
                                    }
                                    this.cekinco(incoterm, this.textType.Text);
                                    this.qst = dictionary2["ZZISCC"];
                                    this.txtQStandard.Text = dictionary2["ZZISCC_DESC"];
                                    this.origin = dictionary2["ZZORIGIN"];
                                    this.qst_desc = dictionary2["QSTD_DESC"];
                                    this.textQst.Text = this.qst;
                                    this.textQstDesc.Text = this.qst_desc;
                                    this.textOrigin.Text = this.origin;
                                    this.SO_ITEM_COUNT = Convert.ToInt16(dictionary2["SO_ITEM_COUNT"]);
                                    if (this.textPOItem.Text.Trim() == "")
                                    {
                                        this.textPOItem.Text = str22;
                                    }
                                    if (str12 != "")
                                    {
                                        this.textCommodity.Text = this.getData("wb_commodity", "material", str12, "comm_code");
                                        flag = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Trade") != "N";
                                        this.ChkComm(0);
                                        this.textVend.Text = this.getData("wb_relation", "sap_code", str11, "relation_code");
                                        this.ChkVend(0);
                                        if ((this.IO != "O") || (((this.comboIncoterm.Text != "LCO") && (this.comboIncoterm.Text != "FOB")) && (this.comboIncoterm.Text != "CIF")))
                                        {
                                            this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str13, "transporter_code");
                                            this.ChkTransporter(0);
                                        }
                                        else if (this.textTransporter.Text.Trim() == "")
                                        {
                                            this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str13, "transporter_code");
                                            this.ChkTransporter(0);
                                        }
                                    }
                                    this.adopt = "Y";
                                    if ((str12 != "") && (str12.Substring(0, 2) == "7."))
                                    {
                                        string str23 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Gross_Weight");
                                        string str24 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Netto_Weight");
                                        string str25 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Tolerance");
                                        if (((str23 == "0") || ((str23 == "") || ((str24 == "") || ((str24 == "0") || (str25 == ""))))) || (str25 == ""))
                                        {
                                            MessageBox.Show("\nCONVERTION WEIGHT \n" + (((this.textCommodity.Text.Trim() + " : ") + ("\n Gross Weight is " + str23) + ("\n Netto Weight is " + str24)) + ("\n Tolerance is " + str25) + "\n\n This Commodity do not have maintain Gross, Netto Weight & Tolerance"), "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.textCommodity.Text = "";
                                            this.CommodityName.Text = "";
                                            this.adopt = "N";
                                        }
                                    }
                                    if (this.adopt == "Y")
                                    {
                                        MessageBox.Show("Adopt Finish", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    }
                                    if (((this.labelPO.Text == "SO") && (this.SO_ITEM_COUNT < 2)) && (this.textPO.Text != ""))
                                    {
                                        this.textDO.Text = this.textPO.Text;
                                        this.textDO.ReadOnly = true;
                                        this.textPO.ReadOnly = true;
                                    }
                                }
                                if (this.SO_ITEM_COUNT <= 1)
                                {
                                    this.textQuantity.ReadOnly = true;
                                    this.textTolerance.ReadOnly = true;
                                    this.checkQuantity.Enabled = false;
                                }
                                else
                                {
                                    this.textQuantity.ReadOnly = false;
                                    this.textTolerance.ReadOnly = false;
                                    this.checkQuantity.Enabled = true;
                                    this.checkQuantity.Checked = true;
                                    this.textQuantity.Text = "0";
                                    this.textTolerance.Text = "0";
                                }
                                this.comboIncoterm.Enabled = false;
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error " + exception.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void adoptData()
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            string incoterm = "";
            string str7 = "";
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_ZGRTRANSIT");
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("WA_DATA");
                    structure.SetValue("GRPO_NO", this.textGRPO.Text);
                    structure.SetValue("GRPO_CUST_NO", this.textGRPO_Cust.Text);
                    structure.SetValue("STO_NO", this.textSTO.Text);
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    this.ISReturn = WBSAP.rfcFunction.GetStructure("WA_RECORD");
                    if (this.ISReturn.GetString("NOT_EXIST") != "")
                    {
                        MessageBox.Show("Adopt Failed. No Data From SAP", "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        this.qst = this.ISReturn.GetString("ZZISCC");
                        this.txtQStandard.Text = this.ISReturn.GetString("ZZISCC_DESC");
                        str = this.ISReturn.GetString("PO_NO");
                        this.textPO.Text = str;
                        str2 = this.ISReturn.GetString("DO_No");
                        this.textDO.Text = str2;
                        str3 = this.ISReturn.GetString("GRPO");
                        this.textGRPO.Text = str3;
                        str4 = this.ISReturn.GetString("TOLERANCE");
                        this.textTolerance.Text = str4;
                        str5 = this.ISReturn.GetString("DO_DATE");
                        this.dateTimeDO.Value = Convert.ToDateTime(str5);
                        incoterm = this.ISReturn.GetString("INCO1");
                        this.comboIncoterm.Text = incoterm;
                        this.cekinco(incoterm, this.textType.Text);
                        this.checkBerikat.Checked = false;
                        str7 = this.ISReturn.GetString("KB");
                        this.checkBerikat.Checked = str7 == "X";
                        this.textVend.Text = this.getData("wb_Relation", "sap_code", this.ISReturn.GetString("Vendor"), "relation_code");
                        this.sapVend = this.ISReturn.GetString("Vendor");
                        this.ChkVend(0);
                        this.textTransporter.Text = this.getData("wb_transporter", "sap_code", this.ISReturn.GetString("Transporter"), "transporter_code");
                        this.sapTranspt = this.ISReturn.GetString("Transporter");
                        this.ChkTransporter(0);
                        this.textEstate.Text = this.getData("wb_Estate", "sap_code", this.ISReturn.GetString("Estate"), "Estate_code");
                        this.sapEstate = this.ISReturn.GetString("Estate");
                        this.ChkEstate(0);
                        this.textCommodity.Text = this.getData("wb_commodity", "material", this.ISReturn.GetString("Commodity"), "comm_code");
                        this.sapComm = this.ISReturn.GetString("Commodity");
                        this.ChkComm(0);
                        this.textQuantity.Text = Program.StrToDouble(this.ISReturn.GetString("Qty"), 0).ToString();
                        this.textQualityInfo.Text = this.getQualityInfo(this.ISReturn);
                        this.GRPO_Cust = this.textGRPO_Cust.Text;
                        this.adopt = "Y";
                        this.textVend.Enabled = false;
                        this.textEstate.Enabled = false;
                        this.textTransporter.Enabled = false;
                        this.textEstate.Enabled = false;
                        this.textCommodity.Enabled = false;
                        this.textDO.Enabled = false;
                        MessageBox.Show("Adopt Data Finish....", "F I N I S H", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.textQuantity.ReadOnly = true;
                        this.textTolerance.ReadOnly = true;
                        this.checkQuantity.Checked = true;
                        this.checkQuantity.Enabled = false;
                        this.comboIncoterm.Enabled = false;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        public void adoptMillwithMulesoft()
        {
            bool flag = false;
            try
            {
                string coySAP = "";
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                coySAP = WBSetting.CoySAP;
                string str2 = integrator.getURL("ZWB_GET_MILL");
                if (str2 != "")
                {
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    string[] resultHeaderName = new string[] { "ERRORS", "I_MILL", "MESSAGE_ID" };
                    dictionary = integrator.getDataFromMulesoft(str2 + "?lokasi=" + coySAP, resultHeaderName, out err);
                    if (!err)
                    {
                        if (dictionary["ERRORS"].Count > 0)
                        {
                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            List<Dictionary<string, string>> source = dictionary["I_MILL"];
                            this.MillMulesoft = source.Count<Dictionary<string, string>>();
                            if (this.MillMulesoft > 0)
                            {
                                int num = 0;
                                while (true)
                                {
                                    if (num >= source.Count<Dictionary<string, string>>())
                                    {
                                        flag = true;
                                        break;
                                    }
                                    int num2 = 0;
                                    foreach (KeyValuePair<string, string> pair in source[num])
                                    {
                                        this.map[num, num2] = pair.Value.ToString().Trim();
                                    }
                                    num2++;
                                    num++;
                                }
                            }
                            if (!flag)
                            {
                                MessageBox.Show("No Mill from SAP", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.txt_mill.Enabled = true;
                            }
                            else
                            {
                                FormMillMsia msia = new FormMillMsia {
                                    DATA_FROM = "RFC",
                                    map_mill = this.map_mill,
                                    num_of_mill = this.num_of_mill,
                                    relation_code = this.textVend.Text
                                };
                                msia.ShowDialog();
                                if (msia.mill != "")
                                {
                                    this.txt_mill.Text = msia.mill;
                                }
                            }
                            if (dictionary["I_MILL"].Count <= 0)
                            {
                                MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error from SAP: " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void bacaNego()
        {
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_NEGO");
                    WBSAP.rfcFunction.SetValue("NEGNR", this.textNEGO.Text);
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("ZPOM_NEGO_H");
                    if (structure.GetString("LIFNR") == "")
                    {
                        MessageBox.Show("Adopt Failed. No Data From SAP", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        string str = structure.GetString("LIFNR");
                        string str2 = structure.GetString("MATNR");
                        string str3 = structure.GetString("NEGMG");
                        string str4 = structure.GetString("INCO1");
                        string str5 = structure.GetString("agen");
                        string str6 = structure.GetString("DTYPE");
                        string str7 = structure.GetString("FIXMG");
                        this.checkQuantity.Enabled = true;
                        this.textQuantity.Enabled = true;
                        if ((str6 == "K") && (str7 == "X"))
                        {
                            this.checkQuantity.Enabled = false;
                            this.textQuantity.Enabled = false;
                        }
                        this.textQuantity.Text = str3;
                        this.textVend.Text = this.getData("wb_relation", "sap_code", str, "relation_code");
                        this.ChkVend(0);
                        this.sapVend = str;
                        this.sapComm = str2;
                        this.textCommodity.Text = this.getData("wb_commodity", "material", str2, "comm_code");
                        this.ChkComm(0);
                        this.dateTimeDO.Value = Convert.ToDateTime(structure.GetString("NEGDT"));
                        this.textTolerance.Text = "3";
                        this.checkAgen.Checked = str5 == "X";
                        this.checkQuantity.Checked = str7 == "X";
                        this.comboIncoterm.Text = str4;
                        this.textVend.Enabled = this.textCommodity.Enabled = false;
                        MessageBox.Show("Adopt Success", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.needAdoptNego = "N";
                        this.textQuantity.ReadOnly = true;
                        this.textTolerance.ReadOnly = true;
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void bacaPOSO()
        {
            bool flag = false;
            if (WBSetting.activeMulesoftIntegration)
            {
                this.adoptContractWithMulesoft();
            }
            else
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (WBSAP.connect())
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_POSO");
                        IRfcStructure structure = WBSAP.rfcFunction.GetStructure("DOCNO");
                        if (WBSetting.locType == "0")
                        {
                            structure.SetValue(0, this.textSTO.Text);
                            structure.SetValue(1, this.textGRPO.Text);
                            structure.SetValue(3, this.textNEGO.Text);
                            if (this.IO == "I")
                            {
                                structure.SetValue(2, this.textPO.Text);
                                structure.SetValue(4, "");
                            }
                            else if (this.IO == "O")
                            {
                                structure.SetValue(2, "");
                                structure.SetValue(4, this.textPO.Text);
                            }
                            structure.SetValue(5, this.textPOItem.Text);
                            structure.SetValue(6, this.textSTOItem.Text);
                        }
                        else
                        {
                            structure.SetValue(0, this.textSTO1.Text);
                            structure.SetValue(1, this.textGRPO.Text);
                            structure.SetValue(3, this.textNEGO.Text);
                            if (this.IO == "I")
                            {
                                structure.SetValue(2, this.textPO1.Text);
                                structure.SetValue(4, "");
                            }
                            else if (this.IO == "O")
                            {
                                structure.SetValue(2, "");
                                structure.SetValue(4, this.textPO1.Text);
                            }
                            structure.SetValue(5, this.textPO1Item.Text);
                            structure.SetValue(6, this.textSTO_Item.Text);
                        }
                        WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                        IRfcStructure structure2 = WBSAP.rfcFunction.GetStructure("DOC_DETAIL");
                        string str = "";
                        string str2 = "";
                        string str3 = "";
                        string str4 = "";
                        string str5 = "";
                        string str6 = "";
                        string str7 = "";
                        string str8 = "";
                        string str9 = "";
                        string incoterm = "";
                        string str11 = "";
                        string str12 = "";
                        string str13 = "";
                        string str14 = "";
                        if (structure2.GetString("NOT_EXIST") == "X")
                        {
                            MessageBox.Show("Adopt Failed. No Data From SAP");
                        }
                        else
                        {
                            str = structure2.GetString("TYPE");
                            str2 = structure2.GetString("DOCNO");
                            str4 = structure2.GetString("MATNR");
                            str3 = structure2.GetString("relation");
                            str5 = structure2.GetString("TRANSPORTER");
                            str6 = structure2.GetString("QTY");
                            str7 = structure2.GetString("UEBTO");
                            str8 = structure2.GetString("UEBTK");
                            str9 = structure2.GetString("UNTTO");
                            str11 = structure2.GetString("KB");
                            str12 = structure2.GetString("AGENT");
                            incoterm = structure2.GetString("INCO1").ToUpper();
                            str13 = structure2.GetString("MILL").ToUpper();
                            try
                            {
                                str14 = structure2.GetString("POSNR").ToUpper();
                            }
                            catch
                            {
                                str14 = "";
                            }
                            this.textQuantity.Text = str6;
                            this.checkBerikat.Checked = str11 == "X";
                            this.checkAgen.Checked = str12 == "X";
                            this.textTolerance.Text = str7;
                            this.checkQuantity.Checked = str8 != "X";
                            this.comboIncoterm.Text = incoterm;
                            if (this.txt_mill.Text.Trim() == "")
                            {
                                this.txt_mill.Text = str13;
                            }
                            this.cekinco(incoterm, this.textType.Text);
                            this.qst = structure2.GetString("ZZISCC");
                            this.txtQStandard.Text = structure2.GetString("ZZISCC_DESC");
                            this.origin = structure2.GetString("ZZORIGIN");
                            this.qst_desc = structure2.GetString("QSTD_DESC");
                            this.textQst.Text = this.qst;
                            this.textQstDesc.Text = this.qst_desc;
                            this.textOrigin.Text = this.origin;
                            this.SO_ITEM_COUNT = structure2.GetInt("SO_ITEM_COUNT");
                            if (this.textPOItem.Text.Trim() == "")
                            {
                                this.textPOItem.Text = str14;
                            }
                            if (str4 != "")
                            {
                                this.textCommodity.Text = this.getData("wb_commodity", "material", str4, "comm_code");
                                flag = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Trade") != "N";
                                this.ChkComm(0);
                                this.textVend.Text = this.getData("wb_relation", "sap_code", str3, "relation_code");
                                this.ChkVend(0);
                                if ((this.IO != "O") || (((this.comboIncoterm.Text != "LCO") && (this.comboIncoterm.Text != "FOB")) && (this.comboIncoterm.Text != "CIF")))
                                {
                                    this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str5, "transporter_code");
                                    this.ChkTransporter(0);
                                }
                                else if (this.textTransporter.Text.Trim() == "")
                                {
                                    this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str5, "transporter_code");
                                    this.ChkTransporter(0);
                                }
                            }
                            this.adopt = "Y";
                            if ((str4 != "") && (str4.Substring(0, 2) == "7."))
                            {
                                string str15 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Gross_Weight");
                                string str16 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Netto_Weight");
                                string str17 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Tolerance");
                                if (((str15 == "0") || ((str15 == "") || ((str16 == "") || ((str16 == "0") || (str17 == ""))))) || (str17 == ""))
                                {
                                    MessageBox.Show("\nCONVERTION WEIGHT \n" + (((this.textCommodity.Text.Trim() + " : ") + ("\n Gross Weight is " + str15) + ("\n Netto Weight is " + str16)) + ("\n Tolerance is " + str17) + "\n\n This Commodity do not have maintain Gross, Netto Weight & Tolerance"), "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.textCommodity.Text = "";
                                    this.CommodityName.Text = "";
                                    this.adopt = "N";
                                }
                            }
                            if (this.adopt == "Y")
                            {
                                MessageBox.Show("Adopt Finish", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                            if (((this.labelPO.Text == "SO") && (this.SO_ITEM_COUNT < 2)) && (this.textPO.Text != ""))
                            {
                                this.textDO.Text = this.textPO.Text;
                                this.textDO.ReadOnly = true;
                                this.textPO.ReadOnly = true;
                            }
                        }
                        if (this.SO_ITEM_COUNT <= 1)
                        {
                            this.textQuantity.ReadOnly = true;
                            this.textTolerance.ReadOnly = true;
                            this.checkQuantity.Enabled = false;
                        }
                        else
                        {
                            this.textQuantity.ReadOnly = false;
                            this.textTolerance.ReadOnly = false;
                            this.checkQuantity.Enabled = true;
                            this.checkQuantity.Checked = true;
                            this.textQuantity.Text = "0";
                            this.textTolerance.Text = "0";
                        }
                        this.comboIncoterm.Enabled = false;
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception2)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception4)
                {
                    MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void bacaSTO()
        {
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_STO");
                    WBSAP.rfcFunction.SetValue("EBELN", this.textSTO.Text);
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcTable table = WBSAP.rfcFunction.GetTable("TAB_STO");
                    string str = table.GetString("LIFNR");
                    string str2 = table.GetString("MATNR");
                    string str3 = table.GetString("MENGE");
                    if (str.Length <= 0)
                    {
                        MessageBox.Show("Not Found", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        this.textVend.Text = this.getData("wb_relation", "sap_code", str, "relation_code");
                        this.textCommodity.Text = this.getData("wb_commodity", "material", str2, "comm_code");
                        this.dateTimeDO.Value = Convert.ToDateTime(table.GetString("KDATB"));
                        this.textQuantity.Text = str3;
                        this.comboIncoterm.Text = "LCO";
                        this.radioSeller.Checked = true;
                        MessageBox.Show("STO found " + str, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btn_mill_Click(object sender, EventArgs e)
        {
            bool flag = false;
            if (!WBSetting.activeMulesoftIntegration)
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (WBSAP.connect())
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_MILL");
                        WBSAP.rfcFunction.SetValue("_LLOKASI", WBSetting.CoySAP.Trim());
                        WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                        IRfcTable table = WBSAP.rfcFunction.GetTable("I_MILL");
                        this.num_of_mill = table.RowCount;
                        if (this.num_of_mill > 0)
                        {
                            int num = 0;
                            while (true)
                            {
                                if (num >= table.RowCount)
                                {
                                    break;
                                }
                                int index = 0;
                                while (true)
                                {
                                    if (index >= 14)
                                    {
                                        num++;
                                        break;
                                    }
                                    this.map_mill[num, index] = table[num].GetString(index).Trim();
                                    index++;
                                }
                            }
                        }
                        flag = true;
                    }
                    else
                    {
                        return;
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Error from SAP: " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                if (!flag)
                {
                    MessageBox.Show("No Mill from SAP", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.txt_mill.Enabled = true;
                }
                else
                {
                    FormMillMsia msia = new FormMillMsia {
                        DATA_FROM = "RFC",
                        map_mill = this.map_mill,
                        num_of_mill = this.num_of_mill,
                        relation_code = this.textVend.Text
                    };
                    msia.ShowDialog();
                    if (msia.mill != "")
                    {
                        this.txt_mill.Text = msia.mill;
                    }
                }
            }
            else
            {
                this.adoptMillwithMulesoft();
            }
        }

        private void btnAdopt_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (WBSetting.locType != "1")
            {
                if (!(((this.comboIncoterm.Text == "LCO") || ((this.comboIncoterm.Text == "FOB") || (this.comboIncoterm.Text == "CIF"))) ? (this.IO == "I") : false) || ((this.textSTO.Text.Trim().Length > 0) || this.checkSTO1DO.Checked))
                {
                    if (this.textPOItem.Text == "")
                    {
                        if (this.IO == "I")
                        {
                            this.textPOItem.Text = "1";
                        }
                        else if (this.IO == "O")
                        {
                            this.textPOItem.Text = "10";
                        }
                    }
                    if ((this.textSTO.Text != "") && (this.textSTOItem.Text == ""))
                    {
                        this.textSTOItem.Text = "1";
                    }
                    else if (this.textSTO.Text == "")
                    {
                        this.textSTOItem.Text = "";
                    }
                    this.textDO.ReadOnly = false;
                    if (this.textGRPO_Cust.Text.Trim() != "")
                    {
                        this.adoptData();
                    }
                    else
                    {
                        this.bacaPOSO();
                    }
                    if (this.screen == "TIMBUN")
                    {
                        this.textDO.Enabled = this.textGRPO_Cust.Text.Trim() == "";
                    }
                }
                else
                {
                    MessageBox.Show("Please Fill in STO Number", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textSTO.Focus();
                    return;
                }
            }
            else
            {
                if (((this.textPO1.Text != "") && (this.textPO1Item.Text == "")) && (this.IO == "O"))
                {
                    this.textPO1Item.Text = "10";
                }
                if ((this.textSTO1.Text != "") && (this.textSTO_Item.Text == ""))
                {
                    this.textSTO_Item.Text = "1";
                }
                this.bacaPOSO();
            }
            WBSAP.SyncCommTrx();
            Cursor.Current = Cursors.Default;
        }

        private void btnEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                if (((this.adopt != "Y") || (this.sapEstate == "")) || (estate.ReturnRow["sap_code"].ToString().Trim() == this.sapEstate))
                {
                    this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                    this.labelEstateADM.Text = estate.ReturnRow["Estate_Name"].ToString();
                }
                else
                {
                    MessageBox.Show("Cannot Choose Estate with Different SAP Code.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            estate.Dispose();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textCommodity.Text.Trim()
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                if (!(((this.adopt != "Y") || (this.sapComm == "")) ? ((this.needAdoptNego == "N") && (this.sapComm != "")) : true) || (commodity.ReturnRow["material"].ToString().Trim() == this.sapComm))
                {
                    this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                    this.CommodityName.Text = commodity.ReturnRow["comm_name"].ToString();
                    this.trade = commodity.ReturnRow["Trade"].ToString();
                    this.Bulk = commodity.ReturnRow["BulkPack"].ToString();
                    this.Std = commodity.ReturnRow["Type"].ToString();
                    this.actTrade();
                }
                else
                {
                    MessageBox.Show("Cannot Choose Commodity with Different SAP Code.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            commodity.Dispose();
            this.textCommodity.Focus();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textType.Text = type.ReturnRow["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = type.ReturnRow["Transaction_Name"].ToString();
                this.IO = type.ReturnRow["IO"].ToString();
                this.textPO.Enabled = true;
                if (this.IO == "I")
                {
                    this.labelPO.Text = "PO";
                    this.labelPO1.Text = "PO";
                    this.label1.Text = "Delivery Order No.";
                    this.label_tp_desc.Text = "Supplying Batch / Plant / S. Loc";
                }
                else if (this.IO == "O")
                {
                    this.labelPO.Text = "SO";
                    this.labelPO1.Text = "SO";
                    this.label1.Text = "Sales Order No.";
                    this.label_tp_desc.Text = "Destination Batch / Plant / S. Loc";
                }
            }
            this.tblTransType.ReOpen();
            type.Dispose();
            this.textType.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.pMode != "TIMBUN")
            {
                base.Close();
            }
            else
            {
                base.Hide();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.textVend.Text.Trim()
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                if (!(((this.adopt != "Y") || (this.sapVend == "")) ? ((this.needAdoptNego == "N") && (this.sapComm != "")) : true) || (vendor.ReturnRow["sap_code"].ToString().Trim() == this.sapVend))
                {
                    this.textVend.Text = vendor.ReturnRow["relation_code"].ToString();
                    this.relationName.Text = vendor.ReturnRow["relation_name"].ToString();
                    this.checkISCC.Checked = (vendor.ReturnRow["ISCC"].ToString() == "Y") || this.textQstDesc.Text.ToUpper().Contains("ISCC");
                    this.checkISCC.Enabled = (vendor.ReturnRow["ISCC"].ToString() == "Y") || this.textQstDesc.Text.ToUpper().Contains("ISCC");
                }
                else
                {
                    MessageBox.Show("Cannot Choose Relation with Different SAP Code.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            vendor.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE",
                pFind = this.textTransporter.Text.Trim()
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                if (((this.adopt != "Y") || (this.sapTranspt == "")) || (transporter.ReturnRow["sap_code"].ToString().Trim() == this.sapTranspt))
                {
                    this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                    this.TransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                    this.textTransporter.Focus();
                }
                else
                {
                    MessageBox.Show("Cannot Choose Transporter with Different SAP Code.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            transporter.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.timbunBatch = this.textVend.Text;
            this.showTimbunForm();
        }

        private void buttonCheckOS_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "DO_NO" };
            string[] aFind = new string[] { this.textDO.Text };
            if (ReferenceEquals(this.zTable.GetData(aField, aFind), null))
            {
                MessageBox.Show("DO No. Not Yet Saved please Save first and Try Again..");
            }
            else
            {
                this.textBoxOS.Text = Program.checkOS(this.textDO.Text, DateTime.Now.Date.ToString(), "", "").ToString();
            }
        }

        private void buttonLocation_Click(object sender, EventArgs e)
        {
            FormLocationTimbun timbun = new FormLocationTimbun {
                pMode = "CHOOSE",
                pCoy = WBData.sCoyCode
            };
            timbun.ShowDialog();
            if (timbun.ReturnRow != null)
            {
                this.textTimbunCoy.Text = timbun.ReturnRow["Timbun_code"].ToString();
                this.timbunBatch = timbun.ReturnRow["Relation_Code"].ToString();
                this.textTimbunCoy.Focus();
            }
            timbun.Dispose();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.f_Save();
        }

        private void cb_langsir_type_Leave(object sender, EventArgs e)
        {
            string[] aField = new string[] { "langsir_type" };
            string[] aFind = new string[] { this.cb_langsir_type.Text.Trim() };
            this.t_typ.DR = this.t_typ.GetData(aField, aFind);
            if (this.t_typ.DR != null)
            {
                this.label_langsir_desc.Text = this.t_typ.DR["langsir_desc"].ToString();
            }
            if (this.cb_langsir_type.Text.Trim() == "")
            {
                this.label_langsir_desc.Text = "";
            }
        }

        private void cb_langsir_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] aField = new string[] { "langsir_type" };
            string[] aFind = new string[] { this.cb_langsir_type.Text.Trim() };
            this.t_typ.DR = this.t_typ.GetData(aField, aFind);
            if (this.t_typ.DR != null)
            {
                this.label_langsir_desc.Text = this.t_typ.DR["langsir_desc"].ToString();
            }
            if (this.cb_langsir_type.Text.Trim() == "")
            {
                this.label_langsir_desc.Text = "";
            }
        }

        private bool cekAdoptSAP()
        {
            bool flag6;
            if (((WBSetting.IntegrationSAP != "Y") || ((this.trade != "T") || ((this.Std != "S") && (this.Std != "F")))) || (this.SO_ITEM_COUNT >= 2))
            {
                flag6 = true;
            }
            else
            {
                string[] aField = new string[] { "Transaction_Code" };
                string[] aFind = new string[] { this.textType.Text.ToString().Trim() };
                this.tblTransType.DR = this.tblTransType.GetData(aField, aFind);
                if (this.tblTransType.DR == null)
                {
                    flag6 = false;
                }
                else if ((this.tblTransType.DR["AdoptSAP"].ToString() != "Y") || (this.adopt == "Y"))
                {
                    flag6 = true;
                }
                else
                {
                    MessageBox.Show("Please Click Adopt first to save data", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    if (MessageBox.Show("Data Has Not Been Adopted From SAP, Use Token/Password Approval to Save without Adopt ?", "N O T I C E", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        flag6 = false;
                    }
                    else
                    {
                        this.hasil = this.tblTransType.tokenOrApp(this.textContract.Text.Trim(), "", "NOT_ADOPTSAP", "TOKEN_ADOPTSAP", "NOT_ADOPTSAP", "E", "", null);
                        if (this.hasil[0] == "cancel")
                        {
                            flag6 = false;
                        }
                        else
                        {
                            this.approve_type = "NOT_ADOPTSAP";
                            this.approveBy1 = this.hasil[1];
                            this.Approve_Reason = this.hasil[2];
                            flag6 = true;
                        }
                    }
                }
            }
            return flag6;
        }

        private void cekinco(string incoterm, string transtype)
        {
            if (incoterm == "")
            {
                this.radioSeller.Checked = false;
                this.radioBuyer.Checked = false;
            }
            if ((WBSetting.locType != "") && (incoterm != ""))
            {
                string[] aField = new string[] { "Incoterm_code" };
                string[] aFind = new string[] { incoterm };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
                if (this.tblIncoterm.DR == null)
                {
                    this.tblIncoterm.DR = this.tblIncoterm.DT.NewRow();
                    this.tblIncoterm.DR["Coy"] = WBData.sCoyCode;
                    this.tblIncoterm.DR["Location_code"] = WBData.sLocCode;
                    this.tblIncoterm.DR["incoterm_code"] = incoterm;
                    this.tblIncoterm.DR["incoterm_desc"] = incoterm;
                    this.tblIncoterm.DT.Rows.Add(this.tblIncoterm.DR);
                    this.tblIncoterm.Save();
                    this.tblIncoterm.ReOpen();
                    this.labelIncotermCode.Text = incoterm;
                    this.radioBuyer.Checked = false;
                    this.radioSeller.Checked = false;
                }
                else
                {
                    this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_desc"].ToString();
                    string[] textArray3 = new string[] { "transaction_code", "Incoterm_code" };
                    string[] textArray4 = new string[] { transtype, incoterm };
                    this.tblDeductedBy.DR = this.tblDeductedBy.GetData(textArray3, textArray4);
                    if (this.tblDeductedBy.DR != null)
                    {
                        this.radioSeller.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "1";
                        this.radioBuyer.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "0";
                    }
                    else
                    {
                        this.radioSeller.Checked = false;
                        this.radioBuyer.Checked = false;
                    }
                }
                this.comboIncoterm.Text = incoterm;
            }
        }

        private void change_langsir_type()
        {
            if (this.radioLangsirTransfer.Checked)
            {
                this.panel_TP.Visible = true;
            }
            else
            {
                this.textBatch.Text = "";
                this.cb_plant.Text = "";
                this.cb_sloc.Text = "";
                this.panel_TP.Visible = false;
            }
        }

        private void checkPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkPeriod.Checked)
            {
                this.dateDO_period.Visible = true;
                this.dateDO_period.Enabled = true;
            }
            else
            {
                this.dateDO_period.Visible = false;
                this.dateDO_period.Enabled = false;
            }
        }

        private void checkSTO1DO_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.checkSTO1DO.Checked)
            {
                this.comboIncoterm.Enabled = true;
            }
            else
            {
                this.comboIncoterm.Text = "LCO";
                this.comboIncoterm.Enabled = false;
            }
        }

        private bool ChkComm(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_commodity where " + WBData.CompanyLocation("");
            this.tblComm.OpenTable("wb_commodity", sqltext, WBData.conn);
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textCommodity.Text.Trim() };
            this.tblComm.DR = this.tblComm.GetData(aField, aFind);
            if (ReferenceEquals(this.tblComm.DR, null))
            {
                if (err == 1)
                {
                    MessageBox.Show("The Commodity code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.CommodityName.Text = "";
                flag3 = false;
            }
            else
            {
                this.CommodityName.Text = this.tblComm.DR["Comm_Name"].ToString();
                this.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                this.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                this.trade = this.tblComm.DR["Trade"].ToString();
                this.IsSugar = this.tblComm.DR["Type"].ToString().Trim() == "G";
                this.Bulk = this.tblComm.DR["BulkPack"].ToString();
                this.Std = this.tblComm.DR["Type"].ToString();
                this.actTrade();
                this.row_comm = this.tblComm.DT.NewRow();
                this.row_comm.ItemArray = this.tblComm.DR.ItemArray;
                flag3 = true;
            }
            return flag3;
        }

        private bool ChkEstate(int err)
        {
            bool flag3;
            string sqltext = "";
            sqltext = "select * from wb_Estate where " + WBData.CompanyLocation("");
            this.tblEstate.OpenTable("wb_Estate", sqltext, WBData.conn);
            string[] aField = new string[] { "Estate_Code" };
            string[] aFind = new string[] { this.textEstate.Text.Trim() };
            this.tblEstate.DR = this.tblEstate.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblEstate.DR, null))
            {
                this.labelEstateADM.Text = this.tblEstate.DR["Estate_Name"].ToString();
                flag3 = true;
            }
            else
            {
                if (err == 1)
                {
                    MessageBox.Show("The Estate code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.labelEstateADM.Text = "";
                flag3 = false;
            }
            return flag3;
        }

        private bool chkLocTimbun()
        {
            bool flag2;
            string[] aField = new string[] { "timbun_code" };
            string[] aFind = new string[] { this.textTimbunCoy.Text.Trim() };
            this.tblLocation_timbun.DR = this.tblLocation_timbun.GetData(aField, aFind);
            if (ReferenceEquals(this.tblLocation_timbun.DR, null))
            {
                flag2 = false;
            }
            else
            {
                this.timbunBatch = this.tblLocation_timbun.DR["relation_Code"].ToString();
                flag2 = true;
            }
            return flag2;
        }

        private bool ChkTransporter(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_transporter where " + WBData.CompanyLocation("");
            this.tblTransporter.OpenTable("wb_transporter", sqltext, WBData.conn);
            string[] aField = new string[] { "transporter_Code" };
            string[] aFind = new string[] { this.textTransporter.Text.Trim() };
            this.tblTransporter.DR = this.tblTransporter.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblTransporter.DR, null))
            {
                this.TransporterName.Text = this.tblTransporter.DR["Transporter_Name"].ToString();
                flag3 = true;
            }
            else
            {
                if (err == 1)
                {
                    MessageBox.Show("The Transporter code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.TransporterName.Text = "";
                flag3 = false;
            }
            return flag3;
        }

        private bool ChkVend(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_relation where " + WBData.CompanyLocation("");
            this.tblRelation.OpenTable("wb_relation", sqltext, WBData.conn);
            string[] aField = new string[] { "Relation_Code" };
            string[] aFind = new string[] { this.textVend.Text.Trim() };
            this.tblRelation.DR = this.tblRelation.GetData(aField, aFind);
            if (ReferenceEquals(this.tblRelation.DR, null))
            {
                if ((err == 1) || (err == 2))
                {
                    MessageBox.Show("The Vendor / Customer Code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.relationName.Text = "";
                flag3 = false;
            }
            else if (err == 2)
            {
                flag3 = true;
            }
            else
            {
                this.relationName.Text = this.tblRelation.DR["Relation_Name"].ToString();
                this.checkISCC.Checked = (this.tblRelation.DR["ISCC"].ToString() == "Y") || this.textQstDesc.Text.ToUpper().Contains("ISCC");
                this.checkISCC.Enabled = (this.tblRelation.DR["ISCC"].ToString() == "Y") || this.textQstDesc.Text.ToUpper().Contains("ISCC");
                flag3 = true;
            }
            return flag3;
        }

        private void comboBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboIncoterm_Leave(object sender, EventArgs e)
        {
        }

        private void comboIncoterm_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (WBSetting.locType != "")
            {
                string[] aField = new string[] { "Incoterm_code" };
                string[] aFind = new string[] { this.comboIncoterm.Text };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
                if (this.tblIncoterm.DR == null)
                {
                    this.labelIncotermCode.Text = "";
                }
                else
                {
                    this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_desc"].ToString();
                    if (this.textType.Text == "")
                    {
                        this.radioSeller.Checked = false;
                        this.radioBuyer.Checked = false;
                    }
                    else
                    {
                        string[] textArray3 = new string[] { "transaction_code", "Incoterm_code" };
                        string[] textArray4 = new string[] { this.textType.Text, this.comboIncoterm.Text };
                        this.tblDeductedBy.DR = this.tblDeductedBy.GetData(textArray3, textArray4);
                        if (this.tblDeductedBy.DR != null)
                        {
                            this.radioSeller.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "1";
                            this.radioBuyer.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "0";
                        }
                        else
                        {
                            this.radioSeller.Checked = false;
                            this.radioBuyer.Checked = false;
                        }
                    }
                }
            }
        }

        private void comboRefCode_TextChanged(object sender, EventArgs e)
        {
            if (this.comboRefCode.Text.Trim() != "")
            {
                string[] aField = new string[] { "refCode" };
                string[] aFind = new string[] { this.comboRefCode.Text };
                this.tblRefCode.DR = this.tblRefCode.GetData(aField, aFind);
                this.labelRefDes.Text = this.tblRefCode.DR["Description"].ToString();
            }
        }

        private void CompareAll(string commCode)
        {
            int count = this.dataGridView1.Rows.Count;
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_EXTRACT_COMM");
                    if (commCode != "")
                    {
                        WBSAP.rfcFunction.SetValue("P_COMM", commCode.ToUpper());
                    }
                    WBSAP.sendZWB();
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_COMM");
                    WBSAP.rfcTable2 = WBSAP.rfcFunction.GetTable("I_COMMD");
                    FormCommodityCompare compare = new FormCommodityCompare {
                        rfcTable = WBSAP.rfcTable,
                        rfcTableD = WBSAP.rfcTable2
                    };
                    compare.Compare();
                    MessageBox.Show("Inserted : " + compare.inserted + " Rows");
                    compare.Dispose();
                    this.Refresh();
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void ContractToLog(WBTable tLog, DataRow aRow)
        {
            tLog.DR = tLog.DT.NewRow();
            using (IEnumerator enumerator = tLog.DT.Columns.GetEnumerator())
            {
                DataColumn current;
                goto TR_0010;
            TR_000A:
                if (current.ColumnName.ToUpper() == "log_Date".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("dd/MM/yyyy");
                }
                else if (current.ColumnName.ToUpper() == "log_time".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (current.ColumnName.ToUpper() == "sUniq".ToUpper())
                {
                    tLog.DR[current.ColumnName] = aRow["uniq"];
                }
            TR_0010:
                while (true)
                {
                    if (enumerator.MoveNext())
                    {
                        current = (DataColumn) enumerator.Current;
                        if (current.ColumnName.ToUpper() != "UNIQ")
                        {
                            try
                            {
                                tLog.DR[current.ColumnName] = aRow[current.ColumnName];
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        goto TR_0004;
                    }
                    break;
                }
                goto TR_000A;
            }
        TR_0004:
            tLog.DT.Rows.Add(tLog.DR);
        }

        private void disabled4Timbun()
        {
            foreach (Control control in this.GetOffsprings())
            {
                bool flag = control.Name != this.tabPageRef.Name;
                if (flag && ((control.Name != this.tabPageOpening.Name) && (control.GetType() != typeof(Label))))
                {
                    control.Enabled = false;
                }
            }
            this.groupBoxEntry.Enabled = true;
            this.textOpnEntryEstate.Enabled = true;
            this.textOpnEntryFactory.Enabled = true;
            this.panelLangsir.Enabled = true;
            this.textTimbunCoy.Enabled = true;
            this.buttonPreview.Enabled = true;
            this.radioLangsirNone.Enabled = true;
            this.radioLangsirTtb.Enabled = true;
            this.buttonLocation.Enabled = true;
            this.tabControl1.Enabled = true;
            this.buttonSave.Enabled = true;
            this.textType.Enabled = true;
            this.buttonCancel.Enabled = true;
            this.textQuantity.Enabled = true;
            this.textOpnEntryEstate.Enabled = true;
            this.textOpnEntryFactory.Enabled = true;
            this.textTolerance.Enabled = true;
            this.checkQuantity.Enabled = true;
            this.checkPeriod.Enabled = true;
            this.dateDO_period.Enabled = true;
            this.buttonPreview.Enabled = true;
            this.textTimbunCoy.Enabled = true;
            this.buttonLocation.Enabled = true;
            this.groupBoxEntry.Enabled = true;
            this.comboIncoterm.Enabled = true;
            this.groupBoxDeducted.Enabled = true;
            this.radioBuyer.Enabled = true;
            this.radioSeller.Enabled = true;
            this.textRemark.Enabled = true;
            this.checkBerikat.Enabled = true;
            this.textQuantity.Enabled = true;
            this.textContract.Enabled = true;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void duplicateContract()
        {
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Transaction_Code"] = this.textType.Text;
            this.zTable.DR["Do_No"] = this.textDO.Text;
            this.zTable.DR["Do_Date"] = this.dateTimeDO.Value;
            this.zTable.DR["CheckPeriod"] = this.checkPeriod.Checked ? "Y" : "N";
            if (this.checkPeriod.Checked)
            {
                this.zTable.DR["Do_Date2"] = this.dateDO_period.Value;
            }
            this.dateDO_period.Text = "";
            this.dateDO_period.Enabled = this.checkPeriod.Checked;
            this.zTable.DR["Contract"] = this.textContract.Text;
            this.zTable.DR["Contract_Date"] = this.dateTimeContract.Value;
            this.zTable.DR["Comm_Code"] = this.textCommodity.Text;
            this.zTable.DR["Relation_Code"] = this.textVend.Text;
            this.zTable.DR["Transporter_Code"] = this.textTransporter.Text;
            this.zTable.DR["Estate1_Code"] = this.textEstate.Text;
            this.zTable.DR["Vessel"] = this.textVessel.Text;
            this.zTable.DR["Remark"] = this.textRemark.Text;
            this.zTable.DR["Mill"] = this.txt_mill.Text;
            this.zTable.DR["langsir_type"] = this.cb_langsir_type.Text;
            this.zTable.DR["Convertion"] = (this.textConvValue.Text.Trim() == "") ? 0.0 : Convert.ToDouble(this.textConvValue.Text);
            this.zTable.DR["ConvertionUnit"] = this.textConvUnit.Text;
            this.zTable.DR["ISCC"] = this.checkISCC.Checked ? "Y" : "N";
            this.zTable.DR["Quantity"] = this.textQuantity.Text;
            this.zTable.DR["Entry_Fact"] = this.textOpnEntryFactory.Text;
            this.zTable.DR["Entry_est"] = this.textOpnEntryEstate.Text;
            this.zTable.DR["Tolerance"] = this.textTolerance.Text;
            this.zTable.DR["Franco"] = this.comboIncoterm.Text;
            this.zTable.DR["DeductedBy"] = this.radioSeller.Checked ? "1" : "0";
            this.zTable.DR["DeductedBy"] = this.radioBuyer.Checked ? "0" : "1";
            this.zTable.DR["check_qty"] = this.checkQuantity.Checked ? "Y" : "N";
            this.zTable.DR["Upload_Type"] = this.comboUploadType.Text;
            this.zTable.DR["zwb"] = "N";
            this.zTable.DR["Tolling"] = this.radioLangsirTtb.Checked ? "6" : "1";
            this.zTable.DR["Coy_Tolling"] = this.textTimbunCoy.Text;
            this.zTable.DR["Berikat"] = this.checkBerikat.Checked ? "Y" : "N";
            this.zTable.DR["Create_By"] = WBUser.UserID;
            this.zTable.DR["Create_Date"] = DateTime.Now;
            this.zTable.DT.Rows.Add(this.zTable.DR);
        }

        private void enableVessel(string isVessel)
        {
            if (isVessel != "Y")
            {
                this.is_vessel = false;
                this.textVend.Enabled = true;
                this.button2.Enabled = true;
                this.textTransporter.Enabled = true;
                this.button3.Enabled = true;
                this.textEstate.Enabled = true;
                this.btnEstate.Enabled = true;
                foreach (Control control2 in this.tabPageRef.Controls)
                {
                    control2.Enabled = true;
                }
            }
            else
            {
                this.is_vessel = true;
                this.textVend.Enabled = false;
                this.textVend.Text = "";
                this.relationName.Text = "";
                this.button2.Enabled = false;
                this.textTransporter.Enabled = false;
                this.TransporterName.Text = "";
                this.button3.Enabled = false;
                this.textEstate.Enabled = false;
                this.textEstate.Text = "";
                this.labelEstateADM.Text = "";
                this.btnEstate.Enabled = false;
                foreach (Control control in this.tabPageRef.Controls)
                {
                    control.Enabled = false;
                    if (control is TextBox)
                    {
                        control.Text = "";
                    }
                }
            }
        }

        public void f_Load()
        {
            if (this.screen != "TIMBUN")
            {
                this.fTimbun = new FormContractEntryMsia();
                this.fTimbun.screen = "TIMBUN";
                this.fTimbun.Text = "Entry Data Titip Timbun";
                this.fTimbun.zTable = this.zTable;
                this.fTimbun.dataGridView1 = this.dataGridView1;
                this.fTimbun.BackColor = SystemColors.ActiveCaption;
            }
            if (this.screen == "TIMBUN")
            {
                if (this.timbunUniq != "")
                {
                    this.nCurrRow = this.zTable.GetPosRec(this.timbunUniq);
                }
                else
                {
                    this.pMode = "ADD";
                }
                this.screenTimbun();
            }
            Cursor.Current = Cursors.WaitCursor;
            FormProgress progress = new FormProgress();
            base.KeyPreview = true;
            this.relationName.Text = "";
            this.CommodityName.Text = "";
            this.labelEstateADM.Text = "";
            this.TransporterName.Text = "";
            this.labelRefDes.Text = "";
            this.labelIncotermCode.Text = "";
            this.dateTimeDO.Value = DateTime.Now;
            this.dateTimeContract.Value = DateTime.Now;
            this.initCombo();
            this.checkISCC.Enabled = false;
            this.checkISCC.Checked = false;
            this.InitTable();
            this.t_plant.OpenTable("wb_plant", "Select * from wb_plant", WBData.conn);
            this.t_sloc.OpenTable("wb_sloc", "Select * from wb_sloc", WBData.conn);
            this.t_typ.OpenTable("wb_langsir_type", "Select * from wb_langsir_type WHERE 1 = 1", WBData.conn);
            this.cb_plant.Items.Clear();
            foreach (DataRow row in this.t_plant.DT.Rows)
            {
                this.cb_plant.Items.Add(row["plant"].ToString());
            }
            this.cb_plant.Items.Add("");
            this.cb_langsir_type.Items.Clear();
            foreach (DataRow row2 in this.t_typ.DT.Rows)
            {
                this.cb_langsir_type.Items.Add(row2["langsir_type"].ToString());
            }
            this.cb_langsir_type.Items.Add("");
            this.cb_sloc.Items.Clear();
            foreach (DataRow row3 in this.t_sloc.DT.Rows)
            {
                this.cb_sloc.Items.Add(row3["str_loc"].ToString());
            }
            this.cb_sloc.Items.Add("");
            if (this.pMode == "ADD")
            {
                this.dateDO_period.Text = "";
                this.dateDO_period.Enabled = this.checkPeriod.Checked;
                this.textTimbunCoy.Visible = false;
                this.buttonLocation.Visible = false;
            }
            else
            {
                string[] aField = new string[] { "Transaction_Code" };
                string[] aFind = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Transaction_Code"].ToString().Trim() };
                this.tblTransType.DR = this.tblTransType.GetData(aField, aFind);
                this.textType.Text = this.tblTransType.DR["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = this.tblTransType.DR["Transaction_Name"].ToString();
                this.IO = this.tblTransType.DR["IO"].ToString();
                if (this.IO == "I")
                {
                    this.labelPO.Text = "PO";
                    this.labelPO1.Text = "PO";
                    this.label1.Text = "Delivery Order No.";
                    this.label_tp_desc.Text = "Supplying Batch / Plant / S. Loc";
                    this.cb_langsir_type.Text = "P";
                }
                else if (this.IO == "O")
                {
                    this.labelPO.Text = "SO";
                    this.labelPO1.Text = "SO";
                    this.label1.Text = "Sales Order No.";
                    this.label_tp_desc.Text = "Destination Batch / Plant / S. Loc";
                    this.cb_langsir_type.Text = "S";
                }
                this.enableVessel(this.tblTransType.DR["is_vessel"].ToString());
                this.textDO.Text = this.zTable.DT.Rows[this.nCurrRow]["Do_No"].ToString();
                this.qst = this.zTable.DT.Rows[this.nCurrRow]["qstandard"].ToString();
                if ((this.screen == "TIMBUN") && (this.textDO.Text.Substring(this.textDO.Text.Length - 1, 1) == "T"))
                {
                    this.textDO.Text = this.textDO.Text.Substring(0, this.textDO.Text.Length - 1);
                }
                string[] textArray3 = new string[] { "langsir_type" };
                string[] textArray4 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["langsir_type"].ToString().Trim() };
                this.t_typ.DR = this.t_typ.GetData(textArray3, textArray4);
                if (this.t_typ.DR != null)
                {
                    this.label_langsir_desc.Text = this.t_typ.DR["langsir_desc"].ToString();
                }
                this.OldCode = this.textDO.Text;
                this.uniq_contract = this.zTable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                this.dateTimeDO.Text = this.zTable.DT.Rows[this.nCurrRow]["Do_Date"].ToString();
                this.textContract.Text = this.zTable.DT.Rows[this.nCurrRow]["Contract"].ToString();
                this.dateTimeContract.Text = this.zTable.DT.Rows[this.nCurrRow]["Contract_Date"].ToString();
                this.textCommodity.Text = this.zTable.DT.Rows[this.nCurrRow]["Comm_Code"].ToString();
                this.ChkComm(0);
                this.textTransporter.Text = this.zTable.DT.Rows[this.nCurrRow]["Transporter_Code"].ToString();
                this.textQuantity.Text = this.zTable.DT.Rows[this.nCurrRow]["Quantity"].ToString();
                this.textTolerance.Text = this.zTable.DT.Rows[this.nCurrRow]["Tolerance"].ToString();
                if (this.textTolerance.Text.Length <= 0)
                {
                    this.textTolerance.Text = "0";
                }
                this.textEstate.Text = this.zTable.DT.Rows[this.nCurrRow]["Estate1_Code"].ToString();
                this.textVessel.Text = this.zTable.DT.Rows[this.nCurrRow]["Vessel"].ToString();
                this.textVend.Text = this.zTable.DT.Rows[this.nCurrRow]["Relation_code"].ToString();
                this.ChkVend(0);
                if (this.textTransporter.Text.Length > 0)
                {
                    this.ChkTransporter(0);
                }
                if (this.zTable.DT.Rows[this.nCurrRow]["qstandard"].ToString().Trim() != "")
                {
                    string[] textArray5 = new string[] { "ISCC_CODE" };
                    string[] textArray6 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["qstandard"].ToString().Trim() };
                    this.tblIscc.DR = this.tblIscc.GetData(textArray5, textArray6);
                    if (WBSetting.locType == "0")
                    {
                        this.txtQStandard.Text = this.tblIscc.DR["ISCC_TEXT"].ToString();
                    }
                    else
                    {
                        this.textQst.Text = this.tblIscc.DR["ISCC_CODE"].ToString();
                        this.textQstDesc.Text = this.tblIscc.DR["ISCC_TEXT"].ToString();
                        this.textOrigin.Text = this.zTable.DT.Rows[this.nCurrRow]["qOrigin"].ToString().Trim();
                    }
                }
                this.comboIncoterm.Text = this.zTable.DT.Rows[this.nCurrRow]["franco"].ToString().Trim();
                string[] textArray7 = new string[] { "incoterm_code" };
                string[] textArray8 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["franco"].ToString().Trim() };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(textArray7, textArray8);
                this.labelIncotermCode.Text = (this.tblIncoterm.DR == null) ? "" : this.tblIncoterm.DR["incoterm_Desc"].ToString();
                this.radioSeller.Checked = this.zTable.DT.Rows[this.nCurrRow]["DeductedBy"].ToString() == "1";
                this.radioBuyer.Checked = this.zTable.DT.Rows[this.nCurrRow]["DeductedBy"].ToString() == "0";
                this.textOpnEntryEstate.Text = this.zTable.DT.Rows[this.nCurrRow]["Entry_Est"].ToString();
                this.textOpnEntryFactory.Text = this.zTable.DT.Rows[this.nCurrRow]["Entry_Fact"].ToString();
                if (this.textOpnEntryEstate.Text == "")
                {
                    this.textOpnEntryEstate.Text = "0";
                }
                if (this.textOpnEntryFactory.Text == "")
                {
                    this.textOpnEntryFactory.Text = "0";
                }
                this.checkQuantity.Checked = this.zTable.DT.Rows[this.nCurrRow]["check_qty"].ToString() == "Y";
                this.checkISCC.Checked = this.zTable.DT.Rows[this.nCurrRow]["ISCC"].ToString() == "Y";
                this.checkISCC.Enabled = this.zTable.DT.Rows[this.nCurrRow]["ISCC"].ToString() == "Y";
                this.textRemark.Text = this.zTable.DT.Rows[this.nCurrRow]["Remark"].ToString();
                this.txt_mill.Text = this.zTable.DT.Rows[this.nCurrRow]["Mill"].ToString();
                this.cb_langsir_type.Text = this.zTable.DT.Rows[this.nCurrRow]["langsir_type"].ToString();
                string str = this.zTable.DT.Rows[this.nCurrRow]["closed"].ToString().Trim();
                this.dateDO_period.Enabled = false;
                this.dateDO_period.Visible = false;
                this.checkPeriod.Checked = this.zTable.DT.Rows[this.nCurrRow]["CheckPeriod"].ToString() == "Y";
                this.dateDO_period.Text = !this.checkPeriod.Checked ? "" : this.zTable.DT.Rows[this.nCurrRow]["Do_Date2"].ToString();
                this.dateDO_period.Enabled = this.checkPeriod.Checked;
                this.dateDO_period.Visible = this.checkPeriod.Checked;
                this.radioGroupEstate.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "0";
                this.radioOtherGroup.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "1";
                this.radioOthers.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "2";
                this.radioAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "3";
                this.radioKebAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "4";
                this.radioRamp.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "5";
                this.textNEGO.Text = this.zTable.DT.Rows[this.nCurrRow]["NEGO"].ToString();
                this.textLarge1.Text = this.zTable.DT.Rows[this.nCurrRow]["Big_Fruit1"].ToString();
                this.textLarge2.Text = this.zTable.DT.Rows[this.nCurrRow]["Big_Fruit2"].ToString();
                this.textMid1.Text = this.zTable.DT.Rows[this.nCurrRow]["Mid_Fruit1"].ToString();
                this.textMid2.Text = this.zTable.DT.Rows[this.nCurrRow]["Mid_Fruit2"].ToString();
                this.textSmall1.Text = this.zTable.DT.Rows[this.nCurrRow]["Sml_Fruit1"].ToString();
                this.textSmall2.Text = this.zTable.DT.Rows[this.nCurrRow]["Sml_Fruit2"].ToString();
                this.textLoose1.Text = this.zTable.DT.Rows[this.nCurrRow]["Loose1"].ToString();
                this.textLoose2.Text = this.zTable.DT.Rows[this.nCurrRow]["Loose2"].ToString();
                this.textScout1.Text = this.zTable.DT.Rows[this.nCurrRow]["Scout1"].ToString();
                this.textScout2.Text = this.zTable.DT.Rows[this.nCurrRow]["Scout2"].ToString();
                this.checkAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Agen"].ToString() == "Y";
                this.checkTolling.Checked = this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "Y";
                this.textGRPO.Text = this.zTable.DT.Rows[this.nCurrRow]["GR"].ToString();
                this.textGRPO_Cust.Text = this.zTable.DT.Rows[this.nCurrRow]["GR_Cust"].ToString();
                this.GRPO_Cust = this.textGRPO_Cust.Text;
                if (WBSetting.locType != "0")
                {
                    if (WBSetting.locType == "1")
                    {
                        if (this.IO == "O")
                        {
                            this.textPO1.Text = this.zTable.DT.Rows[this.nCurrRow]["SO"].ToString();
                            this.textPO1Item.Text = this.zTable.DT.Rows[this.nCurrRow]["SO_Item"].ToString();
                        }
                        else if (this.IO == "I")
                        {
                            this.textPO1.Text = this.zTable.DT.Rows[this.nCurrRow]["PO"].ToString();
                            this.textPO1Item.Text = this.zTable.DT.Rows[this.nCurrRow]["PO_Item"].ToString();
                        }
                        this.textSTO1.Text = this.zTable.DT.Rows[this.nCurrRow]["STO"].ToString();
                        this.textSTO_Item.Text = this.zTable.DT.Rows[this.nCurrRow]["STO_Item"].ToString();
                        this.comboUploadType1.Text = (this.zTable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString().Length <= 0) ? "" : this.zTable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString();
                    }
                }
                else
                {
                    if (this.IO == "O")
                    {
                        this.textPO.Text = this.zTable.DT.Rows[this.nCurrRow]["SO"].ToString();
                        this.textPOItem.Text = this.zTable.DT.Rows[this.nCurrRow]["SO_Item"].ToString();
                    }
                    else if (this.IO == "I")
                    {
                        this.textPO.Text = this.zTable.DT.Rows[this.nCurrRow]["PO"].ToString();
                        this.textPOItem.Text = this.zTable.DT.Rows[this.nCurrRow]["PO_Item"].ToString();
                    }
                    this.SO_ITEM_COUNT = (this.zTable.DT.Rows[this.nCurrRow]["so_item_count"].ToString() != "") ? Convert.ToInt32(this.zTable.DT.Rows[this.nCurrRow]["so_item_count"].ToString()) : 0;
                    this.textSTO.Text = this.zTable.DT.Rows[this.nCurrRow]["STO"].ToString();
                    this.textSTOItem.Text = this.zTable.DT.Rows[this.nCurrRow]["STO_Item"].ToString();
                    this.checkSTO1DO.Checked = this.zTable.DT.Rows[this.nCurrRow]["STO1DO"].ToString() == "Y";
                    this.textPI_No.Text = this.zTable.DT.Rows[this.nCurrRow]["PI_No"].ToString();
                    this.textBatch.Text = this.zTable.DT.Rows[this.nCurrRow]["Batch"].ToString();
                    this.cb_gain_loss.Checked = this.zTable.DT.Rows[this.nCurrRow]["gain_loss"].ToString() == "Y";
                    this.comboUploadType.Text = (this.zTable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString().Length <= 0) ? ((this.comboUploadType.Items.Count <= 0) ? "" : this.comboUploadType.Items[0].ToString()) : this.zTable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString();
                }
                this.actTrade();
                this.textQualityInfo.Text = this.zTable.DT.Rows[this.nCurrRow]["QualityInfo"].ToString();
                this.vTokenGRCust = this.zTable.DT.Rows[this.nCurrRow]["tokenGRCUst"].ToString();
                this.textTimbunCoy.Text = this.zTable.DT.Rows[this.nCurrRow]["Coy_Tolling"].ToString();
                this.TimbunCoy_beforeEdit = this.textTimbunCoy.Text;
                if (WBSetting.locType == "0")
                {
                    if (this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "1")
                    {
                        this.radioLangsirNone.Checked = true;
                    }
                    else if (this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "6")
                    {
                        this.radioLangsirTtb.Checked = true;
                    }
                    else if (this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "5")
                    {
                        this.radioLangsirTransfer.Checked = true;
                    }
                    else if (this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "7")
                    {
                        this.radioLangsir.Checked = true;
                    }
                    else if (this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "2")
                    {
                        this.radioLangsir2.Checked = true;
                    }
                    this.change_langsir_type();
                    this.cb_plant.Text = this.zTable.DT.Rows[this.nCurrRow]["plant"].ToString();
                    this.cb_sloc.Text = this.zTable.DT.Rows[this.nCurrRow]["str_loc"].ToString();
                    this.cb_langsir_type.Text = this.zTable.DT.Rows[this.nCurrRow]["langsir_type"].ToString();
                }
                if (this.screen != "TIMBUN")
                {
                    this.textTimbunCoy.Visible = this.radioLangsirTtb.Checked;
                    this.buttonLocation.Visible = this.radioLangsirTtb.Checked;
                    this.buttonPreview.Visible = this.radioLangsirTtb.Checked;
                }
                if ((this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "NONE")) && (this.screen != "TIMBUN"))
                {
                    string str3 = this.findTimbun();
                    this.fTimbun.timbunUniq = str3;
                    this.fTimbun.f_Load();
                    if (this.timbunSave)
                    {
                        this.disabled4Timbun();
                    }
                }
                this.checkBerikat.Checked = this.zTable.DT.Rows[this.nCurrRow]["Berikat"].ToString().Trim() == "Y";
                this.checkBerikat.Enabled = true;
                this.textConvValue.Text = this.zTable.DT.Rows[this.nCurrRow]["Convertion"].ToString();
                this.textConvUnit.Text = this.zTable.DT.Rows[this.nCurrRow]["ConvertionUnit"].ToString();
                this.oldComm = this.textCommodity.Text;
                this.oldTransporter = this.textTransporter.Text;
                this.oldTransType = this.textType.Text;
                this.oldrelation = this.textVend.Text;
                this.oldDo = this.textDO.Text;
                this.oldEstate = this.textEstate.Text;
                this.oldPI_No = this.textPI_No.Text;
                this.old_STO = this.textSTO.Text;
                this.old_gr_gust = this.textGRPO_Cust.Text;
                this.oldISCC = this.checkISCC.Checked ? "Y" : "N";
                this.oldRemark = this.textRemark.Text;
                string str2 = "";
                if (this.radioLangsirNone.Checked)
                {
                    str2 = "1";
                }
                else if (this.radioLangsirTtb.Checked)
                {
                    str2 = "6";
                }
                else if (this.radioLangsirTransfer.Checked)
                {
                    str2 = "5";
                }
                else if (this.radioLangsir.Checked)
                {
                    str2 = "7";
                }
                else if (this.radioLangsir2.Checked)
                {
                    str2 = "2";
                }
                this.oldTolling = str2;
            }
            if (WBSetting.locType == "0")
            {
                foreach (Control control in this.tabPagePOM.Controls)
                {
                    control.Enabled = false;
                }
                this.tabControl1.SelectedTab = this.tabPageRef;
            }
            else
            {
                foreach (Control control2 in this.tabPageRef.Controls)
                {
                    control2.Enabled = false;
                }
                this.tabControl1.SelectedTab = this.tabPagePOM;
                this.groupBoxFruit.Enabled = WBUser.CheckTrustee("FRUIT_TYPE", "V");
            }
            if (this.pMode == "EDIT")
            {
                this.tmpContract.DT = this.zTable.DT.Clone();
                this.contractBefore = this.tmpContract.DT.NewRow();
                this.contractBefore.ItemArray = this.zTable.DT.Rows[this.nCurrRow].ItemArray;
                this.tmpContract.DT.Rows.Add(this.contractBefore);
                if ((WBSetting.GrCustRequired == "Y") && (WBUser.UserLevel != "1"))
                {
                    WBTable table = new WBTable();
                    string[] textArray9 = new string[] { "Select * From wb_contract_GRCust where Comm_code = '", this.textCommodity.Text.Trim(), "' and Transaction_code = '", this.textType.Text.Trim(), "' " };
                    table.OpenTable("wb_Contract_GrCust", string.Concat(textArray9), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        this.textType.Enabled = false;
                        this.buttonType.Enabled = false;
                    }
                    else
                    {
                        this.textType.Enabled = true;
                        this.buttonType.Enabled = true;
                    }
                    table.Dispose();
                }
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
            }
            if (this.spMode == "GRCUST")
            {
                this.textGRPO_Cust.Text = this.grCust;
                this.textGRPO_Cust.Enabled = false;
                this.textType.Enabled = false;
                this.buttonType.Enabled = false;
                this.btnAdopt.PerformClick();
            }
            this.change_langsir_type();
            Cursor.Current = Cursors.Default;
        }

        public void f_Save()
        {
            WBTable table2;
            Cursor.Current = Cursors.WaitCursor;
            if (WBSetting.locType != "0")
            {
                if (WBSetting.locType == "1")
                {
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.textCommodity.Text };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    if ((data["PostSAP"].ToString() != "Y") || (this.comboUploadType1.Text != ""))
                    {
                        if ((data["PostSAP"].ToString() != "Y") || (this.comboUploadType1.Text != "STM"))
                        {
                            if ((data["PostSAP"].ToString() == "Y") && (this.comboUploadType1.Text == "ZMY_UPLOADFFB"))
                            {
                                if (!this.radioGroupEstate.Checked)
                                {
                                    if (this.textPO1.Text != "")
                                    {
                                        if (this.textPO1Item.Text != "")
                                        {
                                            if (!this.cekAdoptSAP())
                                            {
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please enter PO item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.textPO1Item.Focus();
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please enter PO number", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.textPO1.Focus();
                                        return;
                                    }
                                }
                                else if (this.textEstate.Text != "")
                                {
                                    string[] textArray3 = new string[] { "Estate_Code" };
                                    string[] textArray4 = new string[] { this.textEstate.Text };
                                    DataRow row2 = this.tblEstate.GetData(textArray3, textArray4);
                                    if (((row2 == null) || (row2["SAP_Code"] == null)) || (row2["SAP_Code"].ToString() == ""))
                                    {
                                        MessageBox.Show("Estate does not have SAP Code. Please remaintain estate or choose another estate.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.textEstate.Focus();
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please enter Estate", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.textEstate.Focus();
                                    return;
                                }
                            }
                        }
                        else if (this.textPO1.Text != "")
                        {
                            if (this.textSTO1.Text != "")
                            {
                                if (!this.cekAdoptSAP())
                                {
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter STO number", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textSTO1.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter SO number", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.textPO1.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please choose upload type", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.comboUploadType1.Focus();
                        return;
                    }
                }
            }
            else
            {
                if (WBSetting.zwb == "Y")
                {
                    if (!(((this.IO == "O") & this.IsSugar) & (this.textPO.Text.Trim() != "")) || (this.adopt == "Y"))
                    {
                        if ((this.textGRPO_Cust.Text.Trim() != "") && (this.adopt != "Y"))
                        {
                            MessageBox.Show("Please Click Adopt first to save data", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Click Adopt first to save data", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                if (((this.adopt == "Y") || this.radioLangsirTtb.Checked) || (((((this.comboIncoterm.Text != "LCO") && ((this.comboIncoterm.Text != "FOB") && (this.comboIncoterm.Text != "CIF"))) || (this.IO != "I")) || this.is_vessel) || ((this.textSTO.Text.Trim() != "") || this.checkSTO1DO.Checked)))
                {
                    if ((this.textPO.Text.Trim().Length <= 0) || (this.textEstate.Text.Trim() != "".Trim()))
                    {
                        if (this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "NONE"))
                        {
                            if (this.textTimbunCoy.Text.Trim() != "")
                            {
                                if (!this.chkLocTimbun())
                                {
                                    MessageBox.Show("The Location code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.textTimbunCoy.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Titip Timbun Must Fill Company.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.textTimbunCoy.Focus();
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Must Fill Estate", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.textEstate.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please Fill STO For " + this.comboIncoterm.Text + " Contract", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    return;
                }
            }
            if (!this.checkQuantity.Checked || (Program.StrToDouble(this.textQuantity.Text, 0) != 0.0))
            {
                TextBox[] aText = new TextBox[] { this.textDO, this.textType };
                if (!Program.CheckEmpty(aText))
                {
                    if (((this.comboIncoterm.Text.Trim() == "") && (((this.textSTO.Text.Trim() == "") || ((this.textPO.Text.Trim() != "") || (this.textGRPO_Cust.Text.Trim() != ""))) || (this.textGRPO.Text.Trim() != ""))) && !this.radioLangsirTtb.Checked)
                    {
                        MessageBox.Show("Must Have Incoterm.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                    if (((((this.comboIncoterm.Text != "LCO") && ((this.comboIncoterm.Text != "FOB") && (this.comboIncoterm.Text != "CIF"))) || (this.adopt != "N")) || this.is_vessel) || ((this.textTransporter.Text.Trim() != "".Trim()) || this.checkSTO1DO.Checked))
                    {
                        if (this.radioBuyer.Checked || this.radioSeller.Checked)
                        {
                            if (!this.is_vessel)
                            {
                                if (this.ChkComm(1) && ((((this.textSTO.Text != "") && ((this.textVend.Text == "") && ((this.textPO.Text == "") && (this.textGRPO.Text == "")))) && (this.textGRPO_Cust.Text == "")) || this.ChkVend(2)))
                                {
                                    if (((this.comboIncoterm.Text != "LCO") && (this.comboIncoterm.Text != "FOB")) && (this.comboIncoterm.Text != "CIF"))
                                    {
                                        if ((this.textTransporter.Text.Trim() != "") && !this.ChkTransporter(1))
                                        {
                                            return;
                                        }
                                    }
                                    else if (!this.ChkTransporter(1))
                                    {
                                        return;
                                    }
                                    if (!this.ChkEstate(1))
                                    {
                                        return;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                            if (this.screen != "TIMBUN")
                            {
                                WBTable table = new WBTable();
                                table.OpenTable("wb_contract", "SELECT tolling,uniq FROM wb_contract Where " + WBData.CompanyLocation(" and (Do_No='" + this.textDO.Text.Trim() + "') and (Tolling <> 'T')"), WBData.conn);
                                if ((table.DT.Rows.Count <= 0) || (((this.pMode != "ADD") && (this.pMode != "COPY")) && ((this.pMode != "EDIT") || (this.zTable.uniq.Trim() == table.DT.Rows[0]["uniq"].ToString().Trim()))))
                                {
                                    table.Dispose();
                                }
                                else
                                {
                                    table.Dispose();
                                    MessageBox.Show("The DO No already exist !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    this.textDO.Focus();
                                    return;
                                }
                            }
                            if (this.screen != "TIMBUN")
                            {
                                if (!(this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "NONE")) || this.timbunSave)
                                {
                                    if (WBSetting.locType == "0")
                                    {
                                        if (WBSetting.Field("GRCustRequired").ToString() != "Y")
                                        {
                                            if (!this.cekAdoptSAP())
                                            {
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            string[] textArray5 = new string[] { "Select * from wb_COntract_GRCUst where Transaction_Code = '", this.textType.Text.Trim().ToUpper(), "' and Comm_COde = '", this.textCommodity.Text.Trim().ToUpper(), "'" };
                                            this.tblContractGRCust.OpenTable("wb_grCust", string.Concat(textArray5), WBData.conn);
                                            if (this.tblContractGRCust.DT.Rows.Count <= 0)
                                            {
                                                if (!this.cekAdoptSAP())
                                                {
                                                    return;
                                                }
                                            }
                                            else if ((this.textGRPO_Cust.Text.Trim() == "") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                                            {
                                                if (MessageBox.Show("GR No Customized. \nPIN NEEDED TO SAVE.\nCONTINUE ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                                                {
                                                    this.textGRPO_Cust.Focus();
                                                    return;
                                                }
                                                else
                                                {
                                                    FormToken token = new FormToken {
                                                        email_code = "LOCK_BONGKAR"
                                                    };
                                                    string[] tokenParams = new string[] { "" };
                                                    token.initData(tokenParams, "GRCUST", "WB_CONTRACT", "0", "");
                                                    if (this.vTokenGRCust != "")
                                                    {
                                                        token.textBoxToken.Text = this.vTokenGRCust;
                                                    }
                                                    token.ShowDialog();
                                                    if (token.saved)
                                                    {
                                                        this.tokenGRCust = true;
                                                        this.completeGRtoken = token.completed;
                                                        this.noToken = token.textBoxToken.Text.Trim();
                                                    }
                                                    else
                                                    {
                                                        this.textGRPO_Cust.Focus();
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (this.pMode == "EDIT")
                                    {
                                        this.nCurrRow = this.zTable.GetPosRec(this.uniq_contract);
                                    }
                                    if (this.pMode != "EDIT")
                                    {
                                        goto TR_00F0;
                                    }
                                    else
                                    {
                                        table2 = new WBTable();
                                        table2.OpenTable("wb_transDO", "Select ref From wb_transDO where " + WBData.CompanyLocation(" and DO_No='" + this.zTable.DT.Rows[this.nCurrRow]["Do_No"].ToString() + "'"), WBData.conn);
                                        if (table2.DT.Rows.Count <= 0)
                                        {
                                            goto TR_00F1;
                                        }
                                        else if (MessageBox.Show("The DO Number will be Edited \n\nSystem will replace all the transaction with the new number, it takes a longer time.\n( " + table2.DT.Rows.Count.ToString() + " records )\nAre you want to continue . . ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                        {
                                            int num2 = 0;
                                            while (true)
                                            {
                                                if (num2 < table2.DT.Rows.Count)
                                                {
                                                    table2.DR = table2.DT.Rows[num2];
                                                    WBTable table3 = new WBTable();
                                                    table3.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + table2.DR["Ref"].ToString() + "'"), WBData.conn);
                                                    if (table3.DT.Rows.Count > 0)
                                                    {
                                                        table3.DR = table3.DT.Rows[0];
                                                        if (table3.Locked(table3.DR["uniq"].ToString(), '0'))
                                                        {
                                                            MessageBox.Show("Cannot Replace Transaction Ref " + table2.DR["Ref"].ToString() + "\nTransaction is Locked by Another User,\nPlease Try again after Close that Transaction ", "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                            table3.Dispose();
                                                            break;
                                                        }
                                                    }
                                                    num2++;
                                                    continue;
                                                }
                                                this.ReplaceAll = true;
                                                goto TR_00F1;
                                            }
                                        }
                                        else
                                        {
                                            this.ReplaceAll = false;
                                            this.textDO.Focus();
                                        }
                                    }
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Owner DO not yet Created for DO Timbun", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    return;
                                }
                            }
                            else
                            {
                                if (this.adopt != "Y")
                                {
                                }
                                if ((((this.comboIncoterm.Text == "LCO") || (this.comboIncoterm.Text == "FOB")) || (this.comboIncoterm.Text == "CIF")) && (this.textTransporter.Text.Trim() == ""))
                                {
                                    MessageBox.Show("Please Fill Transporter for " + this.comboIncoterm.Text + " Contract", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                }
                                base.Hide();
                                this.saved = true;
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please choose deducted by", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Loco Type must have Transporter", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.textTransporter.Focus();
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show("Failed Save Data, Quantity DO is 0 while Check Quantity Checked...", "Message...");
                return;
            }
            goto TR_00F1;
        TR_00F0:
            if (((this.pMode == "EDIT") && (!this.radioLangsirTtb.Checked && (this.TimbunCoy_beforeEdit != this.textTimbunCoy.Text))) && (this.textTimbunCoy.Text.Trim() == ""))
            {
                WBTable table4 = new WBTable();
                table4.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Do_No = '" + this.textDO.Text + "T' AND zauto = 'Y'"), WBData.conn);
                if (table4.DT.Rows.Count > 0)
                {
                    if (MessageBox.Show("The DO Number will be Edited \n\nSystem will TRIGGER all the transaction for TITIP TIMBUN, it takes a longer time.\n( " + table4.DT.Rows.Count.ToString() + " records )\nAre you want to continue . . ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        foreach (DataRow row3 in table4.DT.Rows)
                        {
                            row3.Delete();
                        }
                        table4.Save();
                        WBTable table5 = new WBTable();
                        table5.OpenTable("wb_transDo", "SELECT * FROM wb_transDo WHERE " + WBData.CompanyLocation(" AND Do_No = '" + this.textDO.Text + "T'"), WBData.conn);
                        foreach (DataRow row4 in table5.DT.Rows)
                        {
                            row4.Delete();
                        }
                        table5.Save();
                        WBTable table6 = new WBTable();
                        table6.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Do_No = '" + this.textDO.Text + "'"), WBData.conn);
                        foreach (DataRow row5 in table6.DT.Rows)
                        {
                            row5.BeginEdit();
                            row5["tolling"] = 1;
                            row5["posted"] = "N";
                            row5.EndEdit();
                        }
                        table6.Save();
                    }
                    else
                    {
                        this.ReplaceAll = false;
                        this.textDO.Focus();
                        return;
                    }
                }
            }
            if ((((this.pMode == "EDIT") || (this.pMode == "GRCUST")) && (this.radioLangsirTtb.Checked && (this.TimbunCoy_beforeEdit != this.textTimbunCoy.Text))) && (this.textTimbunCoy.Text.Trim() != ""))
            {
                WBTable table7 = new WBTable();
                WBTable table8 = new WBTable();
                WBTable table9 = new WBTable();
                WBTable table10 = new WBTable();
                WBTable table11 = new WBTable();
                WBTable table12 = new WBTable();
                string str2 = "";
                table7.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Do_No = '" + this.zTable.DT.Rows[this.nCurrRow]["Do_No"].ToString() + "' and _2nd <> 0"), WBData.conn);
                if (table7.DT.Rows.Count > 0)
                {
                    if (MessageBox.Show("The DO Number will be Edited \n\nSystem will TRIGGER all the transaction for TITIP TIMBUN, it takes a longer time.\n( " + table7.DT.Rows.Count.ToString() + " records )\nAre you want to continue . . ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        foreach (DataRow row7 in table7.DT.Rows)
                        {
                            table7.DR = row7;
                            table7.DR.BeginEdit();
                            table7.DR["tolling"] = 6;
                            table7.DR["posted"] = "N";
                            table7.DR.EndEdit();
                            table7.Save();
                            table10.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + row7["Ref"].ToString() + "'"), WBData.conn);
                            table10.DR = table10.DT.Rows[0];
                            table10.DR.BeginEdit();
                            table10.DR["tolling"] = 6;
                            table10.DR.EndEdit();
                            table10.Save();
                            table9.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + row7["Ref"].ToString() + "'"), WBData.conn);
                            DataRow row6 = table9.DT.Rows[0];
                            table8.OpenTable("wb_trans", "select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + row7["Ref"].ToString() + "%T' and zAuto = 'Y'"), WBData.conn);
                            table8.DR = table8.DT.NewRow();
                            foreach (DataColumn column in table7.DT.Columns)
                            {
                                if (column.ColumnName.ToUpper() != "UNIQ")
                                {
                                    table8.DR[column.ColumnName] = row7[column.ColumnName];
                                }
                            }
                            table8.DR["ref"] = table8.DR["ref"].ToString() + "T";
                            table8.DR["DO_NO"] = this.textDO.Text + "T";
                            table8.DR["Comm_Code"] = this.textCommodity.Text;
                            string str = row7["DO_NO"].ToString();
                            table8.DR["Transaction_Code"] = this.fTimbun.textType.Text.Trim();
                            if (this.fTimbun.radioLangsirNone.Checked)
                            {
                                str2 = "1";
                            }
                            else if (this.fTimbun.radioLangsirTtb.Checked)
                            {
                                str2 = "6";
                            }
                            else if (this.fTimbun.radioLangsirTransfer.Checked)
                            {
                                str2 = "5";
                            }
                            else if (this.fTimbun.radioLangsir.Checked)
                            {
                                str2 = "7";
                            }
                            else if (this.fTimbun.radioLangsir2.Checked)
                            {
                                str2 = "2";
                            }
                            table8.DR["tolling"] = str2;
                            table8.DR["zAuto"] = "Y";
                            table8.DR["posted"] = "N";
                            table8.DR["checksum"] = table7.Checksum(table8.DR);
                            table8.DT.Rows.Add(table8.DR);
                            table8.Save();
                            table9.DR = table9.DT.NewRow();
                            foreach (DataColumn column2 in table9.DT.Columns)
                            {
                                if (column2.ColumnName.ToUpper() != "UNIQ")
                                {
                                    table9.DR[column2.ColumnName] = row6[column2.ColumnName];
                                }
                            }
                            table9.DR["ref"] = table9.DR["ref"].ToString() + "T";
                            table9.DR["DO_NO"] = this.textDO.Text + "T";
                            table9.DR["Comm_Code"] = this.textCommodity.Text;
                            table9.DR["tolling"] = str2;
                            table9.DT.Rows.Add(table9.DR);
                            table9.Save();
                            table11.OpenTable("wb_transQC", "select * from wb_transQC where " + WBData.CompanyLocation(" and ref = '" + this.textDO.Text.Trim() + "'"), WBData.conn);
                            if (table11.DT.Rows.Count > 0)
                            {
                                table12.OpenTable("wb_transQC", "select * from wb_transQC where " + WBData.CompanyLocation(" and ref = '" + this.textDO.Text.Trim() + "'"), WBData.conn);
                                table12.DT = table11.DT.Clone();
                                foreach (DataRow row8 in table11.DT.Rows)
                                {
                                    row8.BeginEdit();
                                    row8["Ref"] = row8["Ref"].ToString() + "Y";
                                }
                                table12.Save();
                            }
                        }
                    }
                    else
                    {
                        this.ReplaceAll = false;
                        this.textDO.Focus();
                        return;
                    }
                }
            }
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "DO No" },
                    textRefNo = { Text = this.textDO.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (((this.pMode == "ADD") || (this.pMode == "COPY")) || (this.pMode == "TIMBUN"))
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.uniq_contract };
                this.zTable.DR = this.zTable.GetData(aField, aFind);
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            if (this.qst != "")
            {
                string[] aField = new string[] { "ISCC_CODE" };
                string[] aFind = new string[] { this.qst };
                this.tblIscc.DR = this.tblIscc.GetData(aField, aFind);
                if (this.tblIscc.DR != null)
                {
                    this.tblIscc.DR.BeginEdit();
                    this.tblIscc.DR["ISCC_TEXT"] = (WBSetting.locType != "0") ? this.textQstDesc.Text : this.txtQStandard.Text;
                    this.tblIscc.DR.EndEdit();
                }
                else
                {
                    this.tblIscc.DR = this.tblIscc.DT.NewRow();
                    this.tblIscc.DR["ISCC_CODE"] = this.qst.ToUpper();
                    this.tblIscc.DR["ISCC_TEXT"] = (WBSetting.locType != "0") ? this.textQstDesc.Text : this.txtQStandard.Text;
                    this.tblIscc.DT.Rows.Add(this.tblIscc.DR);
                }
                this.tblIscc.Save();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Transaction_Code"] = this.textType.Text.Trim();
            this.zTable.DR["Do_No"] = this.textDO.Text.Trim();
            this.zTable.DR["Do_Date"] = this.dateTimeDO.Value;
            this.zTable.DR["CheckPeriod"] = this.checkPeriod.Checked ? "Y" : "N";
            if (this.checkPeriod.Checked)
            {
                this.zTable.DR["Do_Date2"] = this.dateDO_period.Value;
            }
            this.dateDO_period.Text = "";
            this.dateDO_period.Enabled = this.checkPeriod.Checked;
            this.zTable.DR["Contract"] = this.textContract.Text.Trim();
            this.zTable.DR["Contract_Date"] = this.dateTimeContract.Value;
            this.zTable.DR["Comm_Code"] = this.textCommodity.Text.Trim();
            this.zTable.DR["Relation_Code"] = this.textVend.Text.Trim();
            this.zTable.DR["Transporter_Code"] = this.textTransporter.Text.Trim();
            this.zTable.DR["Estate1_Code"] = this.textEstate.Text.Trim();
            this.zTable.DR["Vessel"] = this.textVessel.Text.Trim();
            this.zTable.DR["Remark"] = this.textRemark.Text.Trim();
            this.zTable.DR["Mill"] = this.txt_mill.Text.Trim();
            this.zTable.DR["langsir_type"] = this.cb_langsir_type.Text.Trim();
            if (this.radioLangsirTransfer.Checked)
            {
                this.zTable.DR["Batch"] = this.textBatch.Text.Trim();
                this.zTable.DR["Plant"] = this.cb_plant.Text.Trim();
                this.zTable.DR["Str_loc"] = this.cb_sloc.Text.Trim();
            }
            else
            {
                this.zTable.DR["Batch"] = "";
                this.zTable.DR["Plant"] = "";
                this.zTable.DR["Str_loc"] = "";
            }
            this.zTable.DR["Convertion"] = (this.textConvValue.Text.Trim() == "") ? 0.0 : Convert.ToDouble(this.textConvValue.Text);
            this.zTable.DR["ConvertionUnit"] = this.textConvUnit.Text.Trim();
            this.zTable.DR["ISCC"] = this.checkISCC.Checked ? "Y" : "N";
            this.zTable.DR["qstandard"] = this.qst;
            this.zTable.DR["qOrigin"] = this.textOrigin.Text;
            this.zTable.DR["Quantity"] = this.textQuantity.Text.Trim();
            this.zTable.DR["Entry_Fact"] = this.textOpnEntryFactory.Text.Trim();
            this.zTable.DR["Entry_est"] = this.textOpnEntryEstate.Text.Trim();
            this.zTable.DR["Tolerance"] = this.textTolerance.Text.Trim();
            this.zTable.DR["Franco"] = this.comboIncoterm.Text;
            this.zTable.DR["DeductedBy"] = this.radioBuyer.Checked ? "0" : "1";
            this.zTable.DR["check_qty"] = this.checkQuantity.Checked ? "Y" : "N";
            this.zTable.DR["GR"] = this.textGRPO.Text.Trim();
            this.zTable.DR["GR_Cust"] = this.textGRPO_Cust.Text.Trim();
            if (WBSetting.locType != "0")
            {
                if (WBSetting.locType == "1")
                {
                    if (this.IO == "O")
                    {
                        this.zTable.DR["SO"] = this.textPO1.Text.Trim();
                        this.zTable.DR["SO_Item"] = this.textPO1Item.Text.Trim();
                    }
                    else if (this.IO == "I")
                    {
                        this.zTable.DR["PO"] = this.textPO1.Text.Trim();
                        this.zTable.DR["PO_Item"] = this.textPO1Item.Text.Trim();
                    }
                    this.zTable.DR["STO"] = this.textSTO1.Text.Trim();
                    this.zTable.DR["STO_Item"] = this.textSTO_Item.Text.Trim();
                    this.zTable.DR["Upload_Type"] = this.comboUploadType1.Text.Trim();
                }
            }
            else
            {
                if (this.IO == "O")
                {
                    this.zTable.DR["SO"] = this.textPO.Text.Trim();
                    this.zTable.DR["SO_Item"] = this.textPOItem.Text.Trim();
                    this.zTable.DR["PO"] = "";
                    this.zTable.DR["PO_Item"] = "";
                }
                else if (this.IO == "I")
                {
                    this.zTable.DR["PO"] = this.textPO.Text.Trim();
                    this.zTable.DR["PO_Item"] = this.textPOItem.Text.Trim();
                    this.zTable.DR["SO"] = "";
                    this.zTable.DR["SO_Item"] = "";
                }
                this.zTable.DR["SO_Item_count"] = this.SO_ITEM_COUNT;
                this.zTable.DR["STO"] = this.textSTO.Text.Trim();
                this.zTable.DR["STO_Item"] = this.textSTOItem.Text.Trim();
                this.zTable.DR["STO1DO"] = this.checkSTO1DO.Checked ? "Y" : "N";
                this.zTable.DR["PI_No"] = this.textPI_No.Text.Trim();
                this.zTable.DR["gain_loss"] = this.cb_gain_loss.Checked ? "Y" : "N";
                this.zTable.DR["Upload_Type"] = this.comboUploadType.Text.Trim();
            }
            this.zTable.DR["zwb"] = "N";
            this.zTable.DR["QualityInfo"] = this.textQualityInfo.Text.Trim();
            this.zTable.DR["Approve_Reason"] = this.Approve_Reason;
            this.zTable.DR["approveBy1"] = this.approveBy1;
            this.zTable.DR["approve_type"] = this.approve_type;
            if (WBSetting.locType == "0")
            {
                if (this.radioLangsirNone.Checked)
                {
                    this.zTable.DR["Tolling"] = "1";
                }
                else if (this.radioLangsirTtb.Checked)
                {
                    this.zTable.DR["Tolling"] = "6";
                }
                else if (this.radioLangsirTransfer.Checked)
                {
                    this.zTable.DR["Tolling"] = "5";
                }
                else if (this.radioLangsir.Checked)
                {
                    this.zTable.DR["Tolling"] = "7";
                }
                else if (this.radioLangsir2.Checked)
                {
                    this.zTable.DR["Tolling"] = "2";
                }
            }
            this.zTable.DR["zAuto"] = "N";
            this.zTable.DR["Coy_Tolling"] = this.textTimbunCoy.Text.Trim();
            this.zTable.DR["Berikat"] = this.checkBerikat.Checked ? "Y" : "N";
            this.zTable.DR["NEGO"] = this.textNEGO.Text.Trim();
            this.zTable.DR["Agen"] = this.checkAgen.Checked ? "Y" : "N";
            this.zTable.DR["Group_Type"] = this.radioGroupEstate.Checked ? "0" : (this.radioOtherGroup.Checked ? "1" : (this.radioOthers.Checked ? "2" : (this.radioAgen.Checked ? "3" : (this.radioKebAgen.Checked ? "4" : (this.radioRamp.Checked ? "5" : "")))));
            this.zTable.DR["Big_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge1.Text == "") ? "0" : this.textLarge1.Text)), 2);
            this.zTable.DR["Big_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge2.Text == "") ? "0" : this.textLarge2.Text)), 2);
            this.zTable.DR["Mid_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid1.Text == "") ? "0" : this.textMid1.Text)), 2);
            this.zTable.DR["Mid_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid2.Text == "") ? "0" : this.textMid2.Text)), 2);
            this.zTable.DR["Sml_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall1.Text == "") ? "0" : this.textSmall1.Text)), 2);
            this.zTable.DR["Sml_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall2.Text == "") ? "0" : this.textSmall2.Text)), 2);
            this.zTable.DR["Loose1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose1.Text == "") ? "0" : this.textLoose1.Text)), 2);
            this.zTable.DR["Loose2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose2.Text == "") ? "0" : this.textLoose2.Text)), 2);
            this.zTable.DR["Scout1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout1.Text == "") ? "0" : this.textScout1.Text)), 2);
            this.zTable.DR["Scout2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout2.Text == "") ? "0" : this.textScout2.Text)), 2);
            this.zTable.DR["zadp"] = this.adopt;
            if ((this.grCust != "") && (this.zTable.DR["completedGRCust"].ToString() == "X"))
            {
                this.zTable.DR["completedGRCust"] = "Y";
            }
            else if (this.tokenGRCust)
            {
                this.zTable.DR["tokenGRCUst"] = this.noToken;
                this.zTable.DR["completedGRCust"] = this.completeGRtoken;
            }
            if (WBSetting.locType == "1")
            {
                this.zTable.DR["Tolling"] = this.checkTolling.Checked ? "Y" : "N";
            }
            if ((this.pMode == "ADD") || (this.pMode == "COPY"))
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            if (this.pMode != "TIMBUN")
            {
                this.zTable.Save();
            }
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table13 = new WBTable();
                    table13.OpenTable("wb_contract", "SELECT uniq FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + this.textDO.Text + "'"), WBData.conn);
                    this.logKey = table13.DT.Rows[0]["uniq"].ToString();
                    table13.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
            }
            this.savedTimbun();
            if (this.num_of_do > 0)
            {
                WBTable table14 = new WBTable();
                table14.OpenTable("wb_contract", "SELECT uniq FROM wb_contract Where " + WBData.CompanyLocation(" and (Do_No='" + this.textDO.Text.Trim() + "')"), WBData.conn);
                WBTable table15 = new WBTable();
                table15.OpenTable("wb_do_sap", "SELECT * FROM wb_do_sap WHERE uniq_contract = '" + table14.DT.Rows[0]["uniq"].ToString() + "'", WBData.conn);
                int num3 = 0;
                while (true)
                {
                    if (num3 >= this.num_of_do)
                    {
                        table15.Save();
                        table15.ReOpen();
                        foreach (DataRow row10 in table15.DT.Rows)
                        {
                            bool flag118 = false;
                            int num5 = 0;
                            while (true)
                            {
                                if (num5 >= this.num_of_do)
                                {
                                    if (!flag118)
                                    {
                                        row10.BeginEdit();
                                        row10["not_exist"] = "X";
                                        row10.EndEdit();
                                    }
                                    break;
                                }
                                if ((row10["do_sap"].ToString() == this.map[num5, 0].ToString()) && (row10["do_sap_item"].ToString() == this.map[num5, 1].ToString()))
                                {
                                    flag118 = true;
                                }
                                num5++;
                            }
                        }
                        table15.Save();
                        break;
                    }
                    string[] aField = new string[] { "do_sap", "do_sap_item" };
                    string[] aFind = new string[] { this.map[num3, 0].ToString(), this.map[num3, 1].ToString() };
                    DataRow data = table15.GetData(aField, aFind);
                    if (ReferenceEquals(data, null))
                    {
                        table15.DR = table15.DT.NewRow();
                    }
                    else
                    {
                        int posRec = table15.GetPosRec(data["uniq"].ToString());
                        table15.DR = table15.DT.Rows[posRec];
                        table15.DR.BeginEdit();
                    }
                    table15.DR["uniq_contract"] = table14.DT.Rows[0]["uniq"].ToString();
                    table15.DR["do_sap"] = this.map[num3, 0].ToString();
                    table15.DR["do_sap_item"] = this.map[num3, 1].ToString();
                    table15.DR["comm_code"] = this.map[num3, 2].ToString();
                    table15.DR["quantity_kg"] = Program.StrToDouble(this.map[num3, 3].ToString(), 0);
                    table15.DR["quantity"] = Program.StrToDouble(this.map[num3, 4].ToString(), 0);
                    table15.DR["unit"] = this.map[num3, 6].ToString();
                    table15.DR["relation_code"] = this.map[num3, 7].ToString();
                    table15.DR["batch"] = this.map[num3, 8].ToString();
                    table15.DR["not_exist"] = this.map[num3, 9].ToString();
                    table15.DR["conv_qty"] = this.map[num3, 10].ToString();
                    table15.DR["conv_unit"] = this.map[num3, 11].ToString();
                    table15.DR["do_type"] = 0;
                    table15.DR["status"] = "";
                    table15.DR["last_sync"] = DateTime.Now;
                    if (ReferenceEquals(data, null))
                    {
                        table15.DT.Rows.Add(table15.DR);
                    }
                    else
                    {
                        table15.DR.EndEdit();
                    }
                    num3++;
                }
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string str3 = "";
                if (this.radioLangsirNone.Checked)
                {
                    str3 = "1";
                }
                else if (this.radioLangsirTtb.Checked)
                {
                    str3 = "6";
                }
                else if (this.radioLangsirTransfer.Checked)
                {
                    str3 = "5";
                }
                else if (this.radioLangsir.Checked)
                {
                    str3 = "7";
                }
                else if (this.radioLangsir2.Checked)
                {
                    str3 = "2";
                }
                string str4 = this.checkISCC.Checked ? "Y" : "N";
                string str5 = "";
                if (str4 != "Y")
                {
                    str5 = "";
                }
                else if ((this.textCommodity.Text == "6.0110000") && ((WBSetting.Field("ISCC_No_Add") == null) || (WBSetting.Field("ISCC_No_Add").ToString() == "")))
                {
                    str5 = WBSetting.Field("ISCC_No").ToString();
                }
                else if ((this.textCommodity.Text == "6.0110000") && ((WBSetting.Field("ISCC_No_Add") != null) && (WBSetting.Field("ISCC_No_Add").ToString() != "")))
                {
                    str5 = WBSetting.Field("ISCC_No_Add").ToString();
                }
                else if (this.textCommodity.Text == "6.1111002")
                {
                    str5 = WBSetting.Field("ISCC_No").ToString();
                }
                if (((this.textDO.Text.Trim() != this.oldDo.Trim()) || ((this.textVend.Text.Trim() != this.oldrelation.Trim()) || ((this.textPI_No.Text.Trim() != this.oldPI_No.Trim()) || ((this.textEstate.Text.Trim() != this.oldEstate.Trim()) || ((this.textTransporter.Text.Trim() != this.oldTransporter.Trim()) || ((this.textType.Text.Trim() != this.oldTransType.Trim()) || ((this.textCommodity.Text.Trim() != this.oldComm.Trim()) || ((this.textSTO.Text.Trim() != this.old_STO.Trim()) || ((this.textGRPO_Cust.Text.Trim() != this.old_gr_gust.Trim()) || ((str3 != this.oldTolling) || (str4 != this.oldISCC))))))))))) || (this.textRemark.Text != this.oldRemark))
                {
                    string[] aField = new string[] { "Do_No", "Contract", "relation_code", "Comm_Code", "Transaction_Code", "Estate", "PI_No", "tolling" };
                    string[] aNewValue = new string[] { this.textDO.Text.Trim(), this.textContract.Text.Trim(), this.textVend.Text.Trim(), this.textCommodity.Text.Trim(), this.textType.Text.Trim(), this.textEstate.Text.Trim(), this.textPI_No.Text.Trim(), str3 };
                    Program.ReplaceAll("wb_transDO", aField, aNewValue, " Do_No='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit contract master data)");
                    string[] textArray17 = new string[13];
                    textArray17[0] = "transporter_code";
                    textArray17[1] = "Do_No";
                    textArray17[2] = "relation_code";
                    textArray17[3] = "Comm_Code";
                    textArray17[4] = "Transaction_Code";
                    textArray17[5] = "estate_code";
                    textArray17[6] = "edit_by";
                    textArray17[7] = "edit_Date";
                    textArray17[8] = "PI_No";
                    textArray17[9] = "tolling";
                    textArray17[10] = "ISCC_checked";
                    textArray17[11] = "ISCC_No";
                    textArray17[12] = "Remark_Ticket";
                    string[] textArray18 = new string[13];
                    textArray18[0] = this.textTransporter.Text.Trim();
                    textArray18[1] = this.textDO.Text.Trim();
                    textArray18[2] = this.textVend.Text.Trim();
                    textArray18[3] = this.textCommodity.Text.Trim();
                    textArray18[4] = this.textType.Text.Trim();
                    textArray18[5] = this.textEstate.Text.Trim();
                    textArray18[6] = WBUser.UserID;
                    textArray18[7] = DateTime.Now.ToString();
                    textArray18[8] = this.textPI_No.Text.Trim();
                    textArray18[9] = str3;
                    textArray18[10] = this.checkISCC.Checked ? "Y" : "N";
                    string[] local1 = textArray18;
                    local1[11] = str5;
                    local1[12] = this.textRemark.Text;
                    Program.ReplaceAllExceptTransporter("wb_transaction", textArray17, local1, " Do_No='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit contract master data)");
                }
                if (this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "NONE"))
                {
                    string str6 = "";
                    if (this.fTimbun.radioLangsirNone.Checked)
                    {
                        str6 = "1";
                    }
                    else if (this.fTimbun.radioLangsirTtb.Checked)
                    {
                        str6 = "6";
                    }
                    else if (this.fTimbun.radioLangsirTransfer.Checked)
                    {
                        str6 = "5";
                    }
                    else if (this.fTimbun.radioLangsir.Checked)
                    {
                        str6 = "7";
                    }
                    else if (this.fTimbun.radioLangsir2.Checked)
                    {
                        str6 = "2";
                    }
                    if ((((this.fTimbun.textDO.Text.Trim() != this.fTimbun.oldDo.Trim()) || ((this.fTimbun.textVend.Text.Trim() != this.fTimbun.oldrelation.Trim()) || ((this.fTimbun.textPI_No.Text.Trim() != this.fTimbun.oldPI_No.Trim()) || ((this.fTimbun.textEstate.Text.Trim() != this.fTimbun.oldEstate.Trim()) || ((this.fTimbun.textTransporter.Text.Trim() != this.fTimbun.oldTransporter.Trim()) || ((this.fTimbun.textType.Text.Trim() != this.fTimbun.oldTransType.Trim()) || ((this.fTimbun.textCommodity.Text.Trim() != this.fTimbun.oldComm.Trim()) || ((this.fTimbun.textSTO.Text.Trim() != this.fTimbun.old_STO.Trim()) || (this.fTimbun.textGRPO_Cust.Text.Trim() != this.fTimbun.old_gr_gust.Trim()))))))))) || (str6 != this.fTimbun.oldTolling)) && (this.fTimbun.OldCode.Trim() != ""))
                    {
                        string[] aField = new string[] { "Do_No", "Contract", "relation_code", "Comm_Code", "Transaction_Code", "Estate", "PI_No", "tolling" };
                        string[] aNewValue = new string[] { this.fTimbun.textDO.Text.Trim() + "T", this.fTimbun.textContract.Text.Trim(), this.fTimbun.textVend.Text.Trim(), this.fTimbun.textCommodity.Text.Trim(), this.fTimbun.textType.Text.Trim(), this.fTimbun.textEstate.Text.Trim(), this.textPI_No.Text.Trim(), str6 };
                        Program.ReplaceAll("wb_transDO", aField, aNewValue, " Do_No='" + this.fTimbun.OldCode.Trim() + "T'", this.changeReason + " (Edit contract master data)");
                        string[] textArray21 = new string[10];
                        textArray21[0] = "transporter_code";
                        textArray21[1] = "Do_No";
                        textArray21[2] = "relation_code";
                        textArray21[3] = "Comm_Code";
                        textArray21[4] = "Transaction_Code";
                        textArray21[5] = "estate_code";
                        textArray21[6] = "edit_by";
                        textArray21[7] = "edit_Date";
                        textArray21[8] = "PI_No";
                        textArray21[9] = "tolling";
                        string[] textArray22 = new string[10];
                        textArray22[0] = this.fTimbun.textTransporter.Text.Trim();
                        textArray22[1] = this.fTimbun.textDO.Text.Trim() + "T";
                        textArray22[2] = this.fTimbun.textVend.Text.Trim();
                        textArray22[3] = this.fTimbun.textCommodity.Text.Trim();
                        textArray22[4] = this.fTimbun.textType.Text.Trim();
                        textArray22[5] = this.fTimbun.textEstate.Text.Trim();
                        textArray22[6] = WBUser.UserID;
                        textArray22[7] = DateTime.Now.ToString();
                        textArray22[8] = this.textPI_No.Text.Trim();
                        textArray22[9] = str6;
                        Program.ReplaceAllExceptTransporter("wb_transaction", textArray21, textArray22, " Do_No='" + this.fTimbun.OldCode.Trim() + "T'", this.changeReason + " (Edit contract master data)");
                    }
                }
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_00F1:
            table2.Dispose();
            goto TR_00F0;
        }

        private string findTimbun()
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contractTTB", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_NO = '" + this.textDO.Text + "T' and zAuto = 'Y'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = "";
            }
            else
            {
                table.DR = table.DT.Rows[0];
                str = table.DR["uniq"].ToString();
                this.timbunSave = true;
            }
            table.Dispose();
            return str;
        }

        private void force_check_qty()
        {
            if (this.textCommodity.Text.Trim() != "")
            {
                WBCondition condition = new WBCondition();
                DataRow[] dgRows = new DataRow[] { this.row_comm, this.row_type };
                condition.fillParameter("FORCE_CHECK_QTY", dgRows);
                if (!condition.getResult())
                {
                    this.checkQuantity.Enabled = true;
                }
                else
                {
                    this.checkQuantity.Checked = true;
                    this.checkQuantity.Enabled = false;
                }
                condition.Dispose();
            }
        }

        private void FormContractEntry_CursorChanged(object sender, EventArgs e)
        {
            MessageBox.Show(base.ActiveControl.Name);
        }

        private void FormContractEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContractEntry_Load(object sender, EventArgs e)
        {
            this.spMode = this.pMode;
            if (this.pMode == "GRCUST")
            {
                this.pMode = "EDIT";
            }
            this.panelCheckOS.Visible = WBUser.UserLevel == "1";
            if (WBSetting.locType == "1")
            {
                this.tabControl1.TabPages.Remove(this.tabPageRef);
                this.needAdoptNego = (this.textNEGO.Text.Trim() == "") ? "N" : "Y";
                this.labelQualityInfo.Visible = false;
                this.textQualityInfo.Visible = false;
            }
            else if (WBSetting.locType == "0")
            {
                this.tabControl1.TabPages.Remove(this.tabPagePOM);
                this.labelQualityInfo.Visible = true;
                this.textQualityInfo.Visible = true;
            }
            this.f_Load();
        }

        private string getData(string tbl, string field, string value, string sfield)
        {
            string str2;
            if (value.Trim() == "")
            {
                str2 = "";
            }
            else
            {
                WBTable table = new WBTable();
                string str = "";
                string[] textArray1 = new string[11];
                textArray1[0] = "select * from ";
                textArray1[1] = tbl;
                textArray1[2] = " where ";
                textArray1[3] = field;
                textArray1[4] = " = '";
                textArray1[5] = value;
                textArray1[6] = "' and coy = '";
                textArray1[7] = WBData.sCoyCode;
                textArray1[8] = "' and location_code = '";
                textArray1[9] = WBData.sLocCode;
                textArray1[10] = "'";
                table.OpenTable(tbl, string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    str = table.DR[sfield].ToString();
                }
                else
                {
                    str = value;
                    string[] textArray2 = new string[] { "SAP Code ", tbl, " = ", value, " Not Found, Please Maintain in WB.NET Data" };
                    MessageBox.Show(string.Concat(textArray2));
                    if ((tbl == "wb_commodity") && (field == "material"))
                    {
                        string commCode = Interaction.InputBox("Entry Commodity Code", "Get Data From ZWB", "", 300, 300);
                        if (commCode != "")
                        {
                            this.CompareAll(commCode);
                            this.tblComm.ReOpen();
                            string[] textArray3 = new string[] { "select * from ", tbl, " where ", field, " = '", value, "'" };
                            table.OpenTable(tbl, string.Concat(textArray3), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                str = table.DR[sfield].ToString();
                            }
                        }
                    }
                }
                str2 = str;
            }
            return str2;
        }

        private string getQualityInfo(IRfcStructure ISReturn)
        {
            string str = "";
            if (ISReturn.GetString("FFA").Trim() != "")
            {
                string[] textArray1 = new string[] { str, "FFA".PadRight(5, ' '), ":", ISReturn.GetString("FFA").Trim(), " " };
                str = (string.Concat(textArray1) + ISReturn.GetString("FFA_MAX").Trim() + " ") + "\n";
            }
            if (ISReturn.GetString("MNI").Trim() != "")
            {
                string[] textArray2 = new string[] { str, "MNI".PadRight(5, ' '), ":", ISReturn.GetString("MNI").Trim(), " " };
                str = string.Concat(textArray2) + ISReturn.GetString("MNI_MAX").Trim() + "\n";
            }
            if (ISReturn.GetString("DNS").Trim() != "")
            {
                string[] textArray3 = new string[] { str, "DNS".PadRight(5, ' '), ":", ISReturn.GetString("DNS").Trim(), " " };
                str = string.Concat(textArray3) + ISReturn.GetString("DNS_MAX").Trim() + "\n";
            }
            if (ISReturn.GetString("MOIS").Trim() != "")
            {
                str = (str + "MOIS".PadRight(5, ' ') + ":" + ISReturn.GetString("MOIS").Trim()) + "\n";
            }
            if (ISReturn.GetString("IV").Trim() != "")
            {
                str = (str + "IV".PadRight(5, ' ') + ":" + ISReturn.GetString("IV").Trim()) + "\n";
            }
            if (ISReturn.GetString("DOBI").Trim() != "")
            {
                str = (str + "DOBI".PadRight(5, ' ') + ":" + ISReturn.GetString("DOBI").Trim()) + "\n";
            }
            if (ISReturn.GetString("COLOR").Trim() != "")
            {
                str = (str + "COLOR".PadRight(5, ' ') + ":" + ISReturn.GetString("COLOR").Trim()) + "\n";
            }
            if (ISReturn.GetString("OC").Trim() != "")
            {
                str = (str + "OC".PadRight(5, ' ') + ":" + ISReturn.GetString("OC").Trim()) + "\n";
            }
            if (ISReturn.GetString("MP").Trim() != "")
            {
                str = (str + "MP".PadRight(5, ' ') + ":" + ISReturn.GetString("MP").Trim()) + "\n";
            }
            if (ISReturn.GetString("CP").Trim() != "")
            {
                str = (str + "CP".PadRight(5, ' ') + ":" + ISReturn.GetString("CP").Trim()) + "\n";
            }
            if (ISReturn.GetString("PRFAT").Trim() != "")
            {
                str = (str + "PRFAT".PadRight(5, ' ') + ":" + ISReturn.GetString("PRFAT").Trim()) + "\n";
            }
            if (ISReturn.GetString("AV").Trim() != "")
            {
                str = (str + "AV".PadRight(5, ' ') + ":" + ISReturn.GetString("AV").Trim()) + "\n";
            }
            if (ISReturn.GetString("PV").Trim() != "")
            {
                str = (str + "PV".PadRight(5, ' ') + ":" + ISReturn.GetString("PV").Trim()) + "\n";
            }
            if (ISReturn.GetString("SV").Trim() != "")
            {
                str = (str + "SV".PadRight(5, ' ') + ":" + ISReturn.GetString("SV").Trim()) + "\n";
            }
            if (ISReturn.GetString("SM").Trim() != "")
            {
                str = (str + "SM".PadRight(5, ' ') + ":" + ISReturn.GetString("SM").Trim()) + "\n";
            }
            if (ISReturn.GetString("TASTE").Trim() != "")
            {
                str = str + "TASTE".PadRight(5, ' ') + ":" + ISReturn.GetString("TASTE").Trim();
            }
            return str;
        }

        private void initCombo()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_upload_type", "select * from wb_upload_type", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                if (WBSetting.locType == "0")
                {
                    this.comboUploadType.Items.Add(row["Upload_Type"].ToString());
                    continue;
                }
                this.comboUploadType1.Items.Add(row["Upload_Type"].ToString());
            }
            this.tblIncoterm.OpenTable("wb_Incoterm", "select * from wb_Incoterm", WBData.conn);
            foreach (DataRow row2 in this.tblIncoterm.DT.Rows)
            {
                this.comboIncoterm.Items.Add(row2["Incoterm_Code"].ToString());
            }
            if (this.tblIncoterm.DR != null)
            {
                this.comboIncoterm.Text = this.tblIncoterm.DT.Rows[0]["Incoterm_code"].ToString();
            }
            if (this.comboIncoterm.Text.Trim() != "")
            {
                string[] aField = new string[] { "Incoterm_code" };
                string[] aFind = new string[] { this.comboIncoterm.Text.Trim() };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
                if (this.tblIncoterm.DR == null)
                {
                    this.labelIncotermCode.Text = "";
                }
                else
                {
                    this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_Desc"].ToString();
                    if (this.textType.Text == "")
                    {
                        this.radioSeller.Checked = false;
                        this.radioBuyer.Checked = false;
                    }
                    else
                    {
                        string[] textArray3 = new string[] { "transaction_code", "Incoterm_code" };
                        string[] textArray4 = new string[] { this.textType.Text, this.comboIncoterm.Text };
                        this.tblDeductedBy.DR = this.tblDeductedBy.GetData(textArray3, textArray4);
                        if (this.tblDeductedBy.DR != null)
                        {
                            this.radioSeller.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "1";
                            this.radioBuyer.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "0";
                        }
                        else
                        {
                            this.radioSeller.Checked = false;
                            this.radioBuyer.Checked = false;
                        }
                    }
                }
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.label1 = new Label();
            this.textDO = new TextBox();
            this.label2 = new Label();
            this.dateTimeDO = new DateTimePicker();
            this.dateTimeContract = new DateTimePicker();
            this.label3 = new Label();
            this.textContract = new TextBox();
            this.label4 = new Label();
            this.label7 = new Label();
            this.label8 = new Label();
            this.relationName = new Label();
            this.CommodityName = new Label();
            this.label9 = new Label();
            this.label10 = new Label();
            this.checkQuantity = new CheckBox();
            this.tabControl1 = new TabControl();
            this.tabPageRef = new TabPage();
            this.cb_gain_loss = new CheckBox();
            this.panelLangsir = new GroupBox();
            this.panel_TP = new Panel();
            this.textBatch = new TextBox();
            this.cb_sloc = new ComboBox();
            this.cb_plant = new ComboBox();
            this.label_tp_desc = new Label();
            this.radioLangsir2 = new RadioButton();
            this.radioLangsir = new RadioButton();
            this.radioLangsirTransfer = new RadioButton();
            this.radioLangsirTtb = new RadioButton();
            this.buttonPreview = new Button();
            this.textTimbunCoy = new TextBox();
            this.buttonLocation = new Button();
            this.radioLangsirNone = new RadioButton();
            this.labelSlash = new Label();
            this.textSTOItem = new TextBox();
            this.lblQstandard = new Label();
            this.txtQStandard = new TextBox();
            this.textGRPO_Cust = new TextBox();
            this.label5 = new Label();
            this.labelRefDes = new Label();
            this.label41 = new Label();
            this.comboRefCode = new ComboBox();
            this.comboBillOfLading = new ComboBox();
            this.label24 = new Label();
            this.btnAdopt = new Button();
            this.checkSTO1DO = new CheckBox();
            this.label54 = new Label();
            this.textPOItem = new TextBox();
            this.label48 = new Label();
            this.textPI_No = new TextBox();
            this.labelPO = new Label();
            this.comboUploadType = new ComboBox();
            this.textPO = new TextBox();
            this.label52 = new Label();
            this.textSTO = new TextBox();
            this.label20 = new Label();
            this.textGRPO = new TextBox();
            this.label21 = new Label();
            this.checkBerikat = new CheckBox();
            this.tabPagePOM = new TabPage();
            this.textQstDesc = new TextBox();
            this.textQst = new TextBox();
            this.labelQStandard = new Label();
            this.textOrigin = new TextBox();
            this.labelOrigin = new Label();
            this.comboUploadType1 = new ComboBox();
            this.label17 = new Label();
            this.labelPO1Item = new Label();
            this.textPO1Item = new TextBox();
            this.labelPO1 = new Label();
            this.textPO1 = new TextBox();
            this.buttonAdopt2 = new Button();
            this.checkTolling = new CheckBox();
            this.groupBoxFruit = new GroupBox();
            this.label26 = new Label();
            this.label27 = new Label();
            this.label28 = new Label();
            this.label29 = new Label();
            this.label30 = new Label();
            this.label39 = new Label();
            this.textLarge1 = new TextBox();
            this.label31 = new Label();
            this.textScout2 = new TextBox();
            this.textLarge2 = new TextBox();
            this.label40 = new Label();
            this.label32 = new Label();
            this.textMid1 = new TextBox();
            this.textScout1 = new TextBox();
            this.label34 = new Label();
            this.label37 = new Label();
            this.textMid2 = new TextBox();
            this.textLoose2 = new TextBox();
            this.label33 = new Label();
            this.label38 = new Label();
            this.textSmall1 = new TextBox();
            this.textLoose1 = new TextBox();
            this.label36 = new Label();
            this.label35 = new Label();
            this.textSmall2 = new TextBox();
            this.checkAgen = new CheckBox();
            this.label13 = new Label();
            this.textSTO1 = new TextBox();
            this.label58 = new Label();
            this.textSTO_Item = new TextBox();
            this.label23 = new Label();
            this.textNEGO = new TextBox();
            this.groupBox4 = new GroupBox();
            this.label44 = new Label();
            this.label42 = new Label();
            this.radioRamp = new RadioButton();
            this.radioKebAgen = new RadioButton();
            this.radioAgen = new RadioButton();
            this.radioOthers = new RadioButton();
            this.radioGroupEstate = new RadioButton();
            this.radioOtherGroup = new RadioButton();
            this.label19 = new Label();
            this.tabPage3 = new TabPage();
            this.groupBoxConversion = new GroupBox();
            this.labelConvValue = new Label();
            this.textConvValue = new TextBox();
            this.label50 = new Label();
            this.textConvUnit = new TextBox();
            this.label51 = new Label();
            this.tabPageOpening = new TabPage();
            this.groupBoxEntry = new GroupBox();
            this.textOpnEntryFactory = new TextBox();
            this.label43 = new Label();
            this.textOpnEntryEstate = new TextBox();
            this.label3rdOpening = new Label();
            this.labelFactoryOpening = new Label();
            this.labelKG3rd = new Label();
            this.btnEstate = new Button();
            this.labelEstateADM = new Label();
            this.label15 = new Label();
            this.textVessel = new TextBox();
            this.label14 = new Label();
            this.label12 = new Label();
            this.checkISCC = new CheckBox();
            this.label25 = new Label();
            this.textRemark = new TextBox();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.label45 = new Label();
            this.label46 = new Label();
            this.textTransporter = new TextBox();
            this.textType = new TextBox();
            this.buttonType = new Button();
            this.textCommodity = new TextBox();
            this.button1 = new Button();
            this.textVend = new TextBox();
            this.button2 = new Button();
            this.button3 = new Button();
            this.TransporterName = new Label();
            this.labelTransTypeName = new Label();
            this.label49 = new Label();
            this.textTolerance = new TextBox();
            this.label53 = new Label();
            this.textQuantity = new TextBox();
            this.dateDO_period = new DateTimePicker();
            this.checkPeriod = new CheckBox();
            this.textEstate = new TextBox();
            this.toolTip1 = new ToolTip(this.components);
            this.groupBoxDeducted = new GroupBox();
            this.radioSeller = new RadioButton();
            this.radioBuyer = new RadioButton();
            this.textBoxOS = new TextBox();
            this.btn_mill = new Button();
            this.label18 = new Label();
            this.labelQualityInfo = new Label();
            this.textQualityInfo = new RichTextBox();
            this.textToken = new TextBox();
            this.labelIncotermCode = new Label();
            this.comboIncoterm = new ComboBox();
            this.buttonCheckOS = new Button();
            this.label11 = new Label();
            this.panelCheckOS = new Panel();
            this.txt_mill = new TextBox();
            this.label6 = new Label();
            this.cb_langsir_type = new ComboBox();
            this.label16 = new Label();
            this.label_langsir_desc = new Label();
            this.tabControl1.SuspendLayout();
            this.tabPageRef.SuspendLayout();
            this.panelLangsir.SuspendLayout();
            this.panel_TP.SuspendLayout();
            this.tabPagePOM.SuspendLayout();
            this.groupBoxFruit.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBoxConversion.SuspendLayout();
            this.tabPageOpening.SuspendLayout();
            this.groupBoxEntry.SuspendLayout();
            this.groupBoxDeducted.SuspendLayout();
            this.panelCheckOS.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x12, 0x27);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5e, 13);
            this.label1.TabIndex = 0x15;
            this.label1.Text = "Delivery Order No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textDO.Location = new Point(0x77, 0x23);
            this.textDO.Margin = new Padding(3, 4, 3, 4);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xce, 20);
            this.textDO.TabIndex = 0;
            this.textDO.TextChanged += new EventHandler(this.textDO_TextChanged);
            this.textDO.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x14c, 0x27);
            this.label2.Name = "label2";
            this.label2.Size = new Size(30, 13);
            this.label2.TabIndex = 0x1f;
            this.label2.Text = "Date";
            this.dateTimeDO.Format = DateTimePickerFormat.Short;
            this.dateTimeDO.Location = new Point(0x170, 0x23);
            this.dateTimeDO.Margin = new Padding(3, 4, 3, 4);
            this.dateTimeDO.Name = "dateTimeDO";
            this.dateTimeDO.Size = new Size(0x56, 20);
            this.dateTimeDO.TabIndex = 2;
            this.dateTimeDO.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.dateTimeContract.Format = DateTimePickerFormat.Short;
            this.dateTimeContract.Location = new Point(0x170, 0x3d);
            this.dateTimeContract.Margin = new Padding(3, 4, 3, 4);
            this.dateTimeContract.Name = "dateTimeContract";
            this.dateTimeContract.Size = new Size(0x56, 20);
            this.dateTimeContract.TabIndex = 6;
            this.dateTimeContract.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x14c, 0x41);
            this.label3.Name = "label3";
            this.label3.Size = new Size(30, 13);
            this.label3.TabIndex = 0x20;
            this.label3.Text = "Date";
            this.textContract.Location = new Point(0x77, 0x3d);
            this.textContract.Margin = new Padding(3, 4, 3, 4);
            this.textContract.MaxLength = 50;
            this.textContract.Name = "textContract";
            this.textContract.Size = new Size(0xce, 20);
            this.textContract.TabIndex = 5;
            this.textContract.TextChanged += new EventHandler(this.textContract_TextChanged);
            this.textContract.KeyPress += new KeyPressEventHandler(this.textBox2_KeyPress);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x2d, 0x41);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x43, 13);
            this.label4.TabIndex = 0x16;
            this.label4.Text = "Contract No.";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x36, 0x5c);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x3a, 13);
            this.label7.TabIndex = 0x17;
            this.label7.Text = "Commodity";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x10, 0x77);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x60, 13);
            this.label8.TabIndex = 0x18;
            this.label8.Text = "Vendor / Customer";
            this.relationName.AutoSize = true;
            this.relationName.Location = new Point(0x11f, 0x77);
            this.relationName.Name = "relationName";
            this.relationName.Size = new Size(0x4a, 13);
            this.relationName.TabIndex = 0x24;
            this.relationName.Text = "RelationName";
            this.CommodityName.AutoSize = true;
            this.CommodityName.Location = new Point(0x11f, 0x5c);
            this.CommodityName.Name = "CommodityName";
            this.CommodityName.Size = new Size(0x56, 13);
            this.CommodityName.TabIndex = 0x22;
            this.CommodityName.Text = "CommodityName";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x16, 11);
            this.label9.Name = "label9";
            this.label9.Size = new Size(90, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Transaction Type";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x257, 0xdd);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x2e, 13);
            this.label10.TabIndex = 0x2b;
            this.label10.Text = "Quantity";
            this.checkQuantity.AutoSize = true;
            this.checkQuantity.Checked = true;
            this.checkQuantity.CheckState = CheckState.Checked;
            this.checkQuantity.Location = new Point(0x310, 0xdb);
            this.checkQuantity.Margin = new Padding(3, 4, 3, 4);
            this.checkQuantity.Name = "checkQuantity";
            this.checkQuantity.Size = new Size(0x63, 0x11);
            this.checkQuantity.TabIndex = 15;
            this.checkQuantity.Text = "Check Quantity\r\n";
            this.checkQuantity.UseVisualStyleBackColor = true;
            this.tabControl1.Controls.Add(this.tabPageRef);
            this.tabControl1.Controls.Add(this.tabPagePOM);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPageOpening);
            this.tabControl1.Location = new Point(20, 0x126);
            this.tabControl1.Margin = new Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x28f, 0x125);
            this.tabControl1.TabIndex = 0x11;
            this.tabPageRef.BackColor = Color.WhiteSmoke;
            this.tabPageRef.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageRef.Controls.Add(this.cb_gain_loss);
            this.tabPageRef.Controls.Add(this.panelLangsir);
            this.tabPageRef.Controls.Add(this.labelSlash);
            this.tabPageRef.Controls.Add(this.textSTOItem);
            this.tabPageRef.Controls.Add(this.lblQstandard);
            this.tabPageRef.Controls.Add(this.txtQStandard);
            this.tabPageRef.Controls.Add(this.textGRPO_Cust);
            this.tabPageRef.Controls.Add(this.label5);
            this.tabPageRef.Controls.Add(this.labelRefDes);
            this.tabPageRef.Controls.Add(this.label41);
            this.tabPageRef.Controls.Add(this.comboRefCode);
            this.tabPageRef.Controls.Add(this.comboBillOfLading);
            this.tabPageRef.Controls.Add(this.label24);
            this.tabPageRef.Controls.Add(this.btnAdopt);
            this.tabPageRef.Controls.Add(this.checkSTO1DO);
            this.tabPageRef.Controls.Add(this.label54);
            this.tabPageRef.Controls.Add(this.textPOItem);
            this.tabPageRef.Controls.Add(this.label48);
            this.tabPageRef.Controls.Add(this.textPI_No);
            this.tabPageRef.Controls.Add(this.labelPO);
            this.tabPageRef.Controls.Add(this.comboUploadType);
            this.tabPageRef.Controls.Add(this.textPO);
            this.tabPageRef.Controls.Add(this.label52);
            this.tabPageRef.Controls.Add(this.textSTO);
            this.tabPageRef.Controls.Add(this.label20);
            this.tabPageRef.Controls.Add(this.textGRPO);
            this.tabPageRef.Controls.Add(this.label21);
            this.tabPageRef.Controls.Add(this.checkBerikat);
            this.tabPageRef.Location = new Point(4, 0x16);
            this.tabPageRef.Margin = new Padding(3, 4, 3, 4);
            this.tabPageRef.Name = "tabPageRef";
            this.tabPageRef.Padding = new Padding(3, 4, 3, 4);
            this.tabPageRef.Size = new Size(0x287, 0x10b);
            this.tabPageRef.TabIndex = 0;
            this.tabPageRef.Text = "   Refinery   ";
            this.tabPageRef.Click += new EventHandler(this.tabPageRef_Click);
            this.cb_gain_loss.AutoSize = true;
            this.cb_gain_loss.Location = new Point(20, 0xd4);
            this.cb_gain_loss.Margin = new Padding(3, 4, 3, 4);
            this.cb_gain_loss.Name = "cb_gain_loss";
            this.cb_gain_loss.Size = new Size(0xaf, 0x11);
            this.cb_gain_loss.TabIndex = 60;
            this.cb_gain_loss.Text = "Gain / Loss in Destination Sloc.";
            this.cb_gain_loss.UseVisualStyleBackColor = true;
            this.panelLangsir.Controls.Add(this.panel_TP);
            this.panelLangsir.Controls.Add(this.radioLangsir2);
            this.panelLangsir.Controls.Add(this.radioLangsir);
            this.panelLangsir.Controls.Add(this.radioLangsirTransfer);
            this.panelLangsir.Controls.Add(this.radioLangsirTtb);
            this.panelLangsir.Controls.Add(this.buttonPreview);
            this.panelLangsir.Controls.Add(this.textTimbunCoy);
            this.panelLangsir.Controls.Add(this.buttonLocation);
            this.panelLangsir.Controls.Add(this.radioLangsirNone);
            this.panelLangsir.Location = new Point(0xfc, 0x57);
            this.panelLangsir.Name = "panelLangsir";
            this.panelLangsir.Size = new Size(0x183, 0xb0);
            this.panelLangsir.TabIndex = 0x3b;
            this.panelLangsir.TabStop = false;
            this.panelLangsir.Text = "Langsir Type";
            this.panel_TP.Controls.Add(this.textBatch);
            this.panel_TP.Controls.Add(this.cb_sloc);
            this.panel_TP.Controls.Add(this.cb_plant);
            this.panel_TP.Controls.Add(this.label_tp_desc);
            this.panel_TP.Location = new Point(0x23, 0x7c);
            this.panel_TP.Name = "panel_TP";
            this.panel_TP.Size = new Size(0x143, 0x31);
            this.panel_TP.TabIndex = 20;
            this.textBatch.Location = new Point(6, 20);
            this.textBatch.Margin = new Padding(3, 4, 3, 4);
            this.textBatch.MaxLength = 10;
            this.textBatch.Name = "textBatch";
            this.textBatch.Size = new Size(0x4c, 20);
            this.textBatch.TabIndex = 0x38;
            this.cb_sloc.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cb_sloc.FormattingEnabled = true;
            this.cb_sloc.Location = new Point(0xa6, 0x13);
            this.cb_sloc.Name = "cb_sloc";
            this.cb_sloc.Size = new Size(0x48, 0x15);
            this.cb_sloc.TabIndex = 0x1a;
            this.cb_plant.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cb_plant.FormattingEnabled = true;
            this.cb_plant.Location = new Point(0x58, 0x13);
            this.cb_plant.Name = "cb_plant";
            this.cb_plant.Size = new Size(0x48, 0x15);
            this.cb_plant.TabIndex = 0x19;
            this.label_tp_desc.AutoSize = true;
            this.label_tp_desc.Location = new Point(3, 3);
            this.label_tp_desc.Name = "label_tp_desc";
            this.label_tp_desc.Size = new Size(0xa8, 13);
            this.label_tp_desc.TabIndex = 0x15;
            this.label_tp_desc.Text = "Destination Batch / Plant / S. Loc";
            this.radioLangsir2.AutoSize = true;
            this.radioLangsir2.Location = new Point(11, 0x52);
            this.radioLangsir2.Margin = new Padding(3, 4, 3, 4);
            this.radioLangsir2.Name = "radioLangsir2";
            this.radioLangsir2.Size = new Size(80, 0x11);
            this.radioLangsir2.TabIndex = 0x11;
            this.radioLangsir2.TabStop = true;
            this.radioLangsir2.Text = "GR Only (2)";
            this.radioLangsir2.UseVisualStyleBackColor = true;
            this.radioLangsir.AutoSize = true;
            this.radioLangsir.Location = new Point(11, 60);
            this.radioLangsir.Margin = new Padding(3, 4, 3, 4);
            this.radioLangsir.Name = "radioLangsir";
            this.radioLangsir.Size = new Size(0x4a, 0x11);
            this.radioLangsir.TabIndex = 0x10;
            this.radioLangsir.TabStop = true;
            this.radioLangsir.Text = "Langsir (7)";
            this.radioLangsir.UseVisualStyleBackColor = true;
            this.radioLangsirTransfer.AutoSize = true;
            this.radioLangsirTransfer.Location = new Point(11, 0x68);
            this.radioLangsirTransfer.Margin = new Padding(3, 4, 3, 4);
            this.radioLangsirTransfer.Name = "radioLangsirTransfer";
            this.radioLangsirTransfer.Size = new Size(0x75, 0x11);
            this.radioLangsirTransfer.TabIndex = 15;
            this.radioLangsirTransfer.TabStop = true;
            this.radioLangsirTransfer.Text = "Transfer Posting (5)";
            this.radioLangsirTransfer.UseVisualStyleBackColor = true;
            this.radioLangsirTransfer.CheckedChanged += new EventHandler(this.radioLangsirTransfer_CheckedChanged);
            this.radioLangsirTtb.AutoSize = true;
            this.radioLangsirTtb.Location = new Point(11, 0x26);
            this.radioLangsirTtb.Margin = new Padding(3, 4, 3, 4);
            this.radioLangsirTtb.Name = "radioLangsirTtb";
            this.radioLangsirTtb.Size = new Size(0x62, 0x11);
            this.radioLangsirTtb.TabIndex = 10;
            this.radioLangsirTtb.Text = "Titip Timbun (6)";
            this.toolTip1.SetToolTip(this.radioLangsirTtb, "Indicator for titip timbun transaction\r\n\"None\" will not show automate form ");
            this.radioLangsirTtb.UseVisualStyleBackColor = true;
            this.buttonPreview.Location = new Point(0xc5, 0x25);
            this.buttonPreview.Margin = new Padding(3, 4, 3, 4);
            this.buttonPreview.Name = "buttonPreview";
            this.buttonPreview.Size = new Size(0x79, 0x16);
            this.buttonPreview.TabIndex = 13;
            this.buttonPreview.Text = "Automate Form";
            this.toolTip1.SetToolTip(this.buttonPreview, "Show Automate Form for Commodity Owner");
            this.buttonPreview.UseVisualStyleBackColor = true;
            this.buttonPreview.Visible = false;
            this.textTimbunCoy.Location = new Point(0x73, 0x26);
            this.textTimbunCoy.Margin = new Padding(3, 4, 3, 4);
            this.textTimbunCoy.MaxLength = 5;
            this.textTimbunCoy.Name = "textTimbunCoy";
            this.textTimbunCoy.Size = new Size(0x33, 20);
            this.textTimbunCoy.TabIndex = 11;
            this.toolTip1.SetToolTip(this.textTimbunCoy, "Typed in Owner Material ZWB location");
            this.buttonLocation.Location = new Point(0xa9, 0x24);
            this.buttonLocation.Margin = new Padding(0);
            this.buttonLocation.Name = "buttonLocation";
            this.buttonLocation.Size = new Size(0x17, 0x16);
            this.buttonLocation.TabIndex = 14;
            this.buttonLocation.Text = "...";
            this.toolTip1.SetToolTip(this.buttonLocation, "Browse Owner Material ZWB location\r\n");
            this.buttonLocation.UseVisualStyleBackColor = true;
            this.radioLangsirNone.AutoSize = true;
            this.radioLangsirNone.Checked = true;
            this.radioLangsirNone.Location = new Point(11, 0x11);
            this.radioLangsirNone.Margin = new Padding(3, 4, 3, 4);
            this.radioLangsirNone.Name = "radioLangsirNone";
            this.radioLangsirNone.Size = new Size(0x42, 0x11);
            this.radioLangsirNone.TabIndex = 9;
            this.radioLangsirNone.TabStop = true;
            this.radioLangsirNone.Text = "None (1)";
            this.radioLangsirNone.UseVisualStyleBackColor = true;
            this.labelSlash.AutoSize = true;
            this.labelSlash.Location = new Point(0x93, 0x2e);
            this.labelSlash.Name = "labelSlash";
            this.labelSlash.Size = new Size(12, 13);
            this.labelSlash.TabIndex = 0x3a;
            this.labelSlash.Text = "/";
            this.textSTOItem.Location = new Point(0xa4, 0x2b);
            this.textSTOItem.Margin = new Padding(3, 4, 3, 4);
            this.textSTOItem.MaxLength = 6;
            this.textSTOItem.Name = "textSTOItem";
            this.textSTOItem.Size = new Size(0x38, 20);
            this.textSTOItem.TabIndex = 0x39;
            this.lblQstandard.AutoSize = true;
            this.lblQstandard.Location = new Point(7, 0x91);
            this.lblQstandard.Name = "lblQstandard";
            this.lblQstandard.Size = new Size(0x3d, 13);
            this.lblQstandard.TabIndex = 0x36;
            this.lblQstandard.Text = "Q.Standard";
            this.txtQStandard.BackColor = SystemColors.ScrollBar;
            this.txtQStandard.Enabled = false;
            this.txtQStandard.Location = new Point(70, 0x8e);
            this.txtQStandard.Margin = new Padding(3, 4, 3, 4);
            this.txtQStandard.MaxLength = 20;
            this.txtQStandard.Name = "txtQStandard";
            this.txtQStandard.Size = new Size(0x83, 20);
            this.txtQStandard.TabIndex = 0x35;
            this.textGRPO_Cust.Location = new Point(70, 0x5c);
            this.textGRPO_Cust.Margin = new Padding(3, 4, 3, 4);
            this.textGRPO_Cust.MaxLength = 10;
            this.textGRPO_Cust.Name = "textGRPO_Cust";
            this.textGRPO_Cust.Size = new Size(0x4c, 20);
            this.textGRPO_Cust.TabIndex = 4;
            this.textGRPO_Cust.TextChanged += new EventHandler(this.textGRPO_Cust_TextChanged);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(7, 0x5f);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3d, 13);
            this.label5.TabIndex = 0x12;
            this.label5.Text = "GR Custom";
            this.labelRefDes.AutoSize = true;
            this.labelRefDes.Location = new Point(0x1b1, 70);
            this.labelRefDes.Name = "labelRefDes";
            this.labelRefDes.Size = new Size(0x58, 13);
            this.labelRefDes.TabIndex = 0x19;
            this.labelRefDes.Text = "Short Description";
            this.labelRefDes.Visible = false;
            this.label41.AutoSize = true;
            this.label41.Location = new Point(0x114, 0x47);
            this.label41.Name = "label41";
            this.label41.Size = new Size(0x2d, 13);
            this.label41.TabIndex = 0x18;
            this.label41.Text = "WB.Ref";
            this.label41.Visible = false;
            this.comboRefCode.FormattingEnabled = true;
            this.comboRefCode.Location = new Point(0x147, 0x43);
            this.comboRefCode.Margin = new Padding(3, 4, 3, 4);
            this.comboRefCode.Name = "comboRefCode";
            this.comboRefCode.Size = new Size(100, 0x15);
            this.comboRefCode.TabIndex = 13;
            this.comboRefCode.Visible = false;
            this.comboRefCode.TextChanged += new EventHandler(this.comboRefCode_TextChanged);
            this.comboBillOfLading.FormattingEnabled = true;
            this.comboBillOfLading.Location = new Point(520, 0x2a);
            this.comboBillOfLading.Margin = new Padding(3, 4, 3, 4);
            this.comboBillOfLading.Name = "comboBillOfLading";
            this.comboBillOfLading.Size = new Size(100, 0x15);
            this.comboBillOfLading.TabIndex = 12;
            this.comboBillOfLading.Visible = false;
            this.label24.AutoSize = true;
            this.label24.Location = new Point(440, 0x2e);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x45, 13);
            this.label24.TabIndex = 0x17;
            this.label24.Text = "Bill Of Lading";
            this.label24.Visible = false;
            this.btnAdopt.Location = new Point(0x43, 170);
            this.btnAdopt.Margin = new Padding(3, 4, 3, 4);
            this.btnAdopt.Name = "btnAdopt";
            this.btnAdopt.Size = new Size(0x76, 0x26);
            this.btnAdopt.TabIndex = 8;
            this.btnAdopt.Text = "&Adopt from SAP";
            this.toolTip1.SetToolTip(this.btnAdopt, "Adopt Data from SAP");
            this.btnAdopt.UseVisualStyleBackColor = true;
            this.btnAdopt.Click += new EventHandler(this.btnAdopt_Click);
            this.checkSTO1DO.AutoSize = true;
            this.checkSTO1DO.Location = new Point(0x98, 70);
            this.checkSTO1DO.Margin = new Padding(3, 4, 3, 4);
            this.checkSTO1DO.Name = "checkSTO1DO";
            this.checkSTO1DO.Size = new Size(0x58, 0x11);
            this.checkSTO1DO.TabIndex = 2;
            this.checkSTO1DO.Text = "1STO = 1DO";
            this.checkSTO1DO.UseVisualStyleBackColor = true;
            this.checkSTO1DO.CheckedChanged += new EventHandler(this.checkSTO1DO_CheckedChanged);
            this.label54.AutoSize = true;
            this.label54.Location = new Point(0x93, 0x16);
            this.label54.Name = "label54";
            this.label54.Size = new Size(12, 13);
            this.label54.TabIndex = 0x15;
            this.label54.Text = "/";
            this.textPOItem.Location = new Point(0xa4, 0x13);
            this.textPOItem.Margin = new Padding(3, 4, 3, 4);
            this.textPOItem.MaxLength = 6;
            this.textPOItem.Name = "textPOItem";
            this.textPOItem.Size = new Size(0x38, 20);
            this.textPOItem.TabIndex = 6;
            this.label48.AutoSize = true;
            this.label48.Location = new Point(0x11, 0x79);
            this.label48.Name = "label48";
            this.label48.Size = new Size(0x33, 13);
            this.label48.TabIndex = 20;
            this.label48.Text = "PI/SI NO";
            this.textPI_No.Location = new Point(70, 0x75);
            this.textPI_No.Margin = new Padding(3, 4, 3, 4);
            this.textPI_No.MaxLength = 15;
            this.textPI_No.Name = "textPI_No";
            this.textPI_No.Size = new Size(0x75, 20);
            this.textPI_No.TabIndex = 7;
            this.labelPO.AutoSize = true;
            this.labelPO.Location = new Point(0x30, 0x16);
            this.labelPO.Name = "labelPO";
            this.labelPO.Size = new Size(0x16, 13);
            this.labelPO.TabIndex = 15;
            this.labelPO.Text = "PO";
            this.comboUploadType.FormattingEnabled = true;
            this.comboUploadType.Location = new Point(0x147, 0x2c);
            this.comboUploadType.Margin = new Padding(3, 4, 3, 4);
            this.comboUploadType.Name = "comboUploadType";
            this.comboUploadType.Size = new Size(100, 0x15);
            this.comboUploadType.TabIndex = 11;
            this.comboUploadType.Visible = false;
            this.textPO.Location = new Point(70, 0x13);
            this.textPO.Margin = new Padding(3, 4, 3, 4);
            this.textPO.MaxLength = 10;
            this.textPO.Name = "textPO";
            this.textPO.Size = new Size(0x4c, 20);
            this.textPO.TabIndex = 0;
            this.label52.AutoSize = true;
            this.label52.Location = new Point(0xf9, 0x2f);
            this.label52.Name = "label52";
            this.label52.Size = new Size(0x44, 13);
            this.label52.TabIndex = 0x16;
            this.label52.Text = "Upload Type";
            this.label52.Visible = false;
            this.textSTO.Location = new Point(70, 0x2b);
            this.textSTO.Margin = new Padding(3, 4, 3, 4);
            this.textSTO.MaxLength = 10;
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(0x4c, 20);
            this.textSTO.TabIndex = 1;
            this.textSTO.Leave += new EventHandler(this.textSTO_Leave);
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x29, 0x2e);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x1d, 13);
            this.label20.TabIndex = 0x10;
            this.label20.Text = "STO";
            this.textGRPO.Location = new Point(70, 0x43);
            this.textGRPO.Margin = new Padding(3, 4, 3, 4);
            this.textGRPO.MaxLength = 10;
            this.textGRPO.Name = "textGRPO";
            this.textGRPO.Size = new Size(0x4c, 20);
            this.textGRPO.TabIndex = 3;
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0x1b, 70);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x29, 13);
            this.label21.TabIndex = 0x11;
            this.label21.Text = "GR PO";
            this.checkBerikat.AutoSize = true;
            this.checkBerikat.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.checkBerikat.Location = new Point(0xfc, 0x13);
            this.checkBerikat.Margin = new Padding(3, 4, 3, 4);
            this.checkBerikat.Name = "checkBerikat";
            this.checkBerikat.Size = new Size(0x79, 0x11);
            this.checkBerikat.TabIndex = 10;
            this.checkBerikat.Text = "Kawasan Berikat";
            this.checkBerikat.UseVisualStyleBackColor = true;
            this.tabPagePOM.BackColor = Color.WhiteSmoke;
            this.tabPagePOM.BorderStyle = BorderStyle.FixedSingle;
            this.tabPagePOM.Controls.Add(this.textQstDesc);
            this.tabPagePOM.Controls.Add(this.textQst);
            this.tabPagePOM.Controls.Add(this.labelQStandard);
            this.tabPagePOM.Controls.Add(this.textOrigin);
            this.tabPagePOM.Controls.Add(this.labelOrigin);
            this.tabPagePOM.Controls.Add(this.comboUploadType1);
            this.tabPagePOM.Controls.Add(this.label17);
            this.tabPagePOM.Controls.Add(this.labelPO1Item);
            this.tabPagePOM.Controls.Add(this.textPO1Item);
            this.tabPagePOM.Controls.Add(this.labelPO1);
            this.tabPagePOM.Controls.Add(this.textPO1);
            this.tabPagePOM.Controls.Add(this.buttonAdopt2);
            this.tabPagePOM.Controls.Add(this.checkTolling);
            this.tabPagePOM.Controls.Add(this.groupBoxFruit);
            this.tabPagePOM.Controls.Add(this.checkAgen);
            this.tabPagePOM.Controls.Add(this.label13);
            this.tabPagePOM.Controls.Add(this.textSTO1);
            this.tabPagePOM.Controls.Add(this.label58);
            this.tabPagePOM.Controls.Add(this.textSTO_Item);
            this.tabPagePOM.Controls.Add(this.label23);
            this.tabPagePOM.Controls.Add(this.textNEGO);
            this.tabPagePOM.Controls.Add(this.groupBox4);
            this.tabPagePOM.Location = new Point(4, 0x16);
            this.tabPagePOM.Margin = new Padding(3, 4, 3, 4);
            this.tabPagePOM.Name = "tabPagePOM";
            this.tabPagePOM.Padding = new Padding(3, 4, 3, 4);
            this.tabPagePOM.Size = new Size(0x287, 0x10b);
            this.tabPagePOM.TabIndex = 1;
            this.tabPagePOM.Text = "   POM   ";
            this.tabPagePOM.Click += new EventHandler(this.tabPagePOM_Click);
            this.textQstDesc.Enabled = false;
            this.textQstDesc.Location = new Point(0x1bc, 0x1f);
            this.textQstDesc.Name = "textQstDesc";
            this.textQstDesc.Size = new Size(0xc0, 20);
            this.textQstDesc.TabIndex = 30;
            this.textQstDesc.TextChanged += new EventHandler(this.textQstDesc_TextChanged);
            this.textQst.Enabled = false;
            this.textQst.Location = new Point(0x1a0, 0x1f);
            this.textQst.Name = "textQst";
            this.textQst.Size = new Size(0x19, 20);
            this.textQst.TabIndex = 0x1d;
            this.labelQStandard.AutoSize = true;
            this.labelQStandard.Location = new Point(0x15b, 0x22);
            this.labelQStandard.Name = "labelQStandard";
            this.labelQStandard.Size = new Size(0x40, 13);
            this.labelQStandard.TabIndex = 0x1c;
            this.labelQStandard.Text = "Q. Standard";
            this.textOrigin.Enabled = false;
            this.textOrigin.Location = new Point(0x1a0, 8);
            this.textOrigin.Name = "textOrigin";
            this.textOrigin.Size = new Size(220, 20);
            this.textOrigin.TabIndex = 0x1b;
            this.labelOrigin.AutoSize = true;
            this.labelOrigin.Location = new Point(0x15b, 11);
            this.labelOrigin.Name = "labelOrigin";
            this.labelOrigin.Size = new Size(0x22, 13);
            this.labelOrigin.TabIndex = 0x1a;
            this.labelOrigin.Text = "Origin";
            this.comboUploadType1.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboUploadType1.FormattingEnabled = true;
            this.comboUploadType1.Location = new Point(0x54, 9);
            this.comboUploadType1.Name = "comboUploadType1";
            this.comboUploadType1.Size = new Size(0x8d, 0x15);
            this.comboUploadType1.TabIndex = 0x19;
            this.label17.AutoSize = true;
            this.label17.Location = new Point(7, 12);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x44, 13);
            this.label17.TabIndex = 0x18;
            this.label17.Text = "Upload Type";
            this.labelPO1Item.AutoSize = true;
            this.labelPO1Item.Location = new Point(0xb5, 0x56);
            this.labelPO1Item.Name = "labelPO1Item";
            this.labelPO1Item.Size = new Size(12, 13);
            this.labelPO1Item.TabIndex = 0x17;
            this.labelPO1Item.Text = "/";
            this.textPO1Item.Location = new Point(0xc1, 0x53);
            this.textPO1Item.Margin = new Padding(3, 4, 3, 4);
            this.textPO1Item.MaxLength = 6;
            this.textPO1Item.Name = "textPO1Item";
            this.textPO1Item.Size = new Size(0x22, 20);
            this.textPO1Item.TabIndex = 0x16;
            this.labelPO1.AutoSize = true;
            this.labelPO1.Location = new Point(0x35, 0x56);
            this.labelPO1.Name = "labelPO1";
            this.labelPO1.Size = new Size(0x16, 13);
            this.labelPO1.TabIndex = 10;
            this.labelPO1.Text = "PO";
            this.textPO1.Location = new Point(0x54, 0x51);
            this.textPO1.Margin = new Padding(3, 4, 3, 4);
            this.textPO1.MaxLength = 10;
            this.textPO1.Name = "textPO1";
            this.textPO1.Size = new Size(0x60, 20);
            this.textPO1.TabIndex = 3;
            this.buttonAdopt2.Location = new Point(0xf9, 0x41);
            this.buttonAdopt2.Margin = new Padding(3, 4, 3, 4);
            this.buttonAdopt2.Name = "buttonAdopt2";
            this.buttonAdopt2.Size = new Size(0x47, 0x26);
            this.buttonAdopt2.TabIndex = 5;
            this.buttonAdopt2.Text = "&Adopt from SAP";
            this.toolTip1.SetToolTip(this.buttonAdopt2, "Adopt from SAP");
            this.buttonAdopt2.UseVisualStyleBackColor = true;
            this.buttonAdopt2.Click += new EventHandler(this.btnAdopt_Click);
            this.checkTolling.AutoSize = true;
            this.checkTolling.Location = new Point(570, 0xf2);
            this.checkTolling.Margin = new Padding(3, 4, 3, 4);
            this.checkTolling.Name = "checkTolling";
            this.checkTolling.Size = new Size(0x39, 0x11);
            this.checkTolling.TabIndex = 14;
            this.checkTolling.Text = "Tolling";
            this.checkTolling.UseVisualStyleBackColor = true;
            this.checkTolling.Visible = false;
            this.groupBoxFruit.Controls.Add(this.label26);
            this.groupBoxFruit.Controls.Add(this.label27);
            this.groupBoxFruit.Controls.Add(this.label28);
            this.groupBoxFruit.Controls.Add(this.label29);
            this.groupBoxFruit.Controls.Add(this.label30);
            this.groupBoxFruit.Controls.Add(this.label39);
            this.groupBoxFruit.Controls.Add(this.textLarge1);
            this.groupBoxFruit.Controls.Add(this.label31);
            this.groupBoxFruit.Controls.Add(this.textScout2);
            this.groupBoxFruit.Controls.Add(this.textLarge2);
            this.groupBoxFruit.Controls.Add(this.label40);
            this.groupBoxFruit.Controls.Add(this.label32);
            this.groupBoxFruit.Controls.Add(this.textMid1);
            this.groupBoxFruit.Controls.Add(this.textScout1);
            this.groupBoxFruit.Controls.Add(this.label34);
            this.groupBoxFruit.Controls.Add(this.label37);
            this.groupBoxFruit.Controls.Add(this.textMid2);
            this.groupBoxFruit.Controls.Add(this.textLoose2);
            this.groupBoxFruit.Controls.Add(this.label33);
            this.groupBoxFruit.Controls.Add(this.label38);
            this.groupBoxFruit.Controls.Add(this.textSmall1);
            this.groupBoxFruit.Controls.Add(this.textLoose1);
            this.groupBoxFruit.Controls.Add(this.label36);
            this.groupBoxFruit.Controls.Add(this.label35);
            this.groupBoxFruit.Controls.Add(this.textSmall2);
            this.groupBoxFruit.Location = new Point(0x1d, 0x75);
            this.groupBoxFruit.Margin = new Padding(3, 4, 3, 4);
            this.groupBoxFruit.Name = "groupBoxFruit";
            this.groupBoxFruit.Padding = new Padding(3, 4, 3, 4);
            this.groupBoxFruit.Size = new Size(0x106, 0x8e);
            this.groupBoxFruit.TabIndex = 6;
            this.groupBoxFruit.TabStop = false;
            this.groupBoxFruit.Text = "Fruit Types";
            this.toolTip1.SetToolTip(this.groupBoxFruit, "This Range will only\r\nbe Applied for this DO");
            this.label26.AutoSize = true;
            this.label26.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label26.Location = new Point(40, 0x19);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x27, 15);
            this.label26.TabIndex = 10;
            this.label26.Text = "Large";
            this.label27.AutoSize = true;
            this.label27.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label27.Location = new Point(0x1a, 0x2c);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x35, 15);
            this.label27.TabIndex = 11;
            this.label27.Text = "Medium";
            this.label28.AutoSize = true;
            this.label28.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label28.Location = new Point(40, 0x45);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x27, 15);
            this.label28.TabIndex = 12;
            this.label28.Text = "Small";
            this.label29.AutoSize = true;
            this.label29.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label29.Location = new Point(5, 0x5b);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x4a, 15);
            this.label29.TabIndex = 13;
            this.label29.Text = "Loose Fruits";
            this.label30.AutoSize = true;
            this.label30.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label30.Location = new Point(0x29, 0x71);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x26, 15);
            this.label30.TabIndex = 14;
            this.label30.Text = "Scout";
            this.label39.AutoSize = true;
            this.label39.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label39.Location = new Point(0xd9, 0x75);
            this.label39.Name = "label39";
            this.label39.Size = new Size(0x16, 15);
            this.label39.TabIndex = 0x18;
            this.label39.Text = "Kg";
            this.textLarge1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge1.Location = new Point(0x55, 0x16);
            this.textLarge1.Margin = new Padding(3, 4, 3, 4);
            this.textLarge1.MaxLength = 15;
            this.textLarge1.Name = "textLarge1";
            this.textLarge1.Size = new Size(0x35, 0x15);
            this.textLarge1.TabIndex = 0;
            this.textLarge1.Text = "0";
            this.textLarge1.TextAlign = HorizontalAlignment.Right;
            this.textLarge1.Leave += new EventHandler(this.textLarge1_Leave);
            this.label31.AutoSize = true;
            this.label31.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label31.Location = new Point(0x90, 0x19);
            this.label31.Name = "label31";
            this.label31.Size = new Size(11, 15);
            this.label31.TabIndex = 15;
            this.label31.Text = "-";
            this.textScout2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout2.Location = new Point(0xa1, 0x71);
            this.textScout2.Margin = new Padding(3, 4, 3, 4);
            this.textScout2.MaxLength = 15;
            this.textScout2.Name = "textScout2";
            this.textScout2.Size = new Size(0x35, 0x15);
            this.textScout2.TabIndex = 9;
            this.textScout2.Text = "0";
            this.textScout2.TextAlign = HorizontalAlignment.Right;
            this.textScout2.Leave += new EventHandler(this.textScout2_Leave);
            this.textLarge2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge2.Location = new Point(0xa1, 0x16);
            this.textLarge2.Margin = new Padding(3, 4, 3, 4);
            this.textLarge2.MaxLength = 15;
            this.textLarge2.Name = "textLarge2";
            this.textLarge2.Size = new Size(0x35, 0x15);
            this.textLarge2.TabIndex = 5;
            this.textLarge2.Text = "0";
            this.textLarge2.TextAlign = HorizontalAlignment.Right;
            this.textLarge2.Leave += new EventHandler(this.textLarge2_Leave);
            this.label40.AutoSize = true;
            this.label40.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label40.Location = new Point(0x90, 0x75);
            this.label40.Name = "label40";
            this.label40.Size = new Size(11, 15);
            this.label40.TabIndex = 0x13;
            this.label40.Text = "-";
            this.label32.AutoSize = true;
            this.label32.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label32.Location = new Point(0xd9, 0x19);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x16, 15);
            this.label32.TabIndex = 20;
            this.label32.Text = "Kg";
            this.textMid1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid1.Location = new Point(0x55, 0x2d);
            this.textMid1.Margin = new Padding(3, 4, 3, 4);
            this.textMid1.MaxLength = 15;
            this.textMid1.Name = "textMid1";
            this.textMid1.Size = new Size(0x35, 0x15);
            this.textMid1.TabIndex = 1;
            this.textMid1.Text = "0";
            this.textMid1.TextAlign = HorizontalAlignment.Right;
            this.textMid1.Leave += new EventHandler(this.textMid1_Leave);
            this.textScout1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout1.Location = new Point(0x55, 0x71);
            this.textScout1.Margin = new Padding(3, 4, 3, 4);
            this.textScout1.MaxLength = 15;
            this.textScout1.Name = "textScout1";
            this.textScout1.Size = new Size(0x35, 0x15);
            this.textScout1.TabIndex = 4;
            this.textScout1.Text = "0";
            this.textScout1.TextAlign = HorizontalAlignment.Right;
            this.textScout1.Leave += new EventHandler(this.textScout1_Leave);
            this.label34.AutoSize = true;
            this.label34.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label34.Location = new Point(0x90, 0x30);
            this.label34.Name = "label34";
            this.label34.Size = new Size(11, 15);
            this.label34.TabIndex = 0x10;
            this.label34.Text = "-";
            this.label37.AutoSize = true;
            this.label37.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label37.Location = new Point(0xd9, 0x5f);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x16, 15);
            this.label37.TabIndex = 0x17;
            this.label37.Text = "Kg";
            this.textMid2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid2.Location = new Point(0xa1, 0x2d);
            this.textMid2.Margin = new Padding(3, 4, 3, 4);
            this.textMid2.MaxLength = 15;
            this.textMid2.Name = "textMid2";
            this.textMid2.Size = new Size(0x35, 0x15);
            this.textMid2.TabIndex = 6;
            this.textMid2.Text = "0";
            this.textMid2.TextAlign = HorizontalAlignment.Right;
            this.textMid2.Leave += new EventHandler(this.textMid2_Leave);
            this.textLoose2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose2.Location = new Point(0xa1, 0x5b);
            this.textLoose2.Margin = new Padding(3, 4, 3, 4);
            this.textLoose2.MaxLength = 15;
            this.textLoose2.Name = "textLoose2";
            this.textLoose2.Size = new Size(0x35, 0x15);
            this.textLoose2.TabIndex = 8;
            this.textLoose2.Text = "0";
            this.textLoose2.TextAlign = HorizontalAlignment.Right;
            this.textLoose2.Leave += new EventHandler(this.textLoose2_Leave);
            this.label33.AutoSize = true;
            this.label33.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label33.Location = new Point(0xd9, 0x30);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x16, 15);
            this.label33.TabIndex = 0x15;
            this.label33.Text = "Kg";
            this.label38.AutoSize = true;
            this.label38.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label38.Location = new Point(0x90, 0x5f);
            this.label38.Name = "label38";
            this.label38.Size = new Size(11, 15);
            this.label38.TabIndex = 0x12;
            this.label38.Text = "-";
            this.textSmall1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall1.Location = new Point(0x55, 0x45);
            this.textSmall1.Margin = new Padding(3, 4, 3, 4);
            this.textSmall1.MaxLength = 15;
            this.textSmall1.Name = "textSmall1";
            this.textSmall1.Size = new Size(0x35, 0x15);
            this.textSmall1.TabIndex = 2;
            this.textSmall1.Text = "0";
            this.textSmall1.TextAlign = HorizontalAlignment.Right;
            this.textSmall1.Leave += new EventHandler(this.textSmall1_Leave);
            this.textLoose1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose1.Location = new Point(0x55, 0x5b);
            this.textLoose1.Margin = new Padding(3, 4, 3, 4);
            this.textLoose1.MaxLength = 15;
            this.textLoose1.Name = "textLoose1";
            this.textLoose1.Size = new Size(0x35, 0x15);
            this.textLoose1.TabIndex = 3;
            this.textLoose1.Text = "0";
            this.textLoose1.TextAlign = HorizontalAlignment.Right;
            this.textLoose1.Leave += new EventHandler(this.textLoose1_Leave);
            this.label36.AutoSize = true;
            this.label36.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label36.Location = new Point(0x90, 0x47);
            this.label36.Name = "label36";
            this.label36.Size = new Size(11, 15);
            this.label36.TabIndex = 0x11;
            this.label36.Text = "-";
            this.label35.AutoSize = true;
            this.label35.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label35.Location = new Point(0xd9, 0x47);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x16, 15);
            this.label35.TabIndex = 0x16;
            this.label35.Text = "Kg";
            this.textSmall2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall2.Location = new Point(0xa1, 0x45);
            this.textSmall2.Margin = new Padding(3, 4, 3, 4);
            this.textSmall2.MaxLength = 15;
            this.textSmall2.Name = "textSmall2";
            this.textSmall2.Size = new Size(0x35, 0x15);
            this.textSmall2.TabIndex = 7;
            this.textSmall2.Text = "0";
            this.textSmall2.TextAlign = HorizontalAlignment.Right;
            this.textSmall2.Leave += new EventHandler(this.textSmall2_Leave);
            this.checkAgen.AutoSize = true;
            this.checkAgen.Location = new Point(500, 0xf2);
            this.checkAgen.Margin = new Padding(3, 4, 3, 4);
            this.checkAgen.Name = "checkAgen";
            this.checkAgen.Size = new Size(0x33, 0x11);
            this.checkAgen.TabIndex = 13;
            this.checkAgen.Text = "Agen";
            this.checkAgen.UseVisualStyleBackColor = true;
            this.checkAgen.Visible = false;
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0x2e, 0x3d);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x1d, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "STO";
            this.textSTO1.Location = new Point(0x54, 0x39);
            this.textSTO1.Margin = new Padding(3, 4, 3, 4);
            this.textSTO1.MaxLength = 10;
            this.textSTO1.Name = "textSTO1";
            this.textSTO1.Size = new Size(0x60, 20);
            this.textSTO1.TabIndex = 1;
            this.textSTO1.TextChanged += new EventHandler(this.textSTO1_TextChanged);
            this.label58.AutoSize = true;
            this.label58.Location = new Point(0xb5, 0x3d);
            this.label58.Name = "label58";
            this.label58.Size = new Size(12, 13);
            this.label58.TabIndex = 12;
            this.label58.Text = "/";
            this.textSTO_Item.Location = new Point(0xc1, 0x39);
            this.textSTO_Item.Margin = new Padding(3, 4, 3, 4);
            this.textSTO_Item.MaxLength = 2;
            this.textSTO_Item.Name = "textSTO_Item";
            this.textSTO_Item.Size = new Size(0x22, 20);
            this.textSTO_Item.TabIndex = 2;
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x25, 0x25);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x26, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "NEGO";
            this.textNEGO.Location = new Point(0x54, 0x22);
            this.textNEGO.Margin = new Padding(3, 4, 3, 4);
            this.textNEGO.MaxLength = 10;
            this.textNEGO.Name = "textNEGO";
            this.textNEGO.Size = new Size(0x60, 20);
            this.textNEGO.TabIndex = 1;
            this.textNEGO.TextChanged += new EventHandler(this.textNEGO_TextChanged);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.radioRamp);
            this.groupBox4.Controls.Add(this.radioKebAgen);
            this.groupBox4.Controls.Add(this.radioAgen);
            this.groupBox4.Controls.Add(this.radioOthers);
            this.groupBox4.Controls.Add(this.radioGroupEstate);
            this.groupBox4.Controls.Add(this.radioOtherGroup);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupBox4.ForeColor = SystemColors.ControlText;
            this.groupBox4.ImeMode = ImeMode.Off;
            this.groupBox4.Location = new Point(360, 0x44);
            this.groupBox4.Margin = new Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new Padding(3, 4, 3, 4);
            this.groupBox4.Size = new Size(0x107, 0xa6);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "[ From Estate ]";
            this.label44.AutoSize = true;
            this.label44.Location = new Point(0x13, 0x7d);
            this.label44.Name = "label44";
            this.label44.Size = new Size(40, 13);
            this.label44.TabIndex = 8;
            this.label44.Text = "Type 3";
            this.label42.AutoSize = true;
            this.label42.Location = new Point(0x13, 0x52);
            this.label42.Name = "label42";
            this.label42.Size = new Size(40, 13);
            this.label42.TabIndex = 7;
            this.label42.Text = "Type 2";
            this.radioRamp.AutoSize = true;
            this.radioRamp.Location = new Point(0x16, 0x8e);
            this.radioRamp.Margin = new Padding(3, 4, 3, 4);
            this.radioRamp.Name = "radioRamp";
            this.radioRamp.Size = new Size(0x35, 0x11);
            this.radioRamp.TabIndex = 5;
            this.radioRamp.TabStop = true;
            this.radioRamp.Text = "Ramp";
            this.radioRamp.UseVisualStyleBackColor = true;
            this.radioKebAgen.AutoSize = true;
            this.radioKebAgen.Location = new Point(0x7d, 0x36);
            this.radioKebAgen.Margin = new Padding(3, 4, 3, 4);
            this.radioKebAgen.Name = "radioKebAgen";
            this.radioKebAgen.Size = new Size(0x60, 0x11);
            this.radioKebAgen.TabIndex = 2;
            this.radioKebAgen.TabStop = true;
            this.radioKebAgen.Text = "Pekebun Agen";
            this.radioKebAgen.UseVisualStyleBackColor = true;
            this.radioAgen.AutoSize = true;
            this.radioAgen.Location = new Point(0x16, 0x36);
            this.radioAgen.Margin = new Padding(3, 4, 3, 4);
            this.radioAgen.Name = "radioAgen";
            this.radioAgen.Size = new Size(50, 0x11);
            this.radioAgen.TabIndex = 1;
            this.radioAgen.TabStop = true;
            this.radioAgen.Text = "Agen";
            this.radioAgen.UseVisualStyleBackColor = true;
            this.radioOthers.AutoSize = true;
            this.radioOthers.Location = new Point(0x7d, 0x24);
            this.radioOthers.Margin = new Padding(3, 4, 3, 4);
            this.radioOthers.Name = "radioOthers";
            this.radioOthers.Size = new Size(0x44, 0x11);
            this.radioOthers.TabIndex = 4;
            this.radioOthers.Text = "Pekebun";
            this.radioOthers.UseVisualStyleBackColor = true;
            this.radioGroupEstate.AutoSize = true;
            this.radioGroupEstate.Checked = true;
            this.radioGroupEstate.Location = new Point(0x16, 0x63);
            this.radioGroupEstate.Margin = new Padding(3, 4, 3, 4);
            this.radioGroupEstate.Name = "radioGroupEstate";
            this.radioGroupEstate.Size = new Size(0x57, 0x11);
            this.radioGroupEstate.TabIndex = 0;
            this.radioGroupEstate.TabStop = true;
            this.radioGroupEstate.Text = "Group Estate";
            this.radioGroupEstate.UseVisualStyleBackColor = true;
            this.radioOtherGroup.AutoSize = true;
            this.radioOtherGroup.Location = new Point(0x16, 0x24);
            this.radioOtherGroup.Margin = new Padding(3, 4, 3, 4);
            this.radioOtherGroup.Name = "radioOtherGroup";
            this.radioOtherGroup.Size = new Size(0x53, 0x11);
            this.radioOtherGroup.TabIndex = 3;
            this.radioOtherGroup.Text = "Other Group";
            this.radioOtherGroup.UseVisualStyleBackColor = true;
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x13, 0x13);
            this.label19.Name = "label19";
            this.label19.Size = new Size(40, 13);
            this.label19.TabIndex = 6;
            this.label19.Text = "Type 1";
            this.tabPage3.BackColor = Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.groupBoxConversion);
            this.tabPage3.Location = new Point(4, 0x16);
            this.tabPage3.Margin = new Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new Padding(3, 4, 3, 4);
            this.tabPage3.Size = new Size(0x287, 0x10b);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "   Additional Control   ";
            this.groupBoxConversion.Controls.Add(this.labelConvValue);
            this.groupBoxConversion.Controls.Add(this.textConvValue);
            this.groupBoxConversion.Controls.Add(this.label50);
            this.groupBoxConversion.Controls.Add(this.textConvUnit);
            this.groupBoxConversion.Controls.Add(this.label51);
            this.groupBoxConversion.Location = new Point(0x10, 0x19);
            this.groupBoxConversion.Margin = new Padding(3, 4, 3, 4);
            this.groupBoxConversion.Name = "groupBoxConversion";
            this.groupBoxConversion.Padding = new Padding(3, 4, 3, 4);
            this.groupBoxConversion.Size = new Size(0x19f, 0x4c);
            this.groupBoxConversion.TabIndex = 0;
            this.groupBoxConversion.TabStop = false;
            this.groupBoxConversion.Text = "[ Do Conversion ]";
            this.labelConvValue.AutoSize = true;
            this.labelConvValue.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelConvValue.Location = new Point(0xd9, 0x30);
            this.labelConvValue.Name = "labelConvValue";
            this.labelConvValue.Size = new Size(0xbb, 13);
            this.labelConvValue.TabIndex = 4;
            this.labelConvValue.Text = "( in Kg ),  1 \"Convertion Unit\" = xxx Kg";
            this.textConvValue.Location = new Point(0x65, 0x2c);
            this.textConvValue.Margin = new Padding(3, 4, 3, 4);
            this.textConvValue.Name = "textConvValue";
            this.textConvValue.Size = new Size(110, 20);
            this.textConvValue.TabIndex = 1;
            this.textConvValue.Text = "0";
            this.textConvValue.TextAlign = HorizontalAlignment.Right;
            this.label50.AutoSize = true;
            this.label50.Location = new Point(7, 0x30);
            this.label50.Name = "label50";
            this.label50.Size = new Size(0x58, 13);
            this.label50.TabIndex = 2;
            this.label50.Text = "Convertion Value";
            this.textConvUnit.Location = new Point(0x65, 0x11);
            this.textConvUnit.Margin = new Padding(3, 4, 3, 4);
            this.textConvUnit.MaxLength = 20;
            this.textConvUnit.Name = "textConvUnit";
            this.textConvUnit.Size = new Size(110, 20);
            this.textConvUnit.TabIndex = 0;
            this.textConvUnit.TextChanged += new EventHandler(this.textConvUnit_TextChanged);
            this.label51.AutoSize = true;
            this.label51.Location = new Point(12, 0x15);
            this.label51.Name = "label51";
            this.label51.Size = new Size(0x53, 13);
            this.label51.TabIndex = 3;
            this.label51.Text = "Convertion Unit ";
            this.tabPageOpening.BackColor = Color.WhiteSmoke;
            this.tabPageOpening.Controls.Add(this.groupBoxEntry);
            this.tabPageOpening.Location = new Point(4, 0x16);
            this.tabPageOpening.Margin = new Padding(3, 4, 3, 4);
            this.tabPageOpening.Name = "tabPageOpening";
            this.tabPageOpening.Padding = new Padding(3, 4, 3, 4);
            this.tabPageOpening.Size = new Size(0x287, 0x10b);
            this.tabPageOpening.TabIndex = 3;
            this.tabPageOpening.Text = "Opening";
            this.groupBoxEntry.Controls.Add(this.textOpnEntryFactory);
            this.groupBoxEntry.Controls.Add(this.label43);
            this.groupBoxEntry.Controls.Add(this.textOpnEntryEstate);
            this.groupBoxEntry.Controls.Add(this.label3rdOpening);
            this.groupBoxEntry.Controls.Add(this.labelFactoryOpening);
            this.groupBoxEntry.Controls.Add(this.labelKG3rd);
            this.groupBoxEntry.Location = new Point(0x18, 0x18);
            this.groupBoxEntry.Margin = new Padding(3, 4, 3, 4);
            this.groupBoxEntry.Name = "groupBoxEntry";
            this.groupBoxEntry.Padding = new Padding(3, 4, 3, 4);
            this.groupBoxEntry.Size = new Size(200, 0x4d);
            this.groupBoxEntry.TabIndex = 0;
            this.groupBoxEntry.TabStop = false;
            this.groupBoxEntry.Text = "Opening Entry";
            this.toolTip1.SetToolTip(this.groupBoxEntry, "Opening Entry for this DO");
            this.groupBoxEntry.UseCompatibleTextRendering = true;
            this.textOpnEntryFactory.Location = new Point(0x3b, 0x2d);
            this.textOpnEntryFactory.Margin = new Padding(3, 4, 3, 4);
            this.textOpnEntryFactory.MaxLength = 20;
            this.textOpnEntryFactory.Name = "textOpnEntryFactory";
            this.textOpnEntryFactory.Size = new Size(0x63, 20);
            this.textOpnEntryFactory.TabIndex = 1;
            this.textOpnEntryFactory.Text = "0";
            this.textOpnEntryFactory.TextAlign = HorizontalAlignment.Right;
            this.textOpnEntryFactory.Leave += new EventHandler(this.textOpnEntryFactory_Leave_1);
            this.label43.AutoSize = true;
            this.label43.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label43.Location = new Point(0xa4, 0x30);
            this.label43.Name = "label43";
            this.label43.Size = new Size(0x16, 15);
            this.label43.TabIndex = 5;
            this.label43.Text = "Kg";
            this.textOpnEntryEstate.Location = new Point(0x3b, 0x15);
            this.textOpnEntryEstate.Margin = new Padding(3, 4, 3, 4);
            this.textOpnEntryEstate.MaxLength = 20;
            this.textOpnEntryEstate.Name = "textOpnEntryEstate";
            this.textOpnEntryEstate.Size = new Size(0x63, 20);
            this.textOpnEntryEstate.TabIndex = 0;
            this.textOpnEntryEstate.Text = "0";
            this.textOpnEntryEstate.TextAlign = HorizontalAlignment.Right;
            this.textOpnEntryEstate.Leave += new EventHandler(this.textOpnEntryEstate_Leave_1);
            this.label3rdOpening.AutoSize = true;
            this.label3rdOpening.Location = new Point(6, 0x19);
            this.label3rdOpening.Name = "label3rdOpening";
            this.label3rdOpening.Size = new Size(0x31, 13);
            this.label3rdOpening.TabIndex = 3;
            this.label3rdOpening.Text = "3rd Party";
            this.labelFactoryOpening.AutoSize = true;
            this.labelFactoryOpening.Location = new Point(13, 0x30);
            this.labelFactoryOpening.Name = "labelFactoryOpening";
            this.labelFactoryOpening.Size = new Size(0x2a, 13);
            this.labelFactoryOpening.TabIndex = 2;
            this.labelFactoryOpening.Text = "Factory";
            this.labelKG3rd.AutoSize = true;
            this.labelKG3rd.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelKG3rd.Location = new Point(0xa4, 0x18);
            this.labelKG3rd.Name = "labelKG3rd";
            this.labelKG3rd.Size = new Size(0x16, 15);
            this.labelKG3rd.TabIndex = 4;
            this.labelKG3rd.Text = "Kg";
            this.btnEstate.Location = new Point(0x102, 0xa8);
            this.btnEstate.Margin = new Padding(0);
            this.btnEstate.Name = "btnEstate";
            this.btnEstate.Size = new Size(0x17, 0x16);
            this.btnEstate.TabIndex = 0x27;
            this.btnEstate.Text = "...";
            this.toolTip1.SetToolTip(this.btnEstate, "Browse Estate");
            this.btnEstate.UseVisualStyleBackColor = true;
            this.btnEstate.Click += new EventHandler(this.btnEstate_Click);
            this.labelEstateADM.AutoSize = true;
            this.labelEstateADM.Location = new Point(0x11f, 0xad);
            this.labelEstateADM.Name = "labelEstateADM";
            this.labelEstateADM.Size = new Size(0x41, 13);
            this.labelEstateADM.TabIndex = 40;
            this.labelEstateADM.Text = "EstateName";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x255, 0xb6);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x30, 13);
            this.label15.TabIndex = 0x2a;
            this.label15.Text = "Incoterm";
            this.textVessel.Location = new Point(0x76, 0xe1);
            this.textVessel.Margin = new Padding(3, 4, 3, 4);
            this.textVessel.MaxLength = 20;
            this.textVessel.Name = "textVessel";
            this.textVessel.Size = new Size(0x84, 20);
            this.textVessel.TabIndex = 11;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x49, 0xe4);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x26, 13);
            this.label14.TabIndex = 0x1b;
            this.label14.Text = "Vessel";
            this.label14.Click += new EventHandler(this.label14_Click);
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0x4b, 0xad);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x25, 13);
            this.label12.TabIndex = 0x1a;
            this.label12.Text = "Estate";
            this.checkISCC.AutoSize = true;
            this.checkISCC.Location = new Point(0x1d3, 0x3d);
            this.checkISCC.Margin = new Padding(3, 4, 3, 4);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x5b, 0x11);
            this.checkISCC.TabIndex = 0x29;
            this.checkISCC.Text = "ISCC-Certified";
            this.toolTip1.SetToolTip(this.checkISCC, "Indicator for ISCC Certified");
            this.checkISCC.UseVisualStyleBackColor = true;
            this.label25.AutoSize = true;
            this.label25.Location = new Point(0x43, 0xfe);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x2c, 13);
            this.label25.TabIndex = 0x1c;
            this.label25.Text = "Remark";
            this.textRemark.Location = new Point(0x76, 0xfb);
            this.textRemark.Margin = new Padding(3, 4, 3, 4);
            this.textRemark.MaxLength = 100;
            this.textRemark.Multiline = true;
            this.textRemark.Name = "textRemark";
            this.textRemark.Size = new Size(0x179, 0x26);
            this.textRemark.TabIndex = 12;
            this.toolTip1.SetToolTip(this.textRemark, "This Remark will Show in\r\ntransaction remark for ticket\r\n*editable");
            this.textRemark.TextChanged += new EventHandler(this.textRemark_TextChanged);
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x2d1, 0x1d0);
            this.buttonSave.Margin = new Padding(3, 4, 3, 4);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x86, 0x2e);
            this.buttonSave.TabIndex = 0x12;
            this.buttonSave.Text = "&Save";
            this.toolTip1.SetToolTip(this.buttonSave, "Save this DO");
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(0x2d1, 0x211);
            this.buttonCancel.Margin = new Padding(3, 4, 3, 4);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x86, 0x2e);
            this.buttonCancel.TabIndex = 0x13;
            this.buttonCancel.Text = "&Cancel";
            this.toolTip1.SetToolTip(this.buttonCancel, "Cancel");
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.button2_Click);
            this.label45.AutoSize = true;
            this.label45.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label45.Location = new Point(0x2f4, 0xd9);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x16, 15);
            this.label45.TabIndex = 0x2e;
            this.label45.Text = "Kg";
            this.label46.AutoSize = true;
            this.label46.Location = new Point(0x33, 0x93);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x3d, 13);
            this.label46.TabIndex = 0x19;
            this.label46.Text = "Transporter";
            this.textTransporter.Location = new Point(0x77, 0x8e);
            this.textTransporter.Margin = new Padding(3, 4, 3, 4);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x83, 20);
            this.textTransporter.TabIndex = 9;
            this.textTransporter.TextChanged += new EventHandler(this.textTransporter_TextChanged);
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.textType.CharacterCasing = CharacterCasing.Upper;
            this.textType.Location = new Point(0x77, 7);
            this.textType.Margin = new Padding(3, 4, 3, 4);
            this.textType.MaxLength = 20;
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x41, 20);
            this.textType.TabIndex = 0;
            this.textType.TextChanged += new EventHandler(this.textType_TextChanged);
            this.textType.KeyPress += new KeyPressEventHandler(this.textType_KeyPress_1);
            this.textType.Leave += new EventHandler(this.textType_Leave_1);
            this.buttonType.Location = new Point(0xbd, 6);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x17, 0x16);
            this.buttonType.TabIndex = 0x1d;
            this.buttonType.Text = "...";
            this.toolTip1.SetToolTip(this.buttonType, "Browse Transaction Type");
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonType.Click += new EventHandler(this.button13_Click);
            this.textCommodity.Location = new Point(0x77, 0x57);
            this.textCommodity.Margin = new Padding(3, 4, 3, 4);
            this.textCommodity.MaxLength = 20;
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0x83, 20);
            this.textCommodity.TabIndex = 7;
            this.textCommodity.TextChanged += new EventHandler(this.textCommodity_TextChanged_1);
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress_1);
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.button1.Location = new Point(0x102, 0x57);
            this.button1.Margin = new Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x17, 0x16);
            this.button1.TabIndex = 0x21;
            this.button1.Text = "...";
            this.toolTip1.SetToolTip(this.button1, "Browse Commodity");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click_1);
            this.textVend.Location = new Point(0x77, 0x73);
            this.textVend.Margin = new Padding(3, 4, 3, 4);
            this.textVend.MaxLength = 20;
            this.textVend.Name = "textVend";
            this.textVend.Size = new Size(0x83, 20);
            this.textVend.TabIndex = 8;
            this.textVend.TextChanged += new EventHandler(this.textVend_TextChanged);
            this.textVend.KeyPress += new KeyPressEventHandler(this.textVend_KeyPress);
            this.textVend.Leave += new EventHandler(this.textVend_Leave);
            this.button2.Location = new Point(0x102, 0x71);
            this.button2.Margin = new Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x17, 0x16);
            this.button2.TabIndex = 0x23;
            this.button2.Text = "...";
            this.toolTip1.SetToolTip(this.button2, "Browse Vendor/Supplier");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click_1);
            this.button3.Location = new Point(0x102, 0x8d);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x16);
            this.button3.TabIndex = 0x25;
            this.button3.Text = "...";
            this.toolTip1.SetToolTip(this.button3, "Browse Transporter");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.TransporterName.AutoSize = true;
            this.TransporterName.Location = new Point(0x11f, 0x93);
            this.TransporterName.Name = "TransporterName";
            this.TransporterName.Size = new Size(0x59, 13);
            this.TransporterName.TabIndex = 0x26;
            this.TransporterName.Text = "TransporterName";
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Location = new Point(0xd8, 11);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(60, 13);
            this.labelTransTypeName.TabIndex = 30;
            this.labelTransTypeName.Text = "Description";
            this.label49.AutoSize = true;
            this.label49.Location = new Point(590, 0xf6);
            this.label49.Name = "label49";
            this.label49.Size = new Size(0x37, 13);
            this.label49.TabIndex = 0x2c;
            this.label49.Text = "Tolerance";
            this.textTolerance.Location = new Point(0x28b, 0xf2);
            this.textTolerance.Margin = new Padding(3, 4, 3, 4);
            this.textTolerance.MaxLength = 5;
            this.textTolerance.Name = "textTolerance";
            this.textTolerance.Size = new Size(0x2c, 20);
            this.textTolerance.TabIndex = 0x10;
            this.textTolerance.Text = "0";
            this.textTolerance.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textTolerance, "Over Quantity Tolerance");
            this.textTolerance.Leave += new EventHandler(this.textTolerance_Leave);
            this.label53.AutoSize = true;
            this.label53.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label53.Location = new Point(0x2bd, 0xf5);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0x12, 15);
            this.label53.TabIndex = 0x2d;
            this.label53.Text = "%";
            this.textQuantity.Location = new Point(0x28b, 0xd9);
            this.textQuantity.Margin = new Padding(3, 4, 3, 4);
            this.textQuantity.MaxLength = 20;
            this.textQuantity.Name = "textQuantity";
            this.textQuantity.Size = new Size(0x63, 20);
            this.textQuantity.TabIndex = 14;
            this.textQuantity.Text = "0";
            this.textQuantity.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textQuantity, "Quantity");
            this.textQuantity.Leave += new EventHandler(this.textQuantity_Leave);
            this.dateDO_period.Format = DateTimePickerFormat.Short;
            this.dateDO_period.Location = new Point(0x233, 0x23);
            this.dateDO_period.Margin = new Padding(3, 4, 3, 4);
            this.dateDO_period.Name = "dateDO_period";
            this.dateDO_period.Size = new Size(0x56, 20);
            this.dateDO_period.TabIndex = 4;
            this.toolTip1.SetToolTip(this.dateDO_period, "DO date Period");
            this.dateDO_period.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.checkPeriod.AutoSize = true;
            this.checkPeriod.Location = new Point(0x1d3, 0x25);
            this.checkPeriod.Margin = new Padding(3, 4, 3, 4);
            this.checkPeriod.Name = "checkPeriod";
            this.checkPeriod.Size = new Size(90, 0x11);
            this.checkPeriod.TabIndex = 3;
            this.checkPeriod.Text = "Check Period";
            this.toolTip1.SetToolTip(this.checkPeriod, "If Checked system will show warning if Contract is over period in transaction");
            this.checkPeriod.UseVisualStyleBackColor = true;
            this.checkPeriod.CheckedChanged += new EventHandler(this.checkPeriod_CheckedChanged);
            this.textEstate.Location = new Point(0x77, 0xa9);
            this.textEstate.Margin = new Padding(3, 4, 3, 4);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0x83, 20);
            this.textEstate.TabIndex = 10;
            this.textEstate.TextChanged += new EventHandler(this.textEstate_TextChanged);
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.groupBoxDeducted.Controls.Add(this.radioSeller);
            this.groupBoxDeducted.Controls.Add(this.radioBuyer);
            this.groupBoxDeducted.Location = new Point(0x28b, 0x70);
            this.groupBoxDeducted.Margin = new Padding(3, 4, 3, 4);
            this.groupBoxDeducted.Name = "groupBoxDeducted";
            this.groupBoxDeducted.Padding = new Padding(3, 4, 3, 4);
            this.groupBoxDeducted.Size = new Size(0xbb, 0x34);
            this.groupBoxDeducted.TabIndex = 9;
            this.groupBoxDeducted.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBoxDeducted, "Deduction method for Quantity\r\nBuyer Quantity = Factory Quantity\r\nSeller Quantity = 3rd Party / Estate Quantity");
            this.radioSeller.AutoSize = true;
            this.radioSeller.Location = new Point(0x67, 0x16);
            this.radioSeller.Margin = new Padding(3, 4, 3, 4);
            this.radioSeller.Name = "radioSeller";
            this.radioSeller.Size = new Size(70, 0x11);
            this.radioSeller.TabIndex = 1;
            this.radioSeller.TabStop = true;
            this.radioSeller.Text = "Other Qty";
            this.radioSeller.UseVisualStyleBackColor = true;
            this.radioBuyer.AutoSize = true;
            this.radioBuyer.Checked = true;
            this.radioBuyer.Location = new Point(13, 0x16);
            this.radioBuyer.Margin = new Padding(3, 4, 3, 4);
            this.radioBuyer.Name = "radioBuyer";
            this.radioBuyer.Size = new Size(0x4f, 0x11);
            this.radioBuyer.TabIndex = 0;
            this.radioBuyer.TabStop = true;
            this.radioBuyer.Text = "Factory Qty";
            this.radioBuyer.UseVisualStyleBackColor = true;
            this.textBoxOS.Location = new Point(0x18, 7);
            this.textBoxOS.Margin = new Padding(3, 4, 3, 4);
            this.textBoxOS.MaxLength = 20;
            this.textBoxOS.Name = "textBoxOS";
            this.textBoxOS.ReadOnly = true;
            this.textBoxOS.Size = new Size(0x63, 20);
            this.textBoxOS.TabIndex = 0x44;
            this.textBoxOS.Text = "0";
            this.textBoxOS.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxOS, "Quantity");
            this.btn_mill.Location = new Point(0x1d8, 0xc3);
            this.btn_mill.Margin = new Padding(0);
            this.btn_mill.Name = "btn_mill";
            this.btn_mill.Size = new Size(0x17, 0x16);
            this.btn_mill.TabIndex = 0x49;
            this.btn_mill.Text = "...";
            this.toolTip1.SetToolTip(this.btn_mill, "Browse Estate");
            this.btn_mill.UseVisualStyleBackColor = true;
            this.btn_mill.Click += new EventHandler(this.btn_mill_Click);
            this.label18.AutoSize = true;
            this.label18.Location = new Point(0x240, 0x88);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x45, 13);
            this.label18.TabIndex = 0x2f;
            this.label18.Text = "Deducted By";
            this.labelQualityInfo.AutoSize = true;
            this.labelQualityInfo.Location = new Point(0x2bd, 310);
            this.labelQualityInfo.Name = "labelQualityInfo";
            this.labelQualityInfo.Size = new Size(0x52, 13);
            this.labelQualityInfo.TabIndex = 0x30;
            this.labelQualityInfo.Text = "Contract Quality";
            this.textQualityInfo.Enabled = false;
            this.textQualityInfo.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textQualityInfo.Location = new Point(0x2bf, 0x146);
            this.textQualityInfo.Margin = new Padding(3, 4, 3, 4);
            this.textQualityInfo.Name = "textQualityInfo";
            this.textQualityInfo.Size = new Size(0xbf, 0x58);
            this.textQualityInfo.TabIndex = 0x31;
            this.textQualityInfo.Text = "";
            this.textToken.BackColor = SystemColors.Control;
            this.textToken.BorderStyle = BorderStyle.None;
            this.textToken.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textToken.Location = new Point(0x25a, 9);
            this.textToken.Name = "textToken";
            this.textToken.Size = new Size(0x125, 0x13);
            this.textToken.TabIndex = 0x34;
            this.textToken.Text = " Token No.";
            this.textToken.TextAlign = HorizontalAlignment.Right;
            this.textToken.Visible = false;
            this.labelIncotermCode.AutoSize = true;
            this.labelIncotermCode.Location = new Point(0x2f4, 0xb6);
            this.labelIncotermCode.Name = "labelIncotermCode";
            this.labelIncotermCode.Size = new Size(0x5f, 13);
            this.labelIncotermCode.TabIndex = 0x42;
            this.labelIncotermCode.Text = "labelIncotermCode";
            this.comboIncoterm.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboIncoterm.FormattingEnabled = true;
            this.comboIncoterm.Location = new Point(0x28b, 0xb3);
            this.comboIncoterm.Name = "comboIncoterm";
            this.comboIncoterm.Size = new Size(0x63, 0x15);
            this.comboIncoterm.TabIndex = 0x41;
            this.comboIncoterm.SelectedIndexChanged += new EventHandler(this.comboIncoterm_SelectedIndexChanged);
            this.comboIncoterm.Leave += new EventHandler(this.comboIncoterm_Leave);
            this.buttonCheckOS.Location = new Point(0x9d, 4);
            this.buttonCheckOS.Name = "buttonCheckOS";
            this.buttonCheckOS.Size = new Size(0x4b, 0x17);
            this.buttonCheckOS.TabIndex = 0x43;
            this.buttonCheckOS.Text = "Check OS";
            this.buttonCheckOS.UseVisualStyleBackColor = true;
            this.buttonCheckOS.Click += new EventHandler(this.buttonCheckOS_Click);
            this.label11.AutoSize = true;
            this.label11.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label11.Location = new Point(0x81, 8);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x16, 15);
            this.label11.TabIndex = 0x45;
            this.label11.Text = "Kg";
            this.panelCheckOS.Controls.Add(this.buttonCheckOS);
            this.panelCheckOS.Controls.Add(this.label11);
            this.panelCheckOS.Controls.Add(this.textBoxOS);
            this.panelCheckOS.Location = new Point(0x242, 0x41);
            this.panelCheckOS.Name = "panelCheckOS";
            this.panelCheckOS.Size = new Size(260, 0x2c);
            this.panelCheckOS.TabIndex = 70;
            this.txt_mill.Enabled = false;
            this.txt_mill.Location = new Point(0x77, 0xc5);
            this.txt_mill.Margin = new Padding(3, 4, 3, 4);
            this.txt_mill.MaxLength = 40;
            this.txt_mill.Name = "txt_mill";
            this.txt_mill.Size = new Size(0x159, 20);
            this.txt_mill.TabIndex = 0x47;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x59, 200);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x16, 13);
            this.label6.TabIndex = 0x48;
            this.label6.Text = "Mill";
            this.cb_langsir_type.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cb_langsir_type.FormattingEnabled = true;
            this.cb_langsir_type.Location = new Point(290, 0xe1);
            this.cb_langsir_type.Name = "cb_langsir_type";
            this.cb_langsir_type.Size = new Size(0x48, 0x15);
            this.cb_langsir_type.TabIndex = 0x3d;
            this.cb_langsir_type.SelectedIndexChanged += new EventHandler(this.cb_langsir_type_SelectedIndexChanged);
            this.cb_langsir_type.Leave += new EventHandler(this.cb_langsir_type_Leave);
            this.label16.AutoSize = true;
            this.label16.Location = new Point(0xfd, 0xe4);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x1f, 13);
            this.label16.TabIndex = 0x3e;
            this.label16.Text = "Type";
            this.label_langsir_desc.AutoSize = true;
            this.label_langsir_desc.Location = new Point(0x16d, 0xe4);
            this.label_langsir_desc.Name = "label_langsir_desc";
            this.label_langsir_desc.Size = new Size(60, 13);
            this.label_langsir_desc.TabIndex = 0x4a;
            this.label_langsir_desc.Text = "Description";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = SystemColors.Control;
            base.ClientSize = new Size(0x38b, 0x265);
            base.ControlBox = false;
            base.Controls.Add(this.label_langsir_desc);
            base.Controls.Add(this.label16);
            base.Controls.Add(this.btn_mill);
            base.Controls.Add(this.cb_langsir_type);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.txt_mill);
            base.Controls.Add(this.panelCheckOS);
            base.Controls.Add(this.labelIncotermCode);
            base.Controls.Add(this.comboIncoterm);
            base.Controls.Add(this.textToken);
            base.Controls.Add(this.textQualityInfo);
            base.Controls.Add(this.labelQualityInfo);
            base.Controls.Add(this.label18);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.groupBoxDeducted);
            base.Controls.Add(this.dateDO_period);
            base.Controls.Add(this.dateTimeContract);
            base.Controls.Add(this.btnEstate);
            base.Controls.Add(this.checkPeriod);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.checkISCC);
            base.Controls.Add(this.textContract);
            base.Controls.Add(this.labelEstateADM);
            base.Controls.Add(this.checkQuantity);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textVessel);
            base.Controls.Add(this.textQuantity);
            base.Controls.Add(this.dateTimeDO);
            base.Controls.Add(this.label14);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label45);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.label15);
            base.Controls.Add(this.label53);
            base.Controls.Add(this.textTolerance);
            base.Controls.Add(this.label49);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.TransporterName);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.textVend);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.buttonType);
            base.Controls.Add(this.textType);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.label46);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textRemark);
            base.Controls.Add(this.label25);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.CommodityName);
            base.Controls.Add(this.relationName);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Margin = new Padding(3, 4, 3, 4);
            base.Name = "FormContractEntryMsia";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Form Contract Entry";
            base.Load += new EventHandler(this.FormContractEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContractEntry_KeyPress);
            this.tabControl1.ResumeLayout(false);
            this.tabPageRef.ResumeLayout(false);
            this.tabPageRef.PerformLayout();
            this.panelLangsir.ResumeLayout(false);
            this.panelLangsir.PerformLayout();
            this.panel_TP.ResumeLayout(false);
            this.panel_TP.PerformLayout();
            this.tabPagePOM.ResumeLayout(false);
            this.tabPagePOM.PerformLayout();
            this.groupBoxFruit.ResumeLayout(false);
            this.groupBoxFruit.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBoxConversion.ResumeLayout(false);
            this.groupBoxConversion.PerformLayout();
            this.tabPageOpening.ResumeLayout(false);
            this.groupBoxEntry.ResumeLayout(false);
            this.groupBoxEntry.PerformLayout();
            this.groupBoxDeducted.ResumeLayout(false);
            this.groupBoxDeducted.PerformLayout();
            this.panelCheckOS.ResumeLayout(false);
            this.panelCheckOS.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void InitTable()
        {
            this.tblIncoterm.OpenTable("wb_incoterm", "Select * from wb_incoterm", WBData.conn);
            this.tblDeductedBy.OpenTable("wb_deductedBy", "Select * from wb_deductedBy", WBData.conn);
            this.tblContract_log.OpenTable("wb_contract_log", "Select * from wb_Contract_log where " + WBData.CompanyLocation(" and 1=2"), WBData.conn);
            this.tblIscc.OpenTable("wb_iscc", "Select * from wb_iscc WHERE 1 = 1", WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            this.tblRelation.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            Program.AutoComp(this.tblTransType, "Transaction_Code", this.textType);
            Program.AutoComp(this.tblComm, "Comm_Code", this.textCommodity);
            Program.AutoComp(this.tblRelation, "Relation_code", this.textVend);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblEstate, "Estate_Code", this.textEstate);
            if (WBSetting.locType == "0")
            {
                this.tblRefCode.OpenTable("wb_RefCode", "Select * from wb_refCode where 1=1", WBData.conn);
                this.tblLocation_timbun.OpenTable("wb_Location_timbun", "Select * from wb_Location_timbun where 1=1", WBData.conn);
                Program.AutoCompCombo(this.tblRefCode, "RefCode", this.comboRefCode);
                Program.AutoComp(this.tblLocation_timbun, "timbun_code", this.textTimbunCoy);
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {
        }

        private void process1_Exited(object sender, EventArgs e)
        {
        }

        private void radioLangsirNone_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioLangsirTtb.Checked)
            {
                this.textTimbunCoy.Visible = true;
                this.buttonLocation.Visible = true;
            }
            else
            {
                this.textTimbunCoy.Visible = false;
                this.buttonLocation.Visible = false;
                this.comboIncoterm.Enabled = true;
            }
        }

        private void radioLangsirTransfer_CheckedChanged(object sender, EventArgs e)
        {
            this.change_langsir_type();
        }

        private void radioLangsirTtb_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioLangsirTtb.Checked)
            {
                this.textTimbunCoy.Visible = true;
                this.buttonLocation.Visible = true;
                this.textTimbunCoy.Focus();
            }
            else
            {
                this.textTimbunCoy.Clear();
                this.textTimbunCoy.Visible = false;
                this.buttonLocation.Visible = false;
                this.buttonPreview.Visible = false;
            }
        }

        private void savedTimbun()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_Contract1", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + this.textDO.Text.Trim() + "T' and zAuto = 'Y'"), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                table2.DR = table2.DT.Rows[0];
                table2.DR.Delete();
                table2.Save();
            }
            if (this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "NONE"))
            {
                table.OpenTable("wb_contract", "Select * From wb_contract where  " + WBData.CompanyLocation(" and DO_NO = '" + this.textDO.Text.Trim() + "' and tolling = '6'"), WBData.conn);
                table2.OpenTable("wb_Contract1", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + this.textDO.Text.Trim() + "T' and zAuto = 'Y'"), WBData.conn);
                table2.DR = table2.DT.NewRow();
                foreach (DataColumn column in table2.DT.Columns)
                {
                    if (column.ColumnName.ToUpper() != "UNIQ")
                    {
                        table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                    }
                }
                if (WBSetting.locType == "0")
                {
                    if (this.fTimbun.radioLangsirNone.Checked)
                    {
                        table2.DR["Tolling"] = "1";
                    }
                    else if (this.fTimbun.radioLangsirTtb.Checked)
                    {
                        table2.DR["Tolling"] = "6";
                    }
                    else if (this.fTimbun.radioLangsirTransfer.Checked)
                    {
                        table2.DR["Tolling"] = "5";
                    }
                    else if (this.fTimbun.radioLangsir.Checked)
                    {
                        table2.DR["Tolling"] = "7";
                    }
                    else if (this.fTimbun.radioLangsir2.Checked)
                    {
                        table2.DR["Tolling"] = "2";
                    }
                }
                table2.DR["DO_NO"] = table2.DR["DO_NO"].ToString() + "T";
                table2.DR["Relation_Code"] = this.fTimbun.textVend.Text;
                table2.DR["GR"] = this.fTimbun.textGRPO.Text;
                table2.DR["GR_Cust"] = this.fTimbun.textGRPO_Cust.Text;
                if (WBSetting.locType == "0")
                {
                    if (this.fTimbun.IO == "I")
                    {
                        table2.DR["PO"] = this.fTimbun.textPO.Text;
                        table2.DR["PO_Item"] = this.fTimbun.textPOItem.Text;
                    }
                    else if (this.fTimbun.IO == "O")
                    {
                        table2.DR["SO"] = this.fTimbun.textPO.Text;
                        table2.DR["SO_item_count"] = this.fTimbun.SO_ITEM_COUNT;
                        table2.DR["SO_Item"] = this.fTimbun.textPOItem.Text;
                    }
                    table2.DR["STO"] = this.fTimbun.textSTO.Text;
                    table2.DR["STO1DO"] = this.fTimbun.checkSTO1DO.Checked ? "Y" : "N";
                    table2.DR["Batch"] = this.fTimbun.textBatch.Text;
                    table2.DR["gain_loss"] = this.fTimbun.cb_gain_loss.Checked ? "Y" : "N";
                }
                table2.DR["quantity"] = this.fTimbun.textQuantity.Text;
                table2.DR["Coy_Tolling"] = "";
                table2.DR["berikat"] = this.fTimbun.checkBerikat.Checked ? "Y" : "N";
                table2.DR["tolerance"] = this.fTimbun.textTolerance.Text;
                table2.DR["Transaction_Code"] = this.fTimbun.textType.Text;
                table2.DR["ISCC"] = this.fTimbun.checkISCC.Checked ? "Y" : "N";
                table2.DR["Qstandard"] = this.fTimbun.qst;
                table2.DR["zAuto"] = "Y";
                table2.DT.Rows.Add(table2.DR);
                table2.Save();
            }
            table.Dispose();
            table2.Dispose();
        }

        private void screenTimbun()
        {
            foreach (Control control in this.GetOffsprings())
            {
                bool flag = control.Name != this.tabPageRef.Name;
                if (flag && (control.GetType() != typeof(Label)))
                {
                    control.Enabled = false;
                }
            }
            this.tabControl1.Enabled = true;
            this.textType.Enabled = true;
            this.textPO.Enabled = true;
            this.textBatch.Enabled = true;
            this.textSTO.Enabled = true;
            this.radioBuyer.Enabled = true;
            this.radioSeller.Enabled = true;
            this.groupBoxDeducted.Enabled = true;
            this.textPOItem.Enabled = true;
            this.textSTOItem.Enabled = true;
            this.textSTO_Item.Enabled = true;
            this.textGRPO.Enabled = true;
            this.textGRPO_Cust.Enabled = true;
            this.btnAdopt.Enabled = true;
            this.buttonSave.Enabled = true;
            this.buttonCancel.Enabled = true;
            this.buttonType.Enabled = true;
            this.button1.Enabled = true;
            this.button2.Enabled = true;
            this.button3.Enabled = true;
            this.btnEstate.Enabled = true;
            this.textQuantity.Enabled = true;
            this.textContract.Enabled = true;
            this.checkBerikat.Enabled = true;
            this.panelLangsir.Enabled = true;
            this.radioLangsirTtb.Visible = false;
            this.textTimbunCoy.Visible = false;
            this.buttonPreview.Visible = false;
            this.buttonLocation.Visible = false;
            this.radioLangsirTtb.Checked = false;
            this.radioLangsir.Enabled = true;
            this.radioLangsirNone.Enabled = true;
            this.radioLangsirTransfer.Enabled = true;
            this.radioLangsir2.Enabled = true;
            this.label_tp_desc.Enabled = true;
            this.textDO.Enabled = this.textGRPO_Cust.Text.Trim() != "";
        }

        private void showTimbunForm()
        {
            this.fTimbun.pMode = "TIMBUN";
            this.fTimbun.timbunCoy = this.textTimbunCoy.Text;
            this.fTimbun.ShowDialog();
            this.buttonPreview.Visible = true;
            if (this.fTimbun.saved)
            {
                this.timbunSave = true;
                foreach (Control control in this.GetOffsprings())
                {
                    foreach (Control control2 in this.fTimbun.GetOffsprings())
                    {
                        if (control2.Name == control.Name)
                        {
                            if (((control is TextBox) || (control is ComboBox)) && (((control.Name != this.textPO.Name) && ((control.Name != this.textSTO.Name) && ((control.Name != this.textSTO1.Name) && ((control.Name != this.textGRPO.Name) && ((control.Name != this.textGRPO_Cust.Name) && ((control.Name != this.textPOItem.Name) && ((control.Name != this.textSTO_Item.Name) && ((control.Name != this.textSTOItem.Name) && ((control.Name != this.textTimbunCoy.Name) && ((control.Name != this.textVend.Name) && ((control.Name != this.textType.Name) && (control.Name != this.textOpnEntryEstate.Name)))))))))))) && (control.Name != this.textOpnEntryFactory.Name)))
                            {
                                control.Text = control2.Text;
                            }
                            if (control is RichTextBox)
                            {
                                control.Text = control2.Text;
                            }
                            if (control is CheckBox)
                            {
                                ((CheckBox) control).Checked = ((CheckBox) control2).Checked;
                            }
                            if ((control is RadioButton) && (((control.Name != this.radioLangsirTtb.Name) && ((control.Name != this.radioLangsirNone.Name) && (control.Name != this.radioLangsirTransfer.Name))) && (control.Name != this.radioLangsir.Name)))
                            {
                                ((RadioButton) control).Checked = ((RadioButton) control2).Checked;
                            }
                            break;
                        }
                    }
                }
                this.textPO.Clear();
                this.textSTO.Clear();
                this.textGRPO.Clear();
                this.textGRPO_Cust.Clear();
                this.textBatch.Clear();
                this.textPI_No.Clear();
            }
            else
            {
                this.timbunSave = false;
            }
            if ((this.textCommodity.Text.Trim() == "") || this.ChkComm(0))
            {
                this.textVend.Text = this.timbunBatch;
                if (((this.textTransporter.Text.Trim() == "") || this.ChkTransporter(0)) && ((this.textEstate.Text.Trim() == "") || this.ChkEstate(0)))
                {
                    if (this.timbunSave)
                    {
                        this.disabled4Timbun();
                    }
                    if ((this.textVend.Text.Trim() != "") && this.ChkVend(0))
                    {
                    }
                }
            }
        }

        private void tabPagePOM_Click(object sender, EventArgs e)
        {
        }

        private void tabPageRef_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textTolerance);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            if (this.textCommodity.Text.Trim() == "")
            {
                this.CommodityName.Text = "";
            }
            else
            {
                string sqltext = "select * from wb_commodity where " + WBData.CompanyLocation("");
                this.tblComm.OpenTable("wb_commodity", sqltext, WBData.conn);
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                if (ReferenceEquals(this.tblComm.DR, null))
                {
                    MessageBox.Show("Commodity Not Exist...", "WARNING...");
                    this.textCommodity.Text = "";
                    this.tblComm.Close();
                }
                else if (this.tblComm.DR["Deleted"].ToString() == "Y")
                {
                    MessageBox.Show("Cannot Choose Deleted Commodity...", "WARNING...");
                    this.textCommodity.Text = "";
                    this.tblComm.Close();
                }
                else
                {
                    this.row_comm = this.tblComm.DT.NewRow();
                    this.row_comm.ItemArray = this.tblComm.DR.ItemArray;
                    this.CommodityName.Text = this.tblComm.DR["Comm_Name"].ToString();
                    this.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                    this.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                    this.trade = this.tblComm.DR["Trade"].ToString();
                    this.IsSugar = this.tblComm.DR["Type"].ToString().Trim() == "G";
                    this.Bulk = this.tblComm.DR["BulkPack"].ToString();
                    this.Std = this.tblComm.DR["Type"].ToString();
                    this.actTrade();
                    this.force_check_qty();
                    if ((this.IO == "O") & this.IsSugar)
                    {
                        this.textSTO.ReadOnly = true;
                        this.checkSTO1DO.Enabled = false;
                    }
                    string objA = this.tblComm.DR["postSAP"].ToString();
                    if (!(((objA == "N") || (objA == "")) || ReferenceEquals(objA, null)))
                    {
                        if (this.comboUploadType1.Items.Contains("-"))
                        {
                            this.comboUploadType1.Items.Remove("-");
                        }
                        this.comboUploadType1.Enabled = true;
                    }
                    else
                    {
                        if (!this.comboUploadType1.Items.Contains("-"))
                        {
                            this.comboUploadType1.Items.Add("-");
                        }
                        this.comboUploadType1.Text = "-";
                        this.comboUploadType1.Enabled = false;
                    }
                }
            }
        }

        private void textCommodity_TextChanged(object sender, EventArgs e)
        {
            this.ChkComm(1);
        }

        private void textCommodity_TextChanged_1(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textContract_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textConvUnit_TextChanged(object sender, EventArgs e)
        {
            this.labelConvValue.Text = (this.textConvUnit.Text != "") ? (" ( in Kg ),  1 " + this.textConvUnit.Text + " = xxx Kg") : "";
        }

        private void textDO_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (((this.textEstate.Text.Trim() == "") || this.ChkEstate(1)) && (this.textEstate.Text.Trim() == ""))
            {
                this.labelEstateADM.Text = "";
            }
        }

        private void textEstate_TextChanged(object sender, EventArgs e)
        {
        }

        private void textGRPO_Cust_Leave(object sender, EventArgs e)
        {
        }

        private void textGRPO_Cust_TextChanged(object sender, EventArgs e)
        {
        }

        private void textLarge1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLarge1);
        }

        private void textLarge2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLarge2);
        }

        private void textLoose1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLoose1);
        }

        private void textLoose2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLoose2);
        }

        private void textMid1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textMid1);
        }

        private void textMid2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textMid2);
        }

        private void textNEGO_TextChanged(object sender, EventArgs e)
        {
            this.needAdoptNego = (this.textNEGO.Text == "") ? "N" : "Y";
        }

        private void textOpnEntryEstate_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryEstate);
        }

        private void textOpnEntryEstate_Leave_1(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textOpnEntryFactory_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textOpnEntryFactory_Leave_1(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textPO_TextChanged(object sender, EventArgs e)
        {
        }

        private void textQstDesc_TextChanged(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "SELECT ISCC FROM wb_relation WHERE " + WBData.CompanyLocation(" AND relation_code = '" + this.textVend.Text.Trim() + "'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.checkISCC.Checked = this.textQstDesc.Text.ToUpper().Contains("ISCC") || (table.DT.Rows[0]["ISCC"].ToString() == "Y");
            }
        }

        private void textQty_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
            if (!(Convert.ToDouble(this.textQuantity.Text) != 0.0))
            {
                this.textQuantity.Text = this.textOpnEntryFactory.Text;
            }
        }

        private void textQuantity_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textQuantity);
            if ((this.radioLangsirTtb.Checked && (this.textTimbunCoy.Text.Trim() != "")) && ((this.textQuantity.Text.Trim() != "") && (Program.StrToDouble(this.textQuantity.Text, 0) < Program.StrToDouble(this.fTimbun.textQuantity.Text, 0))))
            {
                MessageBox.Show("Quantity Cannot Smaller than Material Owner Qty", "WARNING");
                this.textQuantity.Focus();
            }
        }

        private void textRemark_TextChanged(object sender, EventArgs e)
        {
        }

        private void textScout1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textScout1);
        }

        private void textScout2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textScout2);
        }

        private void textSmall1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textSmall1);
        }

        private void textSmall2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textSmall2);
        }

        private void textSTO_Leave(object sender, EventArgs e)
        {
        }

        private void textSTO_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
            this.textSTO1.Text = this.textSTO.Text;
        }

        private void textSTO1_TextChanged(object sender, EventArgs e)
        {
            this.textSTO.Text = this.textSTO1.Text;
        }

        private void textTimbunCoy_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTimbunCoy_Leave(object sender, EventArgs e)
        {
            if (this.textTimbunCoy.Text.Trim() != "")
            {
                if (!this.chkLocTimbun())
                {
                    MessageBox.Show("The Location code is wrong !", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else if (this.textTimbunCoy.Text.Trim() != "NONE")
                {
                    this.showTimbunForm();
                }
            }
        }

        private void textTolerance_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textTolerance);
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (((this.textTransporter.Text.Trim() == "") || this.ChkTransporter(1)) && (this.textTransporter.Text.Trim() == ""))
            {
                this.TransporterName.Text = "";
            }
        }

        private void textTransporter_TextChanged(object sender, EventArgs e)
        {
            if (((this.IO != "O") && ((this.comboIncoterm.Text != "LCO") && ((this.comboIncoterm.Text != "CIF") && (this.comboIncoterm.Text != "FOB")))) && (this.textSTO.Text != ""))
            {
                this.adopt = "N";
            }
        }

        private void textType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textType_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textType_Leave_1(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { this.textType.Text.Trim() };
            DataRow data = this.tblTransType.GetData(aField, aFind);
            if (data == null)
            {
                this.buttonType.PerformClick();
                this.textType.Focus();
            }
            else
            {
                this.textType.Text = data["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = data["Transaction_Name"].ToString();
                this.IO = data["IO"].ToString();
                this.textPO.Enabled = true;
                if (this.IO == "I")
                {
                    this.labelPO.Text = "PO";
                    this.labelPO1.Text = "PO";
                    this.label1.Text = "Delivery Order No.";
                    this.label_tp_desc.Text = "Supplying Batch / Plant / S. Loc";
                    this.cb_langsir_type.Text = "P";
                }
                else if (this.IO == "O")
                {
                    this.labelPO.Text = "SO";
                    this.labelPO1.Text = "SO";
                    this.label1.Text = "Sales Order No.";
                    this.label_tp_desc.Text = "Destination Batch / Plant / S. Loc";
                    this.cb_langsir_type.Text = "S";
                }
                this.enableVessel(data["is_vessel"].ToString().Trim());
                this.row_type = this.tblTransType.DT.NewRow();
                this.row_type.ItemArray = data.ItemArray;
            }
            this.cekinco(this.comboIncoterm.Text, this.textType.Text);
            this.force_check_qty();
        }

        private void textType_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
            this.cekinco(this.comboIncoterm.Text, this.textType.Text);
        }

        private void textVend_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textVend_Leave(object sender, EventArgs e)
        {
            if (((this.textVend.Text.Trim() == "") || this.ChkVend(1)) && (this.textVend.Text.Trim() == ""))
            {
                this.relationName.Text = "";
            }
        }

        private void textVend_TextChanged(object sender, EventArgs e)
        {
            if (((this.textSTO.Text == "") || ((this.textPO.Text != "") || (this.textGRPO.Text != ""))) || (this.textGRPO_Cust.Text != ""))
            {
                this.adopt = "N";
            }
        }
    }
}

