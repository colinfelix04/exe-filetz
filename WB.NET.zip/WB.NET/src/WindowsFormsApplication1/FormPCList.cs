﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormPCList : Form
    {
        private WBTable tblPC = new WBTable();
        private IContainer components = null;
        private StatusStrip statusStrip1;
        private Panel panel1;
        private Button buttonClose;
        private Label labelDes;
        private DataGridView dgPCList;

        public FormPCList()
        {
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormPCList_Load(object sender, EventArgs e)
        {
            this.tblPC.OpenTable("wb_Setting", "Select Coy, Location_code, WBCode, CompName, WB_type,version from wb_setting where 1 = 1", WBData.conn);
            this.dgPCList.DataSource = this.tblPC.DT;
            this.dgPCList.Sort(this.dgPCList.Columns["WBCode"], ListSortDirection.Ascending);
            this.dgPCList.Columns["WBCode"].HeaderText = "WBCode";
            this.dgPCList.Columns["CompName"].HeaderText = "Computer Name";
            this.dgPCList.Columns["WB_type"].HeaderText = "Indicator Type";
            this.dgPCList.Columns["Version"].HeaderText = "WB.Net Version";
        }

        private void InitializeComponent()
        {
            this.statusStrip1 = new StatusStrip();
            this.panel1 = new Panel();
            this.buttonClose = new Button();
            this.labelDes = new Label();
            this.dgPCList = new DataGridView();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dgPCList).BeginInit();
            base.SuspendLayout();
            this.statusStrip1.Location = new Point(0, 0x169);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x259, 0x16);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.panel1.Controls.Add(this.dgPCList);
            this.panel1.Dock = DockStyle.Top;
            this.panel1.Location = new Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x259, 0x139);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
            this.buttonClose.Location = new Point(500, 0x13c);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(0x4b, 0x2c);
            this.buttonClose.TabIndex = 2;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.labelDes.AutoSize = true;
            this.labelDes.Location = new Point(3, 0x13c);
            this.labelDes.Name = "labelDes";
            this.labelDes.Size = new Size(0x103, 0x27);
            this.labelDes.TabIndex = 3;
            this.labelDes.Text = "Show All WB.NET Computer List.\r\n\r\nPlease use uniq WB Code to different each Computer";
            this.dgPCList.AllowUserToAddRows = false;
            this.dgPCList.AllowUserToDeleteRows = false;
            this.dgPCList.AllowUserToResizeRows = false;
            this.dgPCList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgPCList.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgPCList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPCList.Dock = DockStyle.Fill;
            this.dgPCList.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgPCList.Location = new Point(0, 0);
            this.dgPCList.MultiSelect = false;
            this.dgPCList.Name = "dgPCList";
            this.dgPCList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgPCList.Size = new Size(0x259, 0x139);
            this.dgPCList.TabIndex = 0x11;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x259, 0x17f);
            base.ControlBox = false;
            base.Controls.Add(this.labelDes);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.statusStrip1);
            base.Name = "FormPCList";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "WB.Net Computer List";
            base.Load += new EventHandler(this.FormPCList_Load);
            this.panel1.ResumeLayout(false);
            ((ISupportInitialize) this.dgPCList).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }
    }
}

