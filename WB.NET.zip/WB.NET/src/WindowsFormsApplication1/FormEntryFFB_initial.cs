﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEntryFFB_initial : Form
    {
        private WBTable tblEstate = new WBTable();
        private WBTable tblRelation = new WBTable();
        private WBTable tblTrans = new WBTable();
        private WBTable tblTruck = new WBTable();
        private IContainer components = null;
        private GroupBox groupType;
        private Button buttonCancel;
        private Button buttonProcess;
        private Label labelRefDate;
        private Button button11;
        public DateTimePicker calRefDate;
        private TextBox textEstate;
        private Label labelRefNo;
        private Label label1;
        private TextBox textRef;
        private Label labelEstate;
        private Label labelRelation;
        private Button button12;
        private TextBox textRelation;
        private Label label2;
        private TextBox textTruck;
        private Label label3;

        public FormEntryFFB_initial()
        {
            this.InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstate.Text = estate.ReturnRow["Estate_Name"].ToString();
            }
            estate.Dispose();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_Code"].ToString();
                this.labelRelation.Text = vendor.ReturnRow["relation_Name"].ToString();
            }
            vendor.Dispose();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            FormEntryFFB_main _main = new FormEntryFFB_main {
                date1 = Program.DTOC(this.calRefDate.Value) + " 00:00:00",
                ref_no = this.textRef.Text,
                estate = this.textEstate.Text,
                relation = this.textRelation.Text,
                truck = this.textTruck.Text
            };
            _main.ShowDialog();
            _main.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormEntryFFB_initial_Load(object sender, EventArgs e)
        {
            this.tblEstate.OpenTable("wb_estate", "SELECT * FROM wb_estate", WBData.conn);
            this.tblRelation.OpenTable("wb_relation", "SELECT * FROM wb_relation", WBData.conn);
            this.tblTrans.OpenTable("wb_transaction", "SELECT * FROM wb_transaction", WBData.conn);
            this.tblTruck.OpenTable("wb_truck", "SELECT * FROM wb_truck", WBData.conn);
            Program.AutoComp(this.tblEstate, "Estate_Code", this.textEstate);
            Program.AutoComp(this.tblRelation, "Relation_Code", this.textRelation);
            Program.AutoComp(this.tblTrans, "ref", this.textRef);
            Program.AutoComp(this.tblTruck, "truck_number", this.textTruck);
            this.labelEstate.Visible = this.textEstate.Text != "";
            this.labelRelation.Visible = this.textEstate.Text != "";
        }

        private void InitializeComponent()
        {
            this.groupType = new GroupBox();
            this.labelRelation = new Label();
            this.button12 = new Button();
            this.textRelation = new TextBox();
            this.label2 = new Label();
            this.labelEstate = new Label();
            this.buttonCancel = new Button();
            this.buttonProcess = new Button();
            this.labelRefDate = new Label();
            this.button11 = new Button();
            this.calRefDate = new DateTimePicker();
            this.textEstate = new TextBox();
            this.labelRefNo = new Label();
            this.label1 = new Label();
            this.textRef = new TextBox();
            this.label3 = new Label();
            this.textTruck = new TextBox();
            this.groupType.SuspendLayout();
            base.SuspendLayout();
            this.groupType.Controls.Add(this.textTruck);
            this.groupType.Controls.Add(this.label3);
            this.groupType.Controls.Add(this.labelRelation);
            this.groupType.Controls.Add(this.button12);
            this.groupType.Controls.Add(this.textRelation);
            this.groupType.Controls.Add(this.label2);
            this.groupType.Controls.Add(this.labelEstate);
            this.groupType.Controls.Add(this.buttonCancel);
            this.groupType.Controls.Add(this.buttonProcess);
            this.groupType.Controls.Add(this.labelRefDate);
            this.groupType.Controls.Add(this.button11);
            this.groupType.Controls.Add(this.calRefDate);
            this.groupType.Controls.Add(this.textEstate);
            this.groupType.Controls.Add(this.labelRefNo);
            this.groupType.Controls.Add(this.label1);
            this.groupType.Controls.Add(this.textRef);
            this.groupType.Location = new Point(12, 12);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(0x1a0, 0xd7);
            this.groupType.TabIndex = 0x34;
            this.groupType.TabStop = false;
            this.labelRelation.AutoSize = true;
            this.labelRelation.Location = new Point(0xe9, 0x67);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x2e, 13);
            this.labelRelation.TabIndex = 0x39;
            this.labelRelation.Text = "Relation";
            this.button12.Location = new Point(0xcf, 0x62);
            this.button12.Margin = new Padding(0);
            this.button12.Name = "button12";
            this.button12.Size = new Size(0x17, 0x17);
            this.button12.TabIndex = 0x38;
            this.button12.Text = "...";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new EventHandler(this.button12_Click);
            this.textRelation.Location = new Point(0x68, 100);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(100, 20);
            this.textRelation.TabIndex = 0x37;
            this.textRelation.Leave += new EventHandler(this.textRelation_Leave);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(15, 0x67);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2e, 13);
            this.label2.TabIndex = 0x36;
            this.label2.Text = "Relation";
            this.labelEstate.AutoSize = true;
            this.labelEstate.Location = new Point(0xe9, 0x4d);
            this.labelEstate.Name = "labelEstate";
            this.labelEstate.Size = new Size(0x25, 13);
            this.labelEstate.TabIndex = 0x35;
            this.labelEstate.Text = "Estate";
            this.buttonCancel.Location = new Point(0x146, 170);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x1d);
            this.buttonCancel.TabIndex = 0x34;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonProcess.Location = new Point(0xea, 170);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x4b, 0x1d);
            this.buttonProcess.TabIndex = 0x33;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.labelRefDate.AutoSize = true;
            this.labelRefDate.Location = new Point(15, 0x1b);
            this.labelRefDate.Name = "labelRefDate";
            this.labelRefDate.Size = new Size(0x53, 13);
            this.labelRefDate.TabIndex = 0;
            this.labelRefDate.Text = "Reference Date";
            this.button11.Location = new Point(0xcf, 0x48);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 50;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.calRefDate.Format = DateTimePickerFormat.Short;
            this.calRefDate.Location = new Point(0x68, 0x18);
            this.calRefDate.Name = "calRefDate";
            this.calRefDate.Size = new Size(100, 20);
            this.calRefDate.TabIndex = 0x2d;
            this.textEstate.Location = new Point(0x68, 0x4a);
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(100, 20);
            this.textEstate.TabIndex = 0x31;
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.labelRefNo.AutoSize = true;
            this.labelRefNo.Location = new Point(15, 0x34);
            this.labelRefNo.Name = "labelRefNo";
            this.labelRefNo.Size = new Size(0x4d, 13);
            this.labelRefNo.TabIndex = 0x2e;
            this.labelRefNo.Text = "Reference No.";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(15, 0x4d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x25, 13);
            this.label1.TabIndex = 0x30;
            this.label1.Text = "Estate";
            this.textRef.Location = new Point(0x68, 0x31);
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0xb9, 20);
            this.textRef.TabIndex = 0x2f;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(15, 0x7f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3e, 13);
            this.label3.TabIndex = 0x3a;
            this.label3.Text = "Vehicle No.";
            this.textTruck.Location = new Point(0x68, 0x7c);
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0xb9, 20);
            this.textTruck.TabIndex = 0x3b;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(440, 0xef);
            base.Controls.Add(this.groupType);
            base.Name = "FormEntryFFB_initial";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Entry FFB Grading";
            base.Load += new EventHandler(this.FormEntryFFB_initial_Load);
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            base.ResumeLayout(false);
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (this.textEstate.Text != "")
            {
                FormEstate estate = new FormEstate();
                WBTable table = new WBTable();
                table.OpenTable("wb_estate", "SELECT * FROM wb_estate Where " + WBData.CompanyLocation(" and estate_code='" + this.textEstate.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.button11.PerformClick();
                }
                else
                {
                    this.labelEstate.Visible = true;
                    this.labelEstate.Text = table.DT.Rows[0]["estate_name"].ToString();
                }
                estate.Dispose();
                table.Dispose();
            }
        }

        private void textRelation_Leave(object sender, EventArgs e)
        {
            if (this.textRelation.Text != "")
            {
                FormVendor vendor = new FormVendor();
                WBTable table = new WBTable();
                table.OpenTable("wb_relation", "SELECT * FROM wb_relation Where " + WBData.CompanyLocation(" and relation_code='" + this.textRelation.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.button12.PerformClick();
                }
                else
                {
                    this.labelRelation.Visible = true;
                    this.labelRelation.Text = table.DT.Rows[0]["relation_name"].ToString();
                }
                vendor.Dispose();
                table.Dispose();
            }
        }
    }
}

