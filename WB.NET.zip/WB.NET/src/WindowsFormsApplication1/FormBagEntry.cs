﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBagEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string nlastCheck;
        public string minTare;
        public string maxTare;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public int sUniq;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        private Label label7;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textWeight;
        private TextBox textDesc;
        public GroupBox groupType;
        public RadioButton radioCopra;
        public RadioButton radioFFB;
        public RadioButton radioStandard;
        private Button buttonCancel;
        private Button buttonSave;
        public TextBox textBagCode;
        private Label label4;

        public FormBagEntry()
        {
            this.InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textBagCode, this.textWeight, this.textDesc };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_bag", "Select Uniq From wb_bag Where " + WBData.CompanyLocation(" and ( bag_code='" + this.textBagCode.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = "Bag Code" },
                            textRefNo = { Text = this.textBagCode.Text },
                            Text = "CHANGE REASON",
                            label2 = { Text = "Change Reason : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["Bag_Code"] = this.textBagCode.Text.Trim();
                    this.zTable.DR["Comm_Type"] = this.radioStandard.Checked ? "S" : (this.radioFFB.Checked ? "F" : (this.radioCopra.Checked ? "C" : "S"));
                    this.zTable.DR["weight"] = this.textWeight.Text.Trim();
                    this.zTable.DR["Description"] = this.textDesc.Text.Trim();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now.ToString();
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Change_By"] = WBUser.UserID;
                        this.zTable.DR["Change_Date"] = DateTime.Now.ToString();
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_bag", "SELECT uniq FROM wb_bag WHERE " + WBData.CompanyLocation(" AND bag_code = '" + this.textBagCode.Text.Trim() + "'"), WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_bag", this.logKey, logField, logValue);
                    }
                    Cursor.Current = Cursors.Default;
                    this.saved = true;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textBagCode.Focus();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormBagEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.translate();
            if (this.pMode != "ADD")
            {
                this.textBagCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Bag_Code"].Value.ToString();
                this.textWeight.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Weight"].Value.ToString();
                this.textDesc.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Description"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Comm_type"].Value.ToString() == "S")
                {
                    this.radioStandard.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Comm_type"].Value.ToString() == "F")
                {
                    this.radioStandard.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Comm_type"].Value.ToString() == "C")
                {
                    this.radioCopra.Checked = true;
                }
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
                this.buttonCancel.Text = " &Closed ";
            }
        }

        private void InitializeComponent()
        {
            this.textBagCode = new TextBox();
            this.label7 = new Label();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.textWeight = new TextBox();
            this.textDesc = new TextBox();
            this.groupType = new GroupBox();
            this.radioCopra = new RadioButton();
            this.radioFFB = new RadioButton();
            this.radioStandard = new RadioButton();
            this.buttonCancel = new Button();
            this.buttonSave = new Button();
            this.label4 = new Label();
            this.groupType.SuspendLayout();
            base.SuspendLayout();
            this.textBagCode.Location = new Point(90, 12);
            this.textBagCode.MaxLength = 10;
            this.textBagCode.Name = "textBagCode";
            this.textBagCode.Size = new Size(0x83, 20);
            this.textBagCode.TabIndex = 0;
            this.textBagCode.KeyPress += new KeyPressEventHandler(this.textBagCode_KeyPress);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x19, 0x10);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x36, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Bag Code";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x26, 0x33);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x29, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Weight";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x17, 0xdd);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x55, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Commodity Type";
            this.label2.Visible = false;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x13, 0x55);
            this.label3.Name = "label3";
            this.label3.Size = new Size(60, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Description";
            this.textWeight.Location = new Point(90, 0x30);
            this.textWeight.MaxLength = 10;
            this.textWeight.Name = "textWeight";
            this.textWeight.Size = new Size(0x4c, 20);
            this.textWeight.TabIndex = 2;
            this.textWeight.Text = "0";
            this.textWeight.TextAlign = HorizontalAlignment.Right;
            this.textWeight.KeyPress += new KeyPressEventHandler(this.textWeight_KeyPress);
            this.textWeight.Leave += new EventHandler(this.textWeight_Leave);
            this.textDesc.Location = new Point(90, 0x52);
            this.textDesc.MaxLength = 250;
            this.textDesc.Multiline = true;
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new Size(0x12f, 0x30);
            this.textDesc.TabIndex = 3;
            this.textDesc.KeyPress += new KeyPressEventHandler(this.textDesc_KeyPress);
            this.groupType.Controls.Add(this.radioCopra);
            this.groupType.Controls.Add(this.radioFFB);
            this.groupType.Controls.Add(this.radioStandard);
            this.groupType.Location = new Point(0x77, 0xc7);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(0xcc, 0x2e);
            this.groupType.TabIndex = 1;
            this.groupType.TabStop = false;
            this.groupType.Visible = false;
            this.radioCopra.AutoSize = true;
            this.radioCopra.Location = new Point(0x8e, 0x13);
            this.radioCopra.Name = "radioCopra";
            this.radioCopra.Size = new Size(0x35, 0x11);
            this.radioCopra.TabIndex = 2;
            this.radioCopra.Text = "Copra";
            this.radioCopra.UseVisualStyleBackColor = true;
            this.radioFFB.AutoSize = true;
            this.radioFFB.Location = new Point(0x53, 0x13);
            this.radioFFB.Name = "radioFFB";
            this.radioFFB.Size = new Size(0x2c, 0x11);
            this.radioFFB.TabIndex = 1;
            this.radioFFB.Text = "FFB";
            this.radioFFB.UseVisualStyleBackColor = true;
            this.radioStandard.AutoSize = true;
            this.radioStandard.Checked = true;
            this.radioStandard.Location = new Point(8, 0x13);
            this.radioStandard.Name = "radioStandard";
            this.radioStandard.Size = new Size(0x44, 0x11);
            this.radioStandard.TabIndex = 0;
            this.radioStandard.TabStop = true;
            this.radioStandard.Text = "Standard";
            this.radioStandard.UseVisualStyleBackColor = true;
            this.buttonCancel.Location = new Point(0x13e, 0x92);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x23);
            this.buttonCancel.TabIndex = 5;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonSave.Location = new Point(0xdb, 0x92);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x23);
            this.buttonSave.TabIndex = 4;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xac, 0x33);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x16, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "KG";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x19c, 0xc1);
            base.ControlBox = false;
            base.Controls.Add(this.label4);
            base.Controls.Add(this.groupType);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textDesc);
            base.Controls.Add(this.textWeight);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textBagCode);
            base.Controls.Add(this.label7);
            base.FormBorderStyle = FormBorderStyle.FixedSingle;
            base.Name = "FormBagEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Bag Entry";
            base.Load += new EventHandler(this.FormBagEntry_Load);
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBagCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textWeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textWeight_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textWeight);
        }

        private void translate()
        {
            this.label7.Text = Resource.Trans_095;
            this.label3.Text = Resource.Trans_096;
            this.buttonSave.Text = Resource.Save;
            this.buttonCancel.Text = Resource.Menu_Cancel;
        }
    }
}

