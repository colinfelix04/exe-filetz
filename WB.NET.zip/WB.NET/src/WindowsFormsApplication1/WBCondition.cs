﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;

    public class WBCondition : Component
    {
        private WBTable tblCondition;
        private DataRow dgParam;
        public string conditionCode = "";

        public void fillParameter(string pconditionCode, DataRow[] dgRows)
        {
            DataRow[] rowArray;
            int num;
            this.conditionCode = pconditionCode;
            this.tblCondition = new WBTable();
            DateTime now = DateTime.Now;
            this.tblCondition.OpenTable("wb_condition", "Select * from wb_condition where " + WBData.CompanyLocation(" and condition_code = '" + this.conditionCode + "' and (getdate() not between start_inactive_time and end_inactive_time or start_inactive_time is null or end_inactive_time is null)"), WBData.conn);
            if (this.tblCondition.DT.Rows.Count <= 0)
            {
                return;
            }
            else
            {
                this.dgParam = this.tblCondition.DT.Rows[0];
                foreach (DataColumn column in this.dgParam.Table.Columns)
                {
                    if (((column.ColumnName.ToString().ToUpper() != "UNIQ") && ((column.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column.ColumnName.ToString().ToUpper() != "DESCRIPTION"))))) && (column.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                    {
                        this.dgParam[column.ColumnName] = "";
                    }
                }
                rowArray = dgRows;
                num = 0;
            }
            while (true)
            {
                if (num >= rowArray.Length)
                {
                    break;
                }
                DataRow row = rowArray[num];
                foreach (DataColumn column2 in this.dgParam.Table.Columns)
                {
                    foreach (DataColumn column3 in row.Table.Columns)
                    {
                        if (((column2.ColumnName.ToUpper() == column3.ColumnName.ToUpper()) && ((column2.ColumnName.ToString().ToUpper() != "UNIQ") && ((column2.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column2.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column2.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column2.ColumnName.ToString().ToUpper() != "DESCRIPTION")))))) && (column2.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                        {
                            this.dgParam[column2.ColumnName.ToString()] = row[column2.ColumnName.ToString()];
                            break;
                        }
                    }
                }
                num++;
            }
        }

        public void fillParameterWithoutCoyLoc(string pconditionCode, DataRow[] dgRows)
        {
            DataRow[] rowArray;
            int num;
            this.conditionCode = pconditionCode;
            this.tblCondition = new WBTable();
            string sqltext = "SELECT * FROM wb_condition WHERE condition_code = '" + this.conditionCode + "'";
            this.tblCondition.OpenTable("wb_condition", sqltext, WBData.conn);
            if (this.tblCondition.DT.Rows.Count <= 0)
            {
                return;
            }
            else
            {
                this.dgParam = this.tblCondition.DT.Rows[0];
                foreach (DataColumn column in this.dgParam.Table.Columns)
                {
                    if (((column.ColumnName.ToString().ToUpper() != "UNIQ") && ((column.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column.ColumnName.ToString().ToUpper() != "DESCRIPTION"))))) && (column.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                    {
                        this.dgParam[column.ColumnName] = "";
                    }
                }
                rowArray = dgRows;
                num = 0;
            }
            while (true)
            {
                if (num >= rowArray.Length)
                {
                    break;
                }
                DataRow row = rowArray[num];
                foreach (DataColumn column2 in this.dgParam.Table.Columns)
                {
                    foreach (DataColumn column3 in row.Table.Columns)
                    {
                        if (((column2.ColumnName.ToUpper() == column3.ColumnName.ToUpper()) && ((column2.ColumnName.ToString().ToUpper() != "UNIQ") && ((column2.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column2.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column2.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column2.ColumnName.ToString().ToUpper() != "DESCRIPTION")))))) && (column2.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                        {
                            this.dgParam[column2.ColumnName.ToString()] = row[column2.ColumnName.ToString()];
                            break;
                        }
                    }
                }
                num++;
            }
        }

        public bool getConditionTCS(string pconditionCode, string field, string value)
        {
            bool flag = false;
            this.conditionCode = pconditionCode;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_condition WHERE condition_code = '", pconditionCode, "' AND ", field, "= '", value, "'" };
            string sqltext = string.Concat(textArray1);
            table.OpenTable("wb_condition", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                flag = true;
            }
            table.Dispose();
            return flag;
        }

        public string getConditionValue(string pconditionCode, string pCol)
        {
            string str = "";
            this.conditionCode = pconditionCode;
            this.tblCondition = new WBTable();
            DateTime now = DateTime.Now;
            this.tblCondition.OpenTable("wb_condition", "Select " + pCol + " from wb_condition where " + WBData.CompanyLocation(" and condition_code = '" + this.conditionCode + "' and (getdate() not between start_inactive_time and end_inactive_time or start_inactive_time is null or end_inactive_time is null)"), WBData.conn);
            if (this.tblCondition.DT.Rows.Count > 0)
            {
                str = this.tblCondition.DT.Rows[0][pCol].ToString();
            }
            return str;
        }

        public string getConditionValueWithoutCoyLoc(string pconditionCode, string pCol)
        {
            string str = "";
            this.conditionCode = pconditionCode;
            this.tblCondition = new WBTable();
            DateTime now = DateTime.Now;
            string[] textArray1 = new string[] { "Select ", pCol, " from wb_condition where condition_code = '", this.conditionCode, "' and (getdate() not between start_inactive_time and end_inactive_time or start_inactive_time is null or end_inactive_time is null)" };
            this.tblCondition.OpenTable("wb_condition", string.Concat(textArray1), WBData.conn);
            if (this.tblCondition.DT.Rows.Count > 0)
            {
                str = this.tblCondition.DT.Rows[0][pCol].ToString();
            }
            return str;
        }

        public bool getResult()
        {
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            DateTime now = DateTime.Now;
            this.tblCondition.OpenTable("wb_condition", "Select * from wb_condition where " + WBData.CompanyLocation(" and condition_code = '" + this.conditionCode + "' and (getdate() not between start_inactive_time and end_inactive_time or start_inactive_time is null or end_inactive_time is null)"), WBData.conn);
            if (this.tblCondition.DT.Rows.Count > 0)
            {
                flag = false;
                foreach (DataRow row in this.tblCondition.DT.Rows)
                {
                    foreach (DataColumn column in row.Table.Columns)
                    {
                        flag2 = true;
                        foreach (DataColumn column2 in this.dgParam.Table.Columns)
                        {
                            if (((column.ColumnName.ToString().ToUpper() == column2.ColumnName.ToString().ToUpper()) && ((column2.ColumnName.ToString().ToUpper() != "UNIQ") && ((column2.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column2.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column2.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column2.ColumnName.ToString().ToUpper() != "DESCRIPTION")))))) && (column2.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                            {
                                flag2 = ((row[column.ColumnName.ToString().ToUpper()] == null) || (row[column.ColumnName.ToString().ToUpper()].ToString() == "")) || (row[column.ColumnName.ToString().ToUpper()].ToString().Trim() == this.dgParam[column.ColumnName.ToString().ToUpper()].ToString().Trim());
                                break;
                            }
                        }
                        if (!flag2)
                        {
                            break;
                        }
                    }
                    flag3 |= flag2;
                }
            }
            return flag3;
        }

        public bool getResultWithoutCoyLoc()
        {
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            DateTime now = DateTime.Now;
            this.tblCondition.OpenTable("wb_condition", "Select * from wb_condition where condition_code = '" + this.conditionCode + "' and (getdate() not between start_inactive_time and end_inactive_time or start_inactive_time is null or end_inactive_time is null)", WBData.conn);
            if (this.tblCondition.DT.Rows.Count > 0)
            {
                flag = false;
                foreach (DataRow row in this.tblCondition.DT.Rows)
                {
                    foreach (DataColumn column in row.Table.Columns)
                    {
                        flag2 = true;
                        foreach (DataColumn column2 in this.dgParam.Table.Columns)
                        {
                            if (((column.ColumnName.ToString().ToUpper() == column2.ColumnName.ToString().ToUpper()) && ((column2.ColumnName.ToString().ToUpper() != "UNIQ") && ((column2.ColumnName.ToString().ToUpper() != "CONDITION_CODE") && ((column2.ColumnName.ToString().ToUpper() != "START_INACTIVE_TIME") && ((column2.ColumnName.ToString().ToUpper() != "END_INACTIVE_TIME") && (column2.ColumnName.ToString().ToUpper() != "DESCRIPTION")))))) && (column2.ColumnName.ToString().ToUpper() != "ALLOW_DISABLE"))
                            {
                                flag2 = ((row[column.ColumnName.ToString().ToUpper()] == null) || (row[column.ColumnName.ToString().ToUpper()].ToString() == "")) || (row[column.ColumnName.ToString().ToUpper()].ToString() == this.dgParam[column.ColumnName.ToString().ToUpper()].ToString());
                                break;
                            }
                        }
                        if (!flag2)
                        {
                            break;
                        }
                    }
                    flag3 |= flag2;
                }
            }
            return flag3;
        }

        public bool getSettingCondition(string pconditionCode)
        {
            bool flag = false;
            this.conditionCode = pconditionCode;
            this.tblCondition = new WBTable();
            this.tblCondition.OpenTable("wb_condition", "Select * from wb_condition where " + WBData.CompanyLocation(" and condition_code = '" + this.conditionCode + "'"), WBData.conn);
            if (this.tblCondition.DT.Rows.Count > 0)
            {
                DateTime now = new DateTime();
                now = DateTime.Now;
                if (string.IsNullOrEmpty(this.tblCondition.DT.Rows[0]["start_inactive_time"].ToString()) || string.IsNullOrEmpty(this.tblCondition.DT.Rows[0]["end_inactive_time"].ToString()))
                {
                    flag = true;
                }
                else
                {
                    try
                    {
                        DateTime time3 = Convert.ToDateTime(this.tblCondition.DT.Rows[0]["end_inactive_time"].ToString());
                        flag = (now < Convert.ToDateTime(this.tblCondition.DT.Rows[0]["start_inactive_time"].ToString())) || (now > time3);
                    }
                    catch (Exception)
                    {
                        flag = true;
                    }
                }
            }
            return flag;
        }

        public bool getSettingConditionWithoutCoyLoc(string pconditionCode)
        {
            bool flag = false;
            this.conditionCode = pconditionCode;
            WBTable table = new WBTable();
            string sqltext = "SELECT * FROM wb_condition WHERE condition_code = '" + pconditionCode + "'";
            table.OpenTable("wb_condition", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                DateTime now = new DateTime();
                now = DateTime.Now;
                if (string.IsNullOrEmpty(table.DT.Rows[0]["start_inactive_time"].ToString()) || string.IsNullOrEmpty(table.DT.Rows[0]["end_inactive_time"].ToString()))
                {
                    flag = true;
                }
                else
                {
                    try
                    {
                        DateTime time3 = Convert.ToDateTime(table.DT.Rows[0]["end_inactive_time"].ToString());
                        flag = (now < Convert.ToDateTime(table.DT.Rows[0]["start_inactive_time"].ToString())) || (now > time3);
                    }
                    catch (Exception)
                    {
                        flag = true;
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        public void initCondition(string condition_code)
        {
        }
    }
}

