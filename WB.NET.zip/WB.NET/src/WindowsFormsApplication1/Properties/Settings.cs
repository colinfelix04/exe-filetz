﻿namespace WindowsFormsApplication1.Properties
{
    using System;
    using System.CodeDom.Compiler;
    using System.Configuration;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;

    [CompilerGenerated, GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
    internal sealed class Settings : ApplicationSettingsBase
    {
        private static Settings defaultInstance = ((Settings) Synchronized(new Settings()));

        public static Settings Default =>
            defaultInstance;

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("0")]
        public string Setting
        {
            get => 
                (string) this["Setting"];
            set => 
                this["Setting"] = value;
        }

        [ApplicationScopedSetting, DebuggerNonUserCode, SpecialSetting(SpecialSetting.ConnectionString), DefaultSettingValue(@"Data Source=JEFI-SAP\SQLEXPRESS;Initial Catalog=wbsystem;Persist Security Info=True;User ID=sa;Password=12345")]
        public string wbsystemConnectionString =>
            (string) this["wbsystemConnectionString"];

        [ApplicationScopedSetting, DebuggerNonUserCode, SpecialSetting(SpecialSetting.ConnectionString), DefaultSettingValue(@"Data Source=10.21.4.9\wbnet;Initial Catalog=wbsystem;Persist Security Info=True;User ID=sa;Password=WBn3t16")]
        public string wbsystemWEO =>
            (string) this["wbsystemWEO"];

        [ApplicationScopedSetting, DebuggerNonUserCode, SpecialSetting(SpecialSetting.ConnectionString), DefaultSettingValue(@"Data Source=10.1.1.150\sqlexpress;Initial Catalog=WBSystem;Persist Security Info=True;User ID=sa;Password=server!2345")]
        public string WBSystemConnectionString1 =>
            (string) this["WBSystemConnectionString1"];
    }
}

