﻿namespace WindowsFormsApplication1.Properties
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
    internal class Resources
    {
        private static System.Resources.ResourceManager resourceMan;
        private static CultureInfo resourceCulture;

        internal Resources()
        {
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (ReferenceEquals(resourceMan, null))
                {
                    resourceMan = new System.Resources.ResourceManager("WindowsFormsApplication1.Properties.Resources", typeof(Resources).Assembly);
                }
                return resourceMan;
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get => 
                resourceCulture;
            set => 
                resourceCulture = value;
        }

        internal static Bitmap add_24px =>
            (Bitmap) ResourceManager.GetObject("add_24px", resourceCulture);

        internal static Bitmap blue_info_icon =>
            (Bitmap) ResourceManager.GetObject("blue-info-icon", resourceCulture);

        internal static Bitmap cancel_24px =>
            (Bitmap) ResourceManager.GetObject("cancel_24px", resourceCulture);

        internal static Bitmap cancel_24px1 =>
            (Bitmap) ResourceManager.GetObject("cancel_24px1", resourceCulture);

        internal static Bitmap ChangePasswordAD1 =>
            (Bitmap) ResourceManager.GetObject("ChangePasswordAD1", resourceCulture);

        internal static Bitmap ChangePasswordAD2 =>
            (Bitmap) ResourceManager.GetObject("ChangePasswordAD2", resourceCulture);

        internal static Bitmap edit_16px =>
            (Bitmap) ResourceManager.GetObject("edit_16px", resourceCulture);

        internal static Bitmap edit_24px =>
            (Bitmap) ResourceManager.GetObject("edit_24px", resourceCulture);

        internal static Bitmap NoImage =>
            (Bitmap) ResourceManager.GetObject("NoImage", resourceCulture);

        internal static Bitmap people__3_ =>
            (Bitmap) ResourceManager.GetObject("people (3)", resourceCulture);

        internal static Bitmap printer_25px =>
            (Bitmap) ResourceManager.GetObject("printer_25px", resourceCulture);

        internal static Bitmap refresh_24px =>
            (Bitmap) ResourceManager.GetObject("refresh_24px", resourceCulture);

        internal static Bitmap refresh_30px =>
            (Bitmap) ResourceManager.GetObject("refresh_30px", resourceCulture);

        internal static Bitmap Save =>
            (Bitmap) ResourceManager.GetObject("Save", resourceCulture);

        internal static Bitmap save_24px =>
            (Bitmap) ResourceManager.GetObject("save_24px", resourceCulture);

        internal static Bitmap search_16px =>
            (Bitmap) ResourceManager.GetObject("search_16px", resourceCulture);

        internal static Bitmap search_pink_16px =>
            (Bitmap) ResourceManager.GetObject("search_pink_16px", resourceCulture);

        internal static Bitmap submit_22px =>
            (Bitmap) ResourceManager.GetObject("submit_22px", resourceCulture);

        internal static Bitmap truck_24px =>
            (Bitmap) ResourceManager.GetObject("truck_24px", resourceCulture);

        internal static Bitmap undo_25px =>
            (Bitmap) ResourceManager.GetObject("undo_25px", resourceCulture);

        internal static Bitmap wbconnicon =>
            (Bitmap) ResourceManager.GetObject("wbconnicon", resourceCulture);
    }
}

