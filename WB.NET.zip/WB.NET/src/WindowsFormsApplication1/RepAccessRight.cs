﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Data;

    internal class RepAccessRight
    {
        public void generateRep()
        {
            string str = (((("SELECT a.autho_group AS autho_group, a.autho_menu AS autho_menu, a.autho_trustee AS autho_trustee, " + " g.name AS group_name, m.name AS menu_name " + " FROM wb_authorization a, wb_group g, wb_menu m") + " WHERE a.coy = g.coy " + " AND a.location_code = g.location_code") + " AND a.coy = '" + WBData.sCoyCode + "' ") + " AND a.location_code = '" + WBData.sLocCode + "' ") + " AND a.autho_group = g.code " + " AND a.autho_menu = m.code ";
            WBTable table = new WBTable();
            table.OpenTable("wb_group", str + " ORDER BY a.autho_group, a.autho_menu ", WBData.conn);
            HTML html = new HTML();
            html.File = html.File + @"\" + WBUser.UserID + "_AccessRight.htm";
            html.Title = "Access Right Report";
            html.Open();
            html.Write(html.Style());
            html.Write("<br><font size=5><b>ACCESS RIGHT REPORT</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", WBData.sCoyCode, ")</font>" };
            html.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            html.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            html.Write("<br><br><font size=2>Report Date : <b>" + DateTime.Now.ToShortDateString() + "</b></font><br>");
            html.Write("<br><br>");
            html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
            html.Write("<tr class=bd>");
            html.Write("<th rowspan=2>No.</th>");
            html.Write("<th rowspan=2>Group</th>");
            html.Write("<th rowspan=2>Group Name</th>");
            html.Write("<th rowspan=2>Authorization Code</th>");
            html.Write("<th rowspan=2>Authorization Description</th>");
            html.Write("<th colspan=5>Authorization</th>");
            html.Write("</tr>");
            html.Write("<tr class=bd>");
            html.Write("<th>View</th>");
            html.Write("<th>Add</th>");
            html.Write("<th>Edit</th>");
            html.Write("<th>Delete</th>");
            html.Write("<th>Print</th>");
            html.Write("</tr>");
            int num = 1;
            string str2 = "";
            foreach (DataRow row in table.DT.Rows)
            {
                html.Write("<tr class=bd>");
                html.Write("<td align='right'>" + num + "</td>");
                if (str2 != row["autho_group"].ToString())
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_authorization", str + " AND autho_group = '" + row["autho_group"].ToString() + "'", WBData.conn);
                    string[] textArray3 = new string[] { "<td rowspan=", table2.DT.Rows.Count.ToString(), " valign=top>", row["autho_group"].ToString(), "</td>" };
                    html.Write(string.Concat(textArray3));
                    string[] textArray4 = new string[] { "<td rowspan=", table2.DT.Rows.Count.ToString(), " align=center valign=top>", row["group_name"].ToString(), "</td>" };
                    html.Write(string.Concat(textArray4));
                    table2.Dispose();
                }
                str2 = row["autho_group"].ToString();
                html.Write("<td>" + row["autho_menu"].ToString() + "</td>");
                html.Write("<td>" + row["menu_name"].ToString() + "</td>");
                string[] strArray = new string[] { "V", "A", "E", "D", "P" };
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        html.Write("</tr>");
                        num++;
                        break;
                    }
                    if (row["autho_trustee"].ToString().Contains(strArray[index]))
                    {
                        html.Write("<td align='center'>&#10003</td>");
                    }
                    else
                    {
                        html.Write("<td align='center'>-</td>");
                    }
                    index++;
                }
            }
            html.Write("</table>");
            html.Write("<br>");
            html.Write("<br>");
            html.writeSign();
            html.Close();
            if (html != null)
            {
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + html.File) }
                };
                report.ShowDialog();
                html.Dispose();
                report.Dispose();
            }
            table.Dispose();
        }
    }
}

