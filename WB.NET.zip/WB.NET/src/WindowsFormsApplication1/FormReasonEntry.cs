﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormReasonEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dgv;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        public ComboBox cb_purpose;
        private Label label1;
        private Label label2;
        public TextBox txt_reason;
        private Button btn_save;
        private Button btn_cancel;

        public FormReasonEntry()
        {
            this.InitializeComponent();
            this.translate();
            this.txt_reason.CharacterCasing = CharacterCasing.Upper;
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.txt_reason };
            if (!Program.CheckEmpty(aText))
            {
                this.txt_reason.Text = this.txt_reason.Text.Trim();
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " and ( purpose ='", this.cb_purpose.Text.Trim(), "' AND reason ='", this.txt_reason.Text, "')" };
                table.OpenTable("wb_reason", "SELECT uniq FROM wb_reason WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Main_055 },
                            textRefNo = { Text = this.txt_reason.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    this.zTable.ReOpen();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["purpose"] = this.cb_purpose.Text;
                    this.zTable.DR["reason"] = this.txt_reason.Text;
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now;
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Change_By"] = WBUser.UserID;
                        this.zTable.DR["Change_Date"] = DateTime.Now;
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            string sqltext = (("SELECT uniq FROM wb_reason WHERE " + WBData.CompanyLocation("")) + " AND purpose = '" + this.cb_purpose.Text + "'") + " AND reason = '" + this.txt_reason.Text + "'";
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_reason", sqltext, WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_reason", this.logKey, logField, logValue);
                    }
                    this.saved = true;
                    Cursor.Current = Cursors.Default;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044);
                    this.txt_reason.Focus();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormReasonEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.cb_purpose.Items.Clear();
            this.cb_purpose.Items.Add("REASON_REPRINT_TICKET");
            if (this.pMode != "ADD")
            {
                this.cb_purpose.Text = this.dgv.Rows[this.zTable.dataGridPosRow].Cells["purpose"].Value.ToString();
                this.txt_reason.Text = this.dgv.Rows[this.zTable.dataGridPosRow].Cells["reason"].Value.ToString();
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.btn_cancel.Text = Resource.Btn_Close;
                this.btn_cancel.Enabled = true;
            }
            if (this.pMode == "EDIT")
            {
                this.cb_purpose.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.cb_purpose = new ComboBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.txt_reason = new TextBox();
            this.btn_save = new Button();
            this.btn_cancel = new Button();
            base.SuspendLayout();
            this.cb_purpose.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cb_purpose.FormattingEnabled = true;
            this.cb_purpose.Location = new Point(0x54, 12);
            this.cb_purpose.Name = "cb_purpose";
            this.cb_purpose.Size = new Size(0xb0, 0x15);
            this.cb_purpose.TabIndex = 1;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2e, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Purpose";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x2a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2c, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Reason";
            this.txt_reason.Location = new Point(0x54, 0x27);
            this.txt_reason.Name = "txt_reason";
            this.txt_reason.Size = new Size(420, 20);
            this.txt_reason.TabIndex = 4;
            this.txt_reason.TextChanged += new EventHandler(this.txt_reason_TextChanged);
            this.btn_save.Location = new Point(0x15c, 0x41);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new Size(0x4b, 0x17);
            this.btn_save.TabIndex = 5;
            this.btn_save.Text = "&Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.btn_cancel.Location = new Point(0x1ad, 0x41);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x17);
            this.btn_cancel.TabIndex = 6;
            this.btn_cancel.Text = "&Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x220, 0x6b);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_save);
            base.Controls.Add(this.txt_reason);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.cb_purpose);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormReasonEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Reason";
            base.Load += new EventHandler(this.FormReasonEntry_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Gatepass_043;
            this.label2.Text = Resource.Main_055;
            this.btn_save.Text = Resource.Btn_Save;
            this.btn_cancel.Text = Resource.Btn_Cancel;
        }

        private void txt_reason_TextChanged(object sender, EventArgs e)
        {
        }
    }
}

