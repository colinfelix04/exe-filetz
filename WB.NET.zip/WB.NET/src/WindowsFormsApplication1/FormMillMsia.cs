﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMillMsia : Form
    {
        public string mill = "";
        public int nCurrRow;
        public int num_of_mill = 0;
        public string[,] map_mill = new string[0x3e7, 14];
        public string relation_code = "";
        public string DATA_FROM = "";
        private IContainer components = null;
        private DataGridView dgv_mill;
        private ToolStripMenuItem chooseStripMenuItem1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Button buttonFind;
        public MenuStrip menuStrip1;
        public Panel panel1;
        private Button btn_refresh;
        private RadioButton rb_all;
        private RadioButton rb_vendor;

        public FormMillMsia()
        {
            this.InitializeComponent();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_sap_mill", "DELETE FROM wb_sap_mill WHERE 1 = 1", WBData.conn);
            table.OpenTable("wb_sap_mill", "SELECT * FROM wb_sap_mill WHERE 1 = 1", WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.num_of_mill)
                    {
                        table.Save();
                        break;
                    }
                    table.DR = table.DT.NewRow();
                    if (this.map_mill[num, 5] != "X")
                    {
                        table.DR["mill_code"] = this.map_mill[num, 2];
                        table.DR["mill_name"] = this.map_mill[num, 3];
                        table.DR["relation_code"] = this.map_mill[num, 13];
                        table.DT.Rows.Add(table.DR);
                    }
                    num++;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            string text = this.TextFind.Text;
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            bool flag4 = false;
            bool flag5 = false;
            bool flag7 = false;
            string str2 = "";
            int num = 0;
            while (true)
            {
                if (num >= text.Length)
                {
                    if (flag5 & flag7)
                    {
                        flag3 = true;
                    }
                    else if (flag7)
                    {
                        flag4 = true;
                    }
                    else if (flag5)
                    {
                        flag2 = true;
                    }
                    this.dgv_mill.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    try
                    {
                        foreach (DataGridViewRow row in (IEnumerable) this.dgv_mill.Rows)
                        {
                            if ((!flag2 && !flag3) && !flag4)
                            {
                                if (!row.Cells[0].Value.ToString().Equals(str2))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else if (flag2)
                            {
                                if (row.Cells[0].Value.ToString().IndexOf(str2) != 0)
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else if (flag3)
                            {
                                if ((row.Cells[0].Value.ToString().IndexOf(str2) <= 0) || (row.Cells[0].Value.ToString().IndexOf(str2) >= (row.Cells[0].Value.ToString().Length - 1)))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            else
                            {
                                if (!flag4 || (row.Cells[0].Value.ToString().IndexOf(str2) != (row.Cells[0].Value.ToString().Length - str2.Length)))
                                {
                                    continue;
                                }
                                row.Selected = true;
                                flag = true;
                            }
                            break;
                        }
                        if (!flag)
                        {
                            MessageBox.Show("Record is not found!");
                        }
                        else
                        {
                            this.dgv_mill.FirstDisplayedScrollingRowIndex = this.dgv_mill.SelectedRows[0].Index;
                        }
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show("Searching: " + exception.Message);
                    }
                    return;
                }
                char ch = text[num];
                if (ch.ToString() != "*")
                {
                    str2 = str2 + text[num].ToString();
                }
                else if (num == 0)
                {
                    flag7 = true;
                }
                else if (num == (text.Length - 1))
                {
                    flag5 = true;
                }
                num++;
            }
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.mill = this.dgv_mill.CurrentRow.Cells["MILL_CODE"].Value.ToString();
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.mill = "";
            base.Close();
        }

        private void dgv_mill_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.mill = this.dgv_mill.CurrentRow.Cells["MILL_CODE"].Value.ToString();
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMillMsia_Load(object sender, EventArgs e)
        {
            int num = 0;
            if (this.num_of_mill > 0)
            {
                this.dgv_mill.ColumnCount = 3;
                this.dgv_mill.Columns[num].Name = "RELATION_CODE";
                this.dgv_mill.Columns[num].HeaderText = "Relation Code";
                num++;
                this.dgv_mill.Columns[num].Name = "MILL_CODE";
                this.dgv_mill.Columns[num].HeaderText = "Mill Code";
                num++;
                this.dgv_mill.Columns[num].Name = "MILL_DESC";
                this.dgv_mill.Columns[num].HeaderText = "Mill Description";
                if (this.relation_code == "")
                {
                    this.rb_all.Checked = true;
                    this.rb_vendor.Visible = false;
                    this.rb_all.Visible = false;
                }
                this.trigger_checkbox();
                this.dgv_mill.Sort(this.dgv_mill.Columns["MILL_CODE"], ListSortDirection.Ascending);
            }
        }

        private void InitializeComponent()
        {
            this.dgv_mill = new DataGridView();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            this.panel1 = new Panel();
            this.btn_refresh = new Button();
            this.rb_vendor = new RadioButton();
            this.rb_all = new RadioButton();
            ((ISupportInitialize) this.dgv_mill).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dgv_mill.AllowUserToAddRows = false;
            this.dgv_mill.AllowUserToDeleteRows = false;
            this.dgv_mill.AllowUserToResizeRows = false;
            this.dgv_mill.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_mill.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgv_mill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mill.Dock = DockStyle.Fill;
            this.dgv_mill.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgv_mill.Location = new Point(0, 0x18);
            this.dgv_mill.MultiSelect = false;
            this.dgv_mill.Name = "dgv_mill";
            this.dgv_mill.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgv_mill.Size = new Size(0x2c8, 0x185);
            this.dgv_mill.TabIndex = 0x13;
            this.dgv_mill.CellDoubleClick += new DataGridViewCellEventHandler(this.dgv_mill_CellDoubleClick);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x37, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x2d, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x2c8, 0x18);
            this.menuStrip1.TabIndex = 0x15;
            this.menuStrip1.Text = "menuStrip1";
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.rb_all);
            this.panel1.Controls.Add(this.rb_vendor);
            this.panel1.Controls.Add(this.btn_refresh);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x19d);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2c8, 0x23);
            this.panel1.TabIndex = 20;
            this.btn_refresh.Location = new Point(0x271, 4);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new Size(0x4b, 0x17);
            this.btn_refresh.TabIndex = 0x16;
            this.btn_refresh.Text = "Replace Mill";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new EventHandler(this.btn_refresh_Click);
            this.rb_vendor.AutoSize = true;
            this.rb_vendor.Checked = true;
            this.rb_vendor.Location = new Point(0x120, 7);
            this.rb_vendor.Name = "rb_vendor";
            this.rb_vendor.Size = new Size(0xa5, 0x11);
            this.rb_vendor.TabIndex = 0x17;
            this.rb_vendor.TabStop = true;
            this.rb_vendor.Text = "Mill from Contract Vendor only";
            this.rb_vendor.UseVisualStyleBackColor = true;
            this.rb_vendor.CheckedChanged += new EventHandler(this.rb_vendor_CheckedChanged);
            this.rb_all.AutoSize = true;
            this.rb_all.Location = new Point(0x1de, 7);
            this.rb_all.Name = "rb_all";
            this.rb_all.Size = new Size(0x3b, 0x11);
            this.rb_all.TabIndex = 0x18;
            this.rb_all.Text = "All Mills";
            this.rb_all.UseVisualStyleBackColor = true;
            this.rb_all.CheckedChanged += new EventHandler(this.rb_all_CheckedChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2c8, 0x1c0);
            base.Controls.Add(this.dgv_mill);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormMillMsia";
            this.Text = "Choose Mill";
            base.Load += new EventHandler(this.FormMillMsia_Load);
            ((ISupportInitialize) this.dgv_mill).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void rb_all_CheckedChanged(object sender, EventArgs e)
        {
            this.trigger_checkbox();
        }

        private void rb_vendor_CheckedChanged(object sender, EventArgs e)
        {
            this.trigger_checkbox();
        }

        private void trigger_checkbox()
        {
            if (this.DATA_FROM != "RFC")
            {
                if (this.DATA_FROM != "DB")
                {
                    return;
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_sap_mill", "select c.relation_code, c.mill, m.mill_name from wb_contract c \r\n                    left join wb_sap_mill m on c.mill = m.mill_code \r\n                    where c.mill <> '' \r\n                    group by c.relation_code, c.mill, m.mill_name \r\n                    order by c.Relation_Code", WBData.conn);
                    this.dgv_mill.Rows.Clear();
                    int num3 = 0;
                    if (table.DT.Rows.Count > 0)
                    {
                        foreach (DataRow row in table.DT.Rows)
                        {
                            this.dgv_mill.Rows.Add();
                            this.dgv_mill.Rows[num3].Cells[0].Value = row["relation_code"].ToString();
                            this.dgv_mill.Rows[num3].Cells[1].Value = row["mill"].ToString();
                            this.dgv_mill.Rows[num3].Cells[2].Value = row["mill_name"].ToString();
                            num3++;
                        }
                    }
                }
            }
            else
            {
                this.dgv_mill.Rows.Clear();
                int num = 0;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.num_of_mill)
                    {
                        break;
                    }
                    bool flag2 = this.map_mill[num2, 5] == "X";
                    if (!flag2 && !(this.rb_vendor.Checked && (this.map_mill[num2, 13].Trim() != this.relation_code.Trim())))
                    {
                        this.dgv_mill.Rows.Add();
                        this.dgv_mill.Rows[num].Cells[0].Value = this.map_mill[num2, 13];
                        this.dgv_mill.Rows[num].Cells[1].Value = this.map_mill[num2, 2];
                        this.dgv_mill.Rows[num].Cells[2].Value = this.map_mill[num2, 3];
                        num++;
                    }
                    num2++;
                }
                return;
            }
            this.btn_refresh.Visible = false;
        }
    }
}

