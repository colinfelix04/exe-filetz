﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCompareDB : Form
    {
        private string str_conn;
        private SqlConnection conn;
        private SqlConnection conn2;
        private SqlConnection connInsert;
        private string sqlInsert;
        private string sField = "";
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private TextBox textServer;
        private Button BtnClose;
        private Button BtnProcess;
        private Label labelProgress;
        private ShapeContainer shapeContainer1;
        private RectangleShape rectangleShape1;
        private Label label3;
        private Label label4;
        private TextBox textDatabase;
        private Label label5;
        private TextBox textUser;
        private Label label6;
        private TextBox textPassword;
        private CheckBox checkInsert;
        private CheckBox checkInsertAll;

        public FormCompareDB()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = this.textServer.Text;
            textArray1[2] = "; database=";
            textArray1[3] = this.textDatabase.Text;
            textArray1[4] = "; uid=";
            textArray1[5] = this.textUser.Text;
            textArray1[6] = "; password=";
            textArray1[7] = this.textPassword.Text;
            textArray1[8] = ";";
            this.str_conn = string.Concat(textArray1);
            this.conn = new SqlConnection(this.str_conn);
            this.connInsert = new SqlConnection(this.str_conn);
            SqlCommand command = this.conn.CreateCommand();
            command.CommandText = "SELECT table_name AS Name FROM INFORMATION_SCHEMA.Tables WHERE TABLE_TYPE = 'BASE TABLE' Order By table_name";
            try
            {
                this.conn.Open();
                SqlDataReader reader = command.ExecuteReader();
                HTML html = new HTML {
                    File = Application.StartupPath + @"\" + WBUser.UserID + "_Compare.htm",
                    Title = "Database Comparison"
                };
                html.Open();
                html.Write(html.Style());
                html.Write("<head><meta charset='UTF-8'></head>");
                html.Write("<font size=3>RESULT OF COMPARISON TO : " + this.textServer.Text + "</font><br><br>");
                while (true)
                {
                    if (!reader.Read())
                    {
                        Cursor.Current = Cursors.Default;
                        html.Close();
                        ViewReport report = new ViewReport {
                            webBrowser1 = { Url = new Uri("file:///" + html.File) }
                        };
                        report.ShowDialog();
                        html.Dispose();
                        report.Dispose();
                        break;
                    }
                    string tablename = (string) reader[0];
                    this.labelProgress.Text = tablename;
                    this.labelProgress.Refresh();
                    if (tablename.Substring(0, 3) == "wb_")
                    {
                        string sqltext = "Select ORDINAL_POSITION as NO, COLUMN_NAME as FIELD, DATA_TYPE as TYPE, CHARACTER_MAXIMUM_LENGTH as LENGTH, IS_NULLABLE as ISNULL from INFORMATION_SCHEMA.COLUMNS WHERE table_name ='" + tablename + "'";
                        if (this.checkInsert.Checked)
                        {
                            this.sqlInsert = " Alter table " + tablename + " ADD ";
                            this.sField = "";
                        }
                        table.OpenTable(tablename, sqltext, WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            string[] textArray2 = new string[] { "TABLE : ", tablename, " Does Not Exist in database ", WBData.sDatabase, " <br>" };
                            html.Write(string.Concat(textArray2));
                            html.Write("<br>");
                        }
                        this.conn2 = new SqlConnection(this.str_conn);
                        try
                        {
                            this.conn2.Open();
                        }
                        catch (Exception exception2)
                        {
                            MessageBox.Show("Error of Database Connection : \n\n" + exception2.Message, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            break;
                        }
                        table2.OpenTable(tablename, sqltext, this.conn2);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            string[] textArray3 = new string[] { "TABLE : ", tablename, " Does Not Exist in database ", this.textDatabase.Text, " <br>" };
                            html.Write(string.Concat(textArray3));
                            html.Write("<br>");
                        }
                        bool flag2 = false;
                        bool flag3 = false;
                        foreach (DataRow row in table.DT.Rows)
                        {
                            flag3 = false;
                            string[] aField = new string[] { "FIELD" };
                            string[] aFind = new string[] { row["FIELD"].ToString() };
                            int recNo = table2.GetRecNo(aField, aFind);
                            if (recNo < 0)
                            {
                                flag3 = true;
                            }
                            else
                            {
                                if (row["TYPE"].ToString() != table2.DT.Rows[recNo]["TYPE"].ToString())
                                {
                                    flag3 = true;
                                }
                                if (row["LENGTH"].ToString() != table2.DT.Rows[recNo]["LENGTH"].ToString())
                                {
                                    flag3 = true;
                                }
                                if (row["ISNULL"].ToString() != table2.DT.Rows[recNo]["ISNULL"].ToString())
                                {
                                    flag3 = true;
                                }
                            }
                            if (flag3)
                            {
                                if (!flag2)
                                {
                                    flag2 = true;
                                    html.Write("TABLE : " + tablename + "<br>");
                                    html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                    html.Write("<tr class='bd'>");
                                    foreach (DataColumn column in table.DT.Columns)
                                    {
                                        html.Write("<td nowrap>" + column.ColumnName + "</td>");
                                    }
                                    html.Write("<td nowrap>DESCRIPTION</td>");
                                    html.Write("</tr>");
                                }
                                html.Write("<tr class='bd'>");
                                foreach (DataColumn column2 in table.DT.Columns)
                                {
                                    html.Write("<td nowrap>" + html.strq(row[column2.ColumnName].ToString()) + "</td>");
                                }
                                if (recNo >= 0)
                                {
                                    html.Write("<td nowrap>Different</td>");
                                }
                                else
                                {
                                    html.Write("<td nowrap>Field does not exist</td>");
                                    if (this.checkInsert.Checked)
                                    {
                                        if (row["LENGTH"].ToString() == "")
                                        {
                                            string[] textArray7 = new string[] { this.sField, " ", row["FIELD"].ToString(), " ", row["TYPE"].ToString(), "," };
                                            this.sField = string.Concat(textArray7);
                                        }
                                        else if (Convert.ToInt16(row["LENGTH"].ToString()) > 0)
                                        {
                                            string[] textArray6 = new string[] { this.sField, " ", row["FIELD"].ToString(), " ", row["TYPE"].ToString(), "(", row["LENGTH"].ToString(), ") ," };
                                            this.sField = string.Concat(textArray6);
                                        }
                                    }
                                }
                                html.Write("</tr>");
                            }
                        }
                        if (flag2)
                        {
                            html.Write("</table>");
                            html.Write("<br>");
                            html.Write("<br>");
                        }
                        if (this.checkInsert.Checked && (this.sField.Length > 0))
                        {
                            this.sField = this.sField.Substring(0, this.sField.Length - 1);
                            this.sqlInsert = this.sqlInsert + this.sField;
                            SqlCommand command2 = this.connInsert.CreateCommand();
                            command2.CommandText = this.sqlInsert;
                            try
                            {
                                this.connInsert.Open();
                                try
                                {
                                    if (this.checkInsertAll.Checked)
                                    {
                                        command2.ExecuteNonQuery();
                                        MessageBox.Show("Insert to table " + tablename + " Success");
                                    }
                                    else if (tablename.Substring(0, 6) != "wb_tra")
                                    {
                                        command2.ExecuteNonQuery();
                                        MessageBox.Show("Insert to table " + tablename + " Success");
                                    }
                                }
                                catch (Exception exception4)
                                {
                                    MessageBox.Show("Error Insert : \n\n" + exception4.Message, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                this.connInsert.Close();
                                continue;
                            }
                            catch (Exception exception3)
                            {
                                MessageBox.Show("Error of Database Connection : \n\n" + exception3.Message, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            break;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error of Database Connection : \n\n" + exception.Message, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCompareDB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCompareDB_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProgress.Text = "";
            this.textServer.Text = WBData.sServer;
            this.textDatabase.Text = WBData.sDatabase;
            this.textUser.Text = WBData.sUserID;
            this.textPassword.Text = WBData.sPassword;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.textServer = new TextBox();
            this.BtnClose = new Button();
            this.BtnProcess = new Button();
            this.labelProgress = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textDatabase = new TextBox();
            this.label5 = new Label();
            this.textUser = new TextBox();
            this.label6 = new Label();
            this.textPassword = new TextBox();
            this.checkInsert = new CheckBox();
            this.checkInsertAll = new CheckBox();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x26, 0x12);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0xa1, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Database : WBSYSTEM";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(40, 0x34);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Compare With  :";
            this.textServer.Location = new Point(0x84, 0x52);
            this.textServer.Name = "textServer";
            this.textServer.Size = new Size(0xcf, 20);
            this.textServer.TabIndex = 1;
            this.BtnClose.Location = new Point(0x108, 0xe5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new Size(0x4b, 0x23);
            this.BtnClose.TabIndex = 12;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new EventHandler(this.button3_Click);
            this.BtnProcess.Location = new Point(0x84, 0xe5);
            this.BtnProcess.Name = "BtnProcess";
            this.BtnProcess.Size = new Size(0x4b, 0x23);
            this.BtnProcess.TabIndex = 7;
            this.BtnProcess.Text = "Process";
            this.BtnProcess.UseVisualStyleBackColor = true;
            this.BtnProcess.Click += new EventHandler(this.button1_Click);
            this.labelProgress.AutoSize = true;
            this.labelProgress.Dock = DockStyle.Bottom;
            this.labelProgress.Location = new Point(0, 290);
            this.labelProgress.Name = "labelProgress";
            this.labelProgress.Size = new Size(0x3f, 13);
            this.labelProgress.TabIndex = 13;
            this.labelProgress.Text = "Progress.....";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x197, 0x12f);
            this.shapeContainer1.TabIndex = 14;
            this.shapeContainer1.TabStop = false;
            this.rectangleShape1.Location = new Point(0x1f, 0x42);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x147, 0x86);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x55, 0x55);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x26, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Server";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x2a, 0x6f);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x54, 13);
            this.label4.TabIndex = 0x11;
            this.label4.Text = "Database Name";
            this.textDatabase.Location = new Point(0x84, 0x6c);
            this.textDatabase.Name = "textDatabase";
            this.textDatabase.Size = new Size(0xcf, 20);
            this.textDatabase.TabIndex = 2;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x61, 0x89);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x1d, 13);
            this.label5.TabIndex = 0x13;
            this.label5.Text = "User";
            this.textUser.Location = new Point(0x84, 0x86);
            this.textUser.Name = "textUser";
            this.textUser.Size = new Size(0xcf, 20);
            this.textUser.TabIndex = 3;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(70, 0xa3);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x35, 13);
            this.label6.TabIndex = 0x15;
            this.label6.Text = "Password";
            this.textPassword.Location = new Point(0x84, 160);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new Size(0xcf, 20);
            this.textPassword.TabIndex = 4;
            this.checkInsert.AutoSize = true;
            this.checkInsert.Location = new Point(30, 0xca);
            this.checkInsert.Name = "checkInsert";
            this.checkInsert.Size = new Size(200, 0x11);
            this.checkInsert.TabIndex = 5;
            this.checkInsert.Text = "Insert to Table if Field Does Not Exist";
            this.checkInsert.UseVisualStyleBackColor = true;
            this.checkInsertAll.AutoSize = true;
            this.checkInsertAll.Location = new Point(0x108, 0xca);
            this.checkInsertAll.Name = "checkInsertAll";
            this.checkInsertAll.Size = new Size(110, 0x11);
            this.checkInsertAll.TabIndex = 6;
            this.checkInsertAll.Text = "Insert to wb_trans";
            this.checkInsertAll.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x197, 0x12f);
            base.Controls.Add(this.checkInsertAll);
            base.Controls.Add(this.checkInsert);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textPassword);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textUser);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textDatabase);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelProgress);
            base.Controls.Add(this.BtnClose);
            base.Controls.Add(this.BtnProcess);
            base.Controls.Add(this.textServer);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "FormCompareDB";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Compare DB";
            base.Load += new EventHandler(this.FormCompareDB_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCompareDB_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

