﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormMaintainActivationKey : Form
    {
        private IContainer components = null;
        private Label label4;
        private DataGridView dgvActivation;
        private Label label1;
        private Button buttonDelete;
        private Button button1;

        public FormMaintainActivationKey()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (this.dgvActivation.RowCount > 0)
            {
                int index = this.dgvActivation.CurrentRow.Index;
                string str = this.dgvActivation.Rows[index].Cells["WBCODE"].Value.ToString();
                string str2 = this.dgvActivation.Rows[index].Cells["COMPUTERNAME"].Value.ToString();
                string[] textArray1 = new string[] { "Are you sure to delete activation code for WB code ", str, " (computer name ", str2, ")?", Environment.NewLine, "Deleting activation code will remove weighing feature for that PC." };
                if (MessageBox.Show(string.Concat(textArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    WBTable table = new WBTable();
                    table.OpenTable("wb_act", "SELECT * FROM wb_act WHERE UNIQ = '" + this.dgvActivation.Rows[index].Cells["UNIQ"].Value.ToString() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        table.DT.Rows[0].Delete();
                        table.Save();
                    }
                    table.Dispose();
                    this.dgvActivation.Rows.Remove(this.dgvActivation.Rows[index]);
                    Cursor.Current = Cursors.Default;
                    string[] textArray2 = new string[] { "Deleting activation code for WB code ", str, " (computer name ", str2, ") is success!" };
                    MessageBox.Show(string.Concat(textArray2), "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMaintainActivationKey_Load(object sender, EventArgs e)
        {
            this.dgvActivation.ColumnCount = 4;
            this.dgvActivation.Columns[0].Name = "WBCODE";
            this.dgvActivation.Columns[1].Name = "COMPUTERNAME";
            this.dgvActivation.Columns[2].Name = "ACTIVATEDON";
            this.dgvActivation.Columns[3].Name = "UNIQ";
            this.dgvActivation.Columns["WBCODE"].HeaderText = "WB Code";
            this.dgvActivation.Columns["COMPUTERNAME"].HeaderText = "Computer Name";
            this.dgvActivation.Columns["ACTIVATEDON"].HeaderText = "Activated on";
            this.dgvActivation.Columns["UNIQ"].Visible = false;
            WBTable sourceTable = new WBTable();
            sourceTable.OpenTable("wb_act", "SELECT * FROM wb_act WHERE 1 = 1", WBData.conn);
            DataTable table2 = WBUtility.WBTableToDataTable(sourceTable, null);
            int num = 0;
            while (true)
            {
                if (num >= table2.Rows.Count)
                {
                    DataRow[] rowArray = table2.Select(" param LIKE 'WB%' ");
                    int index = 0;
                    while (true)
                    {
                        if (index >= rowArray.Length)
                        {
                            sourceTable.Dispose();
                            return;
                        }
                        char[] separator = new char[] { '|' };
                        string[] strArray = rowArray[index][0].ToString().Split(separator);
                        object[] values = new object[] { strArray[1], strArray[2], rowArray[index][1], rowArray[index][2] };
                        this.dgvActivation.Rows.Add(values);
                        index++;
                    }
                }
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table2.Columns.Count)
                    {
                        num++;
                        break;
                    }
                    if (table2.Columns[num2].ColumnName.ToUpper() != "UNIQ")
                    {
                        table2.Rows[num][num2] = WBEncryption.Decrypt(table2.Rows[num][num2].ToString(), "encryptDATA");
                    }
                    num2++;
                }
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.label4 = new Label();
            this.dgvActivation = new DataGridView();
            this.label1 = new Label();
            this.buttonDelete = new Button();
            this.button1 = new Button();
            ((ISupportInitialize) this.dgvActivation).BeginInit();
            base.SuspendLayout();
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x18, 0x1d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0xbb, 0x12);
            this.label4.TabIndex = 7;
            this.label4.Text = "Usage of Activation Key";
            this.dgvActivation.AllowUserToAddRows = false;
            this.dgvActivation.AllowUserToDeleteRows = false;
            this.dgvActivation.AllowUserToResizeRows = false;
            this.dgvActivation.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvActivation.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvActivation.ColumnHeadersDefaultCellStyle = style;
            this.dgvActivation.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvActivation.DefaultCellStyle = style2;
            this.dgvActivation.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvActivation.Location = new Point(0x1b, 90);
            this.dgvActivation.MultiSelect = false;
            this.dgvActivation.Name = "dgvActivation";
            this.dgvActivation.ReadOnly = true;
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvActivation.RowHeadersDefaultCellStyle = style3;
            this.dgvActivation.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvActivation.Size = new Size(0x1db, 0x94);
            this.dgvActivation.TabIndex = 8;
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x18, 0x45);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x137, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Below is list of computer(s) using WB.Net activation key. ";
            this.buttonDelete.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonDelete.Location = new Point(0x1b, 0xf9);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x81, 0x2e);
            this.buttonDelete.TabIndex = 11;
            this.buttonDelete.Text = "Delete Activation Key";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(400, 0xf9);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x66, 0x2e);
            this.button1.TabIndex = 12;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x213, 0x13f);
            base.ControlBox = false;
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonDelete);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.dgvActivation);
            base.Controls.Add(this.label4);
            base.Name = "FormMaintainActivationKey";
            base.StartPosition = FormStartPosition.CenterScreen;
            base.Load += new EventHandler(this.FormMaintainActivationKey_Load);
            ((ISupportInitialize) this.dgvActivation).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

