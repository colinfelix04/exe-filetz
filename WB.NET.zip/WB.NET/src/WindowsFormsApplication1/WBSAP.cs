﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Linq;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class WBSAP : Component
    {
        public static RfcConfigParameters rfcParams;
        public static RfcDestination rfcDest;
        public static RfcRepository rfcRep;
        public static IRfcFunction rfcFunction;
        public static IRfcTable rfcTable;
        public static IRfcTable rfcTable2;
        public static string[] result = new string[3];
        public static string[] result_trans = new string[4];
        public static DataTable retTable;
        public static DataTable retImport;

        public static void appendTable(string[] zwbRow)
        {
            rfcTable.Append();
            for (int i = 0; i < zwbRow.Length; i++)
            {
                rfcTable.SetValue(i, zwbRow[i].ToString());
            }
        }

        public static bool connect()
        {
            try
            {
                WBSetting.OpenSetting();
                rfcParams = new RfcConfigParameters();
                rfcParams.Add("NAME", "TEST_SAP");
                rfcParams.Add("USER", WBSetting.Field("SAPLoginID"));
                rfcParams.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                rfcParams.Add("SYSNR", "03");
                rfcParams.Add("CLIENT", WBSetting.Field("SAPClient"));
                rfcParams.Add("IDLE_TIMEOUT", "10");
                rfcParams.Add("MSHOST", WBSetting.Field("SAPServer"));
                rfcParams.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                rfcParams.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                rfcParams.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                rfcDest = RfcDestinationManager.GetDestination(rfcParams);
                rfcRep = rfcDest.Repository;
                return true;
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return false;
        }

        public static void getAllResult(DataTable updTable, DataTable zReturn, string zField)
        {
            int count = 0;
            count = updTable.Rows.Count;
            zReturn.Rows.Clear();
            if (retImport.Rows.Count > 0)
            {
                int num2 = 0;
                while (true)
                {
                    if (num2 >= retImport.Rows.Count)
                    {
                        break;
                    }
                    result[0] = retImport.Rows[num2][0].ToString();
                    result[1] = retImport.Rows[num2][1].ToString();
                    result[2] = retImport.Rows[num2][2].ToString();
                    zReturn.Rows.Add(result);
                    num2++;
                }
            }
            int num3 = 0;
            while (true)
            {
                if (num3 >= count)
                {
                    retTable = zReturn;
                    if (retImport.Rows.Count > 0)
                    {
                        retImport.Rows.Clear();
                        retImport.Dispose();
                    }
                    return;
                }
                result[0] = rfcTable[num3].GetString(zField);
                result[1] = rfcTable[num3].GetString("stat");
                result[2] = rfcTable[num3].GetString("rfc_Text");
                zReturn.Rows.Add(result);
                num3++;
            }
        }

        public static string[] getResult()
        {
            result[0] = "";
            result[1] = rfcTable.GetString("stat");
            result[2] = rfcTable.GetString("rfc_Text");
            return result;
        }

        public static void getTransResult(DataTable updTable, DataTable zReturn, string zField)
        {
            int count = 0;
            count = updTable.Rows.Count;
            zReturn.Rows.Clear();
            if (retImport.Rows.Count > 0)
            {
                int num2 = 0;
                while (true)
                {
                    if (num2 >= retImport.Rows.Count)
                    {
                        break;
                    }
                    result_trans[0] = retImport.Rows[num2][0].ToString();
                    result_trans[1] = retImport.Rows[num2][1].ToString();
                    result_trans[2] = retImport.Rows[num2][2].ToString();
                    result_trans[3] = retImport.Rows[num2][3].ToString();
                    zReturn.Rows.Add(result_trans);
                    num2++;
                }
            }
            int num3 = 0;
            while (true)
            {
                if (num3 >= count)
                {
                    retTable = zReturn;
                    if (retImport.Rows.Count > 0)
                    {
                        retImport.Rows.Clear();
                        retImport.Dispose();
                    }
                    return;
                }
                result_trans[0] = rfcTable[num3].GetString(zField);
                result_trans[1] = rfcTable[num3].GetString("stat");
                result_trans[2] = rfcTable[num3].GetString("rfc_Text");
                result_trans[3] = rfcTable[num3].GetString("restat");
                zReturn.Rows.Add(result_trans);
                num3++;
            }
        }

        public static void importResult(string[] result)
        {
            retImport.Rows.Add(result);
        }

        public static string[] RFC_GET_REF_OP(string OP_REF)
        {
            string[] strArray = new string[] { "" };
            string str = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            try
            {
                rfcFunction = rfcRep.CreateFunction("ZRFC_ZWB_TO_WBNET");
                rfcFunction.SetValue("TICKET", OP_REF);
                rfcFunction.Invoke(rfcDest);
                IRfcTable table = rfcFunction.GetTable("ITAB_ZWB");
                if (rfcFunction.GetValue("MSG_ERR").ToString() != "")
                {
                    strArray[0] = "Error";
                    MessageBox.Show("Error from " + str + " : " + rfcFunction.GetValue("MSG_ERR").ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    strArray[1] = table.GetString("WBRUTOPB");
                    strArray[2] = table.GetString("WTARRAPB");
                    strArray[3] = table.GetString("WNETTOPB2");
                }
            }
            catch (Exception exception)
            {
                strArray[0] = "Error";
                MessageBox.Show("Error from SAP: " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return strArray;
        }

        public static void sendTable(DataTable updTable)
        {
            int count = 0;
            count = updTable.Rows.Count;
            rfcTable.Append(count);
            int num2 = 0;
            while (num2 < count)
            {
                DataRow row = updTable.Rows[num2];
                int index = 0;
                while (true)
                {
                    if (index >= row.ItemArray.Count<object>())
                    {
                        num2++;
                        break;
                    }
                    rfcTable[num2].SetValue(index, row[index].ToString());
                    index++;
                }
            }
        }

        public static void sendZWB()
        {
            rfcFunction.Invoke(rfcDest);
        }

        public static void setImportReturn()
        {
            retImport = new DataTable();
            DataColumn column = new DataColumn {
                ColumnName = "Ref"
            };
            retImport.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Status"
            };
            retImport.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Remark"
            };
            retImport.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Repost"
            };
            retImport.Columns.Add(column);
            column.Dispose();
        }

        public static void setReturnTable()
        {
            retTable = new DataTable();
            DataColumn column = new DataColumn {
                ColumnName = "Ref"
            };
            retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Status"
            };
            retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Remark"
            };
            retTable.Columns.Add(column);
            column.Dispose();
        }

        public static void showResult(DataTable zTable)
        {
            FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                aTable = zTable
            };
            return2.ShowDialog();
            return2.Dispose();
        }

        public static void showReturn()
        {
            showResult(retTable);
        }

        public static void SyncCommTrx()
        {
            string str = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            if (WBSetting.GrCustRequired == "Y")
            {
                try
                {
                    if (!WBSetting.activeMulesoftIntegration)
                    {
                        WBSetting.OpenSetting();
                        if (connect())
                        {
                            rfcFunction = rfcRep.CreateFunction("ZRFC_DNET_WB_SYNC_GET");
                            rfcFunction.SetValue("P_BUKRS", WBData.sCoyCode);
                            rfcFunction.SetValue("P_ZWB_LOC", WBData.sLocCode);
                            sendZWB();
                            rfcTable = rfcFunction.GetTable("I_RECORD");
                            if (rfcTable[0].GetString("SYNC").ToString() == "N")
                            {
                                try
                                {
                                    rfcFunction = rfcRep.CreateFunction("ZRFC_DNET_ADOPT_MAP_COMM_TRX");
                                    rfcTable = rfcFunction.GetTable("I_RECORD");
                                    sendZWB();
                                    int num2 = 0;
                                    WBTable table2 = new WBTable();
                                    table2.OpenTable("wb_ContractGrCust", "Select * From wb_contract_GRCust where 1=1", WBData.conn);
                                    foreach (DataRow row2 in table2.DT.Rows)
                                    {
                                        row2.Delete();
                                        num2++;
                                    }
                                    table2.Save();
                                    table2.ReOpen();
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= rfcTable.RowCount)
                                        {
                                            table2.Save();
                                            WBSetting.OpenSetting();
                                            if (connect())
                                            {
                                                rfcFunction = rfcRep.CreateFunction("ZRFC_DNET_WB_SYNC_SET");
                                                rfcFunction.SetValue("P_BUKRS", WBData.sCoyCode);
                                                rfcFunction.SetValue("P_ZWB_LOC", WBData.sLocCode);
                                                rfcFunction.SetValue("P_CDESC", WBData.sCoyName + " " + WBSetting.sLocName);
                                                sendZWB();
                                            }
                                            break;
                                        }
                                        table2.DR = table2.DT.NewRow();
                                        table2.DR["Comm_code"] = rfcTable[num3].GetValue("COMM").ToString();
                                        table2.DR["Transaction_code"] = rfcTable[num3].GetValue("STATUS").ToString();
                                        table2.DT.Rows.Add(table2.DR);
                                        num3++;
                                    }
                                }
                                catch (RfcInvalidParameterException exception2)
                                {
                                    MessageBox.Show($"{exception2.GetType().Name} : {exception2.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                catch (RfcCommunicationException exception3)
                                {
                                    if (WBUser.UserLevel == "1")
                                    {
                                        MessageBox.Show(exception3.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                    else
                                    {
                                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                }
                                catch (RfcBaseException exception4)
                                {
                                    if (WBUser.UserLevel == "1")
                                    {
                                        MessageBox.Show(exception4.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                    else
                                    {
                                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                }
                                catch (Exception exception5)
                                {
                                    MessageBox.Show(Resource.Title_003 + ": " + exception5.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                        }
                        return;
                    }
                    else
                    {
                        WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                        string str2 = integrator.getURL("ZRFC_DNET_WB_SYNC_GET");
                        if (str2 != "")
                        {
                            string[] textArray1 = new string[] { str2, "?p_bukrs=", WBData.sCoyCode, "&p_zwb_loc=", WBData.sLocCode };
                            bool err = false;
                            Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                            string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                            dictionary = integrator.getDataFromMulesoft(string.Concat(textArray1), resultHeaderName, out err);
                            if (!err)
                            {
                                if (dictionary["ERRORS"].Count > 0)
                                {
                                    MessageBox.Show("Error from " + str + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else if (dictionary["I_RECORD"][0]["SYNC"] == "N")
                                {
                                    try
                                    {
                                        string url = integrator.getURL("ZRFC_DNET_ADOPT_MAP_COMM_TRX");
                                        if (url != "")
                                        {
                                            Dictionary<string, List<Dictionary<string, string>>> dictionary2 = new Dictionary<string, List<Dictionary<string, string>>>();
                                            string[] textArray3 = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                                            dictionary2 = integrator.getDataFromMulesoft(url, textArray3, out err);
                                            if (!err)
                                            {
                                                if (dictionary["ERRORS"].Count > 0)
                                                {
                                                    MessageBox.Show("Error from " + str + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                    return;
                                                }
                                                else
                                                {
                                                    int num = 0;
                                                    WBTable table = new WBTable();
                                                    table.OpenTable("wb_ContractGrCust", "Select * From wb_contract_GRCust where 1=1", WBData.conn);
                                                    foreach (DataRow row in table.DT.Rows)
                                                    {
                                                        row.Delete();
                                                        num++;
                                                    }
                                                    table.Save();
                                                    table.ReOpen();
                                                    foreach (Dictionary<string, string> dictionary5 in dictionary2["I_RECORD"])
                                                    {
                                                        table.DR = table.DT.NewRow();
                                                        table.DR["Comm_code"] = dictionary5["COMM"];
                                                        table.DR["Transaction_code"] = dictionary5["STATUS"];
                                                        table.DT.Rows.Add(table.DR);
                                                    }
                                                    table.Save();
                                                    WBMulesoftIntegrator integrator2 = new WBMulesoftIntegrator();
                                                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                                                    Dictionary<string, string> item = new Dictionary<string, string> {
                                                        { 
                                                            "P_BUKRS",
                                                            WBData.sCoyCode
                                                        },
                                                        { 
                                                            "P_ZWB_LOC",
                                                            WBData.sLocCode
                                                        },
                                                        { 
                                                            "P_CDESC",
                                                            WBData.sCoyName + " " + WBSetting.sLocName
                                                        }
                                                    };
                                                    sentTable.Add(item);
                                                    string str4 = integrator2.getURL("ZRFC_DNET_WB_SYNC_SET");
                                                    if (str4 != "")
                                                    {
                                                        integrator2.prepareTable();
                                                        integrator2.addTable(sentTable, "I_RECORD");
                                                        string[] textArray4 = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                                                        Dictionary<string, List<Dictionary<string, string>>> dictionary4 = integrator2.sendDataToMulesoft(str4, textArray4, out err);
                                                        if (!err)
                                                        {
                                                            if (dictionary4["ERRORS"].Count <= 0)
                                                            {
                                                                MessageBox.Show(Resource.Mes_223);
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Error from " + str + " : \n\n" + dictionary4["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            return;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        return;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    catch (Exception exception)
                                    {
                                        MessageBox.Show(Resource.Title_003 + ": " + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                }
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (RfcInvalidParameterException exception6)
                {
                    MessageBox.Show($"{exception6.GetType().Name} : {exception6.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception7)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception7.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception8)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception8.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception9)
                {
                    MessageBox.Show(Resource.Title_003 + ": " + exception9.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }
    }
}

