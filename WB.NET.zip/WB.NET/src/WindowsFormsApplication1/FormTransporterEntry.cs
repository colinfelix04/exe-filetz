﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTransporterEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public int nCurrRowD;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private bool adopt = false;
        private string code = "";
        private string name = "";
        private string address = "";
        private string contact = "";
        private string phone = "";
        private string remark = "";
        private string fax = "";
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private CheckBox checkBoxBlocked;
        private TextBox textBoxSAPCode;
        private TextBox textBoxContactPerson;
        private TextBox textBoxFax;
        private TextBox textBoxPhone;
        private TextBox textBoxAddress;
        private TextBox textBoxTransporterName;
        public TextBox textBoxTransporterCode;
        private Label labelBlacklist;
        private Label labelCode;
        private Label labelContactPerson;
        private Label labelFax;
        private Label labelPhone;
        private Label labelAddress;
        private Label labelTransporterName;
        private Label labelTransporterCode;
        private TextBox textBoxBlockedReason;
        private Label labelBlockedReason;
        private GroupBox groupType;
        private RadioButton radioCust;
        private RadioButton radioVend;
        private Button buttonAdopt;
        private TextBox textBoxRemark;
        private Label labelRemark;

        public FormTransporterEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        public void adoptData()
        {
            try
            {
                this.adopt = false;
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_VENDOR");
                    WBSAP.rfcFunction.SetValue("P_LIFNR", this.textBoxSAPCode.Text);
                    if (this.radioCust.Checked)
                    {
                        WBSAP.rfcFunction.SetValue("P_TYPE", "C");
                    }
                    else if (this.radioVend.Checked)
                    {
                        WBSAP.rfcFunction.SetValue("P_TYPE", "V");
                    }
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("WA_RECORD");
                    if (structure.GetString("NOT_EXIST") == "X")
                    {
                        MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                    }
                    else
                    {
                        string str = structure.GetString("NAME1");
                        string str2 = structure.GetString("STREET");
                        string str3 = structure.GetString("CITY1");
                        string str6 = structure.GetString("TELF1");
                        string str4 = (str6.Trim() == "") ? structure.GetString("TELF2") : str6;
                        string str5 = structure.GetString("TELFX");
                        this.textBoxTransporterName.Text = str;
                        this.textBoxAddress.Text = str2;
                        this.textBoxBlockedReason.Text = str3;
                        this.textBoxPhone.Text = str4;
                        this.textBoxFax.Text = str5;
                        this.textBoxRemark.Text = this.remark;
                        this.adopt = true;
                        MessageBox.Show(Resource.Mes_087, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        public void adoptDataIDSYS()
        {
            try
            {
                WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
                string url = integrator.getURL("IDSYS_ADOPT_VENDOR");
                if (url != "")
                {
                    string[] textArray1 = new string[] { "{coy:'", WBSetting.CoySAP, "',code:'", this.textBoxSAPCode.Text, "',indc:'2' }" };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                    if (!err)
                    {
                        if (dictionary["data"].Count <= 0)
                        {
                            MessageBox.Show(Resource.IDSY_Adopt_Failled, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            foreach (Dictionary<string, string> dictionary2 in dictionary["data"])
                            {
                                this.code = dictionary2["code"];
                                this.name = dictionary2["name"];
                                this.address = dictionary2["address"];
                                this.contact = dictionary2["contact"];
                                this.phone = dictionary2["phone"];
                                this.fax = dictionary2["fax"];
                                this.remark = dictionary2["remark"];
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                this.textBoxTransporterCode.Text = this.code;
                this.textBoxTransporterName.Text = this.name;
                this.textBoxAddress.Text = this.address;
                this.textBoxPhone.Text = this.phone;
                this.textBoxFax.Text = this.fax;
                this.textBoxContactPerson.Text = this.contact;
                this.textBoxRemark.Text = this.remark;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBoxTransporterCode, this.textBoxTransporterName, this.textBoxAddress };
            if (!Program.CheckEmpty(aText))
            {
                if (!((this.textBoxTransporterCode.Text.Length > 50) && WBSetting.integrationIDSYS))
                {
                    if ((this.textBoxTransporterCode.Text.Length <= 10) || WBSetting.integrationIDSYS)
                    {
                        if ((WBSetting.region != "1") || (((this.pMode != "ADD") && (this.pMode != "EDIT")) || (this.adopt || WBUser.CheckTrustee("MD_CREATEVST", "V"))))
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_transporter", "Select Uniq,deleted From wb_transporter Where  " + WBData.CompanyLocation(" and ( transporter_Code='" + this.textBoxTransporterCode.Text.Trim() + "')"), WBData.conn);
                            if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                            {
                                table.Dispose();
                                Cursor.Current = Cursors.WaitCursor;
                                this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                                if ((this.pMode != "EDIT") || (this.textBoxTransporterCode.Text.Trim() == this.OldCode.Trim()))
                                {
                                    goto TR_0023;
                                }
                                else
                                {
                                    table2 = new WBTable();
                                    table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where  " + WBData.Company(" and ( Transporter_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Transporter_Code"].ToString() + "')"), WBData.conn);
                                    WBTable table3 = new WBTable();
                                    table3.OpenTable("wb_transDO", "Select uniq From wb_transDO where  " + WBData.Company(" and ( Transporter_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Transporter_Code"].ToString().Trim() + "')"), WBData.conn);
                                    Cursor.Current = Cursors.Default;
                                    if ((table2.DT.Rows.Count <= 0) && (table3.DT.Rows.Count <= 0))
                                    {
                                        goto TR_0024;
                                    }
                                    else
                                    {
                                        string[] textArray1 = new string[13];
                                        textArray1[0] = Resource.Mes_Transporter_Code_Change;
                                        textArray1[1] = " ";
                                        textArray1[2] = this.OldCode;
                                        textArray1[3] = " -> ";
                                        textArray1[4] = this.textBoxTransporterCode.Text;
                                        textArray1[5] = "\n\n";
                                        textArray1[6] = Resource.Msg_Replace_Warning;
                                        textArray1[7] = "\n( ";
                                        textArray1[8] = table2.DT.Rows.Count.ToString();
                                        textArray1[9] = " &  ";
                                        textArray1[10] = table3.DT.Rows.Count.ToString();
                                        textArray1[11] = " records )\n\n";
                                        textArray1[12] = Resource.Mes_Confirm_Continue;
                                        if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                        {
                                            this.ReplaceAll = true;
                                            goto TR_0024;
                                        }
                                        else
                                        {
                                            this.ReplaceAll = false;
                                            this.textBoxTransporterCode.Focus();
                                        }
                                    }
                                }
                            }
                            else if (table.DT.Rows[0]["deleted"].ToString() == "Y")
                            {
                                table.Dispose();
                                MessageBox.Show(Resource.Mes_625, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textBoxTransporterCode.Focus();
                            }
                            else
                            {
                                table.Dispose();
                                MessageBox.Show(Resource.Mes_044, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textBoxTransporterCode.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_376 + this.sapIDSYS, Resource.Title_002);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                        this.textBoxTransporterCode.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                    this.textBoxTransporterCode.Focus();
                }
            }
            return;
        TR_0023:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Transporter_001 },
                    textRefNo = { Text = this.textBoxTransporterCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRowD = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRowD];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["transporter_Code"] = this.textBoxTransporterCode.Text.ToString().Trim();
            this.zTable.DR["transporter_Name"] = this.textBoxTransporterName.Text.ToString().Trim();
            this.zTable.DR["Address"] = this.textBoxAddress.Text;
            this.zTable.DR["Reason"] = this.checkBoxBlocked.Checked ? this.textBoxBlockedReason.Text : "";
            this.zTable.DR["Phone"] = this.textBoxPhone.Text;
            this.zTable.DR["Fax"] = this.textBoxFax.Text;
            this.zTable.DR["Contact_Person"] = this.textBoxContactPerson.Text;
            this.zTable.DR["SAP_Code"] = this.textBoxSAPCode.Text;
            this.zTable.DR["Remark"] = this.textBoxRemark.Text;
            this.zTable.DR["Black_List"] = this.checkBoxBlocked.Checked ? "Y" : "N";
            this.zTable.DR["Transporter_Type"] = this.radioCust.Checked ? "C" : "V";
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_transporter", "SELECT uniq FROM wb_transporter WHERE " + WBData.CompanyLocation(" AND transporter_code = '" + this.textBoxTransporterCode.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_transporter", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                string[] textArray4 = new string[] { "(Triggered add new transporter in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray4);
            }
            else if (this.pMode == "EDIT")
            {
                string[] textArray5 = new string[] { "(Triggered edit transporter in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray5);
            }
            Program.copyToLoc("wb_transporter", this.textBoxTransporterCode.Text, 0, this.changeReason + " " + str);
            if ((this.pMode == "EDIT") && (this.textBoxTransporterCode.Text != this.OldCode))
            {
                Program.copyToLoc("wb_transporter", this.OldCode, 0, this.changeReason + " " + str);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Transporter_Code" };
                string[] aNewValue = new string[] { this.textBoxTransporterCode.Text };
                Program.ReplaceInCompany("wb_transaction", aField, aNewValue, " Transporter_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit tranporter master data)");
                string[] textArray8 = new string[] { "Transporter_Code" };
                string[] textArray9 = new string[] { this.textBoxTransporterCode.Text };
                Program.ReplaceInCompany("wb_transDO", textArray8, textArray9, " Transporter_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit transporter master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0024:
            table2.Dispose();
            goto TR_0023;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonAdopt_Click(object sender, EventArgs e)
        {
            if (!((this.textBoxTransporterCode.Text.Length > 50) && WBSetting.integrationIDSYS))
            {
                if ((this.textBoxTransporterCode.Text.Length <= 10) || WBSetting.integrationIDSYS)
                {
                    if (!((this.textBoxTransporterCode.Text.Length > 50) && WBSetting.integrationIDSYS))
                    {
                        if ((this.textBoxTransporterCode.Text.Length <= 10) || WBSetting.integrationIDSYS)
                        {
                            if (this.textBoxSAPCode.Text.Trim() == "")
                            {
                                return;
                            }
                            else if (!WBSetting.activeMulesoftIntegration)
                            {
                                Cursor.Current = Cursors.WaitCursor;
                                Cursor.Current = Cursors.WaitCursor;
                                if (WBSetting.integrationIDSYS)
                                {
                                    this.adoptDataIDSYS();
                                }
                                else
                                {
                                    this.adoptData();
                                }
                                Cursor.Current = Cursors.Default;
                                return;
                            }
                            else
                            {
                                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                                string str = integrator.getURL("ZRFC_DNET_ADOPT_VENDOR");
                                if (str != "")
                                {
                                    string[] textArray1 = new string[] { str, "?lifnr=", this.textBoxSAPCode.Text, "&zwb_loc=", WBSetting.CoySAP };
                                    bool err = false;
                                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                                    string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                                    dictionary = integrator.getDataFromMulesoft(string.Concat(textArray1), resultHeaderName, out err);
                                    if (!err)
                                    {
                                        if (dictionary["ERRORS"].Count > 0)
                                        {
                                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                        else
                                        {
                                            foreach (Dictionary<string, string> dictionary2 in dictionary["I_RECORD"])
                                            {
                                                string str2 = "";
                                                foreach (KeyValuePair<string, string> pair in dictionary2)
                                                {
                                                    string[] textArray3 = new string[] { str2, pair.Key, " : ", pair.Value, "\n" };
                                                    str2 = string.Concat(textArray3);
                                                }
                                                if (dictionary2["NOT_EXIST"] == "X")
                                                {
                                                    MessageBox.Show(Resource.Mes_118 + this.sapIDSYS);
                                                }
                                                else
                                                {
                                                    string str3 = dictionary2["NAME1"];
                                                    string str4 = dictionary2["STREET"];
                                                    string str5 = dictionary2["CITY1"];
                                                    string str8 = dictionary2["TELF1"];
                                                    string str6 = (str8.Trim() == "") ? dictionary2["TELF2"] : str8;
                                                    string str7 = dictionary2["TELFX"];
                                                    this.textBoxTransporterName.Text = str3;
                                                    this.textBoxAddress.Text = str4;
                                                    this.textBoxBlockedReason.Text = str5;
                                                    this.textBoxPhone.Text = str6;
                                                    this.textBoxFax.Text = str7;
                                                    this.textBoxRemark.Text = this.remark;
                                                    this.adopt = true;
                                                    MessageBox.Show(Resource.Mes_087, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                            this.textBoxTransporterCode.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                        this.textBoxTransporterCode.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                    this.textBoxTransporterCode.Focus();
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_Error_Transporter_Code_Length);
                this.textBoxTransporterCode.Focus();
                return;
            }
            Cursor.Current = Cursors.Default;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.textBoxBlockedReason.Enabled = this.checkBoxBlocked.Checked;
            if (this.checkBoxBlocked.Checked)
            {
                this.textBoxBlockedReason.Focus();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransporterEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransporterEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBoxTransporterCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["transporter_Code"].Value.ToString();
                this.OldCode = this.textBoxTransporterCode.Text;
                this.textBoxTransporterName.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["transporter_Name"].Value.ToString();
                this.textBoxAddress.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Address"].Value.ToString();
                this.textBoxBlockedReason.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Reason"].Value.ToString();
                this.textBoxPhone.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Phone"].Value.ToString();
                this.textBoxFax.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Fax"].Value.ToString();
                this.textBoxContactPerson.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Contact_Person"].Value.ToString();
                this.textBoxSAPCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
                this.textBoxRemark.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Remark"].Value.ToString();
                this.checkBoxBlocked.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Black_List"].Value.ToString() == "Y";
                this.checkBoxBlocked.Enabled = !this.checkBoxBlocked.Checked ? WBUser.CheckTrustee("BLACKLIST_TRANSPORTER", "A") : WBUser.CheckTrustee("BLACKLIST_TRANSPORTER", "E");
                this.textBoxBlockedReason.Enabled = this.checkBoxBlocked.Enabled && this.checkBoxBlocked.Checked;
                this.radioCust.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transporter_Type"].Value.ToString() == "C";
                this.radioVend.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transporter_Type"].Value.ToString() == "V";
                if (!this.radioVend.Checked && !this.radioCust.Checked)
                {
                    this.radioVend.Checked = true;
                }
            }
            if (this.pMode == "VIEW")
            {
                if (this.checkBoxBlocked.Checked)
                {
                    this.labelBlacklist.Visible = true;
                    this.checkBoxBlocked.Visible = true;
                    this.labelBlockedReason.Visible = true;
                    this.textBoxBlockedReason.Visible = true;
                }
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
            if (this.pMode == "EDIT")
            {
                this.textBoxTransporterCode.ReadOnly = true;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.checkBoxBlocked = new CheckBox();
            this.textBoxSAPCode = new TextBox();
            this.textBoxContactPerson = new TextBox();
            this.textBoxFax = new TextBox();
            this.textBoxPhone = new TextBox();
            this.textBoxAddress = new TextBox();
            this.textBoxTransporterName = new TextBox();
            this.textBoxTransporterCode = new TextBox();
            this.labelBlacklist = new Label();
            this.labelCode = new Label();
            this.labelContactPerson = new Label();
            this.labelFax = new Label();
            this.labelPhone = new Label();
            this.labelAddress = new Label();
            this.labelTransporterName = new Label();
            this.labelTransporterCode = new Label();
            this.textBoxBlockedReason = new TextBox();
            this.labelBlockedReason = new Label();
            this.groupType = new GroupBox();
            this.radioCust = new RadioButton();
            this.radioVend = new RadioButton();
            this.buttonAdopt = new Button();
            this.textBoxRemark = new TextBox();
            this.labelRemark = new Label();
            this.groupType.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(0x246, 0x13b);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 10;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x1e2, 0x13b);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 9;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.checkBoxBlocked.AutoSize = true;
            this.checkBoxBlocked.Enabled = false;
            this.checkBoxBlocked.Location = new Point(0xb9, 0xe8);
            this.checkBoxBlocked.Name = "checkBoxBlocked";
            this.checkBoxBlocked.Size = new Size(0x41, 0x11);
            this.checkBoxBlocked.TabIndex = 7;
            this.checkBoxBlocked.Text = "Blocked";
            this.checkBoxBlocked.UseVisualStyleBackColor = true;
            this.checkBoxBlocked.Visible = false;
            this.checkBoxBlocked.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.textBoxSAPCode.Location = new Point(0xb9, 0xb1);
            this.textBoxSAPCode.MaxLength = 50;
            this.textBoxSAPCode.Name = "textBoxSAPCode";
            this.textBoxSAPCode.Size = new Size(0xfb, 20);
            this.textBoxSAPCode.TabIndex = 6;
            this.textBoxContactPerson.Location = new Point(0xb9, 0x9b);
            this.textBoxContactPerson.MaxLength = 50;
            this.textBoxContactPerson.Name = "textBoxContactPerson";
            this.textBoxContactPerson.Size = new Size(0xfb, 20);
            this.textBoxContactPerson.TabIndex = 5;
            this.textBoxContactPerson.TextChanged += new EventHandler(this.textBox7_TextChanged);
            this.textBoxFax.Location = new Point(0xb9, 0x85);
            this.textBoxFax.MaxLength = 50;
            this.textBoxFax.Name = "textBoxFax";
            this.textBoxFax.Size = new Size(0xfb, 20);
            this.textBoxFax.TabIndex = 4;
            this.textBoxPhone.Location = new Point(0xb9, 0x6f);
            this.textBoxPhone.MaxLength = 50;
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new Size(0xfb, 20);
            this.textBoxPhone.TabIndex = 3;
            this.textBoxAddress.Location = new Point(0xb9, 0x38);
            this.textBoxAddress.MaxLength = 150;
            this.textBoxAddress.Multiline = true;
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new Size(0x1e6, 50);
            this.textBoxAddress.TabIndex = 2;
            this.textBoxTransporterName.Location = new Point(0xb9, 0x20);
            this.textBoxTransporterName.MaxLength = 50;
            this.textBoxTransporterName.Name = "textBoxTransporterName";
            this.textBoxTransporterName.Size = new Size(0x180, 20);
            this.textBoxTransporterName.TabIndex = 1;
            this.textBoxTransporterCode.CharacterCasing = CharacterCasing.Upper;
            this.textBoxTransporterCode.Location = new Point(0xb9, 8);
            this.textBoxTransporterCode.MaxLength = 20;
            this.textBoxTransporterCode.Name = "textBoxTransporterCode";
            this.textBoxTransporterCode.Size = new Size(0xa5, 20);
            this.textBoxTransporterCode.TabIndex = 0;
            this.textBoxTransporterCode.KeyPress += new KeyPressEventHandler(this.textBoxTransporterCode_KeyPress);
            this.textBoxTransporterCode.Leave += new EventHandler(this.textBoxTransporterCode_Leave);
            this.labelBlacklist.Enabled = false;
            this.labelBlacklist.Location = new Point(0x12, 0xe4);
            this.labelBlacklist.Name = "labelBlacklist";
            this.labelBlacklist.Size = new Size(0xa1, 20);
            this.labelBlacklist.TabIndex = 0x1c;
            this.labelBlacklist.Text = "Blacklist";
            this.labelBlacklist.TextAlign = ContentAlignment.MiddleRight;
            this.labelBlacklist.Visible = false;
            this.labelCode.Location = new Point(0x12, 180);
            this.labelCode.Name = "labelCode";
            this.labelCode.Size = new Size(0xa1, 13);
            this.labelCode.TabIndex = 0x1b;
            this.labelCode.Text = " Code";
            this.labelCode.TextAlign = ContentAlignment.MiddleRight;
            this.labelContactPerson.Location = new Point(0x12, 0x9e);
            this.labelContactPerson.Name = "labelContactPerson";
            this.labelContactPerson.Size = new Size(0xa1, 13);
            this.labelContactPerson.TabIndex = 0x1a;
            this.labelContactPerson.Text = "Contact Person";
            this.labelContactPerson.TextAlign = ContentAlignment.MiddleRight;
            this.labelFax.Location = new Point(15, 0x88);
            this.labelFax.Name = "labelFax";
            this.labelFax.Size = new Size(0xa4, 13);
            this.labelFax.TabIndex = 0x19;
            this.labelFax.Text = "Fax.";
            this.labelFax.TextAlign = ContentAlignment.MiddleRight;
            this.labelPhone.Location = new Point(0x12, 0x72);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new Size(0xa1, 13);
            this.labelPhone.TabIndex = 0x18;
            this.labelPhone.Text = "Phone";
            this.labelPhone.TextAlign = ContentAlignment.MiddleRight;
            this.labelAddress.Location = new Point(15, 0x37);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new Size(0xa4, 20);
            this.labelAddress.TabIndex = 0x16;
            this.labelAddress.Text = "Address";
            this.labelAddress.TextAlign = ContentAlignment.MiddleRight;
            this.labelTransporterName.Location = new Point(15, 0x23);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(0xa4, 13);
            this.labelTransporterName.TabIndex = 0x15;
            this.labelTransporterName.Text = "Transporter Name";
            this.labelTransporterName.TextAlign = ContentAlignment.MiddleRight;
            this.labelTransporterCode.Location = new Point(12, 11);
            this.labelTransporterCode.Name = "labelTransporterCode";
            this.labelTransporterCode.Size = new Size(0xa7, 13);
            this.labelTransporterCode.TabIndex = 20;
            this.labelTransporterCode.Text = "Transporter Code";
            this.labelTransporterCode.TextAlign = ContentAlignment.MiddleRight;
            this.textBoxBlockedReason.Enabled = false;
            this.textBoxBlockedReason.Location = new Point(0xb8, 0xfe);
            this.textBoxBlockedReason.MaxLength = 100;
            this.textBoxBlockedReason.Multiline = true;
            this.textBoxBlockedReason.Name = "textBoxBlockedReason";
            this.textBoxBlockedReason.Size = new Size(0x1e7, 0x20);
            this.textBoxBlockedReason.TabIndex = 8;
            this.textBoxBlockedReason.Visible = false;
            this.labelBlockedReason.Enabled = false;
            this.labelBlockedReason.Location = new Point(15, 0x105);
            this.labelBlockedReason.Name = "labelBlockedReason";
            this.labelBlockedReason.Size = new Size(0xa4, 0x10);
            this.labelBlockedReason.TabIndex = 40;
            this.labelBlockedReason.Text = "Blocked Reason";
            this.labelBlockedReason.TextAlign = ContentAlignment.MiddleRight;
            this.labelBlockedReason.Visible = false;
            this.groupType.Controls.Add(this.radioCust);
            this.groupType.Controls.Add(this.radioVend);
            this.groupType.Location = new Point(0x1c8, 0x75);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(200, 40);
            this.groupType.TabIndex = 0x2c;
            this.groupType.TabStop = false;
            this.groupType.Text = "Type";
            this.radioCust.AutoSize = true;
            this.radioCust.Location = new Point(0x19, 0x11);
            this.radioCust.Name = "radioCust";
            this.radioCust.Size = new Size(0x45, 0x11);
            this.radioCust.TabIndex = 30;
            this.radioCust.Text = "Customer";
            this.radioCust.UseVisualStyleBackColor = true;
            this.radioVend.AutoSize = true;
            this.radioVend.Checked = true;
            this.radioVend.Location = new Point(0x7c, 0x11);
            this.radioVend.Name = "radioVend";
            this.radioVend.Size = new Size(0x3b, 0x11);
            this.radioVend.TabIndex = 0x1f;
            this.radioVend.TabStop = true;
            this.radioVend.Text = "Vendor";
            this.radioVend.UseVisualStyleBackColor = true;
            this.buttonAdopt.Location = new Point(0x1c8, 0xa3);
            this.buttonAdopt.Name = "buttonAdopt";
            this.buttonAdopt.Size = new Size(0x4b, 0x17);
            this.buttonAdopt.TabIndex = 0x2b;
            this.buttonAdopt.Text = "&Adopt";
            this.buttonAdopt.UseVisualStyleBackColor = true;
            this.buttonAdopt.Click += new EventHandler(this.buttonAdopt_Click);
            this.textBoxRemark.Location = new Point(0xb8, 0xcb);
            this.textBoxRemark.MaxLength = 50;
            this.textBoxRemark.Name = "textBoxRemark";
            this.textBoxRemark.Size = new Size(0xfc, 20);
            this.textBoxRemark.TabIndex = 0x2d;
            this.labelRemark.Location = new Point(15, 0xce);
            this.labelRemark.Name = "labelRemark";
            this.labelRemark.Size = new Size(0xa1, 13);
            this.labelRemark.TabIndex = 0x2e;
            this.labelRemark.Text = " Remark";
            this.labelRemark.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(730, 0x165);
            base.ControlBox = false;
            base.Controls.Add(this.labelRemark);
            base.Controls.Add(this.textBoxRemark);
            base.Controls.Add(this.groupType);
            base.Controls.Add(this.buttonAdopt);
            base.Controls.Add(this.labelBlockedReason);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.checkBoxBlocked);
            base.Controls.Add(this.textBoxSAPCode);
            base.Controls.Add(this.textBoxContactPerson);
            base.Controls.Add(this.textBoxFax);
            base.Controls.Add(this.textBoxPhone);
            base.Controls.Add(this.textBoxAddress);
            base.Controls.Add(this.textBoxTransporterName);
            base.Controls.Add(this.textBoxTransporterCode);
            base.Controls.Add(this.labelBlacklist);
            base.Controls.Add(this.labelCode);
            base.Controls.Add(this.labelContactPerson);
            base.Controls.Add(this.labelFax);
            base.Controls.Add(this.labelPhone);
            base.Controls.Add(this.labelAddress);
            base.Controls.Add(this.labelTransporterName);
            base.Controls.Add(this.labelTransporterCode);
            base.Controls.Add(this.textBoxBlockedReason);
            base.Name = "FormTransporterEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTransporterEntry";
            base.Load += new EventHandler(this.FormTransporterEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransporterEntry_KeyPress);
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxTransporterCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.CheckInput(e, "A|N|U");
        }

        private void textBoxTransporterCode_Leave(object sender, EventArgs e)
        {
            if (WBUtility.CheckLeave(this.textBoxTransporterCode.Text, "A|N|U"))
            {
                MessageBox.Show(Resource.Filter_003, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxTransporterCode.Focus();
            }
        }

        private void translate()
        {
            this.labelTransporterCode.Text = Resource.Transporter_001;
            this.labelTransporterName.Text = Resource.Transporter_002;
            this.labelAddress.Text = Resource.Transporter_003;
            this.labelPhone.Text = Resource.Transporter_004;
            this.labelFax.Text = Resource.Transporter_005;
            this.labelContactPerson.Text = Resource.Transporter_006;
            this.labelCode.Text = Resource.Transporter_007;
            this.labelBlacklist.Text = Resource.Transporter_008;
            this.labelBlockedReason.Text = Resource.Transporter_009;
            this.checkBoxBlocked.Text = Resource.Transporter_010;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.buttonAdopt.Text = Resource.Btn_Adopt;
            this.groupType.Text = Resource.VendorE_011;
            this.radioCust.Text = Resource.VendorE_012;
            this.radioVend.Text = Resource.VendorE_013;
            this.Text = Resource.Title_Transporter_Entry;
            if (WBSetting.integrationIDSYS)
            {
                this.labelCode.Text = "IDSYS Code";
                this.buttonAdopt.Text = "Adopt";
                this.textBoxTransporterCode.Enabled = false;
                this.textBoxTransporterName.Enabled = false;
                this.textBoxAddress.Enabled = false;
                this.textBoxBlockedReason.Enabled = false;
                this.textBoxPhone.Enabled = false;
                this.textBoxFax.Enabled = false;
                this.textBoxContactPerson.Enabled = false;
                this.textBoxRemark.Enabled = false;
                this.groupType.Enabled = false;
            }
        }
    }
}

