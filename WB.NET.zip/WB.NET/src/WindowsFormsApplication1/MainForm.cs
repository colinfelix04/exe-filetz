﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using Encryption.Utility;
    using Microsoft.VisualBasic;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.IO.Ports;
    using System.Net;
    using System.Net.Sockets;
    using System.Threading;
    using System.Windows.Forms;
    using System.Xml.Serialization;
    using WindowsFormsApplication1.E_Grading;
    using WindowsFormsApplication1.Utility;

    public class MainForm : Form
    {
        private int idxFind = 0;
        public string Truck_Number = "";
        public string Date1 = "";
        public string secondweight = "";
        public string pMode;
        public string cField;
        public string fNoRef;
        public int nCurrRow;
        public WBTable Trans = new WBTable();
        private WBTable TblReportdate = new WBTable();
        private WBTable tblDeduc = new WBTable();
        public WBTable tbl_Loc = new WBTable();
        public WBTable tbl_Loc2 = new WBTable();
        public DateTime dFrom;
        public DateTime dTo;
        public string doviewComm = "";
        public string doviewRefNo = "";
        public string doviewRelation = "";
        public string doviewDO_No = "";
        public string doviewPI_No = "";
        public bool doviewFirsttime = true;
        public bool tambahRecord = true;
        public Thread td;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticketRptSPB = new ReportDocument();
        public ReportDocument ticket2Rpt = new ReportDocument();
        public ReportDocument rpt_advise = new ReportDocument();
        public ReportDocument ticket_multi1 = new ReportDocument();
        public ReportDocument ticket_multi2 = new ReportDocument();
        public ReportDocument ticketLangsir = new ReportDocument();
        public ReportDocument ticketLangsir2 = new ReportDocument();
        private FormRpt fRpt;
        private FormRpt fRptSPB;
        private FormRpt loading_advise;
        private FormRpt fticket_multi1;
        private FormRpt fticket_multi2;
        private FormRpt fticketLangsir;
        private FormRpt fticketLangsir2;
        public bool autoUpd = false;
        public bool updSuccess = true;
        public bool isUpload = false;
        public bool isSendEmail = false;
        private string[] sapJamKirim;
        private string[] hasil = new string[3];
        private FormMessage fm = new FormMessage();
        private int no_of_col = 0;
        private WBTable tbl_temp = new WBTable();
        private string reason = "";
        private string token_in_progress = "";
        private WBTable tbl_rlock = new WBTable();
        private string uniq_gatepass = "";
        private string no_gatepass = "";
        private string no_card = "";
        private string _wx = "";
        public static bool changeProfile = false;
        public string[,] sapD;
        public int intervalForCalibration = 30;
        public string sUniq_TCS;
        public string _result;
        public string pUnq;
        private string sapIDSYS = "";
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem ReportToolStripMenuItem;
        private ToolStripMenuItem masterDataToolStripMenuItem1;
        private ToolStripMenuItem DOToolStripMenuItem;
        private ToolStripMenuItem commodityToolStripMenuItem;
        private ToolStripMenuItem relationToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem truckToolStripMenuItem;
        private ToolStripMenuItem driverToolStripMenuItem;
        private ToolStripMenuItem configurationToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private StatusStrip statusWB;
        private ToolStripMenuItem transpoterToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem locationToolStripMenuItem;
        private ToolStripMenuItem storageToolStripMenuItem;
        private ToolStripMenuItem divisionToolStripMenuItemPOM;
        private ToolStripMenuItem estateToolStripMenuItem;
        private ToolStripMenuItem qualityToolStripMenuItem;
        private ToolStripMenuItem tankerToolStripMenuItem;
        private ToolStripMenuItem gradingToolStripMenuItemPOM;
        private ToolStripSeparator toolStripMenuItem3;
        private ToolStripMenuItem transactionTypeToolStripMenuItem;
        private ToolStripMenuItem FFBReportToolStripMenuItemPOM;
        private ToolStripMenuItem subRP1ToolStripMenuItem;
        private ToolStripMenuItem WeighingMenuItem;
        private ToolStripMenuItem ndWeightToolStripMenuItem;
        private ToolStripMenuItem rdWeightToolStripMenuItem;
        private ToolStripMenuItem thWeightToolStripMenuItem;
        private ToolStripMenuItem databaseConnectionToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem5;
        private ToolStripSeparator toolStripMenuItem6;
        private ToolStripMenuItem userListToolStripMenuItem;
        private ToolStripMenuItem userGroupToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem7;
        private ToolStripMenuItem weighBridgeSettingToolStripMenuItem;
        private ToolStripMenuItem blockStripMenuItemPOM;
        private ToolStripSeparator toolStripMenuItem4;
        private ToolStripMenuItem coytoolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem8;
        private ToolStripMenuItem cancelRecordToolStripMenuItem;
        private ToolStripMenuItem laporanTotalPenerimaanTBSToolStripMenuItem;
        private ToolStripMenuItem fFBGradingReportToolStripMenuItem;
        private ToolStripMenuItem repairChecksumToolStripMenuItem;
        private ToolStripMenuItem registrationToolStripMenuItem;
        private ToolStripMenuItem uploadSAPToolStripMenuItem;
        private ToolStripMenuItem templateSAPToolStripMenuItem;
        private Timer timerSAPUpd;
        private Label lblNow;
        private Label lblDate;
        private ToolStripMenuItem qCItemToolStripMenuItem;
        private ToolStripMenuItem compositToolStripMenuItem;
        private ToolStripMenuItem qcStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem stWeightToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem9;
        private SerialPort serialPort1;
        private ToolStripMenuItem toolStripMenuRekapHarian;
        private ToolStripMenuItem vendorSummaryTBSToolStripMenuItem;
        private BackgroundWorker backgroundWorkerSAP;
        private ToolStripMenuItem schDataToolStripMenuItem;
        private ToolStripMenuItem qCReportToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem11;
        private ToolStripMenuItem ManualEntryMenuItem;
        private ToolStripMenuItem divisionReportToolStripMenuItem;
        private ToolStripMenuItem listOfWeighningToolStripMenuItem1;
        private ToolStripMenuItem doDetailToolStripMenuItem;
        private ToolStripMenuItem compareDatabaseToolStripMenuItem;
        private ToolStripMenuItem receivingEstimationFrom3rdPartyToolStripMenuItem;
        private ToolStripMenuItem copyToNewCompanyToolStripMenuItem;
        private ToolStripMenuItem repairAllChecksumToolStripMenuItem;
        private ToolStripMenuItem splitReferenceToolStripMenuItem;
        private ToolStripMenuItem mergeDOToolStripMenuItem;
        private ToolStripMenuItem laporanPeneriamPerSupploerLA1ToolStripMenuItem;
        private ToolStripMenuItem formulaRendemenToolStripMenuItemPOM;
        private ToolStripMenuItem nonContractTransactionToolStripMenuItem;
        private ToolStripMenuItem vendorSummaryToolStripMenuItem;
        private ToolStripMenuItem logOffToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem12;
        private ToolStripMenuItem copraReportToolStripMenuItem;
        private ToolStripMenuItem dailyReceiptSupplierToolStripMenuItem;
        private ToolStripMenuItem UploadTypeToolStripMenuItem;
        private ToolStripMenuItem reportOutstandingDONonTradeStoreToolStripMenuItem;
        private ToolStripMenuItem DLAdoptMenuItem;
        private ToolStripMenuItem tokenToolStripMenuItem;
        private ToolStripMenuItem contractLogToolStripMenuItem;
        private Timer timerTokenEmail;
        private BackgroundWorker backgroundWorkerEmail;
        private ToolStripMenuItem mapCommTrxTypeToolStripMenuItem;
        private ToolStripMenuItem emailRecipientsToolStripMenuItem;
        private ToolStripMenuItem outstandingDOPerVendorToolStripMenuItem;
        private ToolStripMenuItem incotermToolStripMenuItem;
        private ToolStripMenuItem vendorDetailToolStripMenuItem;
        private ToolStripMenuItem failSynchronizeReportToolStripMenuItem;
        private ToolStripMenuItem wBOwnerToolStripMenuItem;
        private ToolStripMenuItem changeProfileToolStripMenuItem;
        private ToolStripMenuItem weighBridgeControlToolStripMenuItem;
        private ToolStripMenuItem loadingQtyToolStripMenuItem;
        private ToolStripMenuItem toolsToolStripMenuItem;
        private ToolStripMenuItem autoSplitDOVesselToolStripMenuItem1;
        private ToolStripMenuItem markAccidentToolStripMenuItem;
        private ToolStripMenuItem viewDOToolStripMenuItem;
        private ToolTip toolTipInformation;
        private ToolStripMenuItem entryOtherPartyWeightToolStripMenuItem;
        private ToolStripMenuItem toleranceProductToolStripMenuItem;
        private ToolStripMenuItem vesselReportToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem saveColumnPositionToolStripMenuItem;
        private ToolStripMenuItem loadColumnPositionToolStripMenuItem;
        private ToolStripMenuItem tankerLogToolStripMenuItem;
        private ToolStripMenuItem commodityToleranceReportToolStripMenuItem;
        private ToolStripMenuItem printLoadingUnloadingAdviseToolStripMenuItem;
        private ToolStripMenuItem cameraListToolStripMenuItem;
        private ToolStripMenuItem ReasonToolStripMenuItem;
        private ToolStripMenuItem entryFFBGradingToolStripMenuItem;
        private ToolStripMenuItem closeRegisteredTruckToolStripMenuItem;
        private ToolStripMenuItem tsCCTC;
        private ToolStripMenuItem entryReturToolStripMenuItem;
        private ToolStripMenuItem logReportToolStripMenuItem;
        private ToolStripMenuItem transactionLogToolStripMenuItem;
        private ToolStripMenuItem masterDataLogToolStripMenuItem;
        private ToolStripMenuItem migrateOldLogToNewLogToolStripMenuItem;
        private ToolStripMenuItem indicatorStabilityReportToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripMenuItem settingLogReportToolStripMenuItem;
        private ToolStripMenuItem locationLogReportToolStripMenuItem;
        private ToolStripMenuItem userListLogToolStripMenuItem;
        private ToolStripMenuItem authorizationLogToolStripMenuItem;
        private ToolStripMenuItem templateSAPLogToolStripMenuItem;
        private ToolStripMenuItem userLoginLogoutLogToolStripMenuItem;
        private ToolStripMenuItem userManagementReportToolStripMenuItem;
        private ToolStripMenuItem userListReportToolStripMenuItem;
        private ToolStripMenuItem accessRightReportToolStripMenuItem;
        private ToolStripMenuItem multiLineSOOutstandingReportToolStripMenuItem;
        private ToolStripMenuItem emailRecipientReportToolStripMenuItem;
        private ToolStripMenuItem sAPDestinationToolStripMenuItem;
        private ToolStripMenuItem hardwareConfigurationToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripMenuItem wBCalibrationToolStripMenuItem;
        private ToolStripMenuItem wtaReportToolStripMenuItem;
        private ToolStripMenuItem startWeighingToolStripMenuItem;
        private ToolStripMenuItem tCSToolStripMenuItem;
        private ToolStripMenuItem view4XTransactionForContainerOutToolStripMenuItem;
        private ToolStripMenuItem destinationToolStripMenuItem;
        private ToolStripMenuItem indicatorStabilityReportToolStripMenuItem1;
        private ToolStripMenuItem refreshQCFromTCSToolStripMenuItem;
        private ToolStripMenuItem mappingTruckDestinationPerCompanyLocationToolStripMenuItem;
        private ToolStripMenuItem entryGradingDivisionToolStripMenuItem;
        private ToolStripMenuItem cancelTypeToolStripMenuItem;
        private ToolStripMenuItem requestSpecialTokenToolStripMenuItem;
        private ToolStripMenuItem allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem;
        private ToolStripMenuItem requestTokenToEditMultipleContractsTransactionsToolStripMenuItem;
        private ToolStripMenuItem tokenToAllowMannedWeighingToolStripMenuItem;
        private ToolStripMenuItem sparePartQtyToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        private ToolStripMenuItem Additional_Printing_Menu;
        private ToolStripMenuItem printBASerahTerimaToolStripMenuItem;
        private ToolStripMenuItem SPB_Report_Menu;
        private ToolStripMenuItem reportOutstandingDOToolStripMenuItem;
        private ToolStripMenuItem entryDeliveryNoteToolStripMenuItem;
        private ToolStripMenuItem disableFeaturesToolStripMenuItem;
        private ToolStripMenuItem changeFlagUploadToolStripMenuItem;
        private ToolStripMenuItem flagPostedToolStripMenuItem;
        private ToolStripMenuItem flagRepostedToolStripMenuItem;
        private ToolStripMenuItem mergeAutoSplitDOVesselToolStripMenuItem1;
        private ToolStripMenuItem ViewSparepartToolStripMenuItem;
        private Label label1;
        private Panel panel1;
        private Label label5;
        private CheckBox checkWBCode;
        private CheckBox checkPartial;
        private Label Garis3;
        private CheckBox checkShowCheckSum;
        private Label Garis2;
        private Label labelStatus1;
        private CheckBox checkBox1;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label4;
        private TextBox TextFind;
        private Button buttonFind;
        private Button buttonFilter;
        private Label Garis1;
        private DataGridView dataGridView1;
        private TableLayoutPanel tableLayoutPanel1;
        private LinkLabel linkLabelSupport;
        private Label labelExpired;
        private ToolStripStatusLabel Status1;
        private ToolStripStatusLabel label2;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripMenuItem activationKeyToolStripMenuItem;
        private ToolStripMenuItem maintainActivationKeyUsageToolStripMenuItem;
        private ToolStripMenuItem renewActivationKeyToolStripMenuItem;
        private ToolStripMenuItem DriverBlacklistReportToolStripMenuItem;
        private ToolStripMenuItem edittoolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem editQuantityToolStripMenuItem;
        private ToolStripMenuItem editDeductionToolStripMenuItem;
        private ToolStripMenuItem editReportDateToolStripMenuItem;
        private ToolStripMenuItem editDNToolStripMenuItem;
        private ToolStripMenuItem SPBtoolStripMenuItem;
        private ToolStripMenuItem cancelRegistrationReportToolStripMenuItem;
        private ToolStripMenuItem cancelWeighingReportToolStripMenuItem;

        public MainForm()
        {
            this.fm.label1.Text = "Preparing . . . . . . . ";
            this.fm.Show();
            this.fm.Refresh();
            this.InitializeComponent();
        }

        private void _weighMenuActivate()
        {
            this.stWeightToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "A");
            this.toolStripMenuItem11.Enabled = WBUser.CheckTrustee("TRANS", "A");
            this.qcStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS_QC", "V");
            if (WBSetting.Field("GM").ToString() == "Y")
            {
                this.printToolStripMenuItem.Enabled = true;
                this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = true;
            }
            else
            {
                this.printToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_PRINT", "V");
                this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_PRINT", "V");
            }
            this.printLoadingUnloadingAdviseToolStripMenuItem.Visible = WBSetting.print_loading_advise || WBSetting.print_gatepass_advise;
            if (WBSetting.Field("GM") == "Y")
            {
                this.editQuantityToolStripMenuItem.Visible = true;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            else if ((WBUser.UserLevel != "2") && (WBUser.UserLevel != "1"))
            {
                this.editQuantityToolStripMenuItem.Visible = false;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            else
            {
                this.editQuantityToolStripMenuItem.Visible = true;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            if (!WBSetting.activeTCS)
            {
                this.startWeighingToolStripMenuItem.Visible = false;
                this.stWeightToolStripMenuItem.Visible = true;
                this.ndWeightToolStripMenuItem.Visible = true;
                this.rdWeightToolStripMenuItem.Visible = true;
                this.thWeightToolStripMenuItem.Visible = true;
            }
            else
            {
                this.startWeighingToolStripMenuItem.Visible = true;
                this.startWeighingToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "A");
                this.stWeightToolStripMenuItem.Visible = false;
                this.ndWeightToolStripMenuItem.Visible = false;
                this.rdWeightToolStripMenuItem.Visible = false;
                this.thWeightToolStripMenuItem.Visible = false;
            }
            this.view4XTransactionForContainerOutToolStripMenuItem.Visible = WBSetting.Container == "Y";
            if (this.dataGridView1.Rows.Count <= 0)
            {
                this.ndWeightToolStripMenuItem.Enabled = false;
                this.rdWeightToolStripMenuItem.Enabled = false;
                this.thWeightToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.entryOtherPartyWeightToolStripMenuItem.Enabled = false;
                this.entryReturToolStripMenuItem.Enabled = false;
                this.cancelRecordToolStripMenuItem.Enabled = false;
                this.printToolStripMenuItem.Enabled = false;
                this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = false;
                this.qcStripMenuItem.Enabled = false;
                this.startWeighingToolStripMenuItem.Visible = WBSetting.activeTCS;
                this.view4XTransactionForContainerOutToolStripMenuItem.Visible = WBSetting.Container == "Y";
                if (WBSetting.Field("GM") == "Y")
                {
                    this.editQuantityToolStripMenuItem.Enabled = false;
                }
            }
            else
            {
                if ((this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString().Trim() == "Y") && (this.dataGridView1.CurrentRow.Cells["cancel_type"].Value.ToString().Trim() != "R"))
                {
                    this.ndWeightToolStripMenuItem.Enabled = false;
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    this.thWeightToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.editDeductionToolStripMenuItem.Enabled = false;
                    this.editReportDateToolStripMenuItem.Enabled = false;
                    this.editDNToolStripMenuItem.Enabled = false;
                    this.cancelRecordToolStripMenuItem.Enabled = false;
                    this.printToolStripMenuItem.Enabled = false;
                    this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = false;
                    this.qcStripMenuItem.Enabled = false;
                    if (WBSetting.Field("GM") == "Y")
                    {
                        this.editQuantityToolStripMenuItem.Enabled = false;
                    }
                }
                else
                {
                    string str2 = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                    string str3 = this.dataGridView1.CurrentRow.Cells["_3RD"].Value.ToString().Trim();
                    string str4 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                    string str5 = this.dataGridView1.CurrentRow.Cells["Printed"].Value.ToString().Trim();
                    this.ndWeightToolStripMenuItem.Enabled = ((str2 == "0") || (str2 == "")) ? WBUser.CheckTrustee("TRANS", "A") : false;
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    this.thWeightToolStripMenuItem.Enabled = ((!this.ndWeightToolStripMenuItem.Enabled && (!this.rdWeightToolStripMenuItem.Enabled && ((str4 == "0") || (str4 == "")))) && WBUser.CheckTrustee("TRANS", "A")) && (this.dataGridView1.CurrentRow.Cells["linked"].Value.ToString().Trim() != "");
                    this.editDeductionToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
                    this.editReportDateToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
                    this.editDNToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
                    this.cancelRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "D");
                    if (!this.cancelRecordToolStripMenuItem.Enabled)
                    {
                        this.cancelRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("REGISTRATION", "D");
                    }
                    this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
                    if (!this.editRecordToolStripMenuItem.Enabled)
                    {
                        this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("REGISTRATION", "E");
                    }
                    this.entryOtherPartyWeightToolStripMenuItem.Enabled = WBUser.CheckTrustee("EDIT_OPW", "E");
                    this.entryReturToolStripMenuItem.Enabled = WBUser.CheckTrustee("ADD_RETUR", "E");
                    if (WBSetting.Field("GM").ToString() != "N")
                    {
                        this.printToolStripMenuItem.Enabled = true;
                        this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = true;
                        this.editQuantityToolStripMenuItem.Enabled = true;
                    }
                    else if (str5.Trim() != "")
                    {
                        this.printToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_PRINT", "V");
                        this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_PRINT", "V");
                    }
                    else
                    {
                        this.printToolStripMenuItem.Enabled = true;
                        this.printLoadingUnloadingAdviseToolStripMenuItem.Enabled = true;
                    }
                    this.repairAllChecksumToolStripMenuItem.Visible = Convert.ToInt32(WBUser.UserLevel) == 1;
                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) == 1;
                    this.splitReferenceToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_SPLIT", "A");
                    this.mergeDOToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_SPLIT", "E");
                }
                string str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim();
                if ((str == "2X") || (str == ""))
                {
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    this.thWeightToolStripMenuItem.Enabled = false;
                }
                if (str == "")
                {
                    this.ndWeightToolStripMenuItem.Enabled = false;
                }
                if (this.dataGridView1.Rows.Count > 0)
                {
                    if (this.dataGridView1.CurrentRow.Cells["registrationClose_date"].Value.ToString() == "")
                    {
                        this.closeRegisteredTruckToolStripMenuItem.Text = "Close Registered Truck";
                        this.closeRegisteredTruckToolStripMenuItem.Enabled = true;
                    }
                    else
                    {
                        this.closeRegisteredTruckToolStripMenuItem.Text = "Unclose Registered Truck";
                        this.closeRegisteredTruckToolStripMenuItem.Enabled = (WBSetting.Field("GM").ToString() != "Y") ? WBUser.CheckTrustee("TRANS", "E") : true;
                    }
                    WBTable table = new WBTable();
                    WBTable table2 = new WBTable();
                    WBCondition condition = new WBCondition();
                    WBCondition condition2 = new WBCondition();
                    WBCondition condition3 = new WBCondition();
                    WBCondition condition4 = new WBCondition();
                    WBCondition condition5 = new WBCondition();
                    table.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dataGridView1.CurrentRow.Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                    table2.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["Transaction_Code"].Value.ToString() + "'"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        DataRow[] dgRows = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                        condition2.fillParameter("TRANS_SPAREPART_QTY", dgRows);
                        DataRow[] rowArray2 = new DataRow[] { table.DT.Rows[0] };
                        condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray2);
                        DataRow[] rowArray3 = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                        condition.fillParameter("TRANS_LOADING_QTY", rowArray3);
                        DataRow[] rowArray4 = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                        condition4.fillParameter("LOADING_NO_FLOWMETER", rowArray4);
                        DataRow[] rowArray5 = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                        condition5.fillParameter("LOADING_WITH_FLOWMETER", rowArray5);
                        if ((condition2.getResult() && (table.DT.Rows[0]["Unit"].ToString().ToUpper() != "KG")) && !condition3.getResult())
                        {
                            this.loadingQtyToolStripMenuItem.Visible = true;
                            this.loadingQtyToolStripMenuItem.Enabled = false;
                            this.sparePartQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "V");
                            this.sparePartQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "A");
                        }
                        else if ((condition4.getResult() || (condition3.getResult() || condition5.getResult())) || (condition.getResult() && (table.DT.Rows[0]["Unit"].ToString().ToUpper() != "KG")))
                        {
                            this.sparePartQtyToolStripMenuItem.Visible = true;
                            this.sparePartQtyToolStripMenuItem.Enabled = false;
                            this.loadingQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_LOADING_ENTRY", "V");
                            this.loadingQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_LOADING_ENTRY", "A");
                        }
                        else if (table.DT.Rows[0]["Trade"].ToString().ToUpper() == "N")
                        {
                            this.sparePartQtyToolStripMenuItem.Visible = true;
                            this.sparePartQtyToolStripMenuItem.Enabled = false;
                            this.loadingQtyToolStripMenuItem.Visible = true;
                            this.loadingQtyToolStripMenuItem.Enabled = false;
                        }
                        else
                        {
                            this.sparePartQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "V");
                            this.sparePartQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "A");
                            this.loadingQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_LOADING_ENTRY", "V");
                            this.loadingQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_LOADING_ENTRY", "A");
                        }
                    }
                }
            }
        }

        private void accessRightReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RepAccessRight().generateRep();
        }

        private void allowCaptureIndicatorIfNotStableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            string sqltext = "";
            bool flag = false;
            string str3 = "";
            str3 = DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
            sqltext = "Select * from wb_token where Token_Code = 'CAPTURE_NOT_STABLE'";
            table.OpenTable("wb_token", sqltext, WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["key_1"] = "N";
                table.DR["completed"] = "Y";
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Token_code"] = "CAPTURE_NOT_STABLE";
                table.DR["Token_No"] = "";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            table.DR = table.DT.Rows[0];
            if (table.DR["key_1"].ToString().Trim() == "Y")
            {
                TimeSpan span = (TimeSpan) (DateTime.Now - Convert.ToDateTime(table.DR["key_2"].ToString().Trim()));
                if (span.TotalSeconds <= 86400.0)
                {
                    MessageBox.Show("ALLOW CAPTURE IF WEIGHBRIGDE NOT STABLE ACTIVE\nELAPSED TIME = " + new DateTime(span.Ticks).ToString("HH:mm:ss"), "C A U T I O N");
                    return;
                }
                else
                {
                    table.DR.BeginEdit();
                    table.DR["key_1"] = "N";
                    table.DR.EndEdit();
                    table.Save();
                }
            }
            if (MessageBox.Show(" C A U T I O N !!!!! \nThis Approval Will Allow to Capture Weight if Weighbridge Not Stable\nProtection to Captured Weight Will Be Removed For 24 Hours after Receive PIN\nAre You Sure ??", " WARNING ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                FormToken token = new FormToken {
                    email_code = "CAPTURE_NOT_STABLE"
                };
                if (table.DR["completed"].ToString() != "Y")
                {
                    flag = false;
                    token.textBoxToken.Text = table.DR["token_No"].ToString();
                }
                else
                {
                    flag = true;
                    string[] tokenParams = new string[] { str3 };
                    token.initData(tokenParams, "CAPTURE_NOT_STABLE", "wb_token", "0", "");
                }
                token.pmode = "CAPTURE_NOT_STABLE";
                token.ShowDialog();
                if (token.saved)
                {
                    if (token.completed == "N")
                    {
                        table.DR.BeginEdit();
                        table.DR["token_No"] = token.textBoxToken.Text.ToString();
                        table.DR["Completed"] = "N";
                        table.DR["key_2"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        table.DR.EndEdit();
                        table.Save();
                    }
                    else
                    {
                        table.DR.BeginEdit();
                        table.DR["Completed"] = "Y";
                        table.DR["key_1"] = "Y";
                        table.DR["key_2"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        table.DR.EndEdit();
                        table.Save();
                    }
                }
            }
        }

        private void authorizationLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Authorization Log Report",
                labelHeader = { Text = "Log of Authorization" },
                labelMasterData = { Text = "Log for: " },
                flag = "AUTHORIZATION"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void autoSplitDOVesselToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSplitDoVessel vessel = new FormSplitDoVessel();
            vessel.ShowDialog();
            vessel.Dispose();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            if (WBSetting.cpuSAP == "Y")
            {
                if (WBSetting.zwb == "Y")
                {
                    this.uploadSAP();
                }
                else
                {
                    this.uploadSAPExceptZWB();
                }
            }
        }

        private void backgroundWorkerEmail_DoWork(object sender, DoWorkEventArgs e)
        {
            DateTime time;
            this.isSendEmail = true;
            WBMail mail = new WBMail();
            string str = "";
            string str2 = "";
            string zPath = "";
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            table3.OpenTable("wb_loc", "SELECT * FROM wb_location WHERE 1 = 1", WBData.conn);
            foreach (DataRow row in table3.DT.Rows)
            {
                string[] textArray1 = new string[] { " coy = '", row["coy"].ToString(), "' AND location_code = '", row["location_code"].ToString(), "'" };
                string str5 = string.Concat(textArray1);
                string[] textArray2 = new string[] { "select * from wb_email where ", str5, " and Email_date = '", DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd"), " 00:00:00' order by Email_code" };
                table.OpenTable("Wb_email", string.Concat(textArray2), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    table.DR = table.DT.NewRow();
                    table.DR["Email_code"] = "NOLOG";
                    table.DR["Status"] = "N";
                    table.DR["Coy"] = row["coy"].ToString();
                    table.DR["location_code"] = row["location_code"].ToString();
                    table.DR["Email_Date"] = DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd");
                    table.DT.Rows.Add(table.DR);
                    table.Save();
                    table.DR = table.DT.NewRow();
                    table.DR["Email_code"] = "REP_QC";
                    table.DR["Status"] = "N";
                    table.DR["Coy"] = row["coy"].ToString();
                    table.DR["location_code"] = row["location_code"].ToString();
                    table.DR["Email_Date"] = DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd");
                    table.DT.Rows.Add(table.DR);
                    table.Save();
                }
                if (Program.StrToDouble(WBSetting.weighingAnalysis, 0) > 0.0)
                {
                    string[] textArray3 = new string[] { "select * from wb_email where ", str5, " and Email_date = '", DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd"), " 00:00:00'  and Email_code = 'WEIGHING_ANALYSIS'  order by Email_code" };
                    table.OpenTable("Wb_email", string.Concat(textArray3), WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        RepWeighingTimeAnalysis analysis = new RepWeighingTimeAnalysis();
                        time = Convert.ToDateTime(DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd"));
                        analysis.monthCalendar1.Value = time;
                        analysis.monthCalendar2.Value = time;
                        bool flag4 = analysis.checkUntolerance(time, time, row["coy"].ToString(), row["location_code"].ToString());
                        analysis.Dispose();
                        if (flag4)
                        {
                            table.DR = table.DT.NewRow();
                            table.DR["Email_code"] = "WEIGHING_ANALYSIS";
                            table.DR["Status"] = "N";
                            table.DR["Coy"] = row["coy"].ToString();
                            table.DR["location_code"] = row["location_code"].ToString();
                            table.DR["Email_Date"] = DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd");
                            table.DT.Rows.Add(table.DR);
                            table.Save();
                        }
                    }
                }
            }
            table = new WBTable();
            string sqltext = "SELECT * FROM wb_email WHERE Status = 'N' AND Email_date < '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' AND email_code != 'WB_CALIBRATION' ORDER BY Email_code";
            table.OpenTable("Wb_email", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                foreach (DataRow row2 in table.DT.Rows)
                {
                    string[] textArray4 = new string[] { " coy = '", row2["coy"].ToString(), "' AND location_code = '", row2["location_code"].ToString(), "'" };
                    string str6 = string.Concat(textArray4);
                    table3.OpenTable("wb_loc", "SELECT * FROM wb_location WHERE " + str6, WBData.conn);
                    table2.OpenTable("wb_coy", "SELECT * FROM wb_company WHERE coy_code = '" + row2["coy"].ToString() + "'", WBData.conn);
                    try
                    {
                        str = row2["email_code"].ToString().ToUpper();
                        time = Convert.ToDateTime(row2["email_date"].ToString());
                        time.AddDays(-1.0);
                        string str8 = str;
                        string str7 = (str8 == "NOLOG") ? "LOG_NONE" : ((str8 == "TRANSLOG") ? "LOG_TRANS" : ((str8 == "CONTRACTLOG") ? "LOG_CONTRACT" : ((str8 == "REP_QC") ? "REP_QC" : ((str8 == "INDICATOR_STABILITY") ? "INDICATOR_STABILITY" : ((str8 == "WEIGHING_ANALYSIS") ? "WEIGHING_ANALYSIS" : str)))));
                        WBTable table4 = new WBTable();
                        string[] textArray5 = new string[] { "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE ", str6, " AND ( Email_Code ='", str7, "')" };
                        table4.OpenTable("wb_email_master", string.Concat(textArray5), WBData.conn);
                        if (table4.DT.Rows.Count > 0)
                        {
                            int num = 0;
                            while (true)
                            {
                                if (num >= table4.DT.Rows.Count)
                                {
                                    if (str == "CONTRACTLOG")
                                    {
                                        RepMasterDataLog log = new RepMasterDataLog();
                                        log.defineCombo();
                                        log.monthCalendar1.Value = time;
                                        log.monthCalendar2.Value = time;
                                        log.flag = "MASTER_DATA";
                                        log.comboMasterData.Text = "CONTRACT";
                                        log.generateRep(true, time, time, "", row2["coy"].ToString(), row2["location_code"].ToString(), "1");
                                        log.Dispose();
                                    }
                                    else if (str == "TRANSLOG")
                                    {
                                        RepTransLog_New new2 = new RepTransLog_New {
                                            monthCalendar1 = { Value = time },
                                            monthCalendar2 = { Value = time }
                                        };
                                        new2.generateRep(true, time, time, "", row2["coy"].ToString(), row2["location_code"].ToString(), "1");
                                        new2.Dispose();
                                    }
                                    else if (str == "REP_QC")
                                    {
                                        mail.Subject = mail.Subject + " " + time.ToString("dd/MM/yyyy");
                                        RepQualityControl control = new RepQualityControl {
                                            monthCalendar1 = { Value = time },
                                            monthCalendar2 = { Value = time },
                                            zAuto = true,
                                            outspec = true
                                        };
                                        control.generateRep(control.initTable(true, true, time, time, row2["coy"].ToString(), row2["location_code"].ToString()), time, row2["coy"].ToString(), row2["location_code"].ToString());
                                        control.Dispose();
                                    }
                                    else if (str == "INDICATOR_STABILITY")
                                    {
                                        RepIndicator indicator = new RepIndicator {
                                            monthCalendar1 = { Value = time },
                                            monthCalendar2 = { Value = time }
                                        };
                                        indicator.generateRep(true, time, time, "", row2["coy"].ToString(), row2["location_code"].ToString(), "1");
                                        indicator.Dispose();
                                    }
                                    else if (str == "WEIGHING_ANALYSIS")
                                    {
                                        RepWeighingTimeAnalysis analysis2 = new RepWeighingTimeAnalysis {
                                            monthCalendar1 = { Value = time },
                                            monthCalendar2 = { Value = time }
                                        };
                                        analysis2.generateRep(time, time, row2["coy"].ToString(), row2["location_code"].ToString(), "1");
                                        analysis2.Dispose();
                                    }
                                    mail.haveAttachment = false;
                                    if (str == "NOLOG")
                                    {
                                        str2 = (((("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + table2.DT.Rows[0]["coy_name"].ToString()) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + table3.DT.Rows[0]["location_name"].ToString()) + "</tr></table>") + "<br><br>NO HISTORY Report For Date : " + time.ToString("dd/MM/yyyy")) + "<br><br>Thank You. ";
                                    }
                                    else
                                    {
                                        mail.haveAttachment = true;
                                        if (str == "CONTRACTLOG")
                                        {
                                            string[] textArray7 = new string[] { Application.UserAppDataPath, @"\LogReport\", row2["coy"].ToString(), row2["location_code"].ToString(), "MASTERLOG_", time.ToString("ddMMyyyy"), ".htm" };
                                            zPath = string.Concat(textArray7);
                                        }
                                        else
                                        {
                                            string[] textArray8 = new string[] { Application.UserAppDataPath, @"\LogReport\", row2["coy"].ToString(), row2["location_code"].ToString(), str, "_", time.ToString("ddMMyyyy"), ".htm" };
                                            zPath = string.Concat(textArray8);
                                        }
                                        mail.mailAttachment(zPath);
                                        str2 = (("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + table2.DT.Rows[0]["coy_name"].ToString()) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + table3.DT.Rows[0]["location_name"].ToString()) + "</tr></table>";
                                        if (str == "CONTRACTLOG")
                                        {
                                            str2 = str2 + "<br><br>Attached is DO HISTORY Report For Date : " + time.ToString("dd/MM/yyyy");
                                        }
                                        else if (str == "TRANSLOG")
                                        {
                                            str2 = str2 + "<br><br>Attached is Transaction Log Report for date : " + time.ToString("dd/MM/yyyy");
                                        }
                                        else if (str == "REP_QC")
                                        {
                                            str2 = str2 + "<br><br>Attached is Outspec Quality Control Report for date : " + time.ToString("dd/MM/yyyy");
                                        }
                                        else if (str == "INDICATOR_STABILITY")
                                        {
                                            str2 = str2 + "<br><br>Attached is Weighbridge Indicator Stability Report for date : " + time.ToString("dd/MM/yyyy");
                                        }
                                        else if (str == "WEIGHING_ANALYSIS")
                                        {
                                            str2 = str2 + "<br><br>Attached is Weighing Time Analysis Report for date : " + time.ToString("dd/MM/yyyy");
                                        }
                                        str2 = str2 + "<br><br>Thank You. ";
                                        if ((str != "CONTRACTLOG") && (str == "TRANSLOG"))
                                        {
                                        }
                                    }
                                    mail.Body = str2;
                                    if ((str != "NOLOG") && ((str == "NOLOG") || !mail.haveAttachment))
                                    {
                                        row2.Delete();
                                    }
                                    else if (mail.SendMail())
                                    {
                                        row2.BeginEdit();
                                        row2["Status"] = 'Y';
                                        row2.EndEdit();
                                    }
                                    break;
                                }
                                DataRow row3 = table4.DT.Rows[num];
                                string[] textArray6 = new string[] { row3[0].ToString().Trim(), " ( ", row2["coy"].ToString().Trim(), " / ", table3.DT.Rows[0]["location_name"].ToString().Trim(), " )" };
                                mail.Subject = string.Concat(textArray6);
                                mail.To = row3[1].ToString().Trim();
                                mail.CC = row3[2].ToString().Trim();
                                num++;
                            }
                        }
                    }
                    catch
                    {
                        if (str == "REP_QC")
                        {
                            row2.Delete();
                        }
                    }
                }
                mail.Dispose();
                table.Save();
            }
            table = new WBTable();
            sqltext = "SELECT * FROM wb_email WHERE Status = 'N' AND Email_date <= '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' AND email_code = 'WB_CALIBRATION' ORDER BY Email_date";
            table.OpenTable("Wb_email", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                foreach (DataRow row4 in table.DT.Rows)
                {
                    string[] textArray9 = new string[] { " coy = '", row4["coy"].ToString(), "' AND location_code = '", row4["location_code"].ToString(), "'" };
                    string str9 = string.Concat(textArray9);
                    table3.OpenTable("wb_loc", "SELECT * FROM wb_location WHERE " + str9, WBData.conn);
                    table2.OpenTable("wb_coy", "SELECT * FROM wb_company WHERE coy_code = '" + row4["coy"].ToString() + "'", WBData.conn);
                    try
                    {
                        row4.BeginEdit();
                        str = row4["email_code"].ToString().ToUpper();
                        time = Convert.ToDateTime(row4["email_date"].ToString());
                        time.AddDays(-1.0);
                        string str10 = (str == "WB_CALIBRATION") ? "WB_CALIBRATION" : "";
                        WBTable table5 = new WBTable();
                        string[] textArray10 = new string[] { "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE ", str9, " AND ( Email_Code ='", str10, "')" };
                        table5.OpenTable("wb_email_master", string.Concat(textArray10), WBData.conn);
                        if (table5.DT.Rows.Count > 0)
                        {
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= table5.DT.Rows.Count)
                                {
                                    mail.haveAttachment = false;
                                    str2 = (((("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + table2.DT.Rows[0]["coy_name"].ToString()) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + table3.DT.Rows[0]["location_name"].ToString()) + "</tr></table>") + "<br><br>Below is list of expired / almost expired WB Calibration Certification per : " + time.ToString("dd/MM/yyyy") + "<br><br>") + "<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><th nowrap>No.</th><th nowrap>WB Code</th><th nowrap>Certification No</th><th nowrap>Calibration Date</th><th nowrap>Valid Date</th><th nowrap>Remark</th></tr>";
                                    WBTable table6 = new WBTable();
                                    int num2 = 1;
                                    table6.OpenTable("wb_setting", "SELECT DISTINCT(wbCode) FROM wb_setting WHERE " + WBData.CompanyLocation("  AND usedForWeighing = 'Y'"), WBData.conn);
                                    foreach (DataRow row6 in table6.DT.Rows)
                                    {
                                        WBTable table7 = new WBTable();
                                        table7.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE 1=1 AND WBCode = '" + row6["wbcode"].ToString() + "' ORDER BY valid_date DESC", WBData.conn);
                                        if (table7.DT.Rows.Count > 0)
                                        {
                                            table7.DR = table7.DT.Rows[0];
                                            DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(table7.DR["valid_date"].ToString()).ToShortDateString());
                                            DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(table7.DR["calibration_date"].ToString()).ToShortDateString());
                                            DateTime time5 = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                                            if (time3 <= time5)
                                            {
                                                object[] objArray1 = new object[12];
                                                objArray1[0] = str2;
                                                objArray1[1] = "<tr class='bd' style='background-color:red'><td nowrap align='center'>";
                                                objArray1[2] = num2;
                                                objArray1[3] = "</td><td nowrap>";
                                                objArray1[4] = table7.DR["wbcode"].ToString();
                                                objArray1[5] = "</td><td nowrap>";
                                                objArray1[6] = table7.DR["certification_no"].ToString();
                                                objArray1[7] = "</td><td nowrap>";
                                                objArray1[8] = Convert.ToDateTime(table7.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy");
                                                objArray1[9] = "</td><td nowrap>";
                                                objArray1[10] = Convert.ToDateTime(table7.DR["valid_date"].ToString()).ToString("dd/MM/yyyy");
                                                objArray1[11] = "</td><td nowrap>Certification has been expired</td></tr>";
                                                str2 = string.Concat(objArray1);
                                            }
                                            else if (((time3 > time5) && (time4 <= time5)) && ((time3 - time5).Days <= this.intervalForCalibration))
                                            {
                                                object[] objArray2 = new object[14];
                                                objArray2[0] = str2;
                                                objArray2[1] = "<tr class='bd' style='background-color:yellow'><td nowrap align='center'>";
                                                objArray2[2] = num2;
                                                objArray2[3] = "</td><td nowrap>";
                                                objArray2[4] = table7.DR["wbcode"].ToString();
                                                objArray2[5] = "</td><td nowrap>";
                                                objArray2[6] = table7.DR["certification_no"].ToString();
                                                objArray2[7] = "</td><td nowrap>";
                                                objArray2[8] = Convert.ToDateTime(table7.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy");
                                                objArray2[9] = "</td><td nowrap>";
                                                objArray2[10] = Convert.ToDateTime(table7.DR["valid_date"].ToString()).ToString("dd/MM/yyyy");
                                                objArray2[11] = "</td><td nowrap>Certification will be expired in ";
                                                objArray2[12] = (time3 - time5).Days;
                                                objArray2[13] = " day(s)</td></tr>";
                                                str2 = string.Concat(objArray2);
                                            }
                                            num2++;
                                        }
                                        table7.Dispose();
                                    }
                                    table6.Dispose();
                                    mail.Body = str2 + "</table>" + "<br><br>Thank You. ";
                                    if (mail.SendMail())
                                    {
                                        row4["Status"] = 'Y';
                                    }
                                    row4.EndEdit();
                                    break;
                                }
                                DataRow row5 = table5.DT.Rows[num3];
                                string[] textArray11 = new string[] { row5[0].ToString().Trim(), " ( ", row4["coy"].ToString().Trim(), " - ", row4["location_code"].ToString().Trim(), " )" };
                                mail.Subject = string.Concat(textArray11);
                                mail.To = row5[1].ToString().Trim();
                                mail.CC = row5[2].ToString().Trim();
                                num3++;
                            }
                        }
                    }
                    catch
                    {
                    }
                }
                mail.Dispose();
                table.Save();
            }
            this.isSendEmail = false;
        }

        private void blockStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_BLOCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormBlock block = new FormBlock();
                block.ShowDialog();
                block.Dispose();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string sqltext = this.checkPartial.Checked ? ("Select " + this.cField + " From vw_main Where " + WBData.CompanyLocation(" AND " + WBData.NotMarkDelInclReject)) : ("Select " + this.cField + " From vw_main Where " + WBData.CompanyLocation(""));
            if (!(this.checkPartial.Checked && this.checkWBCode.Checked))
            {
                if (!this.checkPartial.Checked)
                {
                    this.dFrom = this.dateTimePicker1.Value;
                    this.dTo = this.dateTimePicker2.Value;
                    if (this.dTo.Subtract(this.dFrom).Days <= 14)
                    {
                        string str2 = Program.DTOC(this.dFrom) + " 00:00:00";
                        string str3 = Program.DTOC(this.dTo) + " 00:00:00";
                        string[] textArray2 = new string[] { sqltext, " and ((Ref_Date>='", str2, "' and Ref_Date<='", str3, "') or (WX = '' AND ", WBData.NotMarkDeleted, "))" };
                        sqltext = string.Concat(textArray2);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mainform_096, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    sqltext = sqltext + " and (_2nd=0 or( WX='4X' and (_3rd=0 or _4th=0)) or WX = '')" + " and (split ='N' or split is null) ";
                }
                if (this.checkWBCode.Checked)
                {
                    string[] textArray3 = new string[] { sqltext, " and (WBCode1 = '", WBData.sWBCode, "' or WBCode2 = '", WBData.sWBCode, "' )" };
                    sqltext = string.Concat(textArray3);
                }
            }
            else
            {
                sqltext = sqltext + " and (_2nd=0 or( WX='4X' and (_3rd=0 or _4th=0)))" + " and (split ='N' or split is null) ";
                string[] textArray1 = new string[] { sqltext, " and (WX = '' or (WBCode1 = '", WBData.sWBCode, "' or WBCode2 = '", WBData.sWBCode, "' ))" };
                sqltext = string.Concat(textArray1);
            }
            this.Trans.Close();
            this.Trans.OpenTable("wb_transaction", sqltext, WBData.conn);
            this.DataReset();
            Cursor.Current = Cursors.Default;
            this.ShowStatus();
            this.SetDisplayOrder();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.Trans.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void CacheDisplayOrder()
        {
            FileStream stream = new FileStream(Directory.GetParent(Application.UserAppDataPath) + @"\col_pos.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            int[] o = new int[this.dataGridView1.ColumnCount];
            int index = 0;
            while (true)
            {
                if (index >= this.dataGridView1.ColumnCount)
                {
                    new XmlSerializer(typeof(int[])).Serialize((Stream) stream, o);
                    stream.Close();
                    return;
                }
                o[index] = this.dataGridView1.Columns[index].DisplayIndex;
                index++;
            }
        }

        private void cameraListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("CTR_CAMERA", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormCamera camera = new FormCamera();
                camera.ShowDialog();
                camera.Dispose();
            }
        }

        private void cancelRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] textArray1 = new string[] { Resource.Mainform_053, " ", this.dataGridView1.CurrentRow.Cells["REf"].Value.ToString(), " ", Resource.Mainform_054, "?" };
            if ((MessageBox.Show(string.Concat(textArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes) && (this.dataGridView1.Rows.Count > 0))
            {
                if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X")
                {
                    if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "")
                    {
                        if (!this.checkWeightValid("DELETE"))
                        {
                            MessageBox.Show("This User Do Not have CANCEL RECORD Authorization", "N O T I C E");
                            return;
                        }
                    }
                    else if (!this.checkWeightValid("DELETE_REGIS"))
                    {
                        MessageBox.Show("This User Do Not have CANCEL RECORD Authorization", "N O T I C E");
                        return;
                    }
                    string str = "";
                    str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    if (str.Substring(str.Length - 1, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                    {
                        string[] textArray2 = new string[] { Resource.Mainform_035, " ", Resource.Mainform_031, " ", Resource.Mainform_055 };
                        MessageBox.Show(string.Concat(textArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        str = "";
                        string[] aField = new string[] { "Uniq" };
                        string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                        int recNo = this.Trans.GetRecNo(aField, aFind);
                        if (this.Trans.DT.Rows[recNo]["Deleted"].ToString() != "Y")
                        {
                            this.token_in_progress = "";
                            string str3 = "Y";
                            WBTable table = new WBTable();
                            table.OpenTable("wb_cancel_type", "Select * from wb_cancel_type where cancel_type = 'C'", WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                str3 = (table.DT.Rows[0]["require_token"].ToString() == "Y") ? "Y" : "N";
                            }
                            if (WBSetting.Field("GM") != "Y")
                            {
                                if (this.lock_all_split())
                                {
                                    FormMessageEntry entry3 = new FormMessageEntry {
                                        lblHeader = { Text = "Cancel Transaction" },
                                        lblDetail = { Text = "Reason for Cancel Transaction" }
                                    };
                                    entry3.ShowDialog();
                                    this.reason = entry3.reason;
                                    if (this.reason != "")
                                    {
                                        this.update_all_split();
                                    }
                                    else
                                    {
                                        int num2 = 0;
                                        while (true)
                                        {
                                            if (num2 >= this.tbl_temp.DT.Rows.Count)
                                            {
                                                break;
                                            }
                                            this.tbl_temp.RLock(this.tbl_temp.DT.Rows[num2]["Uniq"].ToString().Trim(), false);
                                            num2++;
                                        }
                                    }
                                }
                            }
                            else if (this.lock_all_split())
                            {
                                if (str3 != "Y")
                                {
                                    FormMessageEntry entry2 = new FormMessageEntry {
                                        lblHeader = { Text = "Cancel Transaction" },
                                        lblDetail = { Text = "Reason for Cancel Transaction" }
                                    };
                                    entry2.ShowDialog();
                                    this.reason = entry2.reason;
                                }
                                else if (!this.Trans.BeforeEdit(this.dataGridView1, "CANCEL"))
                                {
                                    this.token_in_progress = "Y";
                                }
                                else
                                {
                                    FormMessageEntry entry = new FormMessageEntry {
                                        lblHeader = { Text = "Cancel Transaction" },
                                        lblDetail = { Text = "Reason for Cancel Transaction" }
                                    };
                                    entry.ShowDialog();
                                    this.reason = entry.reason;
                                }
                                this.update_all_split();
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mainform_059, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void cancelRegistrationReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepCancelTruckRegistration registration = new RepCancelTruckRegistration();
            registration.ShowDialog();
            registration.Dispose();
        }

        private void cancelTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCancelType type = new FormCancelType();
            type.ShowDialog();
            type.Dispose();
        }

        private void cancelWeighingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepCancelTrx trx = new RepCancelTrx();
            trx.ShowDialog();
            trx.Dispose();
        }

        private void changeProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeProfile = true;
            base.Hide();
            if (!WBUser.Login())
            {
                base.Show();
            }
            else
            {
                base.WindowState = FormWindowState.Minimized;
                this.Refresh();
                base.Show();
                this.fm = new FormMessage();
                this.fm.label1.Text = "Preparing . . . . . . . ";
                this.fm.Show();
                this.fm.Refresh();
                this.f_load();
                base.WindowState = FormWindowState.Maximized;
                this.fm.Dispose();
            }
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.sAPDestinationToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
            this.uploadSAPToolStripMenuItem.Text = "&Upload To " + this.sapIDSYS;
            this.templateSAPToolStripMenuItem.Text = Resource.Menu_042 + this.sapIDSYS;
        }

        private void check_active_Egrading(string wx)
        {
            if (!WBSetting.activeEGrading)
            {
                this.Timbang(wx);
            }
            else
            {
                EGrading_DBIntg intg = new EGrading_DBIntg {
                    sServer = WBSetting.EG_Server,
                    sDatabase = WBSetting.EG_Database,
                    sUserID = WBSetting.EG_usID,
                    sPassword = WBSetting.EG_password
                };
                if (!intg.TestConnect())
                {
                    MessageBox.Show(Resource.Mainform_029);
                }
                else
                {
                    this.tblDeduc.OpenTable("vw_entry_deduction", "select * from vw_entry_deduction where " + WBData.CompanyLocation(" and RefNumber = '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "' "), EGrading_DBIntg.conn);
                    if (this.tblDeduc.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show("Grader hasn't input data. No Grading Data. ", "E R R O R");
                    }
                    else
                    {
                        this.Timbang(wx);
                        this.tblDeduc.Dispose();
                        intg.Dispose();
                    }
                }
            }
        }

        private void check_final_weigh(string wx)
        {
            if (!(((this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "2X") || (wx != "2ND")) ? ((this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() == "4X") && (wx == "4TH")) : true))
            {
                this.Timbang(wx);
            }
            else
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBCondition condition = new WBCondition();
                WBCondition condition2 = new WBCondition();
                WBCondition condition3 = new WBCondition();
                WBCondition condition4 = new WBCondition();
                WBCondition condition5 = new WBCondition();
                table.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dataGridView1.CurrentRow.Cells["Comm_code"].Value.ToString() + "'"), WBData.conn);
                table2.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["Transaction_Code"].Value.ToString() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mainform_026, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    table2.DR = table2.DT.Rows[0];
                    DataRow[] dgRows = new DataRow[] { table.DR, table2.DR };
                    condition2.fillParameter("TRANS_SPAREPART_QTY", dgRows);
                    DataRow[] rowArray2 = new DataRow[] { table.DR };
                    condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray2);
                    DataRow[] rowArray3 = new DataRow[] { table.DR, table2.DR };
                    condition.fillParameter("TRANS_LOADING_QTY", rowArray3);
                    DataRow[] rowArray4 = new DataRow[] { table.DR, table2.DR };
                    condition4.fillParameter("LOADING_WITH_FLOWMETER", rowArray4);
                    DataRow[] rowArray5 = new DataRow[] { table.DR, table2.DR };
                    condition5.fillParameter("LOADING_NO_FLOWMETER", rowArray5);
                    if (condition4.getResult())
                    {
                        WBTable table3 = new WBTable();
                        string[] textArray1 = new string[9];
                        textArray1[0] = "select do_sap, internal_number from wb_transdo  where Ref = '";
                        textArray1[1] = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        textArray1[2] = "' and do_no = '";
                        textArray1[3] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                        textArray1[4] = "' and coy = '";
                        textArray1[5] = WBData.sCoyCode;
                        textArray1[6] = "' and location_code = '";
                        textArray1[7] = WBData.sLocCode;
                        textArray1[8] = "' and (( Density is null or Density = '0' ) or (Loading_qty is null or Loading_qty = '0'))";
                        table3.OpenTable("wb_transdo", string.Concat(textArray1), WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            MessageBox.Show("Density or Loading Quantity is 0", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            this.Timbang(wx);
                        }
                        table3.Dispose();
                    }
                    else if (condition5.getResult() || condition3.getResult())
                    {
                        WBTable table4 = new WBTable();
                        string[] textArray2 = new string[9];
                        textArray2[0] = "select do_sap, internal_number from wb_transdo  where Ref = '";
                        textArray2[1] = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        textArray2[2] = "' and do_no = '";
                        textArray2[3] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                        textArray2[4] = "' and coy = '";
                        textArray2[5] = WBData.sCoyCode;
                        textArray2[6] = "' and location_code = '";
                        textArray2[7] = WBData.sLocCode;
                        textArray2[8] = "' and ( Density is null or Density = '0' )";
                        table4.OpenTable("wb_transdo", string.Concat(textArray2), WBData.conn);
                        if (table4.DT.Rows.Count > 0)
                        {
                            MessageBox.Show("Density is 0", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            this.Timbang(wx);
                        }
                        table4.Dispose();
                    }
                    else if (condition.getResult() && (table.DR["Unit"].ToString().ToUpper() != "KG"))
                    {
                        WBTable table5 = new WBTable();
                        string[] textArray3 = new string[9];
                        textArray3[0] = "select do_sap, internal_number from wb_transdo  where Ref = '";
                        textArray3[1] = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        textArray3[2] = "' and do_no = '";
                        textArray3[3] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                        textArray3[4] = "' and coy = '";
                        textArray3[5] = WBData.sCoyCode;
                        textArray3[6] = "' and location_code = '";
                        textArray3[7] = WBData.sLocCode;
                        textArray3[8] = "' and ( loading_qty is null or loading_qty = '0' )";
                        table5.OpenTable("wb_transdo", string.Concat(textArray3), WBData.conn);
                        if (table5.DT.Rows.Count > 0)
                        {
                            MessageBox.Show(Resource.Mainform_025, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            this.Timbang(wx);
                        }
                        table5.Dispose();
                    }
                    else if (!(condition2.getResult() && (table.DR["Unit"].ToString().ToUpper() != "KG")))
                    {
                        if ((table.DR["Type"].ToString().ToUpper() == "F") && (table2.DR["IO"].ToString().ToUpper() == "I"))
                        {
                            this.check_active_Egrading(wx);
                        }
                        else
                        {
                            this.Timbang(wx);
                        }
                    }
                    else
                    {
                        WBTable table6 = new WBTable();
                        string[] textArray4 = new string[9];
                        textArray4[0] = "select * from wb_transBC  where Ref = '";
                        textArray4[1] = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        textArray4[2] = "' and do_no = '";
                        textArray4[3] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                        textArray4[4] = "' and coy = '";
                        textArray4[5] = WBData.sCoyCode;
                        textArray4[6] = "' and location_code = '";
                        textArray4[7] = WBData.sLocCode;
                        textArray4[8] = "' and ( item_load_qty IS NOT NULL AND item_load_qty <> '0' AND item_load_qty <> '' )";
                        table6.OpenTable("wb_transBC", string.Concat(textArray4), WBData.conn);
                        if (table6.DT.Rows.Count == 0)
                        {
                            MessageBox.Show(Resource.Mes_618_01 + this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() + Resource.Mes_618_02, "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            this.Timbang(wx);
                        }
                        table6.Dispose();
                    }
                }
                condition.Dispose();
                table.Dispose();
                table2.Dispose();
            }
        }

        private bool checkCollectivetoken()
        {
            bool flag = false;
            DateTime now = Convert.ToDateTime(this.dataGridView1.CurrentRow.Cells["Ref_Date"].Value.ToString());
            DateTime time = Convert.ToDateTime(now.ToShortDateString());
            WBTable table = new WBTable();
            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation("") + " AND token_code = 'EDIT_COLLECTIVE'  AND completed = 'Y'", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(row["key_1"].ToString()).ToShortDateString());
                DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(row["key_2"].ToString()).ToShortDateString());
                DateTime time5 = Convert.ToDateTime(Convert.ToDateTime(row["datetime1"].ToString()).ToShortDateString()).AddDays(7.0);
                if ((time >= time3) && (time <= time4))
                {
                    now = DateTime.Now;
                    if ((time5 - Convert.ToDateTime(now.ToShortDateString())).Days >= 0)
                    {
                        flag = true;
                        break;
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        private bool checkCompleteTrans(string aMenu)
        {
            string str = "0";
            string str2 = "0";
            if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "2X")
            {
                if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "4X")
                {
                    if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() == "")
                    {
                        MessageBox.Show("Can not" + aMenu + "transaction for registration!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return false;
                    }
                }
                else
                {
                    str2 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                    if ((str2 == "0") || (str2 == ""))
                    {
                        MessageBox.Show("Can not " + aMenu + " uncompleted transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return false;
                    }
                }
            }
            else
            {
                str = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                if ((str == "0") || (str == ""))
                {
                    MessageBox.Show("Can not " + aMenu + " uncompleted transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
            }
            str = "0";
            str2 = "0";
            return true;
        }

        private void checkPartial_CheckedChanged(object sender, EventArgs e)
        {
            this.dateTimePicker1.Enabled = !this.checkPartial.Checked;
            this.dateTimePicker2.Enabled = !this.checkPartial.Checked;
            this.buttonFilter.PerformClick();
        }

        private void checkShowCheckSum_CheckedChanged(object sender, EventArgs e)
        {
            this.dataGridView1.Refresh();
        }

        private void checkWBCode_CheckedChanged(object sender, EventArgs e)
        {
            this.buttonFilter.PerformClick();
        }

        private bool checkWeightValid(string vpmode)
        {
            bool flag3;
            if (vpmode == "QC")
            {
                this.qcStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS_QC", "V");
                if (!this.qcStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            if (vpmode == "DL")
            {
                this.DLAdoptMenuItem.Enabled = WBUser.CheckTrustee("DL_ADOPT", "E");
                if (!this.qcStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            if (vpmode != "2ND")
            {
                if (vpmode != "3RD")
                {
                    if (vpmode == "4TH")
                    {
                        string str3 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                        this.thWeightToolStripMenuItem.Enabled = (!this.ndWeightToolStripMenuItem.Enabled && (!this.rdWeightToolStripMenuItem.Enabled && ((str3 == "0") || (str3 == "")))) && (this.dataGridView1.CurrentRow.Cells["linked"].Value.ToString().Trim() != "");
                        if (!this.thWeightToolStripMenuItem.Enabled)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    if (!this.rdWeightToolStripMenuItem.Enabled)
                    {
                        return false;
                    }
                }
            }
            else
            {
                string str = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                this.ndWeightToolStripMenuItem.Enabled = (str == "0") || (str == "");
                if (!this.ndWeightToolStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            this.repairAllChecksumToolStripMenuItem.Visible = Convert.ToInt32(WBUser.UserLevel) == 1;
            if (vpmode == "EDIT")
            {
                if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "")
                {
                    if (!WBUser.CheckTrustee("TRANS", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.repairChecksumToolStripMenuItem.Enabled = false;
                        return false;
                    }
                    else
                    {
                        this.editRecordToolStripMenuItem.Enabled = true;
                        this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                    }
                }
                else if (WBUser.CheckTrustee("REGISTRATION", "E"))
                {
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                }
            }
            if ((vpmode != "QTY") || WBUser.CheckTrustee("TRANS_QTY", "E"))
            {
                if ((vpmode != "DEDUCTION") || WBUser.CheckTrustee("TRANS", "E"))
                {
                    if ((vpmode != "EDIT_SPB") || WBUser.CheckTrustee("TRANS", "E"))
                    {
                        if ((vpmode != "EDIT_REPORTDATE") || WBUser.CheckTrustee("TRANS", "E"))
                        {
                            if (vpmode == "EDIT_OPW")
                            {
                                if (!WBUser.CheckTrustee("EDIT_OPW", "E"))
                                {
                                    this.entryOtherPartyWeightToolStripMenuItem.Enabled = false;
                                    this.repairChecksumToolStripMenuItem.Enabled = false;
                                    return false;
                                }
                                else
                                {
                                    this.entryOtherPartyWeightToolStripMenuItem.Enabled = true;
                                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                                }
                            }
                            if (vpmode == "ADD_RETUR")
                            {
                                if (!WBUser.CheckTrustee("ADD_RETUR", "E"))
                                {
                                    this.entryReturToolStripMenuItem.Enabled = false;
                                    return false;
                                }
                                else
                                {
                                    this.entryReturToolStripMenuItem.Enabled = true;
                                }
                            }
                            if (vpmode == "DELETE_REGIS")
                            {
                                if (!WBUser.CheckTrustee("REGISTRATION", "D"))
                                {
                                    this.cancelRecordToolStripMenuItem.Enabled = false;
                                    this.repairChecksumToolStripMenuItem.Enabled = false;
                                    return false;
                                }
                                else
                                {
                                    this.cancelRecordToolStripMenuItem.Enabled = true;
                                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                                }
                            }
                            if (vpmode == "DELETE")
                            {
                                if (!WBUser.CheckTrustee("TRANS", "D"))
                                {
                                    this.cancelRecordToolStripMenuItem.Enabled = false;
                                    this.repairChecksumToolStripMenuItem.Enabled = false;
                                    return false;
                                }
                                else
                                {
                                    this.cancelRecordToolStripMenuItem.Enabled = true;
                                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                                }
                            }
                            flag3 = true;
                        }
                        else
                        {
                            flag3 = false;
                        }
                    }
                    else
                    {
                        flag3 = false;
                    }
                }
                else
                {
                    flag3 = false;
                }
            }
            else
            {
                flag3 = false;
            }
            return flag3;
        }

        private void closeRegisteredTruckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString();
            string str2 = this.dataGridView1.CurrentRow.Cells["Time2"].Value.ToString();
            string str3 = this.dataGridView1.CurrentRow.Cells["Time4"].Value.ToString();
            string str4 = this.dataGridView1.CurrentRow.Cells["registrationClose_date"].Value.ToString();
            if (!(((str != "2X") || (str2 == "")) ? ((str == "4X") && (str3 != "")) : true))
            {
                string[] textArray11 = new string[] { Resource.Mainform_083, " ", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "!\n", Resource.Mainform_084 };
                MessageBox.Show(string.Concat(textArray11), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string str5 = this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString();
                if (str4 == "")
                {
                    string[] textArray1 = new string[] { Resource.Mainform_080, " '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "'", Resource.Mainform_081, " '", this.dataGridView1.CurrentRow.Cells["truck_number"].Value.ToString(), "'?" };
                    if (MessageBox.Show(string.Concat(textArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_transaction", " select * from wb_transaction where uniq = " + str5.Trim(), WBData.conn);
                        table.DR = table.DT.Rows[0];
                        table.DR.BeginEdit();
                        table.DR["registrationClose_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                        table.DR["registrationClose_time"] = DateTime.Now.ToString("HH:mm:ss");
                        table.DR["registrationClose_by"] = WBUser.UserID.Trim();
                        table.DR["reposted"] = "N";
                        table.DR["checksum"] = table.Checksum_Main(table.DR);
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Close Registered Truck" };
                        Program.updateLogHeader("wb_transaction", table.DR["uniq"].ToString(), logField, logValue);
                        table.Dispose();
                        this.buttonFilter.PerformClick();
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { str5 };
                        this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                }
                else
                {
                    string[] textArray6 = new string[] { Resource.Mainform_082, " '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "'", Resource.Mainform_081, " '", this.dataGridView1.CurrentRow.Cells["truck_number"].Value.ToString(), "'?" };
                    if ((MessageBox.Show(string.Concat(textArray6), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) && this.Trans.BeforeEdit(this.dataGridView1, "EDIT"))
                    {
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", " select * from wb_transaction where uniq = " + str5.Trim(), WBData.conn);
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["registrationClose_date"] = DBNull.Value;
                        table2.DR["registrationClose_time"] = "";
                        table2.DR["registrationClose_by"] = WBUser.UserID.Trim();
                        table2.DR["reposted"] = "N";
                        table2.DR["checksum"] = table2.Checksum_Main(table2.DR);
                        table2.DR.EndEdit();
                        table2.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unclose Registered Truck" };
                        Program.updateLogHeader("wb_transaction", table2.DR["uniq"].ToString(), logField, logValue);
                        table2.Dispose();
                        this.buttonFilter.PerformClick();
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { str5 };
                        this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                }
            }
        }

        private void commodityToleranceReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepComTolerance tolerance = new RepComTolerance();
            tolerance.ShowDialog();
            tolerance.Dispose();
        }

        private void compareDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCompareDB edb = new FormCompareDB();
            edb.ShowDialog();
            edb.Dispose();
        }

        private void compositToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormComposit composit = new FormComposit();
            composit.ShowDialog();
            composit.Dispose();
        }

        private void configurationToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
        }

        private void contractLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepContractLog log = new RepContractLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void copraReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA1 pffbla = new RepFFBLA1 {
                checkBunch = { Checked = false },
                checkColly = { Checked = true },
                ffb = false
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void copyToNewCompanyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewCoy coy = new NewCoy();
            coy.ShowDialog();
            coy.Dispose();
        }

        private void coytoolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCompany company = new FormCompany();
            company.ShowDialog();
            company.Dispose();
        }

        private void dailyReceiptSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA2 pffbla = new RepFFBLA2 {
                checkBunch = { Checked = false },
                checkColly = { Checked = true },
                ffb = false
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void databaseConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCfg cfg = new FormCfg {
                firstrun = false
            };
            cfg.ShowDialog();
            if (cfg.pReturn)
            {
                this.ShowLayout();
                this.DataReset();
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.Timbang("VIEW");
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["cancel_type"].Value.ToString() == "R")
            {
                e.CellStyle.BackColor = Color.Bisque;
                e.CellStyle.SelectionBackColor = Color.Coral;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["mark_accident"].Value.ToString() == "X")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["zAuto"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Yellow;
                e.CellStyle.SelectionBackColor = Color.YellowGreen;
            }
            else if (this.checkShowCheckSum.Checked)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.Rows[e.RowIndex].Cells["uniq"].Value.ToString() };
                int recNo = this.Trans.GetRecNo(aField, aFind);
                if (!this.Trans.ValidChecksum_Main(this.Trans.DT.Rows[recNo]))
                {
                    e.CellStyle.BackColor = Color.DimGray;
                    e.CellStyle.SelectionBackColor = Color.Gray;
                    e.CellStyle.ForeColor = Color.White;
                }
            }
            else if ((WBSetting.rangeFlagColor != null) && (WBSetting.rangeFlagColor != ""))
            {
                DataGridViewCell cell = this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                char[] separator = new char[] { '-' };
                string[] strArray = WBSetting.rangeFlagColor.ToString().Split(separator);
                string str = this.dataGridView1.Rows[e.RowIndex].Cells["Register_Date"].Value.ToString();
                string str2 = this.dataGridView1.Rows[e.RowIndex].Cells["Date1"].Value.ToString();
                string str3 = this.dataGridView1.Rows[e.RowIndex].Cells["Date2"].Value.ToString();
                string str4 = this.dataGridView1.Rows[e.RowIndex].Cells["Date3"].Value.ToString();
                string str5 = this.dataGridView1.Rows[e.RowIndex].Cells["Date4"].Value.ToString();
                string str6 = this.dataGridView1.Rows[e.RowIndex].Cells["WX"].Value.ToString();
                string str7 = this.dataGridView1.Rows[e.RowIndex].Cells["Gross"].Value.ToString();
                if ((strArray[0] != "0") && (((str != "") && (str2 != "")) && (str7 == "0")))
                {
                    char[] chArray2 = new char[] { ' ' };
                    if (Convert.ToInt32(DateTime.Now.Subtract(Convert.ToDateTime(str.Split(chArray2)[0] + " " + this.dataGridView1.Rows[e.RowIndex].Cells["Register_Time"].Value.ToString())).TotalMinutes) > (Convert.ToDouble(strArray[0]) * 60.0))
                    {
                        e.CellStyle.BackColor = Color.GreenYellow;
                        e.CellStyle.SelectionBackColor = Color.LimeGreen;
                        cell.ToolTipText = "Truck has not weighed for 1st time for more than " + strArray[0] + " hours";
                    }
                }
                if ((strArray[1] != "0") && (((str2 != "") && (str3 == "")) && (str7 != "0")))
                {
                    char[] chArray3 = new char[] { ' ' };
                    if (Convert.ToInt32(DateTime.Now.Subtract(Convert.ToDateTime(str2.Split(chArray3)[0] + " " + this.dataGridView1.Rows[e.RowIndex].Cells["Time1"].Value.ToString())).TotalMinutes) > (Convert.ToDouble(strArray[1]) * 60.0))
                    {
                        e.CellStyle.BackColor = Color.BurlyWood;
                        e.CellStyle.SelectionBackColor = Color.SaddleBrown;
                        cell.ToolTipText = "Truck has not weighed for 2nd time for more than " + strArray[1] + " hours";
                    }
                }
                if (((strArray[2] != "0") && (str6 == "4X")) && ((str3 != "") && (str4 == "")))
                {
                    char[] chArray4 = new char[] { ' ' };
                    if (Convert.ToInt32(DateTime.Now.Subtract(Convert.ToDateTime(str3.Split(chArray4)[0] + " " + this.dataGridView1.Rows[e.RowIndex].Cells["Time2"].Value.ToString())).TotalMinutes) > (Convert.ToDouble(strArray[2]) * 60.0))
                    {
                        e.CellStyle.BackColor = Color.MediumOrchid;
                        e.CellStyle.SelectionBackColor = Color.Indigo;
                        cell.ToolTipText = "Truck has not weighed for 3rd time for more than " + strArray[2] + " hours";
                    }
                }
                if (((strArray[3] != "0") && (str6 == "4X")) && ((str4 != "") && (str5 == "")))
                {
                    char[] chArray5 = new char[] { ' ' };
                    if (Convert.ToInt32(DateTime.Now.Subtract(Convert.ToDateTime(str4.Split(chArray5)[0] + " " + this.dataGridView1.Rows[e.RowIndex].Cells["Time3"].Value.ToString())).TotalMinutes) > (Convert.ToDouble(strArray[3]) * 60.0))
                    {
                        e.CellStyle.BackColor = Color.Orange;
                        e.CellStyle.SelectionBackColor = Color.DarkOrange;
                        cell.ToolTipText = "Truck has not weighed for 4th time for more than " + strArray[3] + " hours";
                    }
                }
            }
            if ((e.ColumnIndex == this.dataGridView1.Columns["Density"].Index) && (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] != null))
            {
                this.dataGridView1.Columns["Density"].DefaultCellStyle.Format = "N4";
            }
        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this.TextFind.Focus();
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
            }
        }

        public void DataReset()
        {
            string str = this.dataGridView1.SortOrder.ToString();
            DataGridViewColumn sortedColumn = this.dataGridView1.SortedColumn;
            if (this.Trans.BeforeEdit(this.dataGridView1, "REFRESH"))
            {
                this.Trans.ReOpen();
                this.Trans.AfterEdit("REFRESH");
                ListSortDirection direction = (str != "Ascending") ? ListSortDirection.Descending : ListSortDirection.Ascending;
                this.dataGridView1.Sort(this.dataGridView1.Columns[sortedColumn.Name.ToString()], direction);
                if (this.Trans.DT.Rows.Count > 0)
                {
                    foreach (DataColumn column2 in this.Trans.DT.Columns)
                    {
                        this.Trans.DR = this.Trans.DT.Rows[0];
                        if (column2.ColumnName.ToString().ToUpper() == "NET")
                        {
                        }
                        if (this.Trans.DR[column2.ColumnName].GetType().ToString() == "System.Double")
                        {
                            this.dataGridView1.Columns[column2.ColumnName].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dataGridView1.Columns[column2.ColumnName].DefaultCellStyle.Format = "N0";
                        }
                    }
                }
            }
            else
            {
                return;
            }
            this.dataGridView1.Refresh();
        }

        private void dateTimePicker1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFilter.PerformClick();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void dateTimePicker2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFilter.PerformClick();
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
        }

        private void destinationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSource source = new FormSource();
            source.ShowDialog();
            source.Dispose();
        }

        private void disableFeaturesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("DC_TRUSTEE", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormCondition condition = new FormCondition {
                    pMode = "DISABLE_CONDITION",
                    pFilter = " AND allow_disable = 'Y'"
                };
                condition.ShowDialog();
                condition.Dispose();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void divisionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepDivision division = new RepDivision();
            division.ShowDialog();
            division.Dispose();
        }

        private void DLAdoptMenuItem_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("DL_ADOPT", "V"))
            {
                this.Timbang("DL");
            }
        }

        private void doDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepRecIssue issue = new RepRecIssue();
            issue.ShowDialog();
            issue.Dispose();
        }

        private void DriverBlacklistReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepDriverBlacklist blacklist = new RepDriverBlacklist();
            blacklist.ShowDialog();
            blacklist.Dispose();
        }

        private void editDeductionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
            {
                MessageBox.Show(Resource.Mainform_074, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (!this.checkWeightValid("DEDUCTION"))
            {
                MessageBox.Show("This user do not have authorization to edit quantity this transaction!");
            }
            else
            {
                this.Timbang("DEDUCTION");
                this.buttonFilter.PerformClick();
            }
        }

        private void editDNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
            {
                MessageBox.Show(Resource.Mainform_074, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (!this.checkWeightValid("EDIT_SPB"))
            {
                MessageBox.Show("This user do not have authorization to edit quantity this transaction!");
            }
            else
            {
                this.Timbang("EDIT_SPB");
                this.buttonFilter.PerformClick();
            }
        }

        private void editflag(string ref_no, string flag)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + ref_no + "'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                MessageBox.Show("Can not find this transaction");
            }
            else
            {
                table.DR = table.DT.Rows[0];
                string keyField = table.DR["uniq"].ToString();
                table.DR.BeginEdit();
                if (flag != "P")
                {
                    table.DR["reposted"] = "N";
                }
                else
                {
                    table.DR["reposted"] = "N";
                    table.DR["posted"] = "N";
                }
                table.DR["Change_By"] = WBUser.UserID;
                table.DR["Change_Date"] = DateTime.Now;
                table.DR["checksum"] = table.Checksum(table.DR);
                table.DR.EndEdit();
                table.Save();
                if (flag == "P")
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Change Flag Posted Transaction " };
                    Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                }
                else
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Change Flag Reposted Transaction " };
                    Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                }
                MessageBox.Show("Flag upload has been changed succesfully for this transaction", " INFORMATION");
                table.Dispose();
            }
        }

        private void editQuantityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!this.checkWeightValid("QTY"))
            {
                MessageBox.Show("This user do not have authorization to edit quantity this transaction!");
            }
            else
            {
                this.Timbang("QTY");
                this.buttonFilter.PerformClick();
            }
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkWeightValid("EDIT"))
            {
                if (this.checkCollectivetoken())
                {
                    this.Timbang_CollectiveToken("EDIT");
                }
                else
                {
                    this.Timbang("EDIT");
                }
            }
        }

        private void editReportDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
            {
                MessageBox.Show(Resource.Mainform_074, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (!this.checkWeightValid("EDIT_REPORTDATE"))
            {
                MessageBox.Show("This user do not have authorization to edit quantity this transaction!");
            }
            else
            {
                this.Timbang("EDIT_REPORTDATE");
                this.buttonFilter.PerformClick();
            }
        }

        private void emailRecipientReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepEmailRecipient recipient = new RepEmailRecipient();
            recipient.ShowDialog();
            recipient.Dispose();
        }

        private void emailRecipientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_EMAIL", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormEmail email = new FormEmail();
                email.ShowDialog();
                email.Dispose();
            }
        }

        private void entryDeliveryNoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEntryDeliveryNote note = new FormEntryDeliveryNote();
            note.ShowDialog();
            if (note.pReturn)
            {
                this.ShowLayout();
                this.DataReset();
            }
            note.Dispose();
        }

        private void entryFFBGradingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormEntryFFB_initial().ShowDialog();
        }

        private void entryGradingDivisionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Timbang("GRADING");
        }

        private void entryOtherPartyWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
            {
                MessageBox.Show(Resource.Mainform_074, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (this.checkWeightValid("EDIT_OPW"))
            {
                if (WBSetting.IntegrationSAP == "Y")
                {
                    Sync.get_OPW_fromSAP(this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString().Trim(), true);
                }
                this.Timbang("EDIT_OPW");
            }
        }

        private void entryReturToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
            {
                MessageBox.Show(Resource.Mainform_084, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                WBCondition condition = new WBCondition();
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_do", "Select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString().Trim() + "'"), WBData.conn);
                table.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                table.DR = table.DT.Rows[0];
                DataRow[] dgRows = new DataRow[] { table.DR, table2.DT.Rows[0] };
                condition.fillParameter("ENTRY_RETURN_QTY", dgRows);
                if (!condition.getResult())
                {
                    MessageBox.Show(Resource.Mainform_085, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    condition.Dispose();
                    if (this.checkWeightValid("ADD_RETUR"))
                    {
                        this.Timbang("ADD_RETUR");
                    }
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mainform_018, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string keyField = "";
                string machineName = Environment.MachineName;
                string str3 = "";
                IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                int index = 0;
                while (true)
                {
                    if (index >= addressList.Length)
                    {
                        if (!WBSetting.loginWithActiveDirectory)
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                keyField = table.DR["uniq"].ToString();
                                table.DR.BeginEdit();
                                table.DR["lastLogout"] = DateTime.Now;
                                table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                                table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                                table.DR["checksum"] = table.Checksum(table.DR);
                                table.DR.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                                Program.updateLogHeader("wb_user", keyField, logField, logValue);
                            }
                            table.Dispose();
                        }
                        if (Program.TMCready)
                        {
                            base.Close();
                        }
                        else
                        {
                            Application.Exit();
                        }
                        break;
                    }
                    IPAddress address = addressList[index];
                    AddressFamily addressFamily = address.AddressFamily;
                    if (addressFamily.ToString() == "InterNetwork")
                    {
                        str3 = address.ToString();
                    }
                    index++;
                }
            }
        }

        public void f_load()
        {
            int num1;
            this.Status1.Text = "Wilmar Group - Copyright \x00a9, V." + base.ProductVersion.ToString();
            WBTable table = new WBTable();
            table.OpenTable("wb_loc", "select * from wb_location", WBData.conn);
            if (table.DT.Rows[0]["version"].ToString() != base.ProductVersion.ToString())
            {
                Version version = new Version(base.ProductVersion.ToString());
                if (table.DT.Rows[0]["version"].ToString().Trim() == "")
                {
                    table.DT.Rows[0]["version"] = "1.0.0.0";
                }
                int num3 = version.CompareTo(new Version(table.DT.Rows[0]["version"].ToString()));
                if (num3 > 0)
                {
                    table.DT.Rows[0]["version"] = base.ProductVersion.ToString();
                    table.DT.Rows[0]["checksum"] = table.Checksum(table.DT.Rows[0]);
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "LOAD-LOGIN", "SYSTEM", "Update Version" };
                    Program.updateLogHeader("wb_location", table.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                }
                else if (num3 < 0)
                {
                    string[] textArray3 = new string[11];
                    textArray3[0] = Resource.Mainform_001;
                    textArray3[1] = "\n";
                    textArray3[2] = Resource.Mainform_002;
                    textArray3[3] = " ";
                    textArray3[4] = table.DT.Rows[0]["version"].ToString();
                    textArray3[5] = "\n";
                    textArray3[6] = Resource.Mainform_003;
                    textArray3[7] = " ";
                    textArray3[8] = base.ProductVersion.ToString();
                    textArray3[9] = "\n\n";
                    textArray3[10] = Resource.Mainform_004;
                    MessageBox.Show(string.Concat(textArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            table.Dispose();
            this.schDataToolStripMenuItem.Visible = Convert.ToInt16(WBUser.UserLevel) == 1;
            this.timerSAPUpd.Enabled = false;
            this.lblDate.Visible = false;
            this.fm.label1.Text = "Loading WB.Net Setting . . . . . .";
            this.fm.label1.Refresh();
            WBSetting.OpenSetting(true);
            this.cField = WBTable.cFieldTrans;
            string s = WBSetting.colour.ToString();
            uint num4 = <PrivateImplementationDetails>.ComputeStringHash(s);
            if (num4 > 0x727b390b)
            {
                if (num4 > 0xa37f187c)
                {
                    if (num4 == 0xa953c75c)
                    {
                        if (s == "Green")
                        {
                            this.label1.BackColor = Color.Green;
                            goto TR_0062;
                        }
                    }
                    else if ((num4 == 0xb682ba1f) && (s == "Purple"))
                    {
                        this.label1.BackColor = Color.Purple;
                        goto TR_0062;
                    }
                }
                else if (num4 == 0x8bb8038d)
                {
                    if (s == "Pink")
                    {
                        this.label1.BackColor = Color.Pink;
                        goto TR_0062;
                    }
                }
                else if ((num4 == 0xa37f187c) && (s == "Red"))
                {
                    this.label1.BackColor = Color.Red;
                    goto TR_0062;
                }
            }
            else if (num4 == 0x2b043744)
            {
                if (s == "Black")
                {
                    this.label1.BackColor = Color.Black;
                    goto TR_0062;
                }
            }
            else if (num4 == 0x6c94b6b3)
            {
                if (s == "Gold")
                {
                    this.label1.BackColor = Color.Gold;
                    goto TR_0062;
                }
            }
            else if ((num4 == 0x727b390b) && (s == "Orange"))
            {
                this.label1.BackColor = Color.Orange;
                goto TR_0062;
            }
            this.label1.BackColor = Color.RoyalBlue;
        TR_0062:
            this.fm.label1.Text = "Loading WB.Net Data . . . . . .";
            this.fm.label1.Refresh();
            if (WBUser.UserGroup == "ADMIN")
            {
                this.locationToolStripMenuItem.Visible = true;
                this.coytoolStripMenuItem.Visible = true;
                this.copyToNewCompanyToolStripMenuItem.Visible = true;
                this.compareDatabaseToolStripMenuItem.Visible = true;
            }
            else
            {
                this.locationToolStripMenuItem.Visible = false;
                this.coytoolStripMenuItem.Visible = false;
                this.toolStripSeparator5.Visible = false;
                this.copyToNewCompanyToolStripMenuItem.Visible = false;
                this.compareDatabaseToolStripMenuItem.Visible = false;
            }
            this.Trans.OpenTable("wb_transaction", "Select " + this.cField + " From vw_main Where 1=2", WBData.conn);
            this.dataGridView1.DataSource = this.Trans.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Date1"], ListSortDirection.Descending);
            this.dataGridView1.Columns["coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["seal"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["In_Time"].Visible = false;
            this.dataGridView1.Columns["Out_Time"].Visible = false;
            this.dataGridView1.Columns["Nego"].Visible = false;
            this.dataGridView1.Columns["Sto"].Visible = false;
            this.dataGridView1.Columns["Gr"].Visible = false;
            this.dataGridView1.Columns["Do"].Visible = false;
            this.dataGridView1.Columns["Checksum"].Visible = false;
            this.dataGridView1.Columns["Report2_Date"].Visible = false;
            this.dataGridView1.Columns["Relation_Code"].Visible = false;
            this.dataGridView1.Columns["Tolling"].Visible = false;
            this.dataGridView1.Columns["zAuto"].Visible = false;
            this.dataGridView1.Columns["Edit_qty"].Visible = false;
            this.dataGridView1.Columns["Edit_data"].Visible = false;
            if (WBSetting.Field("GM") == "Y")
            {
                this.dataGridView1.Columns["token"].Visible = true;
                this.dataGridView1.Columns["Completed"].Visible = true;
                this.tsCCTC.Visible = true;
            }
            else
            {
                this.dataGridView1.Columns["token"].Visible = false;
                this.dataGridView1.Columns["Completed"].Visible = false;
                this.tsCCTC.Visible = false;
            }
            this.dataGridView1.Columns["WX"].HeaderText = "WX";
            this.dataGridView1.Columns["WX"].Width = 50;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dataGridView1.Columns["ref"].HeaderText = "Ref./Doc. No";
            this.dataGridView1.Sort(this.dataGridView1.Columns["Ref"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["ref"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            this.dataGridView1.Columns["Ref"].Width = 0x69;
            this.dataGridView1.Columns["Ref_Date"].HeaderText = "Ref. Date";
            this.dataGridView1.Columns["Comm_Code"].HeaderText = "Commodity Code";
            this.dataGridView1.Columns["Comm_Name"].HeaderText = "Commodity Name";
            this.dataGridView1.Columns["Density"].HeaderText = "Density";
            this.dataGridView1.Columns["loading_qty"].HeaderText = "Loading Qty";
            this.dataGridView1.Columns["Truck_Number"].HeaderText = "Vehicle No.";
            if (WBSetting.gatepass_registration)
            {
                this.dataGridView1.Columns["Gatepass_Number"].Visible = true;
            }
            if (WBSetting.Container != "Y")
            {
                this.dataGridView1.Columns["Truck_Trailer_Number"].Visible = false;
                this.dataGridView1.Columns["Truck_Number2"].Visible = false;
            }
            else
            {
                this.dataGridView1.Columns["Truck_Trailer_Number"].Visible = true;
                this.dataGridView1.Columns["Truck_Number2"].Visible = true;
                this.dataGridView1.Columns["Truck_Number2"].HeaderText = "2nd Vehicle No.";
                this.dataGridView1.Columns["Truck_Trailer_Number"].HeaderText = "Trailer No.";
            }
            this.dataGridView1.Columns["License_No"].HeaderText = "License of Driver";
            this.dataGridView1.Columns["Name"].HeaderText = "Driver Name";
            this.dataGridView1.Columns["Transporter_Code"].HeaderText = "Transporter";
            this.dataGridView1.Columns["Delivery_Note"].HeaderText = "Delivery Note";
            this.dataGridView1.Columns["Do_No"].HeaderText = "Do No";
            this.dataGridView1.Columns["Delivery_Date"].HeaderText = "Delivery Date";
            this.dataGridView1.Columns["Delivery_Time"].HeaderText = "Delivery Time";
            this.dataGridView1.Columns["Register_Date"].HeaderText = "Register Date";
            this.dataGridView1.Columns["Register_Time"].HeaderText = "Register Time";
            this.dataGridView1.Columns["Report_Date"].HeaderText = "Report Date";
            this.dataGridView1.Columns["PI_No"].HeaderText = "PI/SI No.";
            this.dataGridView1.Columns["_1st"].HeaderText = "1st Weighing";
            this.dataGridView1.Columns["Date1"].HeaderText = "1st Date";
            this.dataGridView1.Columns["Time1"].HeaderText = "1st Time";
            this.dataGridView1.Columns["_2nd"].HeaderText = "2nd Weighing";
            this.dataGridView1.Columns["Date2"].HeaderText = "2nd Date";
            this.dataGridView1.Columns["Time2"].HeaderText = "2nd Time";
            this.dataGridView1.Columns["_3rd"].HeaderText = "3rd Weighing";
            this.dataGridView1.Columns["Date3"].HeaderText = "3rd Date";
            this.dataGridView1.Columns["Time3"].HeaderText = "3rd Time";
            this.dataGridView1.Columns["_4th"].HeaderText = "4th Weighing";
            this.dataGridView1.Columns["Date4"].HeaderText = "4th Date";
            this.dataGridView1.Columns["Time4"].HeaderText = "4th Time";
            this.dataGridView1.Columns["Estate_Code"].HeaderText = "Estate";
            this.dataGridView1.Columns["Storage"].HeaderText = "Storage";
            this.dataGridView1.Columns["Tanker"].HeaderText = "Tanker";
            this.dataGridView1.Columns["MaxCap"].HeaderText = "Max Tanker";
            this.dataGridView1.Columns["Unloading"].HeaderText = "Unloading Point";
            this.dataGridView1.Columns["Remark_Ticket"].HeaderText = "Remark Ticket";
            this.dataGridView1.Columns["Remark_Report"].HeaderText = "Remark Report";
            this.dataGridView1.Columns["Gross_Estate"].HeaderText = "Gross Estate";
            this.dataGridView1.Columns["Tare_Estate"].HeaderText = "Tare Estate";
            this.dataGridView1.Columns["Net_Estate"].HeaderText = "Net Estate";
            this.dataGridView1.Columns["TotalBunch"].HeaderText = "Total Unit";
            this.dataGridView1.Columns["UnitName"].HeaderText = "UnitName";
            this.dataGridView1.Columns["TotalBunchGrading"].HeaderText = "Ttl Unit for Deduction";
            this.dataGridView1.Columns["Average"].HeaderText = "Average Weight/Unit";
            this.dataGridView1.Columns["Fruits_Type"].HeaderText = "Fruits Type";
            this.dataGridView1.Columns["Rend_CPO"].HeaderText = "Rendemen CPO";
            this.dataGridView1.Columns["ISCC_Checked"].HeaderText = "ISCC";
            this.dataGridView1.Columns["ISCC_No"].HeaderText = "ISCC No.";
            this.dataGridView1.Columns["ISCC_GC_Checked"].HeaderText = "Use of Grandfather Clause";
            this.dataGridView1.Columns["ISCC_Weight"].HeaderText = "ISCC Weight";
            this.dataGridView1.Columns["ISCC_Checked"].HeaderText = "ISCC";
            this.dataGridView1.Columns["Estate"].HeaderText = "Estate";
            this.dataGridView1.Columns["ChangeReason"].HeaderText = "Change/Cancel Reason";
            this.dataGridView1.Columns["Addi_Info"].HeaderText = "Additional Information";
            this.dataGridView1.Columns["registrationClose_date"].HeaderText = "Registration Close Date";
            this.dataGridView1.Columns["registrationClose_time"].HeaderText = "Registration Close Time";
            this.dataGridView1.Columns["registrationClose_by"].HeaderText = "Registration Close By";
            this.dataGridView1.Columns["RegCard_No"].HeaderText = "Card No.";
            this.dataGridView1.Columns["Gatepass_Number"].HeaderText = "Gatepass No.";
            this.dateTimePicker1.Value = DateTime.Now;
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Value = DateTime.Now;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.checkPartial.Checked = true;
            int num = 3;
            this.Garis1.Width = num;
            this.Garis2.Width = num;
            this.Garis3.Width = num;
            this.label5.Width = num;
            base.KeyPreview = true;
            this.fm.label1.Text = "Loading WB.Net Layout . . . . . .";
            this.fm.label1.Refresh();
            this.ShowLayout();
            this.fm.label1.Text = "Loading WB.Net Authorization . . . . . .";
            this.fm.label1.Refresh();
            Cursor.Current = Cursors.WaitCursor;
            this.databaseConnectionToolStripMenuItem.Enabled = WBUser.CheckTrustee("CONFIG", "V");
            this.weighBridgeSettingToolStripMenuItem.Enabled = WBUser.CheckTrustee("CONFIG", "V");
            this.DOToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CONTRACT", "V");
            this.commodityToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STOCK", "V");
            this.relationToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_VENDOR", "V");
            this.truckToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRUCK", "V");
            this.driverToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "V");
            this.transpoterToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANSPORTER", "V");
            this.storageToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STORAGE", "V");
            this.divisionToolStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_DIVISION", "V");
            this.estateToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_ESTATE", "V");
            this.qCItemToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_QC", "V");
            this.DLAdoptMenuItem.Enabled = WBUser.CheckTrustee("DL_ADOPT", "V");
            this.compositToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_COMPOSIT", "V");
            this.tankerToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CAPACITY", "V");
            this.gradingToolStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_GRADING", "V");
            this.blockStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_BLOCK", "V");
            this.templateSAPToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TEMPLATE", "V");
            this.transactionTypeToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_TYPE", "V");
            this.UploadTypeToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_UPLOAD_TYPE_LIST", "V");
            this.ManualEntryMenuItem.Visible = WBUser.CheckTrustee("TRANS_MANUAL", "V");
            this.ManualEntryMenuItem.Enabled = WBUser.CheckTrustee("TRANS_MANUAL", "A");
            this.loadingQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_LOADING_ENTRY", "V");
            this.sparePartQtyToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "V");
            this.loadingQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_LOADING_ENTRY", "A");
            this.sparePartQtyToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "A");
            this.entryOtherPartyWeightToolStripMenuItem.Enabled = WBUser.CheckTrustee("ENTRY_OPW", "V");
            this.entryReturToolStripMenuItem.Enabled = WBUser.CheckTrustee("ADD_RETUR", "V");
            this.markAccidentToolStripMenuItem.Enabled = WBUser.CheckTrustee("MARK_ACCIDENT", "E");
            this.markAccidentToolStripMenuItem.Visible = WBUser.CheckTrustee("MARK_ACCIDENT", "V");
            this.SPB_Report_Menu.Enabled = WBUser.CheckTrustee("MN_PRINT_SPB", "V");
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Enabled = WBUser.CheckTrustee("CAPTURE_NOT_STABLE", "E");
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Visible = WBUser.CheckTrustee("CAPTURE_NOT_STABLE", "V");
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Enabled = WBUser.CheckTrustee("EDIT_MULTIPLE", "E");
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Visible = WBUser.CheckTrustee("EDIT_MULTIPLE", "V");
            this.tokenToAllowMannedWeighingToolStripMenuItem.Enabled = WBUser.CheckTrustee("ALLOW_MANNED_WB", "E");
            this.tokenToAllowMannedWeighingToolStripMenuItem.Visible = WBUser.CheckTrustee("ALLOW_MANNED_WB", "V");
            this.printBASerahTerimaToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_PRINT_BA_SERAHTERIMA", "V");
            this.sAPDestinationToolStripMenuItem.Enabled = (WBUser.UserLevel == "1") || WBUser.CheckTrustee("MD_SAP_DESTINATION", "V");
            this.entryDeliveryNoteToolStripMenuItem.Enabled = (WBUser.UserLevel == "1") || WBUser.CheckTrustee("MN_DELIVERY_NOTE", "E");
            this.changeFlagUploadToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_EDIT_FLAG_UPLOAD", "E");
            this.changeFlagUploadToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_EDIT_FLAG_UPLOAD", "V");
            this.disableFeaturesToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_DISABLE_FEATURE", "E");
            this.disableFeaturesToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_DISABLE_FEATURE", "V");
            this.SPBtoolStripMenuItem.Enabled = (WBSetting.locType == "1") ? WBUser.CheckTrustee("MD_DN", "V") : false;
            this.editDeductionToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
            this.editDNToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
            this.editReportDateToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
            if (WBSetting.region != "2")
            {
                this.entryFFBGradingToolStripMenuItem.Visible = false;
                this.entryGradingDivisionToolStripMenuItem.Visible = false;
            }
            else
            {
                this.entryFFBGradingToolStripMenuItem.Visible = true;
                this.entryGradingDivisionToolStripMenuItem.Visible = WBSetting.activeTCS;
                if (WBSetting.locType == "0")
                {
                    this.entryFFBGradingToolStripMenuItem.Enabled = false;
                    this.entryGradingDivisionToolStripMenuItem.Enabled = false;
                }
                else
                {
                    this.entryFFBGradingToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_SYNCH", "A");
                    this.entryGradingDivisionToolStripMenuItem.Enabled = WBSetting.activeTCS && WBUser.CheckTrustee("MD_SYNCH", "A");
                }
            }
            this.hardwareConfigurationToolStripMenuItem.Enabled = (WBUser.UserLevel == "1") || WBUser.CheckTrustee("CONFIG_HARDWARE", "V");
            if ((WBUser.CheckTrustee("MN_PRINT", "V") || WBUser.CheckTrustee("TRANS", "P")) || (WBSetting.Field("GM").ToString() == "Y"))
            {
                this.fRpt = new FormRpt();
                this.fRptSPB = new FormRpt();
                try
                {
                    this.ticketRpt.Load(WBSetting.ticket);
                    this.ticketRpt = Program.rptLogon(this.ticketRpt);
                    this.fRpt.setReport(this.ticketRpt);
                    if (File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine1.rpt") && File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine2.rpt"))
                    {
                        this.fticket_multi1 = new FormRpt();
                        this.fticket_multi2 = new FormRpt();
                        this.ticket_multi1.Load(WBSetting.ticket_MultiLine1);
                        this.ticket_multi1 = Program.rptLogon(this.ticket_multi1);
                        this.fticket_multi1.setReport(this.ticket_multi1);
                        this.ticket_multi2.Load(WBSetting.ticket_MultiLine2);
                        this.ticket_multi2 = Program.rptLogon(this.ticket_multi2);
                        this.fticket_multi2.setReport(this.ticket_multi2);
                    }
                    this.fticketLangsir = new FormRpt();
                    this.ticketLangsir.Load(WBSetting.ticketLangsir);
                    this.ticketLangsir = Program.rptLogon(this.ticketLangsir);
                    this.fticketLangsir.setReport(this.ticketLangsir);
                    this.fticketLangsir2 = new FormRpt();
                    this.ticketLangsir2.Load(WBSetting.ticketLangsir2);
                    this.ticketLangsir2 = Program.rptLogon(this.ticketLangsir2);
                    this.fticketLangsir2.setReport(this.ticketLangsir2);
                }
                catch
                {
                    this.fm.label1.Text = "Ticket is Not Correctly Loaded . . . . . .";
                    this.fm.label1.Refresh();
                    MessageBox.Show(Resource.Mainform_005, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                if (WBSetting.print_loading_advise || WBSetting.print_gatepass_advise)
                {
                    this.loading_advise = new FormRpt();
                    try
                    {
                        this.rpt_advise.Load(WBSetting.loading_advise);
                        this.rpt_advise = Program.rptLogon(this.rpt_advise);
                        this.loading_advise.setReport(this.rpt_advise);
                    }
                    catch
                    {
                        this.fm.label1.Text = "Loading Advise is Not Correctly Loaded . . . . . .";
                        this.fm.label1.Refresh();
                        MessageBox.Show(Resource.Mainform_006, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            int num2 = 0;
            if (Program.StrToDouble(WBSetting.SAPInterval, 3) > 0.0)
            {
                num2 = Convert.ToInt16((double) (24.0 / Program.StrToDouble(WBSetting.SAPInterval, 3)));
                string[] strArray = new string[num2];
                int index = 0;
                while (true)
                {
                    if (index >= num2)
                    {
                        this.sapJamKirim = strArray;
                        this.timerSAPUpd.Enabled = true;
                        this.timerSAPUpd.Interval = 0xea60;
                        break;
                    }
                    DateTime time = Convert.ToDateTime(WBSetting.startTime).AddHours(index * Program.StrToDouble(WBSetting.SAPInterval, 3));
                    strArray[index] = Convert.ToString(time);
                    index++;
                }
            }
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_SAPDest", "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND automaticUpload = 'Y'"), WBData.conn);
            this.sapD = new string[table2.DT.Rows.Count, 2];
            if ((WBSetting.SAPsch == "Y") || (table2.DT.Rows.Count > 0))
            {
                this.timerSAPUpd.Enabled = true;
                this.timerSAPUpd.Interval = 0xea60;
            }
            table2.Dispose();
            if (WBSetting.GMSend == "Y")
            {
                this.timerTokenEmail.Enabled = true;
                this.timerTokenEmail.Interval = 0xea60;
            }
            if (WBSetting.wb_filling_location)
            {
                this.checkWBCode.Checked = true;
            }
            if (WBSetting.locType == "0")
            {
                this.divisionToolStripMenuItemPOM.Visible = false;
                this.blockStripMenuItemPOM.Visible = false;
                this.gradingToolStripMenuItemPOM.Visible = false;
                this.FFBReportToolStripMenuItemPOM.Visible = false;
                this.estateToolStripMenuItem.Visible = true;
            }
            else if (WBSetting.locType == "1")
            {
                this.divisionToolStripMenuItemPOM.Visible = true;
                this.blockStripMenuItemPOM.Visible = true;
                this.estateToolStripMenuItem.Visible = true;
                this.gradingToolStripMenuItemPOM.Visible = true;
                this.FFBReportToolStripMenuItemPOM.Visible = true;
            }
            this.fm.label1.Text = "Loading WB.Net Menu . . . . . .";
            this.fm.label1.Refresh();
            this._weighMenuActivate();
            this.fm.label1.Text = "Application Ready";
            this.fm.label1.Refresh();
            if (WBSetting.checkISCC != "Y")
            {
                num1 = 0;
            }
            else
            {
                DateTime validDateISCC = WBSetting.validDateISCC;
                num1 = 1;
            }
            if (num1 != 0)
            {
                TimeSpan span = (TimeSpan) (WBSetting.validDateISCC - DateTime.Now);
                int num6 = span.Days + 1;
                if (num6 > 0)
                {
                    if (num6 <= 10)
                    {
                        object[] objArray1 = new object[] { Resource.Mainform_008, " ", num6, " ", Resource.Mainform_009 };
                        MessageBox.Show(string.Concat(objArray1), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mainform_007, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            WBTable table3 = new WBTable();
            string str = "";
            bool flag = false;
            table3.OpenTable("wb_setting", "SELECT DISTINCT(wbCode) FROM wb_setting WHERE " + WBData.CompanyLocation("  AND usedForWeighing = 'Y'"), WBData.conn);
            foreach (DataRow row in table3.DT.Rows)
            {
                WBTable table6 = new WBTable();
                table6.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE (deleted is null or deleted <> 'Y') AND WBCode = '" + row["wbcode"].ToString() + "' ORDER BY valid_date DESC", WBData.conn);
                if (table6.DT.Rows.Count > 0)
                {
                    table6.DR = table6.DT.Rows[0];
                    DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(table6.DR["valid_date"].ToString()).ToShortDateString());
                    DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(table6.DR["calibration_date"].ToString()).ToShortDateString());
                    DateTime time5 = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                    if (time3 <= time5)
                    {
                        flag = true;
                        string[] textArray4 = new string[9];
                        textArray4[0] = str;
                        textArray4[1] = Resource.Mainform_010;
                        textArray4[2] = " ";
                        textArray4[3] = table6.DR["certification_no"].ToString();
                        textArray4[4] = " ";
                        textArray4[5] = Resource.Mainform_011;
                        textArray4[6] = " ";
                        textArray4[7] = table6.DR["WBCode"].ToString();
                        textArray4[8] = " ";
                        str = string.Concat(textArray4) + Resource.Mainform_088 + "\n";
                        string[] textArray5 = new string[] { str, Resource.Mainform_014, ": ", Convert.ToDateTime(table6.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy"), "\n" };
                        str = string.Concat(textArray5);
                        string[] textArray6 = new string[] { str, Resource.Mainform_015, ": ", Convert.ToDateTime(table6.DR["valid_date"].ToString()).ToString("dd/MM/yyyy"), "\n\n" };
                        str = string.Concat(textArray6);
                        if ((time3 == time5) && (table6.DR["lock_weighing"].ToString() == ""))
                        {
                            table6.DR.BeginEdit();
                            table6.DR["lock_weighing"] = "Y";
                            table6.DR.EndEdit();
                            table6.Save();
                        }
                    }
                    else if (((time3 > time5) && (time4 <= time5)) && ((time3 - time5).Days <= this.intervalForCalibration))
                    {
                        flag = true;
                        string[] textArray7 = new string[9];
                        textArray7[0] = str;
                        textArray7[1] = Resource.Mainform_010;
                        textArray7[2] = " ";
                        textArray7[3] = table6.DR["certification_no"].ToString();
                        textArray7[4] = " ";
                        textArray7[5] = Resource.Mainform_011;
                        textArray7[6] = " ";
                        textArray7[7] = table6.DR["WBCode"].ToString();
                        textArray7[8] = " ";
                        str = string.Concat(textArray7);
                        object[] objArray2 = new object[] { str, Resource.Mainform_012, " ", (time3 - time5).Days, " ", Resource.Mainform_013, "!\n" };
                        str = string.Concat(objArray2);
                        string[] textArray8 = new string[] { str, Resource.Mainform_014, ": ", Convert.ToDateTime(table6.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy"), "\n" };
                        str = string.Concat(textArray8);
                        string[] textArray9 = new string[] { str, Resource.Mainform_015, ": ", Convert.ToDateTime(table6.DR["valid_date"].ToString()).ToString("dd/MM/yyyy"), "\n\n" };
                        str = string.Concat(textArray9);
                    }
                }
                table6.Dispose();
            }
            if (flag)
            {
                MessageBox.Show(Resource.Mainform_016 + "\n\n" + str + Resource.Mainform_017, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
                {
                    WBTable table7 = new WBTable();
                    table7.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'WB_CALIBRATION' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                    if (table7.DT.Rows.Count <= 0)
                    {
                        table7.DR = table7.DT.NewRow();
                        table7.DR["COY"] = WBData.sCoyCode;
                        table7.DR["LOCATION_CODE"] = WBData.sLocCode;
                        table7.DR["Email_code"] = "WB_CALIBRATION";
                        table7.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                        table7.DR["Status"] = "N";
                        table7.DT.Rows.Add(table7.DR);
                        table7.Save();
                    }
                    table7.Dispose();
                }
            }
            table3.Dispose();
            this.registrationToolStripMenuItem.Visible = WBSetting.gatepass_registration;
            if (WBSetting.AutoCapture)
            {
                this.indicatorStabilityReportToolStripMenuItem.Visible = true;
                this.indicatorStabilityReportToolStripMenuItem1.Visible = true;
            }
            else
            {
                this.indicatorStabilityReportToolStripMenuItem.Visible = false;
                this.indicatorStabilityReportToolStripMenuItem1.Visible = false;
            }
            WBTable table4 = new WBTable();
            table4.OpenTable("wb_act", "SELECT * FROM information_schema.tables WHERE table_name = 'wb_act'", WBData.conn);
            this.toolStripMenuItem7.Visible = table4.DT.Rows.Count > 0;
            this.activationKeyToolStripMenuItem.Visible = table4.DT.Rows.Count > 0;
            table4.Dispose();
            WBTable table5 = new WBTable();
            table5.OpenTable("wb_condition", "SELECT uniq FROM wb_condition WHERE condition_code = 'ACTIVATION_KEY_IS_EXPIRED'", WBData.conn);
            if (table5.DT.Rows.Count > 0)
            {
                this.labelExpired.Visible = true;
                this.reportOutstandingDOToolStripMenuItem.Enabled = false;
                this.reportOutstandingDONonTradeStoreToolStripMenuItem.Enabled = false;
                this.receivingEstimationFrom3rdPartyToolStripMenuItem.Enabled = false;
                this.doDetailToolStripMenuItem.Enabled = false;
                this.nonContractTransactionToolStripMenuItem.Enabled = false;
                this.qCReportToolStripMenuItem.Enabled = false;
                this.vendorSummaryToolStripMenuItem.Enabled = false;
                this.vendorDetailToolStripMenuItem.Enabled = false;
                this.outstandingDOPerVendorToolStripMenuItem.Enabled = false;
                this.failSynchronizeReportToolStripMenuItem.Enabled = false;
                this.toleranceProductToolStripMenuItem.Enabled = false;
                this.vesselReportToolStripMenuItem.Enabled = false;
                this.multiLineSOOutstandingReportToolStripMenuItem.Enabled = false;
                this.wBOwnerToolStripMenuItem.Enabled = false;
                this.tankerLogToolStripMenuItem.Enabled = false;
                this.logReportToolStripMenuItem.Enabled = false;
                this.commodityToleranceReportToolStripMenuItem.Enabled = false;
                this.tsCCTC.Enabled = false;
                this.indicatorStabilityReportToolStripMenuItem.Enabled = false;
                this.indicatorStabilityReportToolStripMenuItem1.Enabled = false;
                this.userManagementReportToolStripMenuItem.Enabled = false;
                this.emailRecipientReportToolStripMenuItem.Enabled = false;
                this.wtaReportToolStripMenuItem.Enabled = false;
                this.cancelWeighingReportToolStripMenuItem.Enabled = false;
                this.cancelRegistrationReportToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.labelExpired.Visible = false;
                this.reportOutstandingDOToolStripMenuItem.Enabled = true;
                this.reportOutstandingDONonTradeStoreToolStripMenuItem.Enabled = true;
                this.receivingEstimationFrom3rdPartyToolStripMenuItem.Enabled = true;
                this.doDetailToolStripMenuItem.Enabled = true;
                this.nonContractTransactionToolStripMenuItem.Enabled = true;
                this.qCReportToolStripMenuItem.Enabled = true;
                this.vendorSummaryToolStripMenuItem.Enabled = true;
                this.vendorDetailToolStripMenuItem.Enabled = true;
                this.outstandingDOPerVendorToolStripMenuItem.Enabled = true;
                this.failSynchronizeReportToolStripMenuItem.Enabled = true;
                this.toleranceProductToolStripMenuItem.Enabled = true;
                this.vesselReportToolStripMenuItem.Enabled = true;
                this.multiLineSOOutstandingReportToolStripMenuItem.Enabled = true;
                this.wBOwnerToolStripMenuItem.Enabled = true;
                this.tankerLogToolStripMenuItem.Enabled = true;
                this.logReportToolStripMenuItem.Enabled = true;
                this.commodityToleranceReportToolStripMenuItem.Enabled = true;
                this.tsCCTC.Enabled = true;
                this.indicatorStabilityReportToolStripMenuItem.Enabled = true;
                this.indicatorStabilityReportToolStripMenuItem1.Enabled = true;
                this.userManagementReportToolStripMenuItem.Enabled = true;
                this.emailRecipientReportToolStripMenuItem.Enabled = true;
                this.wtaReportToolStripMenuItem.Enabled = true;
                this.cancelWeighingReportToolStripMenuItem.Enabled = true;
                this.cancelRegistrationReportToolStripMenuItem.Enabled = true;
            }
            table5.Dispose();
        }

        private void failSynchronizeReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFailSync sync = new RepFailSync();
            sync.ShowDialog();
            sync.Dispose();
        }

        private void fFBGradingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBGrading grading = new RepFFBGrading {
                tableDeduction = "wb_transactionD"
            };
            grading.ShowDialog();
            grading.Dispose();
        }

        private void fillTable(HTML rep, DataRow aRowTransBC, int jumlahbaris)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td rowspan='1' nowrap align=center>" + jumlahbaris + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Ref"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Do_No"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Relation_name"].ToString()) + "</td>");
            if ((jumlahbaris > 1) && (aRowTransBC["Truck_Number"].ToString() == ""))
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(this.Truck_Number) + "</td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Truck_Number"].ToString()) + "</td>");
                this.Truck_Number = aRowTransBC["Truck_Number"].ToString();
            }
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Comm_code"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Comm_name"].ToString()) + "</td>");
            if ((jumlahbaris > 1) && (aRowTransBC["Date1"].ToString() == ""))
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(this.Date1) + "</td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Date1"].ToString()) + "</td>");
                this.Date1 = aRowTransBC["Date1"].ToString();
            }
            if (this.TblReportdate.DT.Rows[0]["report_date"].ToString() != "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["_1st"].ToString()) + "</td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["netto"].ToString()) + "</td>");
            }
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Date2"].ToString()) + "</td>");
            if ((jumlahbaris > 1) && (aRowTransBC["_2nd"].ToString() == ""))
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(this.secondweight) + "</td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["_2nd"].ToString()) + "</td>");
                this.secondweight = aRowTransBC["_2nd"].ToString();
            }
            if (this.TblReportdate.DT.Rows[0]["report_date"].ToString() != "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["net"].ToString()) + "</td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["netto"].ToString()) + "</td>");
            }
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["STO"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["STO_Item"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["STO_QTY"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["STO_UOM"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + rep.strq(aRowTransBC["Tolerance"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Tracking_No"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["Tracking_Item"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["detailsto_require_BC"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["BC_No"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["BC_Item"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["BC_Type"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + rep.strq(aRowTransBC["BC_Date"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + rep.strq(aRowTransBC["BC_Qty"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + rep.strq(aRowTransBC["BC_UoM"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + rep.strq(aRowTransBC["Item_Load_Qty"].ToString()) + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + rep.strq(aRowTransBC["Density"].ToString()) + "</td>");
            rep.Write("</tr>");
        }

        private void flagPostedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.editflag(this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "P");
            }
            else
            {
                MessageBox.Show("Please Select Main Transaction Reference to Change Flag Posted", "Warning...");
            }
        }

        private void flagRepostedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.editflag(this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "R");
            }
            else
            {
                MessageBox.Show("Please Select Main Transaction Reference to Change Flag Reposted", "Warning...");
            }
        }

        private void formulaRendemenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRendemen rendemen = new FormRendemen();
            rendemen.ShowDialog();
            rendemen.Dispose();
        }

        private HTML generateRep(WBTable vWBOwner)
        {
            HTML html = new HTML();
            html.File = html.File + @"\" + WBUser.UserID + "_WBOwner.htm";
            html.Title = "List of WB Owner";
            html.Open();
            html.Write(html.Style());
            html.Write("</b></b>");
            html.Write("<font size=3>" + WBData.sCoyName + "</b></font>");
            html.Write("<br><font size=4><b>List of WB Owner</b></font>");
            html.Write("</b></b>");
            html.Write("</b></b>");
            html.Write("<br>");
            html.Write("<br>");
            html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            html.Write("<tr class='bd'>");
            html.Write("<td nowrap><b>Coy Code</b></td>");
            html.Write("<td nowrap><b>Loc Code</b></td>");
            html.Write("<td nowrap><b>Coy Name</b></td>");
            html.Write("<td nowrap><b>Loc Name</b></td>");
            html.Write("<td nowrap><b>WB Owner</b></td>");
            html.Write("</tr>");
            foreach (DataRow row in vWBOwner.DT.Rows)
            {
                html.Write("<tr class='bd'>");
                html.Write("<td nowrap>" + html.strq(row["Coy"].ToString()) + "</td>");
                html.Write("<td nowrap>" + html.strq(row["Location_code"].ToString()) + "</td>");
                html.Write("<td nowrap>" + html.strq(row["Coy_Name"].ToString()) + "</td>");
                html.Write("<td nowrap>" + html.strq(row["Location_Name"].ToString()) + "</td>");
                html.Write("<td nowrap>" + html.strq(row["WBOwner"].ToString()) + "</td>");
                html.Write("</tr>");
            }
            html.Write("</table>");
            html.Write("<br>");
            html.Write("<br>");
            html.writeSign();
            return html;
        }

        private string getCommName(string comm_code)
        {
            string str = "-";
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where comm_code = '" + comm_code + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["Comm_Name"].ToString();
            }
            return str;
        }

        private void hardwareConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSettingHardware hardware = new FormSettingHardware();
            hardware.ShowDialog();
            WBSetting.ReOpen();
            if (hardware.saved)
            {
                WBSetting.ReOpen();
                this.f_load();
            }
            hardware.Dispose();
        }

        private void incotermToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DEDUCTED", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDeductedBy by = new FormDeductedBy();
                by.ShowDialog();
                by.Dispose();
            }
        }

        private void indicatorStabilityReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepIndicator indicator = new RepIndicator();
            indicator.ShowDialog();
            indicator.Dispose();
        }

        private void indicatorStabilityReportToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RepNotStable stable = new RepNotStable();
            stable.ShowDialog();
            stable.Dispose();
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td rowspan='1' nowrap align=center><b>No.</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_012 + ".</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_017 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_014 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report02_006 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_015 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_031 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Main_057 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource._1stWeight + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Main_059 + " </b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource._2ndWeight + " </b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Col_Netto_Weight + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_037 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_038 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_039 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_040 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_041 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Col_Tracking_No + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Col_Tracking_Item + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_042 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_022 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_023 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_032 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_033 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_024 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_030 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_034 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>Density</b></td>");
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new MenuStrip();
            this.registrationToolStripMenuItem = new ToolStripMenuItem();
            this.WeighingMenuItem = new ToolStripMenuItem();
            this.startWeighingToolStripMenuItem = new ToolStripMenuItem();
            this.stWeightToolStripMenuItem = new ToolStripMenuItem();
            this.ndWeightToolStripMenuItem = new ToolStripMenuItem();
            this.rdWeightToolStripMenuItem = new ToolStripMenuItem();
            this.thWeightToolStripMenuItem = new ToolStripMenuItem();
            this.view4XTransactionForContainerOutToolStripMenuItem = new ToolStripMenuItem();
            this.splitReferenceToolStripMenuItem = new ToolStripMenuItem();
            this.mergeDOToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem11 = new ToolStripMenuItem();
            this.ManualEntryMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem8 = new ToolStripSeparator();
            this.qcStripMenuItem = new ToolStripMenuItem();
            this.DLAdoptMenuItem = new ToolStripMenuItem();
            this.loadingQtyToolStripMenuItem = new ToolStripMenuItem();
            this.sparePartQtyToolStripMenuItem = new ToolStripMenuItem();
            this.entryOtherPartyWeightToolStripMenuItem = new ToolStripMenuItem();
            this.entryGradingDivisionToolStripMenuItem = new ToolStripMenuItem();
            this.entryFFBGradingToolStripMenuItem = new ToolStripMenuItem();
            this.entryReturToolStripMenuItem = new ToolStripMenuItem();
            this.entryDeliveryNoteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.edittoolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editQuantityToolStripMenuItem = new ToolStripMenuItem();
            this.editDeductionToolStripMenuItem = new ToolStripMenuItem();
            this.editReportDateToolStripMenuItem = new ToolStripMenuItem();
            this.editDNToolStripMenuItem = new ToolStripMenuItem();
            this.cancelRecordToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem9 = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.printLoadingUnloadingAdviseToolStripMenuItem = new ToolStripMenuItem();
            this.closeRegisteredTruckToolStripMenuItem = new ToolStripMenuItem();
            this.repairChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.repairAllChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.toolsToolStripMenuItem = new ToolStripMenuItem();
            this.viewDOToolStripMenuItem = new ToolStripMenuItem();
            this.markAccidentToolStripMenuItem = new ToolStripMenuItem();
            this.autoSplitDOVesselToolStripMenuItem1 = new ToolStripMenuItem();
            this.mergeAutoSplitDOVesselToolStripMenuItem1 = new ToolStripMenuItem();
            this.tCSToolStripMenuItem = new ToolStripMenuItem();
            this.refreshQCFromTCSToolStripMenuItem = new ToolStripMenuItem();
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem = new ToolStripMenuItem();
            this.requestSpecialTokenToolStripMenuItem = new ToolStripMenuItem();
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem = new ToolStripMenuItem();
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem = new ToolStripMenuItem();
            this.tokenToAllowMannedWeighingToolStripMenuItem = new ToolStripMenuItem();
            this.Additional_Printing_Menu = new ToolStripMenuItem();
            this.printBASerahTerimaToolStripMenuItem = new ToolStripMenuItem();
            this.SPB_Report_Menu = new ToolStripMenuItem();
            this.disableFeaturesToolStripMenuItem = new ToolStripMenuItem();
            this.changeFlagUploadToolStripMenuItem = new ToolStripMenuItem();
            this.flagPostedToolStripMenuItem = new ToolStripMenuItem();
            this.flagRepostedToolStripMenuItem = new ToolStripMenuItem();
            this.ViewSparepartToolStripMenuItem = new ToolStripMenuItem();
            this.masterDataToolStripMenuItem1 = new ToolStripMenuItem();
            this.DOToolStripMenuItem = new ToolStripMenuItem();
            this.commodityToolStripMenuItem = new ToolStripMenuItem();
            this.relationToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.truckToolStripMenuItem = new ToolStripMenuItem();
            this.driverToolStripMenuItem = new ToolStripMenuItem();
            this.transpoterToolStripMenuItem = new ToolStripMenuItem();
            this.SPBtoolStripMenuItem = new ToolStripMenuItem();
            this.tankerToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.coytoolStripMenuItem = new ToolStripMenuItem();
            this.locationToolStripMenuItem = new ToolStripMenuItem();
            this.estateToolStripMenuItem = new ToolStripMenuItem();
            this.divisionToolStripMenuItemPOM = new ToolStripMenuItem();
            this.blockStripMenuItemPOM = new ToolStripMenuItem();
            this.toolStripMenuItem4 = new ToolStripSeparator();
            this.UploadTypeToolStripMenuItem = new ToolStripMenuItem();
            this.sAPDestinationToolStripMenuItem = new ToolStripMenuItem();
            this.storageToolStripMenuItem = new ToolStripMenuItem();
            this.gradingToolStripMenuItemPOM = new ToolStripMenuItem();
            this.qualityToolStripMenuItem = new ToolStripMenuItem();
            this.qCItemToolStripMenuItem = new ToolStripMenuItem();
            this.compositToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem3 = new ToolStripSeparator();
            this.transactionTypeToolStripMenuItem = new ToolStripMenuItem();
            this.templateSAPToolStripMenuItem = new ToolStripMenuItem();
            this.formulaRendemenToolStripMenuItemPOM = new ToolStripMenuItem();
            this.mapCommTrxTypeToolStripMenuItem = new ToolStripMenuItem();
            this.incotermToolStripMenuItem = new ToolStripMenuItem();
            this.destinationToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator4 = new ToolStripSeparator();
            this.emailRecipientsToolStripMenuItem = new ToolStripMenuItem();
            this.cameraListToolStripMenuItem = new ToolStripMenuItem();
            this.ReasonToolStripMenuItem = new ToolStripMenuItem();
            this.wBCalibrationToolStripMenuItem = new ToolStripMenuItem();
            this.cancelTypeToolStripMenuItem = new ToolStripMenuItem();
            this.configurationToolStripMenuItem = new ToolStripMenuItem();
            this.databaseConnectionToolStripMenuItem = new ToolStripMenuItem();
            this.weighBridgeSettingToolStripMenuItem = new ToolStripMenuItem();
            this.weighBridgeControlToolStripMenuItem = new ToolStripMenuItem();
            this.hardwareConfigurationToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem6 = new ToolStripSeparator();
            this.userListToolStripMenuItem = new ToolStripMenuItem();
            this.userGroupToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator5 = new ToolStripSeparator();
            this.copyToNewCompanyToolStripMenuItem = new ToolStripMenuItem();
            this.compareDatabaseToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.saveColumnPositionToolStripMenuItem = new ToolStripMenuItem();
            this.loadColumnPositionToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem7 = new ToolStripSeparator();
            this.activationKeyToolStripMenuItem = new ToolStripMenuItem();
            this.maintainActivationKeyUsageToolStripMenuItem = new ToolStripMenuItem();
            this.renewActivationKeyToolStripMenuItem = new ToolStripMenuItem();
            this.ReportToolStripMenuItem = new ToolStripMenuItem();
            this.FFBReportToolStripMenuItemPOM = new ToolStripMenuItem();
            this.toolStripMenuRekapHarian = new ToolStripMenuItem();
            this.subRP1ToolStripMenuItem = new ToolStripMenuItem();
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem = new ToolStripMenuItem();
            this.laporanTotalPenerimaanTBSToolStripMenuItem = new ToolStripMenuItem();
            this.fFBGradingReportToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem12 = new ToolStripMenuItem();
            this.vendorSummaryTBSToolStripMenuItem = new ToolStripMenuItem();
            this.divisionReportToolStripMenuItem = new ToolStripMenuItem();
            this.listOfWeighningToolStripMenuItem1 = new ToolStripMenuItem();
            this.copraReportToolStripMenuItem = new ToolStripMenuItem();
            this.dailyReceiptSupplierToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem5 = new ToolStripSeparator();
            this.reportOutstandingDOToolStripMenuItem = new ToolStripMenuItem();
            this.reportOutstandingDONonTradeStoreToolStripMenuItem = new ToolStripMenuItem();
            this.receivingEstimationFrom3rdPartyToolStripMenuItem = new ToolStripMenuItem();
            this.doDetailToolStripMenuItem = new ToolStripMenuItem();
            this.nonContractTransactionToolStripMenuItem = new ToolStripMenuItem();
            this.qCReportToolStripMenuItem = new ToolStripMenuItem();
            this.vendorSummaryToolStripMenuItem = new ToolStripMenuItem();
            this.vendorDetailToolStripMenuItem = new ToolStripMenuItem();
            this.outstandingDOPerVendorToolStripMenuItem = new ToolStripMenuItem();
            this.failSynchronizeReportToolStripMenuItem = new ToolStripMenuItem();
            this.toleranceProductToolStripMenuItem = new ToolStripMenuItem();
            this.vesselReportToolStripMenuItem = new ToolStripMenuItem();
            this.multiLineSOOutstandingReportToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator3 = new ToolStripSeparator();
            this.wBOwnerToolStripMenuItem = new ToolStripMenuItem();
            this.tankerLogToolStripMenuItem = new ToolStripMenuItem();
            this.logReportToolStripMenuItem = new ToolStripMenuItem();
            this.transactionLogToolStripMenuItem = new ToolStripMenuItem();
            this.masterDataLogToolStripMenuItem = new ToolStripMenuItem();
            this.settingLogReportToolStripMenuItem = new ToolStripMenuItem();
            this.locationLogReportToolStripMenuItem = new ToolStripMenuItem();
            this.userListLogToolStripMenuItem = new ToolStripMenuItem();
            this.userLoginLogoutLogToolStripMenuItem = new ToolStripMenuItem();
            this.authorizationLogToolStripMenuItem = new ToolStripMenuItem();
            this.templateSAPLogToolStripMenuItem = new ToolStripMenuItem();
            this.migrateOldLogToNewLogToolStripMenuItem = new ToolStripMenuItem();
            this.cancelRegistrationReportToolStripMenuItem = new ToolStripMenuItem();
            this.cancelWeighingReportToolStripMenuItem = new ToolStripMenuItem();
            this.commodityToleranceReportToolStripMenuItem = new ToolStripMenuItem();
            this.tsCCTC = new ToolStripMenuItem();
            this.indicatorStabilityReportToolStripMenuItem = new ToolStripMenuItem();
            this.indicatorStabilityReportToolStripMenuItem1 = new ToolStripMenuItem();
            this.userManagementReportToolStripMenuItem = new ToolStripMenuItem();
            this.userListReportToolStripMenuItem = new ToolStripMenuItem();
            this.accessRightReportToolStripMenuItem = new ToolStripMenuItem();
            this.emailRecipientReportToolStripMenuItem = new ToolStripMenuItem();
            this.wtaReportToolStripMenuItem = new ToolStripMenuItem();
            this.DriverBlacklistReportToolStripMenuItem = new ToolStripMenuItem();
            this.uploadSAPToolStripMenuItem = new ToolStripMenuItem();
            this.changeProfileToolStripMenuItem = new ToolStripMenuItem();
            this.logOffToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.schDataToolStripMenuItem = new ToolStripMenuItem();
            this.contractLogToolStripMenuItem = new ToolStripMenuItem();
            this.statusWB = new StatusStrip();
            this.Status1 = new ToolStripStatusLabel();
            this.label2 = new ToolStripStatusLabel();
            this.timerSAPUpd = new Timer(this.components);
            this.lblNow = new Label();
            this.lblDate = new Label();
            this.serialPort1 = new SerialPort(this.components);
            this.backgroundWorkerSAP = new BackgroundWorker();
            this.timerTokenEmail = new Timer(this.components);
            this.backgroundWorkerEmail = new BackgroundWorker();
            this.toolTipInformation = new ToolTip(this.components);
            this.label1 = new Label();
            this.panel1 = new Panel();
            this.label5 = new Label();
            this.checkWBCode = new CheckBox();
            this.checkPartial = new CheckBox();
            this.Garis3 = new Label();
            this.checkShowCheckSum = new CheckBox();
            this.Garis2 = new Label();
            this.labelStatus1 = new Label();
            this.checkBox1 = new CheckBox();
            this.dateTimePicker2 = new DateTimePicker();
            this.dateTimePicker1 = new DateTimePicker();
            this.label3 = new Label();
            this.label4 = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.buttonFilter = new Button();
            this.Garis1 = new Label();
            this.labelExpired = new Label();
            this.dataGridView1 = new DataGridView();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.linkLabelSupport = new LinkLabel();
            this.menuStrip1.SuspendLayout();
            this.statusWB.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            base.SuspendLayout();
            this.menuStrip1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[11];
            toolStripItems[0] = this.registrationToolStripMenuItem;
            toolStripItems[1] = this.WeighingMenuItem;
            toolStripItems[2] = this.toolsToolStripMenuItem;
            toolStripItems[3] = this.masterDataToolStripMenuItem1;
            toolStripItems[4] = this.configurationToolStripMenuItem;
            toolStripItems[5] = this.ReportToolStripMenuItem;
            toolStripItems[6] = this.uploadSAPToolStripMenuItem;
            toolStripItems[7] = this.changeProfileToolStripMenuItem;
            toolStripItems[8] = this.logOffToolStripMenuItem;
            toolStripItems[9] = this.exitToolStripMenuItem;
            toolStripItems[10] = this.schDataToolStripMenuItem;
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x404, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.Size = new Size(0x52, 20);
            this.registrationToolStripMenuItem.Text = "Registration";
            this.registrationToolStripMenuItem.Click += new EventHandler(this.registrationToolStripMenuItem_Click);
            ToolStripItem[] itemArray2 = new ToolStripItem[0x1d];
            itemArray2[0] = this.startWeighingToolStripMenuItem;
            itemArray2[1] = this.stWeightToolStripMenuItem;
            itemArray2[2] = this.ndWeightToolStripMenuItem;
            itemArray2[3] = this.rdWeightToolStripMenuItem;
            itemArray2[4] = this.thWeightToolStripMenuItem;
            itemArray2[5] = this.view4XTransactionForContainerOutToolStripMenuItem;
            itemArray2[6] = this.splitReferenceToolStripMenuItem;
            itemArray2[7] = this.mergeDOToolStripMenuItem;
            itemArray2[8] = this.toolStripMenuItem11;
            itemArray2[9] = this.ManualEntryMenuItem;
            itemArray2[10] = this.toolStripMenuItem8;
            itemArray2[11] = this.qcStripMenuItem;
            itemArray2[12] = this.DLAdoptMenuItem;
            itemArray2[13] = this.loadingQtyToolStripMenuItem;
            itemArray2[14] = this.sparePartQtyToolStripMenuItem;
            itemArray2[15] = this.entryOtherPartyWeightToolStripMenuItem;
            itemArray2[0x10] = this.entryGradingDivisionToolStripMenuItem;
            itemArray2[0x11] = this.entryFFBGradingToolStripMenuItem;
            itemArray2[0x12] = this.entryReturToolStripMenuItem;
            itemArray2[0x13] = this.entryDeliveryNoteToolStripMenuItem;
            itemArray2[20] = this.toolStripSeparator1;
            itemArray2[0x15] = this.edittoolStripMenuItem;
            itemArray2[0x16] = this.cancelRecordToolStripMenuItem;
            itemArray2[0x17] = this.toolStripMenuItem9;
            itemArray2[0x18] = this.printToolStripMenuItem;
            itemArray2[0x19] = this.printLoadingUnloadingAdviseToolStripMenuItem;
            itemArray2[0x1a] = this.closeRegisteredTruckToolStripMenuItem;
            itemArray2[0x1b] = this.repairChecksumToolStripMenuItem;
            itemArray2[0x1c] = this.repairAllChecksumToolStripMenuItem;
            this.WeighingMenuItem.DropDownItems.AddRange(itemArray2);
            this.WeighingMenuItem.Name = "WeighingMenuItem";
            this.WeighingMenuItem.Size = new Size(70, 20);
            this.WeighingMenuItem.Text = "&Weighing";
            this.WeighingMenuItem.ToolTipText = "Main Weighning Process";
            this.WeighingMenuItem.DropDownOpening += new EventHandler(this.WeighingMenuItem_DropDownOpening);
            this.startWeighingToolStripMenuItem.Name = "startWeighingToolStripMenuItem";
            this.startWeighingToolStripMenuItem.Size = new Size(290, 0x16);
            this.startWeighingToolStripMenuItem.Text = "Start Weighing";
            this.startWeighingToolStripMenuItem.Click += new EventHandler(this.startWeighingToolStripMenuItem_Click);
            this.stWeightToolStripMenuItem.Name = "stWeightToolStripMenuItem";
            this.stWeightToolStripMenuItem.Size = new Size(290, 0x16);
            this.stWeightToolStripMenuItem.Text = "1st Weight or Registration";
            this.stWeightToolStripMenuItem.Click += new EventHandler(this.stWeightToolStripMenuItem_Click);
            this.ndWeightToolStripMenuItem.Name = "ndWeightToolStripMenuItem";
            this.ndWeightToolStripMenuItem.Size = new Size(290, 0x16);
            this.ndWeightToolStripMenuItem.Text = "2nd Weight";
            this.ndWeightToolStripMenuItem.Click += new EventHandler(this.ndWeightToolStripMenuItem_Click);
            this.rdWeightToolStripMenuItem.Name = "rdWeightToolStripMenuItem";
            this.rdWeightToolStripMenuItem.Size = new Size(290, 0x16);
            this.rdWeightToolStripMenuItem.Text = "3rd Weight";
            this.rdWeightToolStripMenuItem.Click += new EventHandler(this.rdWeightToolStripMenuItem_Click);
            this.thWeightToolStripMenuItem.Name = "thWeightToolStripMenuItem";
            this.thWeightToolStripMenuItem.Size = new Size(290, 0x16);
            this.thWeightToolStripMenuItem.Text = "4th Weight";
            this.thWeightToolStripMenuItem.Click += new EventHandler(this.thWeightToolStripMenuItem_Click);
            this.view4XTransactionForContainerOutToolStripMenuItem.Name = "view4XTransactionForContainerOutToolStripMenuItem";
            this.view4XTransactionForContainerOutToolStripMenuItem.Size = new Size(290, 0x16);
            this.view4XTransactionForContainerOutToolStripMenuItem.Text = "List of Transaction for Container Out (4X)";
            this.view4XTransactionForContainerOutToolStripMenuItem.Click += new EventHandler(this.view4XTransactionForContainerOutToolStripMenuItem_Click);
            this.splitReferenceToolStripMenuItem.Name = "splitReferenceToolStripMenuItem";
            this.splitReferenceToolStripMenuItem.Size = new Size(290, 0x16);
            this.splitReferenceToolStripMenuItem.Text = "Split Reference";
            this.splitReferenceToolStripMenuItem.ToolTipText = "To Split Reference By WB DO/Contract Number \r\nIf A truck is filled by more than 1 WB DO/Contract Number.";
            this.splitReferenceToolStripMenuItem.Click += new EventHandler(this.splitReferenceToolStripMenuItem_Click);
            this.mergeDOToolStripMenuItem.Name = "mergeDOToolStripMenuItem";
            this.mergeDOToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.M;
            this.mergeDOToolStripMenuItem.Size = new Size(290, 0x16);
            this.mergeDOToolStripMenuItem.Text = "Merge DO";
            this.mergeDOToolStripMenuItem.Click += new EventHandler(this.mergeDOToolStripMenuItem_Click);
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.ShortcutKeys = Keys.Insert;
            this.toolStripMenuItem11.Size = new Size(290, 0x16);
            this.toolStripMenuItem11.Text = "Copy Record / Insert for 2X Weight";
            this.toolStripMenuItem11.Click += new EventHandler(this.toolStripMenuItem11_Click);
            this.ManualEntryMenuItem.Name = "ManualEntryMenuItem";
            this.ManualEntryMenuItem.ShortcutKeyDisplayString = "F6";
            this.ManualEntryMenuItem.ShortcutKeys = Keys.F6;
            this.ManualEntryMenuItem.Size = new Size(290, 0x16);
            this.ManualEntryMenuItem.Text = "Manual Entry";
            this.ManualEntryMenuItem.ToolTipText = "To Manually Entry the Transaction Data";
            this.ManualEntryMenuItem.Click += new EventHandler(this.toolStripMenuItem12_Click);
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new Size(0x11f, 6);
            this.qcStripMenuItem.Name = "qcStripMenuItem";
            this.qcStripMenuItem.ShortcutKeys = Keys.Control | Keys.Q;
            this.qcStripMenuItem.Size = new Size(290, 0x16);
            this.qcStripMenuItem.Text = "Entry &Quality Control / Yield       ";
            this.qcStripMenuItem.ToolTipText = "To Entry Quality Data For QC Department or Authorized User";
            this.qcStripMenuItem.Click += new EventHandler(this.qcStripMenuItem_Click);
            this.DLAdoptMenuItem.Name = "DLAdoptMenuItem";
            this.DLAdoptMenuItem.Size = new Size(290, 0x16);
            this.DLAdoptMenuItem.Text = "Adopt Delivery Letter";
            this.DLAdoptMenuItem.ToolTipText = "For Sugar Refinery Process.\r\nCommodity Type = Sugar\r\n\r\nWarehouse to Adopt Delivery Letter From SAP After 1st Weight\r\nCannot 2nd Weight if Delivery Letter is not Filled in Transaction";
            this.DLAdoptMenuItem.Click += new EventHandler(this.DLAdoptMenuItem_Click);
            this.loadingQtyToolStripMenuItem.Name = "loadingQtyToolStripMenuItem";
            this.loadingQtyToolStripMenuItem.Size = new Size(290, 0x16);
            this.loadingQtyToolStripMenuItem.Text = "Entry Loading Qty / Density";
            this.loadingQtyToolStripMenuItem.ToolTipText = "For Refinery Process\r\n1. Standard Commodity\r\n2. Pack Product\r\nor\r\n1. Standard Commodity\r\n2. Bulk Product\r\n3. Unit of Measurement is not in KG (ex : Litre)";
            this.loadingQtyToolStripMenuItem.Click += new EventHandler(this.loadingQtyToolStripMenuItem_Click);
            this.sparePartQtyToolStripMenuItem.Name = "sparePartQtyToolStripMenuItem";
            this.sparePartQtyToolStripMenuItem.Size = new Size(290, 0x16);
            this.sparePartQtyToolStripMenuItem.Text = "Entry Sparepart Qty";
            this.sparePartQtyToolStripMenuItem.Click += new EventHandler(this.sparePartQtyToolStripMenuItem_Click);
            this.entryOtherPartyWeightToolStripMenuItem.Name = "entryOtherPartyWeightToolStripMenuItem";
            this.entryOtherPartyWeightToolStripMenuItem.Size = new Size(290, 0x16);
            this.entryOtherPartyWeightToolStripMenuItem.Text = "Entry Other Party Weight";
            this.entryOtherPartyWeightToolStripMenuItem.Click += new EventHandler(this.entryOtherPartyWeightToolStripMenuItem_Click);
            this.entryGradingDivisionToolStripMenuItem.Name = "entryGradingDivisionToolStripMenuItem";
            this.entryGradingDivisionToolStripMenuItem.Size = new Size(290, 0x16);
            this.entryGradingDivisionToolStripMenuItem.Text = "Entry FFB Grading && Division/Block";
            this.entryGradingDivisionToolStripMenuItem.Click += new EventHandler(this.entryGradingDivisionToolStripMenuItem_Click);
            this.entryFFBGradingToolStripMenuItem.Name = "entryFFBGradingToolStripMenuItem";
            this.entryFFBGradingToolStripMenuItem.Size = new Size(290, 0x16);
            this.entryFFBGradingToolStripMenuItem.Text = "Entry FFB Grading Collectively";
            this.entryFFBGradingToolStripMenuItem.Click += new EventHandler(this.entryFFBGradingToolStripMenuItem_Click);
            this.entryReturToolStripMenuItem.Name = "entryReturToolStripMenuItem";
            this.entryReturToolStripMenuItem.ShowShortcutKeys = false;
            this.entryReturToolStripMenuItem.Size = new Size(290, 0x16);
            this.entryReturToolStripMenuItem.Text = "Entry Return Qty";
            this.entryReturToolStripMenuItem.Click += new EventHandler(this.entryReturToolStripMenuItem_Click);
            this.entryDeliveryNoteToolStripMenuItem.Name = "entryDeliveryNoteToolStripMenuItem";
            this.entryDeliveryNoteToolStripMenuItem.Size = new Size(290, 0x16);
            this.entryDeliveryNoteToolStripMenuItem.Text = "Entry Delivery Note";
            this.entryDeliveryNoteToolStripMenuItem.Click += new EventHandler(this.entryDeliveryNoteToolStripMenuItem_Click);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(0x11f, 6);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.editRecordToolStripMenuItem, this.editQuantityToolStripMenuItem, this.editDeductionToolStripMenuItem, this.editReportDateToolStripMenuItem, this.editDNToolStripMenuItem };
            this.edittoolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.edittoolStripMenuItem.Name = "edittoolStripMenuItem";
            this.edittoolStripMenuItem.Size = new Size(290, 0x16);
            this.edittoolStripMenuItem.Text = "Edit Transaction";
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            this.editRecordToolStripMenuItem.Size = new Size(0xc0, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.editQuantityToolStripMenuItem.Name = "editQuantityToolStripMenuItem";
            this.editQuantityToolStripMenuItem.Size = new Size(0xc0, 0x16);
            this.editQuantityToolStripMenuItem.Text = "Edit Quantity Factory";
            this.editQuantityToolStripMenuItem.Click += new EventHandler(this.editQuantityToolStripMenuItem_Click);
            this.editDeductionToolStripMenuItem.Name = "editDeductionToolStripMenuItem";
            this.editDeductionToolStripMenuItem.Size = new Size(0xc0, 0x16);
            this.editDeductionToolStripMenuItem.Text = "Edit Bunch & Deduction";
            this.editDeductionToolStripMenuItem.Click += new EventHandler(this.editDeductionToolStripMenuItem_Click);
            this.editReportDateToolStripMenuItem.Name = "editReportDateToolStripMenuItem";
            this.editReportDateToolStripMenuItem.Size = new Size(0xc0, 0x16);
            this.editReportDateToolStripMenuItem.Text = "Edit Report Date";
            this.editReportDateToolStripMenuItem.Click += new EventHandler(this.editReportDateToolStripMenuItem_Click);
            this.editDNToolStripMenuItem.Name = "editDNToolStripMenuItem";
            this.editDNToolStripMenuItem.Size = new Size(0xc0, 0x16);
            this.editDNToolStripMenuItem.Text = "Edit Delivery Note";
            this.editDNToolStripMenuItem.Click += new EventHandler(this.editDNToolStripMenuItem_Click);
            this.cancelRecordToolStripMenuItem.Name = "cancelRecordToolStripMenuItem";
            this.cancelRecordToolStripMenuItem.Size = new Size(290, 0x16);
            this.cancelRecordToolStripMenuItem.Text = "&Cancel Record";
            this.cancelRecordToolStripMenuItem.Click += new EventHandler(this.cancelRecordToolStripMenuItem_Click);
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new Size(290, 0x16);
            this.toolStripMenuItem9.Text = "&View Record";
            this.toolStripMenuItem9.Click += new EventHandler(this.toolStripMenuItem9_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            this.printToolStripMenuItem.Size = new Size(290, 0x16);
            this.printToolStripMenuItem.Text = "&Print Record";
            this.printToolStripMenuItem.ToolTipText = "Reprint Transaction";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            this.printLoadingUnloadingAdviseToolStripMenuItem.Name = "printLoadingUnloadingAdviseToolStripMenuItem";
            this.printLoadingUnloadingAdviseToolStripMenuItem.Size = new Size(290, 0x16);
            this.printLoadingUnloadingAdviseToolStripMenuItem.Text = "Print Loading/Unloading Advise";
            this.printLoadingUnloadingAdviseToolStripMenuItem.Click += new EventHandler(this.printLoadingUnloadingAdviseToolStripMenuItem_Click);
            this.closeRegisteredTruckToolStripMenuItem.Name = "closeRegisteredTruckToolStripMenuItem";
            this.closeRegisteredTruckToolStripMenuItem.Size = new Size(290, 0x16);
            this.closeRegisteredTruckToolStripMenuItem.Text = "Close Registered Truck";
            this.closeRegisteredTruckToolStripMenuItem.Visible = false;
            this.closeRegisteredTruckToolStripMenuItem.Click += new EventHandler(this.closeRegisteredTruckToolStripMenuItem_Click);
            this.repairChecksumToolStripMenuItem.Name = "repairChecksumToolStripMenuItem";
            this.repairChecksumToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.R;
            this.repairChecksumToolStripMenuItem.Size = new Size(290, 0x16);
            this.repairChecksumToolStripMenuItem.Text = "&Repair Checksum";
            this.repairChecksumToolStripMenuItem.Click += new EventHandler(this.repairChecksumToolStripMenuItem_Click);
            this.repairAllChecksumToolStripMenuItem.Name = "repairAllChecksumToolStripMenuItem";
            this.repairAllChecksumToolStripMenuItem.Size = new Size(290, 0x16);
            this.repairAllChecksumToolStripMenuItem.Text = "Repair All Checksum";
            this.repairAllChecksumToolStripMenuItem.Click += new EventHandler(this.repairAllChecksumToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[10];
            itemArray4[0] = this.viewDOToolStripMenuItem;
            itemArray4[1] = this.markAccidentToolStripMenuItem;
            itemArray4[2] = this.autoSplitDOVesselToolStripMenuItem1;
            itemArray4[3] = this.mergeAutoSplitDOVesselToolStripMenuItem1;
            itemArray4[4] = this.tCSToolStripMenuItem;
            itemArray4[5] = this.requestSpecialTokenToolStripMenuItem;
            itemArray4[6] = this.Additional_Printing_Menu;
            itemArray4[7] = this.disableFeaturesToolStripMenuItem;
            itemArray4[8] = this.changeFlagUploadToolStripMenuItem;
            itemArray4[9] = this.ViewSparepartToolStripMenuItem;
            this.toolsToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new Size(0x3f, 20);
            this.toolsToolStripMenuItem.Text = "&Features";
            this.toolsToolStripMenuItem.ToolTipText = "Transaction Features";
            this.toolsToolStripMenuItem.DropDownOpening += new EventHandler(this.toolsToolStripMenuItem_DropDownOpening);
            this.viewDOToolStripMenuItem.Name = "viewDOToolStripMenuItem";
            this.viewDOToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.D;
            this.viewDOToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.viewDOToolStripMenuItem.Text = "View &DO Transaction";
            this.viewDOToolStripMenuItem.Click += new EventHandler(this.viewDOToolStripMenuItem_Click);
            this.markAccidentToolStripMenuItem.Name = "markAccidentToolStripMenuItem";
            this.markAccidentToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.markAccidentToolStripMenuItem.Text = "Mark Accident";
            this.markAccidentToolStripMenuItem.Click += new EventHandler(this.markAccidentToolStripMenuItem_Click);
            this.autoSplitDOVesselToolStripMenuItem1.Name = "autoSplitDOVesselToolStripMenuItem1";
            this.autoSplitDOVesselToolStripMenuItem1.ShortcutKeys = Keys.F7;
            this.autoSplitDOVesselToolStripMenuItem1.Size = new Size(0xe1, 0x16);
            this.autoSplitDOVesselToolStripMenuItem1.Text = "Auto Split DO Vessel";
            this.autoSplitDOVesselToolStripMenuItem1.Click += new EventHandler(this.autoSplitDOVesselToolStripMenuItem_Click);
            this.mergeAutoSplitDOVesselToolStripMenuItem1.Name = "mergeAutoSplitDOVesselToolStripMenuItem1";
            this.mergeAutoSplitDOVesselToolStripMenuItem1.Size = new Size(0xe1, 0x16);
            this.mergeAutoSplitDOVesselToolStripMenuItem1.Text = "Merge Auto Split DO Vessel";
            this.mergeAutoSplitDOVesselToolStripMenuItem1.Click += new EventHandler(this.mergeAutoSplitDOVesselToolStripMenuItem1_Click);
            ToolStripItem[] itemArray5 = new ToolStripItem[] { this.refreshQCFromTCSToolStripMenuItem, this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem };
            this.tCSToolStripMenuItem.DropDownItems.AddRange(itemArray5);
            this.tCSToolStripMenuItem.Name = "tCSToolStripMenuItem";
            this.tCSToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.tCSToolStripMenuItem.Text = "TCS";
            this.refreshQCFromTCSToolStripMenuItem.Name = "refreshQCFromTCSToolStripMenuItem";
            this.refreshQCFromTCSToolStripMenuItem.Size = new Size(0x165, 0x16);
            this.refreshQCFromTCSToolStripMenuItem.Text = "Refresh QC from TCS";
            this.refreshQCFromTCSToolStripMenuItem.Click += new EventHandler(this.refreshQCFromTCSToolStripMenuItem_Click);
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem.Name = "mappingTruckDestinationPerCompanyLocationToolStripMenuItem";
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem.Size = new Size(0x165, 0x16);
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem.Text = "Mapping Truck Destination per Company && Location ";
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem.Click += new EventHandler(this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem_Click);
            ToolStripItem[] itemArray6 = new ToolStripItem[] { this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem, this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem, this.tokenToAllowMannedWeighingToolStripMenuItem };
            this.requestSpecialTokenToolStripMenuItem.DropDownItems.AddRange(itemArray6);
            this.requestSpecialTokenToolStripMenuItem.Name = "requestSpecialTokenToolStripMenuItem";
            this.requestSpecialTokenToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.requestSpecialTokenToolStripMenuItem.Text = "Request Special Token";
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Name = "allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem";
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Size = new Size(0x15a, 0x16);
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Text = "Token to Allow Capture if Weighbridge is not Stable";
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Click += new EventHandler(this.allowCaptureIndicatorIfNotStableToolStripMenuItem_Click);
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Name = "requestTokenToEditMultipleContractsTransactionsToolStripMenuItem";
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Size = new Size(0x15a, 0x16);
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Text = "Token to Edit Multiple Contracts && Transactions";
            this.requestTokenToEditMultipleContractsTransactionsToolStripMenuItem.Click += new EventHandler(this.requestCollectiveTokenToolStripMenuItem_Click);
            this.tokenToAllowMannedWeighingToolStripMenuItem.Name = "tokenToAllowMannedWeighingToolStripMenuItem";
            this.tokenToAllowMannedWeighingToolStripMenuItem.Size = new Size(0x15a, 0x16);
            this.tokenToAllowMannedWeighingToolStripMenuItem.Text = "Token to Allow Manned Weighing";
            this.tokenToAllowMannedWeighingToolStripMenuItem.Click += new EventHandler(this.tokenToAllowMannedWeighingToolStripMenuItem_Click);
            ToolStripItem[] itemArray7 = new ToolStripItem[] { this.printBASerahTerimaToolStripMenuItem, this.SPB_Report_Menu };
            this.Additional_Printing_Menu.DropDownItems.AddRange(itemArray7);
            this.Additional_Printing_Menu.Name = "Additional_Printing_Menu";
            this.Additional_Printing_Menu.Size = new Size(0xe1, 0x16);
            this.Additional_Printing_Menu.Text = "Additional Printing Menu";
            this.printBASerahTerimaToolStripMenuItem.Name = "printBASerahTerimaToolStripMenuItem";
            this.printBASerahTerimaToolStripMenuItem.Size = new Size(0xbc, 0x16);
            this.printBASerahTerimaToolStripMenuItem.Text = "Print BA Serah Terima";
            this.printBASerahTerimaToolStripMenuItem.Visible = false;
            this.printBASerahTerimaToolStripMenuItem.Click += new EventHandler(this.printBASerahTerimaToolStripMenuItem_Click);
            this.SPB_Report_Menu.Name = "SPB_Report_Menu";
            this.SPB_Report_Menu.Size = new Size(0xbc, 0x16);
            this.SPB_Report_Menu.Text = "Print SPB";
            this.SPB_Report_Menu.Click += new EventHandler(this.SPB_Report_Menu_Click);
            this.disableFeaturesToolStripMenuItem.Name = "disableFeaturesToolStripMenuItem";
            this.disableFeaturesToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.disableFeaturesToolStripMenuItem.Text = "Disable Feature";
            this.disableFeaturesToolStripMenuItem.Click += new EventHandler(this.disableFeaturesToolStripMenuItem_Click);
            ToolStripItem[] itemArray8 = new ToolStripItem[] { this.flagPostedToolStripMenuItem, this.flagRepostedToolStripMenuItem };
            this.changeFlagUploadToolStripMenuItem.DropDownItems.AddRange(itemArray8);
            this.changeFlagUploadToolStripMenuItem.Name = "changeFlagUploadToolStripMenuItem";
            this.changeFlagUploadToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.changeFlagUploadToolStripMenuItem.Text = "Change Flag Upload";
            this.flagPostedToolStripMenuItem.Name = "flagPostedToolStripMenuItem";
            this.flagPostedToolStripMenuItem.Size = new Size(0x94, 0x16);
            this.flagPostedToolStripMenuItem.Text = "Flag Posted";
            this.flagPostedToolStripMenuItem.Click += new EventHandler(this.flagPostedToolStripMenuItem_Click);
            this.flagRepostedToolStripMenuItem.Name = "flagRepostedToolStripMenuItem";
            this.flagRepostedToolStripMenuItem.Size = new Size(0x94, 0x16);
            this.flagRepostedToolStripMenuItem.Text = "Flag Reposted";
            this.flagRepostedToolStripMenuItem.Click += new EventHandler(this.flagRepostedToolStripMenuItem_Click);
            this.ViewSparepartToolStripMenuItem.Name = "ViewSparepartToolStripMenuItem";
            this.ViewSparepartToolStripMenuItem.Size = new Size(0xe1, 0x16);
            this.ViewSparepartToolStripMenuItem.Text = "View Sparepart";
            this.ViewSparepartToolStripMenuItem.Click += new EventHandler(this.ViewSparepartToolStripMenuItem_Click);
            ToolStripItem[] itemArray9 = new ToolStripItem[0x22];
            itemArray9[0] = this.DOToolStripMenuItem;
            itemArray9[1] = this.commodityToolStripMenuItem;
            itemArray9[2] = this.relationToolStripMenuItem;
            itemArray9[3] = this.toolStripMenuItem1;
            itemArray9[4] = this.truckToolStripMenuItem;
            itemArray9[5] = this.driverToolStripMenuItem;
            itemArray9[6] = this.transpoterToolStripMenuItem;
            itemArray9[7] = this.SPBtoolStripMenuItem;
            itemArray9[8] = this.tankerToolStripMenuItem;
            itemArray9[9] = this.toolStripMenuItem2;
            itemArray9[10] = this.coytoolStripMenuItem;
            itemArray9[11] = this.locationToolStripMenuItem;
            itemArray9[12] = this.estateToolStripMenuItem;
            itemArray9[13] = this.divisionToolStripMenuItemPOM;
            itemArray9[14] = this.blockStripMenuItemPOM;
            itemArray9[15] = this.toolStripMenuItem4;
            itemArray9[0x10] = this.UploadTypeToolStripMenuItem;
            itemArray9[0x11] = this.sAPDestinationToolStripMenuItem;
            itemArray9[0x12] = this.storageToolStripMenuItem;
            itemArray9[0x13] = this.gradingToolStripMenuItemPOM;
            itemArray9[20] = this.qualityToolStripMenuItem;
            itemArray9[0x15] = this.toolStripMenuItem3;
            itemArray9[0x16] = this.transactionTypeToolStripMenuItem;
            itemArray9[0x17] = this.templateSAPToolStripMenuItem;
            itemArray9[0x18] = this.formulaRendemenToolStripMenuItemPOM;
            itemArray9[0x19] = this.mapCommTrxTypeToolStripMenuItem;
            itemArray9[0x1a] = this.incotermToolStripMenuItem;
            itemArray9[0x1b] = this.destinationToolStripMenuItem;
            itemArray9[0x1c] = this.toolStripSeparator4;
            itemArray9[0x1d] = this.emailRecipientsToolStripMenuItem;
            itemArray9[30] = this.cameraListToolStripMenuItem;
            itemArray9[0x1f] = this.ReasonToolStripMenuItem;
            itemArray9[0x20] = this.wBCalibrationToolStripMenuItem;
            itemArray9[0x21] = this.cancelTypeToolStripMenuItem;
            this.masterDataToolStripMenuItem1.DropDownItems.AddRange(itemArray9);
            this.masterDataToolStripMenuItem1.Name = "masterDataToolStripMenuItem1";
            this.masterDataToolStripMenuItem1.Size = new Size(0x52, 20);
            this.masterDataToolStripMenuItem1.Text = "&Master Data";
            this.masterDataToolStripMenuItem1.DropDownOpening += new EventHandler(this.masterDataToolStripMenuItem1_DropDownOpening);
            this.DOToolStripMenuItem.Name = "DOToolStripMenuItem";
            this.DOToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.DOToolStripMenuItem.Text = "DO/Contract/Confirmation";
            this.DOToolStripMenuItem.Click += new EventHandler(this.md1ToolStripMenuItem_Click);
            this.commodityToolStripMenuItem.Name = "commodityToolStripMenuItem";
            this.commodityToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.commodityToolStripMenuItem.Text = "Commodity";
            this.commodityToolStripMenuItem.Click += new EventHandler(this.md2ToolStripMenuItem_Click);
            this.relationToolStripMenuItem.Name = "relationToolStripMenuItem";
            this.relationToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.relationToolStripMenuItem.Text = "Relation List ( Customer/Vendor)";
            this.relationToolStripMenuItem.Click += new EventHandler(this.md3ToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xf3, 6);
            this.truckToolStripMenuItem.Name = "truckToolStripMenuItem";
            this.truckToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.truckToolStripMenuItem.Text = "Truck";
            this.truckToolStripMenuItem.Click += new EventHandler(this.md4ToolStripMenuItem_Click);
            this.driverToolStripMenuItem.Name = "driverToolStripMenuItem";
            this.driverToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.driverToolStripMenuItem.Text = "Driver ID";
            this.driverToolStripMenuItem.Click += new EventHandler(this.md5ToolStripMenuItem_Click);
            this.transpoterToolStripMenuItem.Name = "transpoterToolStripMenuItem";
            this.transpoterToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.transpoterToolStripMenuItem.Text = "Transporter";
            this.transpoterToolStripMenuItem.Click += new EventHandler(this.md6rToolStripMenuItem_Click);
            this.SPBtoolStripMenuItem.Name = "SPBtoolStripMenuItem";
            this.SPBtoolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.SPBtoolStripMenuItem.Text = "Delivery Note";
            this.SPBtoolStripMenuItem.Click += new EventHandler(this.SPBtoolStripMenuItem_Click);
            this.tankerToolStripMenuItem.Name = "tankerToolStripMenuItem";
            this.tankerToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.tankerToolStripMenuItem.Text = "Tanker List && Capacity";
            this.tankerToolStripMenuItem.Click += new EventHandler(this.md12ToolStripMenuItem_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0xf3, 6);
            this.coytoolStripMenuItem.Name = "coytoolStripMenuItem";
            this.coytoolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.coytoolStripMenuItem.Text = "Company";
            this.coytoolStripMenuItem.Click += new EventHandler(this.coytoolStripMenuItem_Click);
            this.locationToolStripMenuItem.Name = "locationToolStripMenuItem";
            this.locationToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.locationToolStripMenuItem.Text = "Location";
            this.locationToolStripMenuItem.Click += new EventHandler(this.md7ToolStripMenuItem_Click);
            this.estateToolStripMenuItem.Name = "estateToolStripMenuItem";
            this.estateToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.estateToolStripMenuItem.Text = "Estate";
            this.estateToolStripMenuItem.Click += new EventHandler(this.md10ToolStripMenuItem_Click);
            this.divisionToolStripMenuItemPOM.Name = "divisionToolStripMenuItemPOM";
            this.divisionToolStripMenuItemPOM.Size = new Size(0xf6, 0x16);
            this.divisionToolStripMenuItemPOM.Text = "Division";
            this.divisionToolStripMenuItemPOM.Click += new EventHandler(this.md9ToolStripMenuItem_Click);
            this.blockStripMenuItemPOM.Name = "blockStripMenuItemPOM";
            this.blockStripMenuItemPOM.Size = new Size(0xf6, 0x16);
            this.blockStripMenuItemPOM.Text = "Block";
            this.blockStripMenuItemPOM.Click += new EventHandler(this.blockStripMenuItem_Click);
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new Size(0xf3, 6);
            this.UploadTypeToolStripMenuItem.Name = "UploadTypeToolStripMenuItem";
            this.UploadTypeToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.UploadTypeToolStripMenuItem.Text = "Upload Type";
            this.UploadTypeToolStripMenuItem.Click += new EventHandler(this.UploadTypeToolStripMenuItem_Click);
            this.sAPDestinationToolStripMenuItem.Name = "sAPDestinationToolStripMenuItem";
            this.sAPDestinationToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.sAPDestinationToolStripMenuItem.Text = "SAP Destination";
            this.sAPDestinationToolStripMenuItem.Click += new EventHandler(this.sAPDestinationToolStripMenuItem_Click);
            this.storageToolStripMenuItem.Name = "storageToolStripMenuItem";
            this.storageToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.storageToolStripMenuItem.Text = "Storage";
            this.storageToolStripMenuItem.Click += new EventHandler(this.md8ToolStripMenuItem_Click);
            this.gradingToolStripMenuItemPOM.Name = "gradingToolStripMenuItemPOM";
            this.gradingToolStripMenuItemPOM.Size = new Size(0xf6, 0x16);
            this.gradingToolStripMenuItemPOM.Text = "Grading";
            this.gradingToolStripMenuItemPOM.Click += new EventHandler(this.md13ToolStripMenuItem_Click);
            ToolStripItem[] itemArray10 = new ToolStripItem[] { this.qCItemToolStripMenuItem, this.compositToolStripMenuItem };
            this.qualityToolStripMenuItem.DropDownItems.AddRange(itemArray10);
            this.qualityToolStripMenuItem.Name = "qualityToolStripMenuItem";
            this.qualityToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.qualityToolStripMenuItem.Text = "Quality Control";
            this.qCItemToolStripMenuItem.Name = "qCItemToolStripMenuItem";
            this.qCItemToolStripMenuItem.Size = new Size(0x7e, 0x16);
            this.qCItemToolStripMenuItem.Text = "QC Item";
            this.qCItemToolStripMenuItem.Click += new EventHandler(this.qCItemToolStripMenuItem_Click);
            this.compositToolStripMenuItem.Name = "compositToolStripMenuItem";
            this.compositToolStripMenuItem.Size = new Size(0x7e, 0x16);
            this.compositToolStripMenuItem.Text = "Composit";
            this.compositToolStripMenuItem.Click += new EventHandler(this.compositToolStripMenuItem_Click);
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new Size(0xf3, 6);
            this.transactionTypeToolStripMenuItem.Name = "transactionTypeToolStripMenuItem";
            this.transactionTypeToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.transactionTypeToolStripMenuItem.Text = "Transaction Type";
            this.transactionTypeToolStripMenuItem.Click += new EventHandler(this.transactionTypeToolStripMenuItem_Click);
            this.templateSAPToolStripMenuItem.Name = "templateSAPToolStripMenuItem";
            this.templateSAPToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.templateSAPToolStripMenuItem.Text = "Template SAP";
            this.templateSAPToolStripMenuItem.Click += new EventHandler(this.templateSAPToolStripMenuItem_Click);
            this.formulaRendemenToolStripMenuItemPOM.Name = "formulaRendemenToolStripMenuItemPOM";
            this.formulaRendemenToolStripMenuItemPOM.Size = new Size(0xf6, 0x16);
            this.formulaRendemenToolStripMenuItemPOM.Text = "Formula Rendemen";
            this.formulaRendemenToolStripMenuItemPOM.Click += new EventHandler(this.formulaRendemenToolStripMenuItem_Click);
            this.mapCommTrxTypeToolStripMenuItem.Name = "mapCommTrxTypeToolStripMenuItem";
            this.mapCommTrxTypeToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.mapCommTrxTypeToolStripMenuItem.Text = "Map Comm-Trx Type";
            this.mapCommTrxTypeToolStripMenuItem.Click += new EventHandler(this.mapCommTrxTypeToolStripMenuItem_Click);
            this.incotermToolStripMenuItem.Name = "incotermToolStripMenuItem";
            this.incotermToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.incotermToolStripMenuItem.Text = "DeductedBy";
            this.incotermToolStripMenuItem.Click += new EventHandler(this.incotermToolStripMenuItem_Click);
            this.destinationToolStripMenuItem.Name = "destinationToolStripMenuItem";
            this.destinationToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.destinationToolStripMenuItem.Text = "Destination";
            this.destinationToolStripMenuItem.Click += new EventHandler(this.destinationToolStripMenuItem_Click);
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new Size(0xf3, 6);
            this.emailRecipientsToolStripMenuItem.Name = "emailRecipientsToolStripMenuItem";
            this.emailRecipientsToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.emailRecipientsToolStripMenuItem.Text = "Email Recipients";
            this.emailRecipientsToolStripMenuItem.Click += new EventHandler(this.emailRecipientsToolStripMenuItem_Click);
            this.cameraListToolStripMenuItem.Name = "cameraListToolStripMenuItem";
            this.cameraListToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.cameraListToolStripMenuItem.Text = "Camera List";
            this.cameraListToolStripMenuItem.Click += new EventHandler(this.cameraListToolStripMenuItem_Click);
            this.ReasonToolStripMenuItem.Name = "ReasonToolStripMenuItem";
            this.ReasonToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.ReasonToolStripMenuItem.Text = "Reason Master Data";
            this.ReasonToolStripMenuItem.Click += new EventHandler(this.ReasonToolStripMenuItem_Click);
            this.wBCalibrationToolStripMenuItem.Name = "wBCalibrationToolStripMenuItem";
            this.wBCalibrationToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.wBCalibrationToolStripMenuItem.Text = "WB Calibration";
            this.wBCalibrationToolStripMenuItem.Click += new EventHandler(this.wBCalibrationToolStripMenuItem_Click);
            this.cancelTypeToolStripMenuItem.Name = "cancelTypeToolStripMenuItem";
            this.cancelTypeToolStripMenuItem.Size = new Size(0xf6, 0x16);
            this.cancelTypeToolStripMenuItem.Text = "Cancel Type";
            this.cancelTypeToolStripMenuItem.Click += new EventHandler(this.cancelTypeToolStripMenuItem_Click);
            ToolStripItem[] itemArray11 = new ToolStripItem[15];
            itemArray11[0] = this.databaseConnectionToolStripMenuItem;
            itemArray11[1] = this.weighBridgeSettingToolStripMenuItem;
            itemArray11[2] = this.weighBridgeControlToolStripMenuItem;
            itemArray11[3] = this.hardwareConfigurationToolStripMenuItem;
            itemArray11[4] = this.toolStripMenuItem6;
            itemArray11[5] = this.userListToolStripMenuItem;
            itemArray11[6] = this.userGroupToolStripMenuItem;
            itemArray11[7] = this.toolStripSeparator5;
            itemArray11[8] = this.copyToNewCompanyToolStripMenuItem;
            itemArray11[9] = this.compareDatabaseToolStripMenuItem;
            itemArray11[10] = this.toolStripSeparator2;
            itemArray11[11] = this.saveColumnPositionToolStripMenuItem;
            itemArray11[12] = this.loadColumnPositionToolStripMenuItem;
            itemArray11[13] = this.toolStripMenuItem7;
            itemArray11[14] = this.activationKeyToolStripMenuItem;
            this.configurationToolStripMenuItem.DropDownItems.AddRange(itemArray11);
            this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
            this.configurationToolStripMenuItem.Size = new Size(0x5d, 20);
            this.configurationToolStripMenuItem.Text = "&Configuration";
            this.configurationToolStripMenuItem.DropDownOpening += new EventHandler(this.configurationToolStripMenuItem_DropDownOpening);
            this.databaseConnectionToolStripMenuItem.Name = "databaseConnectionToolStripMenuItem";
            this.databaseConnectionToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.databaseConnectionToolStripMenuItem.Text = "Database Connection";
            this.databaseConnectionToolStripMenuItem.Click += new EventHandler(this.databaseConnectionToolStripMenuItem_Click);
            this.weighBridgeSettingToolStripMenuItem.Name = "weighBridgeSettingToolStripMenuItem";
            this.weighBridgeSettingToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.weighBridgeSettingToolStripMenuItem.Text = "WeighBridge Setting";
            this.weighBridgeSettingToolStripMenuItem.Click += new EventHandler(this.weighBridgeSettingToolStripMenuItem_Click);
            this.weighBridgeControlToolStripMenuItem.Name = "weighBridgeControlToolStripMenuItem";
            this.weighBridgeControlToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.weighBridgeControlToolStripMenuItem.Text = "WeighBridge Control";
            this.weighBridgeControlToolStripMenuItem.Click += new EventHandler(this.weighBridgeControlToolStripMenuItem_Click);
            this.hardwareConfigurationToolStripMenuItem.Name = "hardwareConfigurationToolStripMenuItem";
            this.hardwareConfigurationToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.hardwareConfigurationToolStripMenuItem.Text = "Hardware Configuration";
            this.hardwareConfigurationToolStripMenuItem.Click += new EventHandler(this.hardwareConfigurationToolStripMenuItem_Click);
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new Size(0xc7, 6);
            this.userListToolStripMenuItem.Name = "userListToolStripMenuItem";
            this.userListToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.userListToolStripMenuItem.Text = "User List";
            this.userListToolStripMenuItem.Click += new EventHandler(this.userListToolStripMenuItem_Click);
            this.userGroupToolStripMenuItem.Name = "userGroupToolStripMenuItem";
            this.userGroupToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.userGroupToolStripMenuItem.Text = "User Group";
            this.userGroupToolStripMenuItem.Click += new EventHandler(this.userGroupToolStripMenuItem_Click);
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new Size(0xc7, 6);
            this.copyToNewCompanyToolStripMenuItem.Name = "copyToNewCompanyToolStripMenuItem";
            this.copyToNewCompanyToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.copyToNewCompanyToolStripMenuItem.Text = "Copy to New Company";
            this.copyToNewCompanyToolStripMenuItem.Click += new EventHandler(this.copyToNewCompanyToolStripMenuItem_Click);
            this.compareDatabaseToolStripMenuItem.Name = "compareDatabaseToolStripMenuItem";
            this.compareDatabaseToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.compareDatabaseToolStripMenuItem.Text = "Compare Database";
            this.compareDatabaseToolStripMenuItem.Click += new EventHandler(this.compareDatabaseToolStripMenuItem_Click);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(0xc7, 6);
            this.saveColumnPositionToolStripMenuItem.Name = "saveColumnPositionToolStripMenuItem";
            this.saveColumnPositionToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.saveColumnPositionToolStripMenuItem.Text = "Save Column Position";
            this.saveColumnPositionToolStripMenuItem.Click += new EventHandler(this.saveColumnPositionToolStripMenuItem_Click);
            this.loadColumnPositionToolStripMenuItem.Name = "loadColumnPositionToolStripMenuItem";
            this.loadColumnPositionToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.loadColumnPositionToolStripMenuItem.Text = "Load Column Position";
            this.loadColumnPositionToolStripMenuItem.Click += new EventHandler(this.loadColumnPositionToolStripMenuItem_Click);
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new Size(0xc7, 6);
            ToolStripItem[] itemArray12 = new ToolStripItem[] { this.maintainActivationKeyUsageToolStripMenuItem, this.renewActivationKeyToolStripMenuItem };
            this.activationKeyToolStripMenuItem.DropDownItems.AddRange(itemArray12);
            this.activationKeyToolStripMenuItem.Name = "activationKeyToolStripMenuItem";
            this.activationKeyToolStripMenuItem.Size = new Size(0xca, 0x16);
            this.activationKeyToolStripMenuItem.Text = "Activation Key";
            this.maintainActivationKeyUsageToolStripMenuItem.Name = "maintainActivationKeyUsageToolStripMenuItem";
            this.maintainActivationKeyUsageToolStripMenuItem.Size = new Size(0x13b, 0x16);
            this.maintainActivationKeyUsageToolStripMenuItem.Text = "Maintain Activation Key Usage";
            this.maintainActivationKeyUsageToolStripMenuItem.Click += new EventHandler(this.maintainActivationKeyUsageToolStripMenuItem_Click);
            this.renewActivationKeyToolStripMenuItem.Name = "renewActivationKeyToolStripMenuItem";
            this.renewActivationKeyToolStripMenuItem.Size = new Size(0x13b, 0x16);
            this.renewActivationKeyToolStripMenuItem.Text = "Renew Activation Key for All Registered WB(s)";
            this.renewActivationKeyToolStripMenuItem.Click += new EventHandler(this.renewActivationKeyToolStripMenuItem_Click);
            ToolStripItem[] itemArray13 = new ToolStripItem[30];
            itemArray13[0] = this.FFBReportToolStripMenuItemPOM;
            itemArray13[1] = this.listOfWeighningToolStripMenuItem1;
            itemArray13[2] = this.copraReportToolStripMenuItem;
            itemArray13[3] = this.dailyReceiptSupplierToolStripMenuItem;
            itemArray13[4] = this.toolStripMenuItem5;
            itemArray13[5] = this.reportOutstandingDOToolStripMenuItem;
            itemArray13[6] = this.reportOutstandingDONonTradeStoreToolStripMenuItem;
            itemArray13[7] = this.receivingEstimationFrom3rdPartyToolStripMenuItem;
            itemArray13[8] = this.doDetailToolStripMenuItem;
            itemArray13[9] = this.nonContractTransactionToolStripMenuItem;
            itemArray13[10] = this.qCReportToolStripMenuItem;
            itemArray13[11] = this.vendorSummaryToolStripMenuItem;
            itemArray13[12] = this.vendorDetailToolStripMenuItem;
            itemArray13[13] = this.outstandingDOPerVendorToolStripMenuItem;
            itemArray13[14] = this.failSynchronizeReportToolStripMenuItem;
            itemArray13[15] = this.toleranceProductToolStripMenuItem;
            itemArray13[0x10] = this.vesselReportToolStripMenuItem;
            itemArray13[0x11] = this.multiLineSOOutstandingReportToolStripMenuItem;
            itemArray13[0x12] = this.toolStripSeparator3;
            itemArray13[0x13] = this.wBOwnerToolStripMenuItem;
            itemArray13[20] = this.tankerLogToolStripMenuItem;
            itemArray13[0x15] = this.logReportToolStripMenuItem;
            itemArray13[0x16] = this.commodityToleranceReportToolStripMenuItem;
            itemArray13[0x17] = this.tsCCTC;
            itemArray13[0x18] = this.indicatorStabilityReportToolStripMenuItem;
            itemArray13[0x19] = this.indicatorStabilityReportToolStripMenuItem1;
            itemArray13[0x1a] = this.userManagementReportToolStripMenuItem;
            itemArray13[0x1b] = this.emailRecipientReportToolStripMenuItem;
            itemArray13[0x1c] = this.wtaReportToolStripMenuItem;
            itemArray13[0x1d] = this.DriverBlacklistReportToolStripMenuItem;
            this.ReportToolStripMenuItem.DropDownItems.AddRange(itemArray13);
            this.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem";
            this.ReportToolStripMenuItem.Size = new Size(0x36, 20);
            this.ReportToolStripMenuItem.Text = "&Report";
            this.ReportToolStripMenuItem.DropDownOpening += new EventHandler(this.ReportToolStripMenuItem_DropDownOpening);
            ToolStripItem[] itemArray14 = new ToolStripItem[] { this.toolStripMenuRekapHarian, this.subRP1ToolStripMenuItem, this.laporanPeneriamPerSupploerLA1ToolStripMenuItem, this.laporanTotalPenerimaanTBSToolStripMenuItem, this.fFBGradingReportToolStripMenuItem, this.toolStripMenuItem12, this.vendorSummaryTBSToolStripMenuItem, this.divisionReportToolStripMenuItem };
            this.FFBReportToolStripMenuItemPOM.DropDownItems.AddRange(itemArray14);
            this.FFBReportToolStripMenuItemPOM.Name = "FFBReportToolStripMenuItemPOM";
            this.FFBReportToolStripMenuItemPOM.Size = new Size(410, 0x16);
            this.FFBReportToolStripMenuItemPOM.Text = "FFB Report";
            this.toolStripMenuRekapHarian.Name = "toolStripMenuRekapHarian";
            this.toolStripMenuRekapHarian.Size = new Size(280, 0x16);
            this.toolStripMenuRekapHarian.Text = "Rekap Harian FFB";
            this.toolStripMenuRekapHarian.Click += new EventHandler(this.toolStripMenuRekapHarian_Click);
            this.subRP1ToolStripMenuItem.Name = "subRP1ToolStripMenuItem";
            this.subRP1ToolStripMenuItem.Size = new Size(280, 0x16);
            this.subRP1ToolStripMenuItem.Text = "Daily Report FFB (LA)";
            this.subRP1ToolStripMenuItem.Click += new EventHandler(this.subRP1ToolStripMenuItem_Click);
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Name = "laporanPeneriamPerSupploerLA1ToolStripMenuItem";
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Size = new Size(280, 0x16);
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Text = "Laporan Penerimaan Per Supplier (LA1)";
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Click += new EventHandler(this.laporanPeneriamPerSupploerLA1ToolStripMenuItem_Click);
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Name = "laporanTotalPenerimaanTBSToolStripMenuItem";
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Size = new Size(280, 0x16);
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Text = "Laporan Total Penerimaan TBS (LA2)";
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Click += new EventHandler(this.laporanTotalPenerimaanTBSToolStripMenuItem_Click);
            this.fFBGradingReportToolStripMenuItem.Name = "fFBGradingReportToolStripMenuItem";
            this.fFBGradingReportToolStripMenuItem.Size = new Size(280, 0x16);
            this.fFBGradingReportToolStripMenuItem.Text = "FFB Grading Report";
            this.fFBGradingReportToolStripMenuItem.Click += new EventHandler(this.fFBGradingReportToolStripMenuItem_Click);
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new Size(280, 0x16);
            this.toolStripMenuItem12.Text = "FFB Porla Report";
            this.toolStripMenuItem12.Click += new EventHandler(this.toolStripMenuItem12_Click_1);
            this.vendorSummaryTBSToolStripMenuItem.Name = "vendorSummaryTBSToolStripMenuItem";
            this.vendorSummaryTBSToolStripMenuItem.Size = new Size(280, 0x16);
            this.vendorSummaryTBSToolStripMenuItem.Text = "Vendor Summary TBS";
            this.vendorSummaryTBSToolStripMenuItem.Click += new EventHandler(this.vendorSummaryTBSToolStripMenuItem_Click);
            this.divisionReportToolStripMenuItem.Name = "divisionReportToolStripMenuItem";
            this.divisionReportToolStripMenuItem.Size = new Size(280, 0x16);
            this.divisionReportToolStripMenuItem.Text = "Division Report";
            this.divisionReportToolStripMenuItem.Click += new EventHandler(this.divisionReportToolStripMenuItem_Click);
            this.listOfWeighningToolStripMenuItem1.Name = "listOfWeighningToolStripMenuItem1";
            this.listOfWeighningToolStripMenuItem1.Size = new Size(410, 0x16);
            this.listOfWeighningToolStripMenuItem1.Text = "List Of Weighing";
            this.listOfWeighningToolStripMenuItem1.Click += new EventHandler(this.listOfWeighningToolStripMenuItem1_Click);
            this.copraReportToolStripMenuItem.Name = "copraReportToolStripMenuItem";
            this.copraReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.copraReportToolStripMenuItem.Text = "Daily Receipt Per Supplier (LA1) Report";
            this.copraReportToolStripMenuItem.Click += new EventHandler(this.copraReportToolStripMenuItem_Click);
            this.dailyReceiptSupplierToolStripMenuItem.Name = "dailyReceiptSupplierToolStripMenuItem";
            this.dailyReceiptSupplierToolStripMenuItem.Size = new Size(410, 0x16);
            this.dailyReceiptSupplierToolStripMenuItem.Text = "Daily Receipt per Supplier (LA2) Report";
            this.dailyReceiptSupplierToolStripMenuItem.Click += new EventHandler(this.dailyReceiptSupplierToolStripMenuItem_Click);
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new Size(0x197, 6);
            this.reportOutstandingDOToolStripMenuItem.Name = "reportOutstandingDOToolStripMenuItem";
            this.reportOutstandingDOToolStripMenuItem.Size = new Size(410, 0x16);
            this.reportOutstandingDOToolStripMenuItem.Text = "Outstanding DO/Contract Report";
            this.reportOutstandingDOToolStripMenuItem.Click += new EventHandler(this.reportOutstandingDOToolStripMenuItem_Click);
            this.reportOutstandingDONonTradeStoreToolStripMenuItem.Name = "reportOutstandingDONonTradeStoreToolStripMenuItem";
            this.reportOutstandingDONonTradeStoreToolStripMenuItem.Size = new Size(410, 0x16);
            this.reportOutstandingDONonTradeStoreToolStripMenuItem.Text = "Outstanding DO Non-Trade Store";
            this.reportOutstandingDONonTradeStoreToolStripMenuItem.Click += new EventHandler(this.reportOutstandingDONonTradeStoreToolStripMenuItem_Click);
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Name = "receivingEstimationFrom3rdPartyToolStripMenuItem";
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Size = new Size(410, 0x16);
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Text = "Receiving Estimation From 3rd Party Report";
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Click += new EventHandler(this.receivingEstimationFrom3rdPartyToolStripMenuItem_Click);
            this.doDetailToolStripMenuItem.Name = "doDetailToolStripMenuItem";
            this.doDetailToolStripMenuItem.Size = new Size(410, 0x16);
            this.doDetailToolStripMenuItem.Text = "Good Receive / Good Issue Report";
            this.doDetailToolStripMenuItem.Click += new EventHandler(this.doDetailToolStripMenuItem_Click);
            this.nonContractTransactionToolStripMenuItem.Name = "nonContractTransactionToolStripMenuItem";
            this.nonContractTransactionToolStripMenuItem.Size = new Size(410, 0x16);
            this.nonContractTransactionToolStripMenuItem.Text = "NonContract Transaction";
            this.nonContractTransactionToolStripMenuItem.Click += new EventHandler(this.nonContractTransactionToolStripMenuItem_Click);
            this.qCReportToolStripMenuItem.Name = "qCReportToolStripMenuItem";
            this.qCReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.qCReportToolStripMenuItem.Text = "QC Report";
            this.qCReportToolStripMenuItem.Click += new EventHandler(this.qCReportToolStripMenuItem_Click);
            this.vendorSummaryToolStripMenuItem.Name = "vendorSummaryToolStripMenuItem";
            this.vendorSummaryToolStripMenuItem.Size = new Size(410, 0x16);
            this.vendorSummaryToolStripMenuItem.Text = "Vendor Summary 1 Report";
            this.vendorSummaryToolStripMenuItem.Click += new EventHandler(this.vendorSummaryToolStripMenuItem_Click);
            this.vendorDetailToolStripMenuItem.Name = "vendorDetailToolStripMenuItem";
            this.vendorDetailToolStripMenuItem.Size = new Size(410, 0x16);
            this.vendorDetailToolStripMenuItem.Text = "Vendor Summary 2 Report";
            this.vendorDetailToolStripMenuItem.Click += new EventHandler(this.vendorDetailToolStripMenuItem_Click);
            this.outstandingDOPerVendorToolStripMenuItem.Name = "outstandingDOPerVendorToolStripMenuItem";
            this.outstandingDOPerVendorToolStripMenuItem.Size = new Size(410, 0x16);
            this.outstandingDOPerVendorToolStripMenuItem.Text = "Outstanding DO per Vendor Report";
            this.outstandingDOPerVendorToolStripMenuItem.Click += new EventHandler(this.outstandingPOPerVendorToolStripMenuItem_Click);
            this.failSynchronizeReportToolStripMenuItem.Name = "failSynchronizeReportToolStripMenuItem";
            this.failSynchronizeReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.failSynchronizeReportToolStripMenuItem.Text = "Fail Synchronize Report";
            this.failSynchronizeReportToolStripMenuItem.Click += new EventHandler(this.failSynchronizeReportToolStripMenuItem_Click);
            this.toleranceProductToolStripMenuItem.Name = "toleranceProductToolStripMenuItem";
            this.toleranceProductToolStripMenuItem.Size = new Size(410, 0x16);
            this.toleranceProductToolStripMenuItem.Text = "Tolerance Product Report";
            this.toleranceProductToolStripMenuItem.Click += new EventHandler(this.toleranceProductToolStripMenuItem_Click);
            this.vesselReportToolStripMenuItem.Name = "vesselReportToolStripMenuItem";
            this.vesselReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.vesselReportToolStripMenuItem.Text = "Vessel Report";
            this.vesselReportToolStripMenuItem.Click += new EventHandler(this.vesselReportToolStripMenuItem_Click);
            this.multiLineSOOutstandingReportToolStripMenuItem.Name = "multiLineSOOutstandingReportToolStripMenuItem";
            this.multiLineSOOutstandingReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.multiLineSOOutstandingReportToolStripMenuItem.Text = "Multi Line SO Outstanding Report";
            this.multiLineSOOutstandingReportToolStripMenuItem.Click += new EventHandler(this.multiLineSOOutstandingReportToolStripMenuItem_Click);
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new Size(0x197, 6);
            this.wBOwnerToolStripMenuItem.Name = "wBOwnerToolStripMenuItem";
            this.wBOwnerToolStripMenuItem.Size = new Size(410, 0x16);
            this.wBOwnerToolStripMenuItem.Text = "WB Owner Report";
            this.wBOwnerToolStripMenuItem.Click += new EventHandler(this.wBOwnerToolStripMenuItem_Click);
            this.tankerLogToolStripMenuItem.Name = "tankerLogToolStripMenuItem";
            this.tankerLogToolStripMenuItem.Size = new Size(410, 0x16);
            this.tankerLogToolStripMenuItem.Text = "Tanker Approval History";
            this.tankerLogToolStripMenuItem.Click += new EventHandler(this.tankerLogToolStripMenuItem_Click);
            ToolStripItem[] itemArray15 = new ToolStripItem[11];
            itemArray15[0] = this.transactionLogToolStripMenuItem;
            itemArray15[1] = this.masterDataLogToolStripMenuItem;
            itemArray15[2] = this.settingLogReportToolStripMenuItem;
            itemArray15[3] = this.locationLogReportToolStripMenuItem;
            itemArray15[4] = this.userListLogToolStripMenuItem;
            itemArray15[5] = this.userLoginLogoutLogToolStripMenuItem;
            itemArray15[6] = this.authorizationLogToolStripMenuItem;
            itemArray15[7] = this.templateSAPLogToolStripMenuItem;
            itemArray15[8] = this.migrateOldLogToNewLogToolStripMenuItem;
            itemArray15[9] = this.cancelRegistrationReportToolStripMenuItem;
            itemArray15[10] = this.cancelWeighingReportToolStripMenuItem;
            this.logReportToolStripMenuItem.DropDownItems.AddRange(itemArray15);
            this.logReportToolStripMenuItem.Name = "logReportToolStripMenuItem";
            this.logReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.logReportToolStripMenuItem.Text = "Log Report";
            this.logReportToolStripMenuItem.Click += new EventHandler(this.logReportToolStripMenuItem_Click);
            this.transactionLogToolStripMenuItem.Name = "transactionLogToolStripMenuItem";
            this.transactionLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.transactionLogToolStripMenuItem.Text = "Transaction Log Report";
            this.transactionLogToolStripMenuItem.Click += new EventHandler(this.transactionLogToolStripMenuItem1_Click);
            this.masterDataLogToolStripMenuItem.Name = "masterDataLogToolStripMenuItem";
            this.masterDataLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.masterDataLogToolStripMenuItem.Text = "Master Data Log Report";
            this.masterDataLogToolStripMenuItem.Click += new EventHandler(this.masterDataLogToolStripMenuItem_Click);
            this.settingLogReportToolStripMenuItem.Name = "settingLogReportToolStripMenuItem";
            this.settingLogReportToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.settingLogReportToolStripMenuItem.Text = "Setting Log Report";
            this.settingLogReportToolStripMenuItem.Click += new EventHandler(this.settingLogReportToolStripMenuItem_Click);
            this.locationLogReportToolStripMenuItem.Name = "locationLogReportToolStripMenuItem";
            this.locationLogReportToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.locationLogReportToolStripMenuItem.Text = "Location Log Report";
            this.locationLogReportToolStripMenuItem.Click += new EventHandler(this.locationLogReportToolStripMenuItem_Click);
            this.userListLogToolStripMenuItem.Name = "userListLogToolStripMenuItem";
            this.userListLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.userListLogToolStripMenuItem.Text = "User List Log Report";
            this.userListLogToolStripMenuItem.Click += new EventHandler(this.userListLogToolStripMenuItem_Click);
            this.userLoginLogoutLogToolStripMenuItem.Name = "userLoginLogoutLogToolStripMenuItem";
            this.userLoginLogoutLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.userLoginLogoutLogToolStripMenuItem.Text = "User Login/Logout Log Report";
            this.userLoginLogoutLogToolStripMenuItem.Click += new EventHandler(this.userLoginLogoutLogToolStripMenuItem_Click);
            this.authorizationLogToolStripMenuItem.Name = "authorizationLogToolStripMenuItem";
            this.authorizationLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.authorizationLogToolStripMenuItem.Text = "Authorization Log Report";
            this.authorizationLogToolStripMenuItem.Click += new EventHandler(this.authorizationLogToolStripMenuItem_Click);
            this.templateSAPLogToolStripMenuItem.Name = "templateSAPLogToolStripMenuItem";
            this.templateSAPLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.templateSAPLogToolStripMenuItem.Text = "Template SAP Log Report";
            this.templateSAPLogToolStripMenuItem.Click += new EventHandler(this.templateSAPLogToolStripMenuItem_Click);
            this.migrateOldLogToNewLogToolStripMenuItem.Name = "migrateOldLogToNewLogToolStripMenuItem";
            this.migrateOldLogToNewLogToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.migrateOldLogToNewLogToolStripMenuItem.Text = "Migrate Old Log to New Log";
            this.migrateOldLogToNewLogToolStripMenuItem.Click += new EventHandler(this.migrateOldLogToNewLogToolStripMenuItem_Click);
            this.cancelRegistrationReportToolStripMenuItem.Name = "cancelRegistrationReportToolStripMenuItem";
            this.cancelRegistrationReportToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.cancelRegistrationReportToolStripMenuItem.Text = "Cancel Registration Report";
            this.cancelRegistrationReportToolStripMenuItem.Click += new EventHandler(this.cancelRegistrationReportToolStripMenuItem_Click);
            this.cancelWeighingReportToolStripMenuItem.Name = "cancelWeighingReportToolStripMenuItem";
            this.cancelWeighingReportToolStripMenuItem.Size = new Size(0xea, 0x16);
            this.cancelWeighingReportToolStripMenuItem.Text = "Cancel Weighing Report";
            this.cancelWeighingReportToolStripMenuItem.Click += new EventHandler(this.cancelWeighingReportToolStripMenuItem_Click);
            this.commodityToleranceReportToolStripMenuItem.Name = "commodityToleranceReportToolStripMenuItem";
            this.commodityToleranceReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.commodityToleranceReportToolStripMenuItem.Text = "Commodity Tolerance Report";
            this.commodityToleranceReportToolStripMenuItem.Click += new EventHandler(this.commodityToleranceReportToolStripMenuItem_Click);
            this.tsCCTC.Name = "tsCCTC";
            this.tsCCTC.Size = new Size(410, 0x16);
            this.tsCCTC.Text = "[TOKEN] Changes of Commodity Tolerance per Contract Report";
            this.tsCCTC.Click += new EventHandler(this.tsCCTC_Click);
            this.indicatorStabilityReportToolStripMenuItem.Name = "indicatorStabilityReportToolStripMenuItem";
            this.indicatorStabilityReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.indicatorStabilityReportToolStripMenuItem.Text = "Indicator Stability Report";
            this.indicatorStabilityReportToolStripMenuItem.Click += new EventHandler(this.indicatorStabilityReportToolStripMenuItem_Click);
            this.indicatorStabilityReportToolStripMenuItem1.Name = "indicatorStabilityReportToolStripMenuItem1";
            this.indicatorStabilityReportToolStripMenuItem1.Size = new Size(410, 0x16);
            this.indicatorStabilityReportToolStripMenuItem1.Text = "Indicator Stability Graph Report";
            this.indicatorStabilityReportToolStripMenuItem1.Click += new EventHandler(this.indicatorStabilityReportToolStripMenuItem1_Click);
            ToolStripItem[] itemArray16 = new ToolStripItem[] { this.userListReportToolStripMenuItem, this.accessRightReportToolStripMenuItem };
            this.userManagementReportToolStripMenuItem.DropDownItems.AddRange(itemArray16);
            this.userManagementReportToolStripMenuItem.Name = "userManagementReportToolStripMenuItem";
            this.userManagementReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.userManagementReportToolStripMenuItem.Text = "User Management Report";
            this.userManagementReportToolStripMenuItem.Click += new EventHandler(this.userManagementReportToolStripMenuItem_Click);
            this.userListReportToolStripMenuItem.Name = "userListReportToolStripMenuItem";
            this.userListReportToolStripMenuItem.Size = new Size(0xb3, 0x16);
            this.userListReportToolStripMenuItem.Text = "User List Report";
            this.userListReportToolStripMenuItem.Click += new EventHandler(this.userListReportToolStripMenuItem_Click);
            this.accessRightReportToolStripMenuItem.Name = "accessRightReportToolStripMenuItem";
            this.accessRightReportToolStripMenuItem.Size = new Size(0xb3, 0x16);
            this.accessRightReportToolStripMenuItem.Text = "Access Right Report";
            this.accessRightReportToolStripMenuItem.Click += new EventHandler(this.accessRightReportToolStripMenuItem_Click);
            this.emailRecipientReportToolStripMenuItem.Name = "emailRecipientReportToolStripMenuItem";
            this.emailRecipientReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.emailRecipientReportToolStripMenuItem.Text = "Email Recipient Report";
            this.emailRecipientReportToolStripMenuItem.Click += new EventHandler(this.emailRecipientReportToolStripMenuItem_Click);
            this.wtaReportToolStripMenuItem.Name = "wtaReportToolStripMenuItem";
            this.wtaReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.wtaReportToolStripMenuItem.Text = "Weighing Time Analysis Report";
            this.wtaReportToolStripMenuItem.Click += new EventHandler(this.secretReportToolStripMenuItem_Click);
            this.DriverBlacklistReportToolStripMenuItem.Name = "DriverBlacklistReportToolStripMenuItem";
            this.DriverBlacklistReportToolStripMenuItem.Size = new Size(410, 0x16);
            this.DriverBlacklistReportToolStripMenuItem.Text = "Driver Blacklist Report";
            this.DriverBlacklistReportToolStripMenuItem.Click += new EventHandler(this.DriverBlacklistReportToolStripMenuItem_Click);
            this.uploadSAPToolStripMenuItem.Name = "uploadSAPToolStripMenuItem";
            this.uploadSAPToolStripMenuItem.Size = new Size(0x5f, 20);
            this.uploadSAPToolStripMenuItem.Text = "&Upload to SAP";
            this.uploadSAPToolStripMenuItem.Click += new EventHandler(this.uploadSAPToolStripMenuItem_Click);
            this.changeProfileToolStripMenuItem.Name = "changeProfileToolStripMenuItem";
            this.changeProfileToolStripMenuItem.Size = new Size(0x61, 20);
            this.changeProfileToolStripMenuItem.Text = "Change Profile";
            this.changeProfileToolStripMenuItem.Click += new EventHandler(this.changeProfileToolStripMenuItem_Click);
            this.logOffToolStripMenuItem.Name = "logOffToolStripMenuItem";
            this.logOffToolStripMenuItem.Size = new Size(0x39, 20);
            this.logOffToolStripMenuItem.Text = "&Logout";
            this.logOffToolStripMenuItem.Click += new EventHandler(this.logOffToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.schDataToolStripMenuItem.Name = "schDataToolStripMenuItem";
            this.schDataToolStripMenuItem.Size = new Size(0x18, 20);
            this.schDataToolStripMenuItem.Text = "/";
            this.schDataToolStripMenuItem.Visible = false;
            this.schDataToolStripMenuItem.Click += new EventHandler(this.schDataToolStripMenuItem_Click);
            this.contractLogToolStripMenuItem.Name = "contractLogToolStripMenuItem";
            this.contractLogToolStripMenuItem.Size = new Size(0x179, 0x16);
            this.contractLogToolStripMenuItem.Text = "Contract Log";
            this.contractLogToolStripMenuItem.Click += new EventHandler(this.contractLogToolStripMenuItem_Click);
            this.statusWB.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.statusWB.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] itemArray17 = new ToolStripItem[] { this.Status1, this.label2 };
            this.statusWB.Items.AddRange(itemArray17);
            this.statusWB.Location = new Point(0, 540);
            this.statusWB.Name = "statusWB";
            this.statusWB.Size = new Size(0x404, 0x16);
            this.statusWB.TabIndex = 1;
            this.statusWB.Text = "statusStrip1";
            this.Status1.Name = "Status1";
            this.Status1.Size = new Size(0x9f, 0x11);
            this.Status1.Text = "Wilmar Group - Copyright \x00a9";
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x67, 0x11);
            this.label2.Text = "User ID and Group";
            this.timerSAPUpd.Interval = 0x3e8;
            this.timerSAPUpd.Tick += new EventHandler(this.timerSAPUpd_Tick);
            this.lblNow.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblNow.AutoSize = true;
            this.lblNow.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblNow.Location = new Point(0x361, 7);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new Size(0x31, 13);
            this.lblNow.TabIndex = 4;
            this.lblNow.Text = "00:00:00";
            this.lblNow.Visible = false;
            this.lblDate.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblDate.Location = new Point(0x336, 7);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new Size(0x25, 13);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "progre";
            this.backgroundWorkerSAP.DoWork += new DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.timerTokenEmail.Tick += new EventHandler(this.timerTokenEmail_Tick);
            this.backgroundWorkerEmail.DoWork += new DoWorkEventHandler(this.backgroundWorkerEmail_DoWork);
            this.label1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.ForeColor = Color.White;
            this.label1.Location = new Point(0, 0);
            this.label1.Margin = new Padding(0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = RightToLeft.Yes;
            this.label1.Size = new Size(0x404, 0x18);
            this.label1.TabIndex = 1;
            this.label1.Text = "WEIGHING TRANSACTION";
            this.label1.TextAlign = ContentAlignment.TopCenter;
            this.label1.Click += new EventHandler(this.label1_Click);
            this.panel1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.checkWBCode);
            this.panel1.Controls.Add(this.checkPartial);
            this.panel1.Controls.Add(this.Garis3);
            this.panel1.Controls.Add(this.checkShowCheckSum);
            this.panel1.Controls.Add(this.Garis2);
            this.panel1.Controls.Add(this.labelStatus1);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Controls.Add(this.buttonFilter);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Controls.Add(this.labelExpired);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.ForeColor = Color.Black;
            this.panel1.Location = new Point(0, 0x1ca);
            this.panel1.Margin = new Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x404, 0x20);
            this.panel1.TabIndex = 2;
            this.label5.BorderStyle = BorderStyle.Fixed3D;
            this.label5.Location = new Point(0x332, -26);
            this.label5.Margin = new Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new Size(11, 0x4d);
            this.label5.TabIndex = 0x10;
            this.checkWBCode.AutoSize = true;
            this.checkWBCode.Location = new Point(0x2ea, 8);
            this.checkWBCode.Name = "checkWBCode";
            this.checkWBCode.Size = new Size(0x48, 0x11);
            this.checkWBCode.TabIndex = 15;
            this.checkWBCode.Text = "WB Code";
            this.checkWBCode.UseVisualStyleBackColor = true;
            this.checkWBCode.CheckedChanged += new EventHandler(this.checkWBCode_CheckedChanged);
            this.checkPartial.AutoSize = true;
            this.checkPartial.Location = new Point(0x2a1, 8);
            this.checkPartial.Name = "checkPartial";
            this.checkPartial.Size = new Size(0x37, 0x11);
            this.checkPartial.TabIndex = 14;
            this.checkPartial.Text = "Partial";
            this.checkPartial.UseVisualStyleBackColor = true;
            this.checkPartial.CheckedChanged += new EventHandler(this.checkPartial_CheckedChanged);
            this.Garis3.BorderStyle = BorderStyle.Fixed3D;
            this.Garis3.Location = new Point(0x2d8, -31);
            this.Garis3.Margin = new Padding(1, 0, 1, 0);
            this.Garis3.Name = "Garis3";
            this.Garis3.Size = new Size(11, 0x4d);
            this.Garis3.TabIndex = 13;
            this.checkShowCheckSum.AutoSize = true;
            this.checkShowCheckSum.Location = new Point(0x343, 15);
            this.checkShowCheckSum.Name = "checkShowCheckSum";
            this.checkShowCheckSum.Size = new Size(0x65, 0x11);
            this.checkShowCheckSum.TabIndex = 12;
            this.checkShowCheckSum.Text = "Checksum Error";
            this.checkShowCheckSum.UseVisualStyleBackColor = true;
            this.checkShowCheckSum.Visible = false;
            this.checkShowCheckSum.CheckedChanged += new EventHandler(this.checkShowCheckSum_CheckedChanged);
            this.Garis2.BorderStyle = BorderStyle.Fixed3D;
            this.Garis2.Location = new Point(0x28f, -32);
            this.Garis2.Margin = new Padding(1, 0, 1, 0);
            this.Garis2.Name = "Garis2";
            this.Garis2.Size = new Size(11, 0x4d);
            this.Garis2.TabIndex = 5;
            this.labelStatus1.AutoSize = true;
            this.labelStatus1.Dock = DockStyle.Right;
            this.labelStatus1.Location = new Point(0x3e1, 0);
            this.labelStatus1.Name = "labelStatus1";
            this.labelStatus1.Size = new Size(0x23, 13);
            this.labelStatus1.TabIndex = 11;
            this.labelStatus1.Text = "label5";
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x343, 1);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0x67, 0x11);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "Show Cancelled";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Visible = false;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(0x1ee, 7);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x62, 20);
            this.dateTimePicker2.TabIndex = 9;
            this.dateTimePicker2.ValueChanged += new EventHandler(this.dateTimePicker2_ValueChanged);
            this.dateTimePicker2.KeyPress += new KeyPressEventHandler(this.dateTimePicker2_KeyPress);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x174, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x5f, 20);
            this.dateTimePicker1.TabIndex = 8;
            this.dateTimePicker1.ValueChanged += new EventHandler(this.dateTimePicker1_ValueChanged);
            this.dateTimePicker1.KeyPress += new KeyPressEventHandler(this.dateTimePicker1_KeyPress);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1d8, 10);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x10, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "to";
            this.label3.Click += new EventHandler(this.label3_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x106, 9);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x69, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Saring Data Tanggal";
            this.label4.Click += new EventHandler(this.label4_Click);
            this.TextFind.CharacterCasing = CharacterCasing.Upper;
            this.TextFind.Location = new Point(3, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 1;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc1, 2);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x2d, 0x1b);
            this.buttonFind.TabIndex = 2;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.buttonFilter.Location = new Point(0x256, 3);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new Size(0x2d, 0x1b);
            this.buttonFilter.TabIndex = 4;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new EventHandler(this.button5_Click);
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0xf2, -26);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(14, 0x3d);
            this.Garis1.TabIndex = 4;
            this.labelExpired.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelExpired.ForeColor = Color.Red;
            this.labelExpired.Location = new Point(820, 15);
            this.labelExpired.Name = "labelExpired";
            this.labelExpired.Size = new Size(0x225, 13);
            this.labelExpired.TabIndex = 0x15;
            this.labelExpired.Text = "SYSTEM KEY IS EXPIRED. PLEASE RENEW IT TO GET FULL VERSION OF WB SYSTEM.";
            this.labelExpired.TextAlign = ContentAlignment.MiddleRight;
            this.labelExpired.Visible = false;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(3, 0x1b);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x3fe, 0x1a5);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.ColumnHeaderMouseClick += new DataGridViewCellMouseEventHandler(this.dataGridView1_ColumnHeaderMouseClick);
            this.dataGridView1.MouseClick += new MouseEventHandler(this.dataGridView1_MouseClick);
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0x18);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 24f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 91.74312f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 39f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 8f));
            this.tableLayoutPanel1.Size = new Size(0x404, 0x1f2);
            this.tableLayoutPanel1.TabIndex = 2;
            this.linkLabelSupport.Dock = DockStyle.Bottom;
            this.linkLabelSupport.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.linkLabelSupport.Location = new Point(0, 0x20a);
            this.linkLabelSupport.Margin = new Padding(2, 0, 2, 0);
            this.linkLabelSupport.Name = "linkLabelSupport";
            this.linkLabelSupport.Size = new Size(0x404, 0x12);
            this.linkLabelSupport.TabIndex = 20;
            this.linkLabelSupport.TabStop = true;
            this.linkLabelSupport.Text = "Please Click This Link to Report Your Issue To Desksupport";
            this.linkLabelSupport.TextAlign = ContentAlignment.MiddleRight;
            this.linkLabelSupport.LinkClicked += new LinkLabelLinkClickedEventHandler(this.linkLabelSupport_LinkClicked);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.Lavender;
            base.ClientSize = new Size(0x404, 0x232);
            base.Controls.Add(this.lblDate);
            base.Controls.Add(this.lblNow);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.linkLabelSupport);
            base.Controls.Add(this.statusWB);
            base.Controls.Add(this.menuStrip1);
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "MainForm";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "WB System";
            base.WindowState = FormWindowState.Maximized;
            base.FormClosing += new FormClosingEventHandler(this.MainForm_FormClosing);
            base.Load += new EventHandler(this.MainForm_Load);
            base.KeyPress += new KeyPressEventHandler(this.MainForm_KeyPress);
            base.Leave += new EventHandler(this.MainForm_Leave);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusWB.ResumeLayout(false);
            this.statusWB.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private bool isRegistrationKeyValid()
        {
            bool valid;
            string sqltext = "";
            WBTable table = new WBTable();
            WBTable sourceTable = new WBTable();
            sqltext = "SELECT * FROM information_schema.tables WHERE table_name = 'wb_act'";
            table.OpenTable("wb_act", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                valid = true;
            }
            else
            {
                sqltext = "SELECT * FROM wb_act WHERE 1 = 1";
                sourceTable.OpenTable("wb_act", sqltext, WBData.conn);
                if (sourceTable.DT.Rows.Count <= 0)
                {
                    FormRegistrationKey key2 = new FormRegistrationKey();
                    key2.ShowDialog();
                    valid = key2.valid;
                }
                else
                {
                    try
                    {
                        DataTable table3 = WBUtility.WBTableToDataTable(sourceTable, null);
                        int num = 0;
                        while (true)
                        {
                            if (num >= table3.Rows.Count)
                            {
                                char[] separator = new char[] { '|' };
                                string[] strArray = WBEncryption.Decrypt(table3.Select(" param = 'key' ")[0][1].ToString(), "R3gK3y4wb").Split(separator);
                                string str3 = strArray[0];
                                string str4 = strArray[1];
                                string str5 = strArray[2];
                                string str6 = strArray[3];
                                string[] textArray1 = new string[] { " param = 'WB|", WBSetting.WBCode, "|", Environment.MachineName, "' " };
                                if (table3.Select(string.Concat(textArray1)).Length == 0)
                                {
                                    DataRow[] rowArray2 = table3.Select(" param LIKE 'WB|%' ");
                                    if (rowArray2.Length < Convert.ToInt32(str5.Substring(2)))
                                    {
                                        FormRegistrationKey key = new FormRegistrationKey();
                                        key.ShowDialog();
                                        valid = key.valid;
                                    }
                                    else
                                    {
                                        string str7 = "";
                                        int index = 0;
                                        while (true)
                                        {
                                            if (index >= rowArray2.Length)
                                            {
                                                string[] textArray5 = new string[13];
                                                textArray5[0] = "Activation key has been used for ";
                                                textArray5[1] = str5.Substring(2);
                                                textArray5[2] = " WB(s) as requested before.";
                                                textArray5[3] = Environment.NewLine;
                                                textArray5[4] = "Current usage: ";
                                                textArray5[5] = Environment.NewLine;
                                                textArray5[6] = str7;
                                                textArray5[7] = Environment.NewLine;
                                                textArray5[8] = Environment.NewLine;
                                                textArray5[9] = "If you use the activation key to wrong PC or you want to change existing WB PC to another PC, please delete one of the key usage from menu Configuration - Activation Key Usage.";
                                                textArray5[10] = Environment.NewLine;
                                                textArray5[11] = Environment.NewLine;
                                                textArray5[12] = "But if you want to register another WB, please contact WCS to renew you activation key.";
                                                MessageBox.Show(string.Concat(textArray5), "ACTIVATION KEY IS FULLY USED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                valid = false;
                                                break;
                                            }
                                            char[] chArray2 = new char[] { '|' };
                                            string[] strArray2 = rowArray2[index][0].ToString().Split(chArray2);
                                            object[] objArray1 = new object[] { str7, index + 1, ". WB code: ", strArray2[1], " (Computer name: ", strArray2[2], ") " };
                                            str7 = string.Concat(objArray1);
                                            if (index < (rowArray2.Length - 1))
                                            {
                                                str7 = str7 + Environment.NewLine;
                                            }
                                            index++;
                                        }
                                    }
                                }
                                else
                                {
                                    this.labelExpired.Visible = true;
                                    DateTime date = DateTime.Now.Date;
                                    WBTable table4 = new WBTable();
                                    table4.OpenTable("wb_transaction", "SELECT TOP 1 uniq, report_date FROM wb_transaction WHERE report_date IS NOT NULL ORDER BY ref DESC", WBData.conn);
                                    if (table4.DT.Rows.Count > 0)
                                    {
                                        date = Convert.ToDateTime(table4.DT.Rows[0]["report_date"].ToString()).Date;
                                    }
                                    table4.Dispose();
                                    string[] textArray2 = new string[] { str6.Substring(0, 2), "-", str6.Substring(2, 2), "-", str6.Substring(4) };
                                    if (date <= Convert.ToDateTime(string.Concat(textArray2)).Date)
                                    {
                                        this.labelExpired.Visible = false;
                                    }
                                    else
                                    {
                                        WBTable table5 = new WBTable();
                                        table5.OpenTable("wb_location", "SELECT uniq, GM from wb_location WHERE GM = 'Y'", WBData.conn);
                                        int num3 = 0;
                                        while (true)
                                        {
                                            if (num3 >= table5.DT.Rows.Count)
                                            {
                                                table5.Dispose();
                                                WBTable table6 = new WBTable();
                                                table6.OpenTable("wb_condition", "SELECT uniq, condition_code FROM wb_condition WHERE condition_code = 'ACTIVATION_KEY_IS_EXPIRED'", WBData.conn);
                                                if (table6.DT.Rows.Count <= 0)
                                                {
                                                    table6.DR = table6.DT.NewRow();
                                                    table6.DR["condition_code"] = "ACTIVATION_KEY_IS_EXPIRED";
                                                    table6.DT.Rows.Add(table6.DR);
                                                    table6.Save();
                                                }
                                                table6.Dispose();
                                                break;
                                            }
                                            table5.DT.Rows[num3].BeginEdit();
                                            table5.DT.Rows[num3]["GM"] = "N";
                                            table5.DT.Rows[num3].EndEdit();
                                            table5.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EXPIRED", WBUser.UserID, "Activation key is expired. Need to renew." };
                                            Program.updateLogHeader("wb_location", table5.DT.Rows[num3]["uniq"].ToString(), logField, logValue);
                                            num3++;
                                        }
                                    }
                                    valid = true;
                                }
                                break;
                            }
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= table3.Columns.Count)
                                {
                                    num++;
                                    break;
                                }
                                if (table3.Columns[num2].ColumnName.ToUpper() != "UNIQ")
                                {
                                    table3.Rows[num][num2] = WBEncryption.Decrypt(table3.Rows[num][num2].ToString(), "encryptDATA");
                                }
                                num2++;
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show("Fail to load key: " + exception.Message + Environment.NewLine + "Please contact WCS for further support!", "FAIL TO LOAD KEY", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        valid = false;
                    }
                }
            }
            return valid;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if ((Convert.ToInt16(WBUser.UserLevel) == 1) && !this.backgroundWorkerEmail.IsBusy)
            {
                this.backgroundWorkerEmail.RunWorkerAsync();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void laporanPeneriamPerSupploerLA1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA1 pffbla = new RepFFBLA1 {
                ffb = true
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void laporanPenerimaanTBSSupplierLA1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void laporanTotalPenerimaanTBSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA2 pffbla = new RepFFBLA2 {
                ffb = true
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void linkLabelSupport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.linkLabelSupport.LinkVisited = true;
            string fileName = "http://10.1.1.130:8081/desksupport/add_bug.aspx?url=/desksupport/bugs.aspx&qs=";
            try
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_ConditionData", "Select condition_code, description from wb_condition where condition_code = 'SUPPORT_PATH'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    fileName = table.DT.Rows[0]["Description"].ToString();
                }
                Process.Start(fileName);
                table.Dispose();
            }
            catch
            {
            }
        }

        private void listOfWeighningToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void listOfWeighningToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RepListWeighing weighing = new RepListWeighing();
            weighing.ShowDialog();
            weighing.Dispose();
        }

        private void loadColumnPositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.SetDisplayOrder();
        }

        private void loadingQtyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X")
                {
                    if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "Y")
                    {
                        string str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim();
                        int num = int.Parse(this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString());
                        int num2 = int.Parse(this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString());
                        if (((str != "2X") || (num <= 0)) ? ((str == "4X") && (num2 > 0)) : true)
                        {
                            if (WBSetting.Field("GM") != "Y")
                            {
                                if (Convert.ToInt16(WBUser.UserLevel) > 2)
                                {
                                    MessageBox.Show(Resource.Mainform_070, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                            else if (!this.Trans.BeforeEdit(this.dataGridView1, "QTY"))
                            {
                                return;
                            }
                        }
                        if ((str == "2X") && ((this.dataGridView1.CurrentRow.Cells["_1st"].Value.ToString().Trim() == "") || (this.dataGridView1.CurrentRow.Cells["_1st"].Value.ToString().Trim() == "0")))
                        {
                            MessageBox.Show(Resource.Mainform_072, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else if (!this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                        {
                            WBTable table = new WBTable();
                            WBTable table2 = new WBTable();
                            WBCondition condition = new WBCondition();
                            WBCondition condition2 = new WBCondition();
                            WBCondition condition3 = new WBCondition();
                            WBCondition condition4 = new WBCondition();
                            table.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dataGridView1.CurrentRow.Cells["Comm_code"].Value.ToString() + "'"), WBData.conn);
                            table2.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                            if (table.DT.Rows.Count <= 0)
                            {
                                MessageBox.Show(Resource.Mainform_026, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                            else
                            {
                                table.DR = table.DT.Rows[0];
                                table2.DR = table2.DT.Rows[0];
                                DataRow[] dgRows = new DataRow[] { table.DR, table2.DR };
                                condition.fillParameter("TRANS_LOADING_QTY", dgRows);
                                DataRow[] rowArray2 = new DataRow[] { table.DR, table2.DR };
                                condition2.fillParameter("LOADING_NO_FLOWMETER", rowArray2);
                                DataRow[] rowArray3 = new DataRow[] { table.DR, table2.DR };
                                condition3.fillParameter("LOADING_WITH_FLOWMETER", rowArray3);
                                DataRow[] rowArray4 = new DataRow[] { table.DR, table2.DR };
                                condition4.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray4);
                                if (!((condition.getResult() || (condition2.getResult() || (condition3.getResult() || condition4.getResult()))) || WBUser.CheckTrustee("MN_LOADING_ENTRY_FOR_MS_ONLY", "A")))
                                {
                                    MessageBox.Show(Resource.Mainform_073, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else if ((((str == "2X") && (num > 0)) || ((str == "4X") && (num2 > 0))) ? ((condition2.getResult() || condition3.getResult()) || condition4.getResult()) : false)
                                {
                                    MessageBox.Show("Please use menu edit record to edit density after weighing!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    this.Trans.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), true);
                                    FormLoadingInfo info = new FormLoadingInfo {
                                        txtRefNo = { Text = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim() },
                                        textRef_Date = { Text = Convert.ToDateTime(this.dataGridView1.CurrentRow.Cells["Ref_date"].Value.ToString().Trim()).ToShortDateString() },
                                        oldComm = this.dataGridView1.CurrentRow.Cells["Comm_code"].Value.ToString().Trim()
                                    };
                                    info.ShowDialog();
                                    info.Dispose();
                                    this.Trans.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), false);
                                    this.DataReset();
                                }
                            }
                            table.Dispose();
                            condition.Dispose();
                            condition4.Dispose();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mainform_069, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mainform_068, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void locationLogReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Location Log Report",
                labelHeader = { Text = "Log of Location" },
                labelMasterData = { Text = "Log for: " },
                flag = "LOCATION"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private bool lock_all_split()
        {
            string str = "";
            this.tbl_temp.OpenTable("wb_transaction", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString() + "%'"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= this.tbl_temp.DT.Rows.Count)
                {
                    bool flag4;
                    this.tbl_rlock.OpenTable("wb_rlock", "Select * from wb_rlock where tableName = 'wb_transaction' and status = 'L' and (" + str + ")", WBData.conn);
                    if (this.tbl_rlock.DT.Rows.Count > 0)
                    {
                        MessageBox.Show(Resource.Mainform_056 + " " + this.tbl_rlock.DT.Rows[0]["ComputerName"].ToString().Trim(), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        flag4 = false;
                    }
                    else
                    {
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= this.tbl_temp.DT.Rows.Count)
                            {
                                flag4 = true;
                                break;
                            }
                            this.tbl_temp.RLock(this.tbl_temp.DT.Rows[num2]["Uniq"].ToString().Trim(), true);
                            num2++;
                        }
                    }
                    return flag4;
                }
                str = str + "Uniq = '" + this.tbl_temp.DT.Rows[num]["Uniq"].ToString().Trim() + "'";
                if (num < (this.tbl_temp.DT.Rows.Count - 1))
                {
                    str = str + " OR ";
                }
                num++;
            }
        }

        private void logOffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mainform_077 + " " + WBUser.UserID + "?", " CONFIRM ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string keyField = "";
                string machineName = Environment.MachineName;
                string str3 = "";
                IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                int index = 0;
                while (true)
                {
                    if (index >= addressList.Length)
                    {
                        if (!WBSetting.loginWithActiveDirectory)
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                keyField = table.DR["uniq"].ToString();
                                table.DR.BeginEdit();
                                table.DR["lastLogout"] = DateTime.Now;
                                table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                                table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                                table.DR["checksum"] = table.Checksum(table.DR);
                                table.DR.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                                Program.updateLogHeader("wb_user", keyField, logField, logValue);
                            }
                            table.Dispose();
                        }
                        base.Hide();
                        WBUser.UserID = "";
                        WBUser.UserPass = "";
                        if (!WBUser.Login())
                        {
                            Application.Exit();
                        }
                        else
                        {
                            base.WindowState = FormWindowState.Minimized;
                            this.Refresh();
                            base.Show();
                            this.fm = new FormMessage();
                            this.fm.label1.Text = "Preparing . . . . . . . ";
                            this.fm.Show();
                            this.fm.Refresh();
                            this.f_load();
                            base.WindowState = FormWindowState.Maximized;
                            this.fm.Dispose();
                        }
                        break;
                    }
                    IPAddress address = addressList[index];
                    AddressFamily addressFamily = address.AddressFamily;
                    if (addressFamily.ToString() == "InterNetwork")
                    {
                        str3 = address.ToString();
                    }
                    index++;
                }
            }
        }

        private void logReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WBData.Close();
        }

        private void MainForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.exitToolStripMenuItem.PerformClick();
            }
        }

        private void MainForm_Leave(object sender, EventArgs e)
        {
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            base.Opacity = 0.0;
            this.f_load();
            base.WindowState = FormWindowState.Maximized;
            base.Opacity = 100.0;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.SetDisplayOrder();
            Cursor.Current = Cursors.Default;
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.fm.Dispose();
            this.translate();
            this.sAPDestinationToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
            this.uploadSAPToolStripMenuItem.Text = "&Upload To " + this.sapIDSYS;
        }

        private void maintainActivationKeyUsageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMaintainActivationKey key = new FormMaintainActivationKey();
            key.ShowDialog();
            key.Dispose();
        }

        private void mapCommTrxTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCommTrx trx = new FormCommTrx();
            trx.ShowDialog();
            trx.Dispose();
        }

        private void mappingTruckDestinationPerCompanyLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSourceMapping mapping = new FormSourceMapping();
            mapping.ShowDialog();
            mapping.Dispose();
        }

        private void markAccidentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMarkAccident accident = new FormMarkAccident();
            accident.ShowDialog();
            accident.Dispose();
        }

        private void masterDataLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Master Data Log Report",
                labelHeader = { Text = "Log of Master Data" },
                radioCode = { Enabled = true }
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void masterDataToolStripMenuItem1_DropDownOpening(object sender, EventArgs e)
        {
            int length = 0;
            try
            {
                foreach (object obj2 in this.masterDataToolStripMenuItem1.DropDownItems)
                {
                    if (obj2.GetType().Equals(typeof(ToolStripMenuItem)))
                    {
                        ToolStripMenuItem item = (ToolStripMenuItem) obj2;
                        string str = (WBSetting.locType != "0") ? "REF" : "POM";
                        length = item.Name.Length;
                        if (length > 2)
                        {
                            item.Visible = item.Name.Substring(length - 3, 3).ToUpper() != str;
                        }
                    }
                }
                this.SPBtoolStripMenuItem.Visible = WBSetting.locType == "1";
            }
            catch
            {
            }
        }

        private void md10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_ESTATE", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormEstate estate = new FormEstate();
                estate.ShowDialog();
                estate.Dispose();
            }
        }

        private void md12ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_CAPACITY", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTanker tanker = new FormTanker();
                tanker.ShowDialog();
                tanker.Dispose();
            }
        }

        private void md13ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_GRADING", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormGrading grading = new FormGrading();
                grading.ShowDialog();
                grading.Dispose();
            }
        }

        private void md1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_CONTRACT", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormContract contract = new FormContract();
                contract.ShowDialog();
                contract.Dispose();
            }
        }

        private void md2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_STOCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormCommodity commodity = new FormCommodity();
                commodity.ShowDialog();
                commodity.Dispose();
            }
        }

        private void md3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_VENDOR", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormVendor vendor = new FormVendor();
                vendor.ShowDialog();
                vendor.Dispose();
            }
        }

        private void md4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_TRUCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTruck truck = new FormTruck();
                truck.ShowDialog();
                truck.Dispose();
            }
        }

        private void md5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DRIVER", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDriver driver = new FormDriver();
                driver.ShowDialog();
                driver.Dispose();
            }
        }

        private void md6rToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_TRANSPORTER", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTransporter transporter = new FormTransporter();
                transporter.ShowDialog();
                transporter.Dispose();
            }
        }

        private void md7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLocation location = new FormLocation();
            location.ShowDialog();
            location.Dispose();
        }

        private void md8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_STORAGE", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormStorage storage = new FormStorage();
                storage.ShowDialog();
                storage.Dispose();
            }
        }

        private void md9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DIVISION", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDivision division = new FormDivision();
                division.ShowDialog();
                division.Dispose();
            }
        }

        private void mergeAutoSplitDOVesselToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormMergeDoVessel vessel = new FormMergeDoVessel();
            vessel.ShowDialog();
            vessel.Dispose();
        }

        private void mergeDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double num = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            string str = "";
            double num5 = 0.0;
            if (this.dataGridView1.Rows.Count > 0)
            {
                string str2 = "";
                str2 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mainform_063, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    str2 = "";
                    if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X")
                    {
                        MessageBox.Show(Resource.Mainform_064, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "N") || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == ""))
                    {
                        MessageBox.Show(Resource.Mainform_065, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "Y") && ((MessageBox.Show(Resource.Mainform_066, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes) && (this.Trans.BeforeEdit(this.dataGridView1, "MERGE") && !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))))
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        WBTable table3 = new WBTable();
                        WBTable table4 = new WBTable();
                        WBTable table5 = new WBTable();
                        string str3 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        string str4 = "";
                        string str5 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                        table3.OpenTable("wb_transDOTemp", "Select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + str3 + "%'"), WBData.conn);
                        table5.OpenTable("wb_transBatchTemp", "Select * from wb_transBatch where " + WBData.CompanyLocation(" and ref like '" + str3 + "%'"), WBData.conn);
                        int count = table5.DT.Rows.Count;
                        string[] strArray = new string[count];
                        int index = 0;
                        while (true)
                        {
                            if (index >= count)
                            {
                                table5.Save();
                                int num8 = 0;
                                while (true)
                                {
                                    if (num8 >= strArray.Length)
                                    {
                                        count = table3.DT.Rows.Count;
                                        table.OpenTable("wb_transSplit", "Select * from wb_transSPlit where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                                        if (table.DT.Rows.Count > 0)
                                        {
                                            table.DR = table.DT.Rows[0];
                                        }
                                        num = 0.0;
                                        num4 = 0.0;
                                        str = "";
                                        num5 = 0.0;
                                        int num9 = 0;
                                        while (true)
                                        {
                                            if (num9 >= count)
                                            {
                                                if ((num > 0.0) && (num4 > 0.0))
                                                {
                                                    num5 = num / num4;
                                                }
                                                string keyField = "";
                                                string[,] strArray2 = new string[count, 2];
                                                int num10 = 0;
                                                while (true)
                                                {
                                                    if (num10 >= count)
                                                    {
                                                        table3.Save();
                                                        int num13 = 0;
                                                        while (true)
                                                        {
                                                            if (num13 >= count)
                                                            {
                                                                table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + str3 + "%'"), WBData.conn);
                                                                count = table2.DT.Rows.Count;
                                                                if (table2.DT.Rows.Count > 0)
                                                                {
                                                                    int num14 = 0;
                                                                    while (true)
                                                                    {
                                                                        if (num14 >= count)
                                                                        {
                                                                            break;
                                                                        }
                                                                        table2.DR = table2.DT.Rows[num14];
                                                                        if (((str3 == table2.DR["REF"].ToString()) || ((str3 + Constant.TITIP_TIMBUN_POSTFIX) == table2.DR["REF"].ToString())) && (table2.DR["split"].ToString() == "Y"))
                                                                        {
                                                                            table2.DR.BeginEdit();
                                                                            table2.DR["Split"] = "N";
                                                                            table2.DR["posted"] = "N";
                                                                            string str9 = "";
                                                                            try
                                                                            {
                                                                                str9 = table.DR["DO_No"].ToString().Trim();
                                                                                if (table2.DR["ZAuto"].ToString() == "Y")
                                                                                {
                                                                                    str9 = "";
                                                                                }
                                                                            }
                                                                            catch
                                                                            {
                                                                                str9 = "";
                                                                            }
                                                                            if (str9 != "")
                                                                            {
                                                                                table2.DR["DO_No"] = str9;
                                                                            }
                                                                            table2.DR["Transaction_Code"] = Program.getFieldValue("wb_contract", "transaction_code", "DO_NO", table2.DR["DO_No"].ToString());
                                                                            table2.DR["Comm_Code"] = Program.getFieldValue("wb_contract", "Comm_Code", "DO_NO", table.DR["DO_No"].ToString());
                                                                            table2.DR["_1ST"] = table.DR["_1ST"].ToString();
                                                                            table2.DR["_2ND"] = table.DR["_2ND"].ToString();
                                                                            table2.DR["_3RD"] = table.DR["_3RD"].ToString();
                                                                            table2.DR["_4TH"] = table.DR["_4TH"].ToString();
                                                                            table2.DR["Gross"] = table.DR["Gross"].ToString();
                                                                            table2.DR["Tare"] = table.DR["Tare"].ToString();
                                                                            table2.DR["Received"] = table.DR["Received"].ToString();
                                                                            table2.DR["Net"] = table.DR["Net"].ToString();
                                                                            if ((num > 0.0) && (num4 > 0.0))
                                                                            {
                                                                                table2.DR["UnitName"] = str;
                                                                                table2.DR["TotalBunch"] = num4;
                                                                                table2.DR["TotalBunchGrading"] = num4;
                                                                            }
                                                                            else
                                                                            {
                                                                                table2.DR["TotalBunch"] = table.DR["TotalBunch"].ToString();
                                                                                table2.DR["TotalBunchGrading"] = table.DR["TotalBunchGrading"].ToString();
                                                                                table2.DR["TBS_Reject"] = string.IsNullOrEmpty(table.DR["TBS_Reject"].ToString()) ? 0.0 : Convert.ToDouble(table.DR["TBS_Reject"].ToString());
                                                                            }
                                                                            table2.DR["Deduction"] = num + (Program.StrToDouble(table2.DR["Deduction"].ToString(), 0) - num3);
                                                                            num5 = ((num4 <= 0.0) || (num <= 0.0)) ? 0.0 : Program.StrToDouble((num / num4).ToString(), 2);
                                                                            table2.DR["WeightPerUnitName"] = num5;
                                                                            table2.DR["Gross_Estate"] = table.DR["Gross_Estate"].ToString();
                                                                            table2.DR["Tare_Estate"] = table.DR["Tare_Estate"].ToString();
                                                                            table2.DR["Net_Estate"] = table.DR["Net_Estate"].ToString();
                                                                            table2.DR["checksum"] = table2.Checksum_Main(table2.DR);
                                                                            table2.DR.EndEdit();
                                                                            table2.Save();
                                                                            string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                            string[] textArray12 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                            Program.updateLogHeader("wb_transaction", table2.DR["uniq"].ToString(), textArray11, textArray12);
                                                                        }
                                                                        num14++;
                                                                    }
                                                                }
                                                                table.Close();
                                                                table2.Close();
                                                                if (num5 > 0.0)
                                                                {
                                                                    table3.OpenTable("wb_transDOTemp", "Select * from wb_transDO where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                                                                    if (table3.DT.Rows.Count > 0)
                                                                    {
                                                                        table3.DR = table3.DT.Rows[0];
                                                                        table3.DR.BeginEdit();
                                                                        table3.DR["WeightPerUnitName"] = Program.StrToDouble(num5.ToString(), 2);
                                                                        table3.DR["DeducUnitQty"] = num4;
                                                                        table3.DR["TotalDeducUnit"] = num;
                                                                        table3.DR["deduction"] = num;
                                                                        table3.DR.EndEdit();
                                                                        table3.Save();
                                                                        string[] textArray13 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                        string[] textArray14 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                        Program.updateLogHeader("wb_transDO", table3.DR["uniq"].ToString(), textArray13, textArray14);
                                                                    }
                                                                }
                                                                this.Trans.ReOpen();
                                                                this.dataGridView1 = this.Trans.AfterEdit(this.pMode);
                                                                this.dataGridView1.Sort(this.dataGridView1.Columns["Ref"], ListSortDirection.Ascending);
                                                                string[] aField = new string[] { "Ref" };
                                                                string[] aFind = new string[] { str3 };
                                                                this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                                                                table.Dispose();
                                                                table4.Dispose();
                                                                table3.Dispose();
                                                                table5.Dispose();
                                                                table2.Dispose();
                                                                MessageBox.Show(Resource.Mainform_067, "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                this.Trans.UnLock();
                                                                break;
                                                            }
                                                            if (strArray2[num13, 1] == "del")
                                                            {
                                                                string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                string[] textArray8 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                Program.updateLogHeader("wb_transDO", strArray2[num13, 0], textArray7, textArray8);
                                                            }
                                                            else if (strArray2[num13, 1] == "edit")
                                                            {
                                                                string[] textArray9 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                string[] textArray10 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                Program.updateLogHeader("wb_transDO", strArray2[num13, 0], textArray9, textArray10);
                                                            }
                                                            num13++;
                                                        }
                                                        break;
                                                    }
                                                    table3.DR = table3.DT.Rows[num10];
                                                    str4 = table3.DR["ref"].ToString().Trim();
                                                    if ((str4 != str3) && (str4 != (str3 + Constant.TITIP_TIMBUN_POSTFIX)))
                                                    {
                                                        table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str4 + "'"), WBData.conn);
                                                        if (table2.DT.Rows.Count > 0)
                                                        {
                                                            table2.DR = table2.DT.Rows[0];
                                                            if (table2.DR["split"].ToString() == "X")
                                                            {
                                                                strArray2[num10, 0] = table3.DR["uniq"].ToString();
                                                                strArray2[num10, 1] = "del";
                                                                table3.DR.Delete();
                                                                keyField = table2.DR["uniq"].ToString();
                                                                table2.DR.Delete();
                                                                table4.OpenTable("wb_transQCtemp", "Select * from wb_transQC where " + WBData.CompanyLocation(" and ref = '" + str4 + "'"), WBData.conn);
                                                                string[] strArray3 = new string[table4.DT.Rows.Count];
                                                                int num11 = 0;
                                                                while (true)
                                                                {
                                                                    if (num11 >= table4.DT.Rows.Count)
                                                                    {
                                                                        table4.Save();
                                                                        int num12 = 0;
                                                                        while (true)
                                                                        {
                                                                            if (num12 >= strArray3.Length)
                                                                            {
                                                                                table4.Close();
                                                                                table2.Save();
                                                                                string[] textArray5 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                                string[] textArray6 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                                Program.updateLogHeader("wb_transaction", keyField, textArray5, textArray6);
                                                                                table2.Close();
                                                                                break;
                                                                            }
                                                                            string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                            string[] textArray4 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                            Program.updateLogHeader("wb_transQC", strArray3[num12], textArray3, textArray4);
                                                                            num12++;
                                                                        }
                                                                        break;
                                                                    }
                                                                    strArray3[num11] = table4.DT.Rows[num11]["uniq"].ToString();
                                                                    table4.DT.Rows[num11].Delete();
                                                                    num11++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else if ((str4 == str3) || (str4 == (str3 + Constant.TITIP_TIMBUN_POSTFIX)))
                                                    {
                                                        table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str4 + "'"), WBData.conn);
                                                        if (table2.DT.Rows.Count > 0)
                                                        {
                                                            table2.DR = table2.DT.Rows[0];
                                                            if (table2.DR["split"].ToString() == "Y")
                                                            {
                                                                strArray2[num10, 0] = table3.DR["uniq"].ToString();
                                                                strArray2[num10, 1] = "edit";
                                                                table3.DR.BeginEdit();
                                                                string str7 = "";
                                                                try
                                                                {
                                                                    str7 = table.DR["DO_No"].ToString().Trim();
                                                                    if (table2.DR["ZAuto"].ToString() == "Y")
                                                                    {
                                                                        str7 = "";
                                                                    }
                                                                }
                                                                catch
                                                                {
                                                                    str7 = "";
                                                                }
                                                                if (str7 != "")
                                                                {
                                                                    table3.DR["DO_No"] = str7;
                                                                }
                                                                WBTable table6 = new WBTable();
                                                                string sqltext = "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND DO_NO = '" + table3.DR["DO_No"].ToString() + "'");
                                                                table6.OpenTable("wb_contract", sqltext, WBData.conn);
                                                                table6.DR = table6.DT.Rows[0];
                                                                table3.DR["Transaction_Code"] = table6.DR["Transaction_Code"].ToString().Trim();
                                                                table3.DR["Comm_Code"] = table6.DR["Comm_Code"].ToString().Trim();
                                                                table3.DR["Relation_Code"] = table6.DR["Relation_Code"].ToString().Trim();
                                                                table3.DR["Estate"] = table6.DR["Estate1_Code"].ToString().Trim();
                                                                table3.DR["Transporter_Code"] = table6.DR["Transporter_Code"].ToString().Trim();
                                                                table3.DR["Relation_Name"] = Program.getFieldValue("wb_relation", "relation_name", "relation_code", table6.DR["Relation_Code"].ToString().Trim());
                                                                table3.DR["Bruto"] = table.DR["Gross"].ToString();
                                                                table3.DR["Tarra"] = table.DR["Tare"].ToString();
                                                                table3.DR["Netto"] = table.DR["Net"].ToString();
                                                                table3.DR["Estate_qty"] = table.DR["Net_Estate"].ToString();
                                                                table3.DR["WeightPerUnitName"] = Program.StrToDouble(num5.ToString(), 2);
                                                                table3.DR["DeducUnitQty"] = num4;
                                                                table3.DR["TotalDeducUnit"] = Math.Round((double) (Program.StrToDouble(num5.ToString(), 2) * num4), 0);
                                                                if ((num > 0.0) && (num4 > 0.0))
                                                                {
                                                                    table2.DR["UnitName"] = str;
                                                                    table2.DR["TotalBunch"] = num4;
                                                                    table2.DR["TotalBunchGrading"] = num4;
                                                                }
                                                                else
                                                                {
                                                                    table2.DR["TotalBunch"] = table.DR["TotalBunch"].ToString();
                                                                    table2.DR["TotalBunchGrading"] = table.DR["TotalBunchGrading"].ToString();
                                                                    table2.DR["TBS_Reject"] = string.IsNullOrEmpty(table.DR["TBS_Reject"].ToString()) ? 0.0 : Convert.ToDouble(table.DR["TBS_Reject"].ToString());
                                                                }
                                                                table3.DR.EndEdit();
                                                            }
                                                        }
                                                        table2.Close();
                                                    }
                                                    num10++;
                                                }
                                                break;
                                            }
                                            table3.DR = table3.DT.Rows[num9];
                                            str4 = table3.DR["ref"].ToString().Trim();
                                            if (str4.Substring(str4.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                                            {
                                                table3.DR["TotalDeducUnit"] = (table3.DR["TotalDeducUnit"] == null) ? 0 : table3.DR["TotalDeducUnit"];
                                                table3.DR["DeducUnitQty"] = (table3.DR["DeducUnitQty"] == null) ? 0 : table3.DR["DeducUnitQty"];
                                                num += Program.StrToDouble(table3.DR["TotalDeducUnit"].ToString(), 0);
                                                num4 += Program.StrToDouble(table3.DR["DeducUnitQty"].ToString(), 0);
                                                if (str4 == str3)
                                                {
                                                    num3 = Program.StrToDouble(table3.DR["TotalDeducUnit"].ToString(), 0);
                                                    str = table3.DR["UnitName"].ToString();
                                                }
                                            }
                                            num9++;
                                        }
                                        break;
                                    }
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                    Program.updateLogHeader("wb_transBatch", strArray[num8], logField, logValue);
                                    num8++;
                                }
                                break;
                            }
                            strArray[index] = table5.DT.Rows[index]["uniq"].ToString();
                            table5.DT.Rows[index].Delete();
                            index++;
                        }
                    }
                }
            }
        }

        private void migrateOldLogToNewLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table;
            WBTable table2;
            WBTable table3;
            WBTable table4;
            WBTable table5;
            string str;
            if (MessageBox.Show(Resource.Mainform_086, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
            {
                return;
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                table = new WBTable();
                table2 = new WBTable();
                table3 = new WBTable();
                table4 = new WBTable();
                table5 = new WBTable();
                table3.OpenTable("wb_log_header", "SELECT * FROM wb_log_header WHERE " + WBData.CompanyLocation(""), WBData.conn);
                table4.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE " + WBData.CompanyLocation(""), WBData.conn);
                str = "";
                str = ("SELECT distinct(ref) FROM wb_trans_log WHERE " + WBData.CompanyLocation("") + " AND ((WX='2X' AND _2nd>0) or (WX='4X' AND _4th>0)) ") + " AND (EDIT_BY is not null AND EDIT_BY <> '') " + " Order by ref asc";
                table2.OpenTable("wb_trans_log", str, WBData.conn);
                foreach (DataRow row in table2.DT.Rows)
                {
                    str = ((("SELECT * FROM wb_trans_log WHERE " + WBData.CompanyLocation("")) + " AND ((WX='2X' AND _2nd>0) or (WX='4X' AND _4th>0)) " + " AND (EDIT_BY is not null AND EDIT_BY <> '') ") + " AND Ref = '" + row["ref"].ToString() + "'") + " Order by ref,uniq asc";
                    table5.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + row["ref"].ToString() + "'"), WBData.conn);
                    table.OpenTable("wb_trans_log", str, WBData.conn);
                    if (table5.DT.Rows.Count > 0)
                    {
                        int num = 1;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            bool flag3 = false;
                            string str2 = "";
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= table.DT.Columns.Count)
                                {
                                    break;
                                }
                                string str3 = table.DT.Columns[num2].ColumnName.ToString();
                                bool flag4 = table.DT.Rows[num]["log_time"].ToString() == table.DT.Rows[num - 1]["log_time"].ToString();
                                if (flag4 && ((table.DT.Columns[num2].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num][num2].ToString() != table.DT.Rows[num - 1][num2].ToString())))
                                {
                                    flag3 = true;
                                    if (str3 == "edit_data")
                                    {
                                        str2 = "EDIT";
                                    }
                                    else if (str3 == "edit_qty")
                                    {
                                        str2 = "QTY";
                                    }
                                    if (flag3 && (str2 != ""))
                                    {
                                        break;
                                    }
                                }
                                num2++;
                            }
                            if (flag3)
                            {
                                string[] textArray1 = new string[9];
                                textArray1[0] = "Coy";
                                textArray1[1] = "Location_Code";
                                textArray1[2] = "logDate";
                                textArray1[3] = "pMode";
                                textArray1[4] = "userID";
                                textArray1[5] = "changeReason";
                                textArray1[6] = "Type";
                                textArray1[7] = "TableName";
                                textArray1[8] = "keyField";
                                string[] aField = textArray1;
                                string[] textArray2 = new string[9];
                                textArray2[0] = WBData.sCoyCode;
                                textArray2[1] = WBData.sLocCode;
                                textArray2[2] = table.DT.Rows[num]["log_time"].ToString();
                                textArray2[3] = str2;
                                textArray2[4] = table.DT.Rows[num]["Edit_By"].ToString();
                                textArray2[5] = table.DT.Rows[num]["changeReason"].ToString();
                                textArray2[6] = "U";
                                textArray2[7] = "wb_transaction";
                                textArray2[8] = table5.DT.Rows[0]["uniq"].ToString();
                                string[] aFind = textArray2;
                                if (((table3.GetData(aField, aFind) == null) && (str2 != "")) && (table.DT.Rows[num]["log_time"].ToString() != ""))
                                {
                                    table3.DR = table3.DT.NewRow();
                                    table3.DR["Coy"] = WBData.sCoyCode;
                                    table3.DR["Location_Code"] = WBData.sLocCode;
                                    table3.DR["logDate"] = table.DT.Rows[num]["log_time"].ToString();
                                    table3.DR["pMode"] = str2;
                                    table3.DR["userID"] = table.DT.Rows[num]["Edit_By"].ToString();
                                    table3.DR["changeReason"] = table.DT.Rows[num]["changeReason"].ToString();
                                    table3.DR["Type"] = "U";
                                    table3.DR["TableName"] = "wb_transaction";
                                    table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                    table3.DT.Rows.Add(table3.DR);
                                    table3.Save();
                                    string str4 = "";
                                    table3.ReOpen();
                                    DataRow data = table3.GetData(aField, aFind);
                                    if (data != null)
                                    {
                                        str4 = data["uniq"].ToString();
                                    }
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= table.DT.Columns.Count)
                                        {
                                            break;
                                        }
                                        string str5 = table.DT.Columns[num3].ColumnName.ToString();
                                        bool flag14 = table.DT.Rows[num]["log_time"].ToString() == table.DT.Rows[num - 1]["log_time"].ToString();
                                        if (flag14 && ((table.DT.Columns[num3].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num][num3].ToString() != table.DT.Rows[num - 1][num3].ToString())))
                                        {
                                            table4.DR = table4.DT.NewRow();
                                            table4.DR["Coy"] = WBData.sCoyCode;
                                            table4.DR["Location_Code"] = WBData.sLocCode;
                                            table4.DR["TableName"] = "wb_transaction";
                                            table4.DR["FieldName"] = str5;
                                            table4.DR["OldValue"] = table.DT.Rows[num - 1][num3].ToString();
                                            table4.DR["NewValue"] = table.DT.Rows[num][num3].ToString();
                                            table4.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                            table4.DR["keyHeader"] = str4;
                                            table4.DT.Rows.Add(table4.DR);
                                            table4.Save();
                                        }
                                        num3++;
                                    }
                                }
                            }
                            num++;
                        }
                    }
                }
                table5.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND deleted = 'Y'"), WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    foreach (DataRow row4 in table5.DT.Rows)
                    {
                        string[] textArray3 = new string[9];
                        textArray3[0] = "Coy";
                        textArray3[1] = "Location_Code";
                        textArray3[2] = "logDate";
                        textArray3[3] = "pMode";
                        textArray3[4] = "userID";
                        textArray3[5] = "changeReason";
                        textArray3[6] = "Type";
                        textArray3[7] = "TableName";
                        textArray3[8] = "keyField";
                        string[] aField = textArray3;
                        string[] textArray4 = new string[9];
                        textArray4[0] = WBData.sCoyCode;
                        textArray4[1] = WBData.sLocCode;
                        textArray4[2] = row4["delete_date"].ToString();
                        textArray4[3] = "CANCEL";
                        textArray4[4] = row4["delete_by"].ToString();
                        textArray4[5] = row4["changeReason"].ToString();
                        textArray4[6] = "U";
                        textArray4[7] = "wb_transaction";
                        textArray4[8] = row4["uniq"].ToString();
                        string[] aFind = textArray4;
                        DataRow data = table3.GetData(aField, aFind);
                        if ((data == null) && (row4["delete_date"].ToString() != ""))
                        {
                            table3.DR = table3.DT.NewRow();
                            table3.DR["Coy"] = WBData.sCoyCode;
                            table3.DR["Location_Code"] = WBData.sLocCode;
                            table3.DR["logDate"] = row4["delete_date"].ToString();
                            table3.DR["pMode"] = "CANCEL";
                            table3.DR["userID"] = row4["delete_by"].ToString();
                            table3.DR["changeReason"] = row4["changeReason"].ToString();
                            table3.DR["Type"] = "U";
                            table3.DR["TableName"] = "wb_transaction";
                            table3.DR["keyField"] = row4["uniq"].ToString();
                            table3.DT.Rows.Add(table3.DR);
                            table3.Save();
                        }
                    }
                }
            }
            str = ((" SELECT printed, printed_by, printed_date, edit_by, changeReason, * FROM wb_trans_log " + " WHERE " + WBData.CompanyLocation("")) + " AND printed > 1 " + " AND ((WX = '2X' AND _2nd > 0) or (WX = '4X' AND _4th > 0))") + " AND (printed_by IS NOT NULL AND printed_date IS NOT NULL)" + " AND (edit_by = '' OR edit_by IS NULL)";
            table.OpenTable("wb_trans_log", str, WBData.conn);
            foreach (DataRow row6 in table.DT.Rows)
            {
                table5.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + row6["ref"].ToString() + "'"), WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    string[] aField = new string[9];
                    aField[0] = "Coy";
                    aField[1] = "Location_Code";
                    aField[2] = "logDate";
                    aField[3] = "pMode";
                    aField[4] = "userID";
                    aField[5] = "changeReason";
                    aField[6] = "Type";
                    aField[7] = "TableName";
                    aField[8] = "keyField";
                    string[] aFind = new string[9];
                    aFind[0] = WBData.sCoyCode;
                    aFind[1] = WBData.sLocCode;
                    aFind[2] = row6["printed_date"].ToString();
                    aFind[3] = "REPRINT";
                    aFind[4] = row6["printed_by"].ToString();
                    aFind[5] = row6["changeReason"].ToString();
                    aFind[6] = "U";
                    aFind[7] = "wb_transaction";
                    aFind[8] = table5.DT.Rows[0]["uniq"].ToString();
                    if ((table3.GetData(aField, aFind) == null) && (row6["printed_date"].ToString() != ""))
                    {
                        table3.DR = table3.DT.NewRow();
                        table3.DR["Coy"] = WBData.sCoyCode;
                        table3.DR["Location_Code"] = WBData.sLocCode;
                        table3.DR["logDate"] = row6["printed_date"].ToString();
                        table3.DR["pMode"] = "REPRINT";
                        table3.DR["userID"] = row6["printed_by"].ToString();
                        table3.DR["changeReason"] = row6["changeReason"].ToString();
                        table3.DR["Type"] = "U";
                        table3.DR["TableName"] = "wb_transaction";
                        table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                        table3.DT.Rows.Add(table3.DR);
                        table3.Save();
                    }
                }
            }
            str = ("SELECT distinct(do_no) FROM wb_contract_log WHERE " + WBData.CompanyLocation("")) + " AND (Change_By is not null AND Change_By <> '') " + " Order by do_no asc";
            table2.OpenTable("wb_contract_log", str, WBData.conn);
            foreach (DataRow row8 in table2.DT.Rows)
            {
                str = (("SELECT * FROM wb_contract_log WHERE " + WBData.CompanyLocation("") + " AND (Change_By is not null AND Change_By <> '') ") + " AND do_no = '" + row8["do_no"].ToString() + "'") + " Order by do_no, uniq asc";
                table5.OpenTable("wb_contract", "SELECT uniq FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + row8["do_no"].ToString() + "'"), WBData.conn);
                table.OpenTable("wb_contract_log", str, WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    int num4 = 1;
                    while (true)
                    {
                        if (num4 >= table.DT.Rows.Count)
                        {
                            break;
                        }
                        bool flag24 = false;
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 < table.DT.Columns.Count)
                            {
                                string str6 = table.DT.Columns[num5].ColumnName.ToString();
                                bool flag25 = table.DT.Rows[num4]["log_time"].ToString() == table.DT.Rows[num4 - 1]["log_time"].ToString();
                                if (!flag25 || ((table.DT.Columns[num5].ColumnName.ToString().ToUpper() == "UNIQ") || (table.DT.Rows[num4][num5].ToString() == table.DT.Rows[num4 - 1][num5].ToString())))
                                {
                                    num5++;
                                    continue;
                                }
                                flag24 = true;
                            }
                            if (flag24)
                            {
                                string[] textArray7 = new string[9];
                                textArray7[0] = "Coy";
                                textArray7[1] = "Location_Code";
                                textArray7[2] = "logDate";
                                textArray7[3] = "pMode";
                                textArray7[4] = "userID";
                                textArray7[5] = "changeReason";
                                textArray7[6] = "Type";
                                textArray7[7] = "TableName";
                                textArray7[8] = "keyField";
                                string[] aField = textArray7;
                                string[] textArray8 = new string[9];
                                textArray8[0] = WBData.sCoyCode;
                                textArray8[1] = WBData.sLocCode;
                                textArray8[2] = table.DT.Rows[num4]["log_time"].ToString();
                                textArray8[3] = "EDIT";
                                textArray8[4] = table.DT.Rows[num4]["Change_By"].ToString();
                                textArray8[5] = "-";
                                textArray8[6] = "U";
                                textArray8[7] = "wb_contract";
                                textArray8[8] = table5.DT.Rows[0]["uniq"].ToString();
                                string[] aFind = textArray8;
                                if (((table3.GetData(aField, aFind) == null) && (this.pMode != "")) && (table.DT.Rows[num4]["log_time"].ToString() != ""))
                                {
                                    table3.DR = table3.DT.NewRow();
                                    table3.DR["Coy"] = WBData.sCoyCode;
                                    table3.DR["Location_Code"] = WBData.sLocCode;
                                    table3.DR["logDate"] = table.DT.Rows[num4]["log_time"].ToString();
                                    table3.DR["pMode"] = "EDIT";
                                    table3.DR["userID"] = table.DT.Rows[num4]["Change_By"].ToString();
                                    table3.DR["changeReason"] = "-";
                                    table3.DR["Type"] = "U";
                                    table3.DR["TableName"] = "wb_contract";
                                    table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                    table3.DT.Rows.Add(table3.DR);
                                    table3.Save();
                                    string str7 = "";
                                    table3.ReOpen();
                                    DataRow data = table3.GetData(aField, aFind);
                                    if (data != null)
                                    {
                                        str7 = data["uniq"].ToString();
                                    }
                                    int num6 = 0;
                                    while (true)
                                    {
                                        if (num6 >= table.DT.Columns.Count)
                                        {
                                            break;
                                        }
                                        string str8 = table.DT.Columns[num6].ColumnName.ToString();
                                        bool flag32 = table.DT.Rows[num4]["log_time"].ToString() == table.DT.Rows[num4 - 1]["log_time"].ToString();
                                        if (flag32 && ((table.DT.Columns[num6].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num4][num6].ToString() != table.DT.Rows[num4 - 1][num6].ToString())))
                                        {
                                            table4.DR = table4.DT.NewRow();
                                            table4.DR["Coy"] = WBData.sCoyCode;
                                            table4.DR["Location_Code"] = WBData.sLocCode;
                                            table4.DR["TableName"] = "wb_contract";
                                            table4.DR["FieldName"] = str8;
                                            table4.DR["OldValue"] = table.DT.Rows[num4 - 1][num6].ToString();
                                            table4.DR["NewValue"] = table.DT.Rows[num4][num6].ToString();
                                            table4.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                            table4.DR["keyHeader"] = str7;
                                            table4.DT.Rows.Add(table4.DR);
                                            table4.Save();
                                        }
                                        num6++;
                                    }
                                }
                            }
                            num4++;
                            break;
                        }
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            table4.Dispose();
            table5.Dispose();
            Cursor.Current = Cursors.Default;
            MessageBox.Show(Resource.Mainform_087, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void multiLineSOOutstandingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepOutstandingMultiLine line = new RepOutstandingMultiLine();
            line.ShowDialog();
            line.Dispose();
        }

        private void ndWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || ((this.dataGridView1.RowCount != 0) && ((this.dataGridView1.RowCount <= 0) || (this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString() == "")))) && this.checkWeightValid("2ND"))
            {
                if (!WBSetting.wb_filling_location || (this.dataGridView1.CurrentRow.Cells["Wbcode1"].Value.ToString().ToUpper() == WBData.sWBCode.ToUpper()))
                {
                    this.check_final_weigh("2ND");
                }
                else
                {
                    string[] textArray1 = new string[0x10];
                    textArray1[0] = Resource.Mainform_019;
                    textArray1[1] = " ";
                    textArray1[2] = this.dataGridView1.CurrentRow.Cells["truck_number"].Value.ToString();
                    textArray1[3] = " ";
                    textArray1[4] = Resource.Mainform_020;
                    textArray1[5] = " ";
                    textArray1[6] = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    textArray1[7] = " ";
                    textArray1[8] = Resource.Mainform_023;
                    textArray1[9] = " ";
                    textArray1[10] = this.dataGridView1.CurrentRow.Cells["WBCode1"].Value.ToString();
                    textArray1[11] = ".\n\n ";
                    textArray1[12] = Resource.Mainform_024;
                    textArray1[13] = " ";
                    textArray1[14] = WBData.sWBCode;
                    textArray1[15] = "!";
                    MessageBox.Show(string.Concat(textArray1), Resource.Mainform_022, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void nonContractTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepNonContract contract = new RepNonContract();
            contract.ShowDialog();
            contract.Dispose();
        }

        private void nonToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (((e.CloseReason == CloseReason.UserClosing) || (e.CloseReason == CloseReason.WindowsShutDown)) || (e.CloseReason == CloseReason.TaskManagerClosing))
            {
                if (MessageBox.Show(Resource.Mainform_018, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    e.Cancel = true;
                }
                else
                {
                    string keyField = "";
                    string machineName = Environment.MachineName;
                    string str3 = "";
                    IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                    int index = 0;
                    while (true)
                    {
                        if (index >= addressList.Length)
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                keyField = table.DR["uniq"].ToString();
                                table.DR.BeginEdit();
                                table.DR["lastLogout"] = DateTime.Now;
                                table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                                table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                                table.DR["checksum"] = table.Checksum(table.DR);
                                table.DR.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                                Program.updateLogHeader("wb_user", keyField, logField, logValue);
                            }
                            table.Dispose();
                            if (Program.TMCready)
                            {
                                base.Close();
                            }
                            else
                            {
                                Application.Exit();
                            }
                            break;
                        }
                        IPAddress address = addressList[index];
                        AddressFamily addressFamily = address.AddressFamily;
                        if (addressFamily.ToString() == "InterNetwork")
                        {
                            str3 = address.ToString();
                        }
                        index++;
                    }
                }
            }
        }

        private void outstandingPOPerVendorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepOsDoVendor vendor = new RepOsDoVendor();
            vendor.ShowDialog();
            vendor.Dispose();
        }

        private void print(string refno, ReportDocument cryRpt)
        {
            string[] paramName = new string[4];
            string[] paramValue = new string[] { refno, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticket2Rpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            this.fRpt.ShowDialog();
        }

        private void print(string refno, string Do_No, ReportDocument cryRpt, bool cek)
        {
            string[] paramName = new string[4];
            string[] paramValue = new string[] { refno, Do_No, WBUser.UserName, Program.getSplitGross(refno) };
            paramName[0] = "ref";
            paramName[1] = "Do_No";
            paramName[2] = "user";
            paramName[3] = "Total_Split_DO";
            WBUtility.ReloadTicket(cryRpt);
            cryRpt = Program.setParam2(cryRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBSetting.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
                this.updatePrinted(cek);
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    if (!cryRpt.FileName.Contains("LoadingAdvise"))
                    {
                        this.updatePrinted(cek);
                    }
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void printBASerahTerimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                try
                {
                    WBTable table = new WBTable();
                    DataTable table2 = new DataTable();
                    string sqltext = "";
                    FormRpt rpt = new FormRpt();
                    ReportDocument cryRpt = new ReportDocument();
                    DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                    sqltext = "Select \r\n\r\n                    CASE \r\n\t                    WHEN a.Do_No is null or a.Do_No = '' THEN '-'\r\n\t                    ELSE a.Do_No\r\n                    End as Do_No,\r\n\r\n                    CASE \r\n\t                    WHEN a.PO is null or a.PO = '' THEN '-'\r\n\t                    ELSE a.PO\r\n                    End as PO,\r\n\r\n                    CASE \r\n\t                    WHEN a.SO is null or a.SO = '' THEN '-'\r\n\t                    ELSE a.SO\r\n                    End as SO,\r\n\r\n                    CASE \r\n\t                    WHEN com.Coy_Name is null or com.Coy_Name = '' THEN '-'\r\n\t                    ELSE com.Coy_Name\r\n                    End as Coy_Name,\r\n\r\n                    CASE \r\n\t                    WHEN b.Coy_Addr1 is null or b.Coy_Addr1 = '' THEN '-'\r\n\t                    ELSE b.Coy_Addr1\r\n                    End as Coy_Addr1,\r\n\r\n                    CASE \r\n\t                    WHEN b.Coy_Addr2 is null or b.Coy_Addr2 = '' THEN '-'\r\n\t                    ELSE b.Coy_Addr2\r\n                    End as Coy_Addr2,\r\n\r\n                    CASE \r\n\t                    WHEN b.Coy_Addr3 is null or b.Coy_Addr3 = '' THEN '-'\r\n\t                    ELSE b.Coy_Addr3\r\n                    End as Coy_Addr3,\r\n\r\n                    CASE \r\n\t                    WHEN r.Relation_Name is null or r.Relation_Name = '' THEN '-'\r\n\t                    ELSE r.Relation_Name\r\n                    End as Relation_Name,\r\n\r\n                    CASE \r\n\t                    WHEN r.Address is null or r.Address = '' THEN '-'\r\n\t                    ELSE r.Address\r\n                    End as Address,\r\n\r\n                    CASE \r\n\t                    WHEN c.Comm_Name is null or c.Comm_Name = '' THEN '-'\r\n\t                    ELSE c.Comm_Name\r\n                    End as Comm_Name,\r\n\r\n                    CASE \r\n\t                    WHEN c.Unit is null or c.Unit = '' THEN '-'\r\n\t                    ELSE c.Unit\r\n                    End as Unit,\r\n\r\n                    CASE \r\n\t                    WHEN tr.Truck_Number is null or tr.Truck_Number = '' THEN '-'\r\n\t                    ELSE tr.Truck_Number\r\n                    End as Truck_Number,\r\n\r\n                    CASE \r\n\t                    WHEN tr_DO.Netto is null THEN 0\r\n\t                    ELSE tr_DO.Netto\r\n                    End as Net,\r\n\r\n                    CASE \r\n\t                    WHEN tr.Net_Estate is null THEN 0\r\n\t                    ELSE tr.Net_Estate\r\n                    End as Net_Estate,\r\n\r\n                    tr.Report_Date, tr.Delivery_Date,\r\n\r\n                    CASE \r\n\t                    WHEN tr_DO.LOADING_QTY is null THEN 0\r\n\t                    ELSE tr_DO.LOADING_QTY\r\n                    End as LOADING_QTY,\r\n\r\n                    CASE \r\n\t                    WHEN tr_DO.LOADING_QTY_OPW is null THEN 0\r\n\t                    ELSE tr_DO.LOADING_QTY_OPW\r\n                    End as LOADING_QTY_OPW,\r\n\r\n                    CASE \r\n\t                    WHEN tr_Transporter.Transporter_Name is null THEN '-'\r\n\t                    ELSE tr_Transporter.Transporter_Name\r\n                    End as Transporter_Name\r\n \r\n                    from wb_contract a\r\n\r\n                    left join wb_location as b \r\n                    On a.Coy = b.Coy and a.Location_Code = b.Location_Code \r\n\r\n                    left join wb_company as com\r\n                    On a.Coy = com.Coy_Code\r\n\r\n                    left join wb_relation r\r\n                    On a.Coy = r.Coy and a.Location_Code = r.Location_Code and a.Relation_Code = r.Relation_Code\r\n\r\n                    left join wb_commodity c \r\n                    On a.Coy = c.Coy and a.Location_Code = c.Location_Code and a.Comm_Code = c.Comm_Code\r\n\r\n                    left join wb_transaction tr\r\n                    ON a.Coy = tr.Coy and a.Location_Code = tr.Location_Code and \r\n                    a.Do_No = tr.Do_No\r\n\r\n                    left join wb_transDO tr_DO\r\n                    ON tr.Coy = tr_DO.Coy and tr.Location_Code = tr_DO.Location_Code and tr.Ref = tr_DO.Ref\r\n\r\n                    left join wb_transporter tr_Transporter\r\n                    ON a.Coy = tr_Transporter.Coy and a.Location_Code = tr_Transporter.Location_Code and a.Transporter_Code = tr_Transporter.Transporter_Code";
                    string[] textArray1 = new string[10];
                    textArray1[0] = sqltext;
                    textArray1[1] = " where a.Coy = '";
                    textArray1[2] = WBData.sCoyCode;
                    textArray1[3] = "' and a.Location_Code = '";
                    textArray1[4] = WBData.sLocCode;
                    textArray1[5] = "' and a.do_no = '";
                    textArray1[6] = this.dataGridView1.CurrentRow.Cells["DO_NO"].Value.ToString();
                    textArray1[7] = "' and tr_DO.Ref LIKE '";
                    textArray1[8] = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                    textArray1[9] = "%'";
                    sqltext = string.Concat(textArray1);
                    table.OpenTable("TBL", sqltext, WBData.conn);
                    if (table.DT.Rows.Count == 0)
                    {
                        throw new Exception("No data available!");
                    }
                    DataTable table3 = barang.Tables["wb_contract"];
                    DataRow row = table3.NewRow();
                    row["Do_No"] = table.DT.Rows[0]["Do_No"].ToString();
                    row["PO"] = table.DT.Rows[0]["PO"].ToString();
                    row["SO"] = table.DT.Rows[0]["SO"].ToString();
                    table3.Rows.Add(row);
                    DataTable table4 = barang.Tables["wb_location"];
                    DataRow row2 = table4.NewRow();
                    row2["Coy_Addr1"] = table.DT.Rows[0]["Coy_Addr1"].ToString();
                    row2["Coy_Addr2"] = table.DT.Rows[0]["Coy_Addr2"].ToString();
                    row2["Coy_Addr3"] = table.DT.Rows[0]["Coy_Addr3"].ToString();
                    table4.Rows.Add(row2);
                    DataTable table5 = barang.Tables["wb_company"];
                    DataRow row3 = table5.NewRow();
                    row3["Coy_Name"] = table.DT.Rows[0]["Coy_Name"].ToString();
                    table5.Rows.Add(row3);
                    DataTable table6 = barang.Tables["wb_relation"];
                    DataRow row4 = table6.NewRow();
                    row4["Relation_Name"] = table.DT.Rows[0]["Relation_Name"].ToString();
                    row4["Address"] = table.DT.Rows[0]["Address"].ToString();
                    table6.Rows.Add(row4);
                    DataTable table7 = barang.Tables["wb_commodity"];
                    DataRow row5 = table7.NewRow();
                    row5["Comm_Name"] = table.DT.Rows[0]["Comm_Name"].ToString();
                    row5["Unit"] = table.DT.Rows[0]["Unit"].ToString();
                    table7.Rows.Add(row5);
                    DataTable table8 = barang.Tables["wb_transaction"];
                    foreach (DataRow row7 in table.DT.Rows)
                    {
                        DataRow row8 = table8.NewRow();
                        row8["Truck_Number"] = row7["Truck_Number"].ToString();
                        row8["Net"] = Convert.ToDouble(row7["Net"].ToString());
                        row8["net_estate"] = Convert.ToDouble(row7["Net_Estate"].ToString());
                        row8["Report_Date"] = row7["Report_Date"].ToString();
                        row8["Delivery_Date"] = row7["Delivery_Date"].ToString();
                        row8["LOADING_QTY"] = Convert.ToDouble(row7["LOADING_QTY"].ToString());
                        row8["LOADING_QTY_OPW"] = Convert.ToDouble(row7["LOADING_QTY_OPW"].ToString());
                        table8.Rows.Add(row8);
                    }
                    DataTable table9 = barang.Tables["wb_transporter"];
                    DataRow row6 = table9.NewRow();
                    row6["Transporter_Name"] = table.DT.Rows[0]["Transporter_Name"].ToString();
                    table9.Rows.Add(row6);
                    cryRpt.Load(Application.StartupPath.ToString() + @"\Report\TicketBASerahBarang.rpt");
                    cryRpt = Program.rptLogon(cryRpt);
                    cryRpt.Refresh();
                    rpt.setReport(cryRpt);
                    cryRpt.DataSourceConnections.Clear();
                    cryRpt.SetDataSource((DataSet) barang);
                    rpt.crystalReportViewer1.ShowPrintButton = false;
                    rpt.crystalReportViewer1.DisplayToolbar = true;
                    rpt.setDoPrint(false);
                    rpt.ShowDialog();
                    if (rpt.doPrint)
                    {
                        cryRpt.PrintToPrinter(1, true, 0, 0);
                    }
                }
                catch (Exception exception1)
                {
                    MessageBox.Show(exception1.Message.ToString());
                }
            }
        }

        private void printLoadingUnloadingAdviseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((!WBUser.CheckTrustee("MN_PRINT", "V") && (this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() != "")) && (this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() != "0"))
            {
                MessageBox.Show(Resource.Mainform_076, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string str2 = "";
                string str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                if (str.Substring(str.Length - 1, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                {
                    MessageBox.Show(Resource.Mainform_078, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() != "")
                {
                    MessageBox.Show(Resource.Mainform_079, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    str = "";
                    string[] aField = new string[] { "Uniq" };
                    string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                    int recNo = this.Trans.GetRecNo(aField, aFind);
                    string str3 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    Cursor.Current = Cursors.WaitCursor;
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction", " select * from wb_transaction where uniq = " + str2.Trim(), WBData.conn);
                    table.DR = table.DT.Rows[0];
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_transDo", "select * from wb_transDo where ref = '" + str3.Trim() + "' order by uniq", WBData.conn);
                    table2.DR = table2.DT.Rows[0];
                    string str4 = table2.DR["Do_No"].ToString().Trim();
                    this.print(str3.Trim(), str4, this.rpt_advise, true);
                    table2.Dispose();
                    this.DataReset();
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str2;
            string str3;
            string str4;
            string str11;
            string str13;
            WBCondition condition;
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_transDO", "SELECT do_no FROM wb_transDO WHERE " + WBData.CompanyLocation(" AND ref like '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "%'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_contract", "SELECT so_item FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + row["do_no"].ToString() + "'"), WBData.conn);
                if (table3.DT.Rows[0]["so_item"].ToString() == "*")
                {
                    flag = true;
                    table3.Dispose();
                    break;
                }
                table3.Dispose();
            }
            table.Dispose();
            if (!(flag && (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X")))
            {
                if (WBUser.CheckTrustee("MN_PRINT", "V"))
                {
                    str2 = "";
                    str3 = "";
                    str4 = "";
                    string str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                    str3 = this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString();
                    if (str3 != "")
                    {
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_gatepass", "SELECT TOP 1 submit_gatepass, wx FROM wb_gatepass WHERE gatepass_number = '" + str3 + "'", WBData.conn);
                        DataRow row2 = table4.DT.Rows[0];
                        if (row2["submit_gatepass"].ToString() != "Y")
                        {
                            MessageBox.Show("Cannot print tiket if gatepass not submit yet", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                        else
                        {
                            str4 = row2["wx"].ToString();
                        }
                    }
                    if (str.Substring(str.Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX)
                    {
                        string str5 = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim();
                        string str6 = this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim();
                        string str7 = this.dataGridView1.CurrentRow.Cells["_1ST"].Value.ToString().Trim();
                        string str8 = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                        string str9 = this.dataGridView1.CurrentRow.Cells["_3RD"].Value.ToString().Trim();
                        string str10 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                        if (!(((str5 != "2X") || (str6 != "")) ? ((str5 == "4X") && (((str7 == "0") || ((str7 == "") || ((str8 != "0") && (str8 != "")))) ? (((str9 != "0") && (str9 != "")) && ((str10 == "0") || (str10 == ""))) : true)) : true))
                        {
                            str = "";
                            string[] aField = new string[] { "Uniq" };
                            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                            int recNo = this.Trans.GetRecNo(aField, aFind);
                            str11 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                            Cursor.Current = Cursors.WaitCursor;
                            if (WBSetting.Field("GM") != "Y")
                            {
                                goto TR_0042;
                            }
                            else
                            {
                                condition = new WBCondition();
                                if (!condition.getSettingCondition("TOKEN_REPRINT"))
                                {
                                    if (WBUser.CheckTrustee("MN_PRINT", "V"))
                                    {
                                        goto TR_0044;
                                    }
                                    else
                                    {
                                        MessageBox.Show(Resource.Mainform_050, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    }
                                }
                                else if (((this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() == "0") || (this.dataGridView1.CurrentRow.Cells["printed"].Value == null)) || (this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() == ""))
                                {
                                    goto TR_0044;
                                }
                                else
                                {
                                    this.hasil = this.Trans.tokenOrApp(str11, "", "REPRINT", "TOKEN_REPRINT", "REPRINT", "V", "", null);
                                    if (this.hasil[0] == "completed")
                                    {
                                        goto TR_0044;
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mainform_052, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mainform_051, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    return;
                }
                else
                {
                    MessageBox.Show(Resource.Mainform_050, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mainform_049, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return;
            }
            goto TR_0044;
        TR_0042:
            str13 = "";
            if (!WBSetting.reason_reprint_ticket)
            {
                str13 = Interaction.InputBox("Reprint", "Reason for reprint", "", 300, 300);
            }
            else
            {
                FormReasonInput input = new FormReasonInput {
                    purpose = "REASON_REPRINT_TICKET"
                };
                input.ShowDialog();
                if (input.ok)
                {
                    str13 = input.cb_reason.Text.Trim();
                }
            }
            if (str13.Trim() != "")
            {
                this.pUnq = str2;
                this._result = str13;
                WBTable table2 = new WBTable();
                string sqltext = " SELECT * FROM wb_transaction WHERE" + WBData.CompanyLocation("") + ((str3 == "") ? (" AND ref = '" + str11 + "' ") : (" AND gatepass_number = '" + str3 + "' ")) + " AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R')) AND (zAuto IS NULL OR zAuto = '' OR zAuto = 'N') ORDER BY ref";
                table2.OpenTable("wb_transaction", sqltext, WBData.conn);
                if (str4 != "1")
                {
                    if (flag)
                    {
                        this.print(this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), this.dataGridView1.CurrentRow.Cells["do_no"].Value.ToString(), this.ticket_multi1, false);
                        this.print(this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), this.dataGridView1.CurrentRow.Cells["do_no"].Value.ToString(), this.ticket_multi2, true);
                    }
                    else
                    {
                        WBTable table16 = new WBTable();
                        table16.OpenTable("wb_transDo", "select * from wb_transDo where ref = '" + str11.Trim() + "' order by uniq", WBData.conn);
                        table16.DR = table16.DT.Rows[0];
                        string str12 = table16.DR["Do_No"].ToString().Trim();
                        this.print(str11.Trim(), str12, this.ticketRpt, true);
                        table16.Dispose();
                    }
                }
                else
                {
                    int num2 = 0;
                    WBTable table5 = new WBTable();
                    table5.OpenTable("wb_transaction", " SELECT trx.printed, trx.printed_by,trx.Delivery_Note, trx.printed_date, trx.uniq, trx.gatepass_number,  trans.Transporter_Name, trx.truck_number, trx.Name, trx.Time1, trx.Time2,  trx.ref, trx.Date1, trx.Date2, trx.Gross, trx.Tare, trx.Received, trx.Deduction,  trx.net, trx.Printed, trx.Printed_By, trx.Printed_Date  FROM wb_transaction AS trx LEFT JOIN wb_transporter AS trans  ON trans.Transporter_Code = trx.Transporter_Code  AND trans.Coy = trx.Coy  AND trans.Location_Code = trx.Location_Code  WHERE trx.Gatepass_Number = '" + str3 + "'  AND ((trx.Deleted = 'N' OR trx.Deleted = '' OR trx.Deleted IS NULL)  OR (trx.Deleted = 'Y' AND trx.cancel_type = 'R'))", WBData.conn);
                    string gatepass = table5.DT.Rows[0]["gatepass_number"].ToString();
                    DataSet2 ds = new DataSet2();
                    DataTable table6 = ds.Tables["DataTable1"];
                    string str16 = "";
                    string str17 = "";
                    string str18 = "";
                    foreach (DataRow row5 in table2.DT.Rows)
                    {
                        this.updatePrintingLogHeader(row5);
                    }
                    table2.Save();
                    DataView defaultView = table5.DT.DefaultView;
                    defaultView.Sort = "[Date2], [Time2]";
                    foreach (DataRow row6 in defaultView.ToTable().Rows)
                    {
                        num2++;
                        DataRow row7 = table6.NewRow();
                        row7["TRANSPORTER"] = row6["Transporter_Name"].ToString();
                        row7["TRUCK"] = row6["Truck_Number"].ToString();
                        row7["DRIVER"] = row6["Name"].ToString();
                        str16 = row6["Name"].ToString();
                        row7["No"] = num2;
                        row7["REF"] = row6["ref"].ToString();
                        str17 = row6["Date1"].ToString().Substring(0, 10);
                        str18 = row6["Time1"].ToString().Substring(0, 5);
                        row7["IN DATETIME"] = str17 + " " + str18;
                        str17 = row6["Date2"].ToString().Substring(0, 10);
                        str18 = row6["Time2"].ToString().Substring(0, 5);
                        row7["OUT DATETIME"] = str17 + " " + str18;
                        row7["GROSS"] = row6["Gross"].ToString();
                        row7["TARE"] = row6["Tare"].ToString();
                        row7["RECEIVED"] = row6["Received"].ToString();
                        row7["DEDUCTION"] = row6["Deduction"].ToString();
                        row7["NET"] = row6["net"].ToString();
                        row7["DELIVERYNOTE"] = row6["Delivery_Note"].ToString();
                        table6.Rows.Add(row7);
                    }
                    WBTable table8 = new WBTable();
                    WBTable table9 = new WBTable();
                    DataTable table10 = ds.Tables["DataTable3"];
                    string[] textArray3 = new string[] { "select  coy_addr1, coy_addr2 from wb_location where coy = '", WBData.sCoyCode, "' AND Location_Code = '", WBData.sLocCode, "'" };
                    table8.OpenTable("wb_location", string.Concat(textArray3), WBData.conn);
                    table9.OpenTable("wb_company", "select coy_name from wb_company where coy_code = '" + WBData.sCoyCode + "'", WBData.conn);
                    string str19 = table9.DT.Rows[0]["Coy_Name"].ToString();
                    DataRow row3 = table10.NewRow();
                    foreach (DataRow row8 in table8.DT.Rows)
                    {
                        row3["COY1"] = str19;
                        row3["COY2"] = row8["coy_addr1"];
                        row3["COY3"] = row8["coy_addr2"];
                    }
                    table10.Rows.Add(row3);
                    WBTable table11 = new WBTable();
                    DataTable table12 = ds.Tables["DataTable4"];
                    string[] textArray4 = new string[] { "select Appr_By from wb_location where coy = '", WBData.sCoyCode, "' AND Location_Code = '", WBData.sLocCode, "'" };
                    table11.OpenTable("wb_location", string.Concat(textArray4), WBData.conn);
                    DataRow row4 = table12.NewRow();
                    foreach (DataRow row9 in table11.DT.Rows)
                    {
                        row4["USER"] = WBUser.UserName;
                        row4["APPROVED"] = row9["Appr_By"];
                        row4["TRANSPORTED"] = str16;
                    }
                    table12.Rows.Add(row4);
                    this.printWithDataset(gatepass, ds, this.ticketLangsir, false);
                    WBTable table13 = new WBTable();
                    DataTable table14 = ds.Tables["DataTable2"];
                    table13.OpenTable("wb_transaction", " SELECT trx.do_no, trxtype.Transaction_Name, comm.comm_name, rel.relation_name, *  FROM wb_transaction AS trx LEFT JOIN wb_transaction_type AS trxtype  ON trx.Transaction_Code = trxtype.Transaction_Code  AND trxtype.Coy = trx.Coy  AND trxtype.Location_Code = trx.Location_Code  LEFT JOIN wb_commodity AS comm  ON trx.Comm_Code = comm.Comm_Code  AND comm.Coy = trx.Coy  AND comm.Location_Code = trx.Location_Code  LEFT JOIN wb_relation AS rel  ON trx.Relation_Code = rel.Relation_Code  AND rel.Coy = trx.Coy  AND rel.Location_Code = trx.Location_Code  WHERE trx.Gatepass_Number = '" + str3 + "'  AND ((trx.Deleted = 'N' OR trx.Deleted = '' OR trx.Deleted IS NULL)  OR (trx.Deleted = 'Y' AND trx.cancel_type = 'R'))", WBData.conn);
                    DataView view2 = table13.DT.DefaultView;
                    view2.Sort = "[Date2], [Time2]";
                    num2 = 0;
                    foreach (DataRow row10 in view2.ToTable().Rows)
                    {
                        num2++;
                        DataRow row11 = table14.NewRow();
                        row11["No"] = num2;
                        row11["WB DO"] = row10["do_no"].ToString();
                        row11["TRANSACTION TYPE"] = row10["Transaction_Name"].ToString();
                        row11["COMMODITY"] = row10["comm_name"].ToString();
                        row11["RELATION"] = row10["relation_name"].ToString();
                        table14.Rows.Add(row11);
                    }
                    this.printWithDataset(gatepass, ds, this.ticketLangsir2, true);
                }
                this.DataReset();
                Cursor.Current = Cursors.Default;
            }
            return;
        TR_0044:
            condition.Dispose();
            goto TR_0042;
        }

        private void printWithDataset(string gatepass, DataSet ds, ReportDocument cryRpt, bool cek)
        {
            string[] strArray = new string[2];
            string[] strArray2 = new string[] { gatepass, WBUser.UserName };
            strArray[0] = "gatepass";
            strArray[1] = "user";
            WBUtility.ReloadTicket(cryRpt);
            this.fRpt.setReport(cryRpt);
            cryRpt.DataSourceConnections.Clear();
            cryRpt.SetDataSource(ds);
            if (WBSetting.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
                this.updatePrinted(cek);
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                    this.updatePrinted(cek);
                }
            }
        }

        private void qCItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormYield yield = new FormYield();
            yield.ShowDialog();
            yield.Dispose();
        }

        private void qCReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepQualityControl control = new RepQualityControl();
            control.ShowDialog();
            control.Dispose();
        }

        private void qcStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("TRANS_QC", "V"))
            {
                this.Timbang("QC");
            }
        }

        private void rdWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || ((this.dataGridView1.RowCount != 0) && ((this.dataGridView1.RowCount <= 0) || (this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString() == "")))) && this.checkWeightValid("3RD"))
            {
                this.Timbang("3RD");
            }
        }

        private void ReasonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_REASON", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormReason reason = new FormReason();
                reason.ShowDialog();
                reason.Dispose();
            }
        }

        private void receivingEstimationFrom3rdPartyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepEstimate estimate = new RepEstimate();
            estimate.ShowDialog();
            estimate.Dispose();
        }

        private void refreshQCFromTCSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRefreshQC hqc = new FormRefreshQC();
            hqc.ShowDialog();
            hqc.Dispose();
        }

        private void refreshQualityToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_REGISTER_GATEPASS", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormRegisGatepass gatepass = new FormRegisGatepass {
                    ticketRpt = this.ticketRpt,
                    ticket_multi1 = this.ticket_multi1,
                    ticket_multi2 = this.ticket_multi2,
                    ticketLangsir = this.ticketLangsir,
                    ticketLangsir2 = this.ticketLangsir2,
                    fRpt = this.fRpt
                };
                gatepass.ShowDialog();
                if (gatepass.needRefresh)
                {
                    this.f_load();
                }
                gatepass.Dispose();
            }
        }

        private void renewActivationKeyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_act", "SELECT * FROM wb_act WHERE 1 = 1", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("There is no activation key entered before!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                FormRegistrationKeyRenew renew = new FormRegistrationKeyRenew();
                renew.ShowDialog();
                renew.Dispose();
            }
            table.Dispose();
        }

        private void repairAllChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text = this.labelStatus1.Text;
            if (this.dataGridView1.Rows.Count > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.dataGridView1.Rows.Count)
                    {
                        this.labelStatus1.Text = text;
                        this.labelStatus1.Refresh();
                        break;
                    }
                    this.labelStatus1.Text = num.ToString() + "/" + this.dataGridView1.Rows.Count.ToString();
                    this.labelStatus1.Refresh();
                    string[] aField = new string[] { "Uniq" };
                    string[] aFind = new string[] { this.dataGridView1.Rows[num].Cells["Uniq"].Value.ToString() };
                    int recNo = this.Trans.GetRecNo(aField, aFind);
                    this.Trans.DR = this.Trans.DT.Rows[recNo];
                    if (!this.Trans.ValidChecksum_Main(this.Trans.DR))
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_transaction", " select * from wb_transaction where uniq = " + this.dataGridView1.Rows[num].Cells["Uniq"].Value.ToString(), WBData.conn);
                        table.DR = table.DT.Rows[0];
                        table.DR.BeginEdit();
                        table.DR["checksum"] = table.Checksum_Main(table.DR);
                        table.DR.EndEdit();
                        table.Save();
                        this.dataGridView1.Rows[num].Cells["checksum"].Value = table.DR["checksum"].ToString();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair Checksum" };
                        Program.updateLogHeader("wb_transaction", table.DR["uniq"].ToString(), logField, logValue);
                        table.Dispose();
                    }
                    num++;
                }
            }
        }

        private void repairChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string[] aField = new string[] { "Uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                int recNo = this.Trans.GetRecNo(aField, aFind);
                string str = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                string[] textArray3 = new string[] { Resource.Mainform_057, " ", str.Trim(), " ", Resource.Mainform_058 };
                if (MessageBox.Show(string.Concat(textArray3), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction", " select * from wb_transaction where uniq = " + this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString(), WBData.conn);
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["checksum"] = table.Checksum_Main(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair checksum" };
                    Program.updateLogHeader("wb_transaction", table.DR["uniq"].ToString(), logField, logValue);
                    this.dataGridView1.CurrentRow.Cells["checksum"].Value = table.DR["checksum"].ToString();
                    table.Dispose();
                }
            }
        }

        private void reportOutstandingDONonTradeStoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepOSDONonTrade trade = new RepOSDONonTrade();
            trade.ShowDialog();
            trade.Dispose();
        }

        private void reportOutstandingDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepOutstandingDO gdo = new RepOutstandingDO();
            gdo.ShowDialog();
            gdo.Dispose();
        }

        private void ReportToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            int length = 0;
            try
            {
                foreach (object obj2 in this.ReportToolStripMenuItem.DropDownItems)
                {
                    if (obj2.GetType().Equals(typeof(ToolStripMenuItem)))
                    {
                        ToolStripMenuItem item = (ToolStripMenuItem) obj2;
                        string str = (WBSetting.locType != "0") ? "REF" : "POM";
                        if (WBSetting.NonContract != "Y")
                        {
                            this.nonContractTransactionToolStripMenuItem.Visible = false;
                        }
                        length = item.Name.Length;
                        if (length > 2)
                        {
                            item.Visible = item.Name.Substring(length - 3, 3).ToUpper() != str;
                        }
                    }
                }
                this.logReportToolStripMenuItem.Visible = WBUser.CheckTrustee("MN_LOGREPORT", "V");
                this.migrateOldLogToNewLogToolStripMenuItem.Visible = Convert.ToInt16(WBUser.UserLevel) <= 1;
                this.userManagementReportToolStripMenuItem.Visible = (Convert.ToInt16(WBUser.UserLevel) == 1) || WBUser.CheckTrustee("MN_USERMGTREPORT", "V");
                this.emailRecipientReportToolStripMenuItem.Visible = (Convert.ToInt16(WBUser.UserLevel) == 1) || WBUser.CheckTrustee("MN_EMAILREPORT", "V");
                this.wtaReportToolStripMenuItem.Visible = (Convert.ToInt16(WBUser.UserLevel) == 1) || WBUser.CheckTrustee("MN_WTAREPORT", "V");
            }
            catch
            {
            }
        }

        private void requestCollectiveTokenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormToken_Collective collective = new FormToken_Collective();
            collective.ShowDialog();
            collective.Dispose();
        }

        private void sAPDestinationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSAPDestination destination = new FormSAPDestination();
            destination.ShowDialog();
            destination.Dispose();
            WBTable table = new WBTable();
            table.OpenTable("wb_SAPDest", "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND automaticUpload = 'Y'"), WBData.conn);
            this.sapD = new string[table.DT.Rows.Count, 2];
            if (!this.timerSAPUpd.Enabled && (table.DT.Rows.Count > 0))
            {
                this.timerSAPUpd.Enabled = true;
                this.timerSAPUpd.Interval = 0xea60;
            }
            table.Dispose();
        }

        private void saveColumnPositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.CacheDisplayOrder();
            MessageBox.Show(Resource.Mainform_075, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void schDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_contract_tmp", "select * from wb_contract_tmp", WBData.conn);
            int count = table2.DT.Rows.Count;
            int num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    table.Dispose();
                    table2.Dispose();
                    MessageBox.Show("Update quantity complete");
                    return;
                }
                table2.DR = table2.DT.Rows[num2];
                table.OpenTable("wb_contract", "select * from wb_contract where Status = 'N' and uniq = '" + table2.DR["uniq"].ToString().Trim() + "'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    if (table2.DR["Do_no"].ToString().Substring(0, 10) == table.DR["DO_NO"].ToString())
                    {
                        table.DR.BeginEdit();
                        table.DR["DO_No"] = table2.DR["Do_No"].ToString();
                        table.DR.EndEdit();
                        table.Save();
                    }
                }
                num2++;
            }
        }

        private void secretReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepWeighingTimeAnalysis analysis = new RepWeighingTimeAnalysis();
            analysis.ShowDialog();
            analysis.Dispose();
        }

        private void SetDisplayOrder()
        {
            try
            {
                FileStream stream = File.Open(Directory.GetParent(Application.UserAppDataPath) + @"\col_pos.xml", FileMode.Open);
                try
                {
                    int[] numArray = (int[]) new XmlSerializer(typeof(int[])).Deserialize(stream);
                    int index = 0;
                    while (true)
                    {
                        if (index >= numArray.Length)
                        {
                            break;
                        }
                        this.dataGridView1.Columns[index].DisplayIndex = numArray[index];
                        index++;
                    }
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Dispose();
                    }
                }
            }
            catch
            {
            }
        }

        private void settingLogReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Setting Log Report",
                labelHeader = { Text = "Log of Setting" },
                labelMasterData = { Text = "Log for: " },
                flag = "SETTING"
            };
            log.ShowDialog();
            log.Dispose();
        }

        public void ShowLayout()
        {
            string[] textArray1 = new string[] { "   |   User : ", WBUser.UserID.Trim(), " (", WBUser.UserName.Trim(), ") - ", WBUser.UserGroup.Trim() };
            this.label2.Text = string.Concat(textArray1);
            WBTable table = new WBTable();
            table.OpenTable("wb_company", "Select * From wb_company Where Coy_Code='" + WBData.sCoyCode.Trim() + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                WBData.sCoyName = table.DT.Rows[0]["coy_name"].ToString();
            }
            table.Dispose();
            this.Text = "WB System,   " + WBData.sCoyName + ", Loc : " + WBData.sLocCode;
            this.buttonFilter.PerformClick();
        }

        public void ShowStatus()
        {
            this.labelStatus1.Text = this.Trans.DT.Rows.Count.ToString() + " records shown";
        }

        private void sparePartQtyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table3;
            string str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim();
            int num = int.Parse(this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString());
            int num2 = int.Parse(this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString());
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X")
                {
                    if (((str != "2X") || (num <= 0)) ? ((str == "4X") && (num2 > 0)) : true)
                    {
                        if (WBSetting.Field("GM") != "Y")
                        {
                            if (Convert.ToInt16(WBUser.UserLevel) > 2)
                            {
                                MessageBox.Show("Transaction already Weighning Out. Cannot change loading Qty/Material Stuff", "Warning...");
                                return;
                            }
                        }
                        else if (!this.Trans.BeforeEdit(this.dataGridView1, "EDIT_SPAREPART"))
                        {
                            return;
                        }
                    }
                    if (!this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        WBCondition condition = new WBCondition();
                        WBCondition condition2 = new WBCondition();
                        table.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dataGridView1.CurrentRow.Cells["Comm_code"].Value.ToString() + "'"), WBData.conn);
                        table2.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mainform_026, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            table.DR = table.DT.Rows[0];
                            table2.DR = table2.DT.Rows[0];
                            DataRow[] dgRows = new DataRow[] { table.DR };
                            condition2.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", dgRows);
                            DataRow[] rowArray2 = new DataRow[] { table.DR, table2.DR };
                            condition.fillParameter("TRANS_SPAREPART_QTY", rowArray2);
                            if (!condition2.getResult())
                            {
                                if (!condition.getResult() || (table.DT.Rows[0]["Unit"].ToString().Trim().ToUpper() == "KG"))
                                {
                                    MessageBox.Show("Input Sparepart Qty is Only for Non-Trade and Non-KG Commodity.");
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("No need to input Sparepart Qty. Please input Density.");
                                return;
                            }
                        }
                        table.Dispose();
                        condition.Dispose();
                        condition2.Dispose();
                        table3 = new WBTable();
                        WBTable table4 = new WBTable();
                        string sqltext = "";
                        table4.OpenTable("wb_contract_detail_STO", "select * from wb_contract_detail_STO where Do_No = '" + this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString() + "'", WBData.conn);
                        if (table4.DT.Rows.Count > 0)
                        {
                            string[] textArray1 = new string[9];
                            textArray1[0] = "select a.uniq from wb_transBC a\r\n                left join wb_contract_detail_STO b\r\n                on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.STO = b.STO and a.STO_Item = b.STO_Item\r\n                left join wb_contract_detail_BC c\r\n                on a.Coy = c.Coy and a.Location_Code = c.Location_Code and a.BC_No = c.BC_No and a.BC_Item = c.BC_Item and a.BC_Type = c.BC_Type and a.BC_Date = c.BC_Date and b.Do_No = c.Do_No\r\n                where a.Coy = '";
                            textArray1[1] = WBData.sCoyCode;
                            textArray1[2] = "' and a.Location_Code = '";
                            textArray1[3] = WBData.sLocCode;
                            textArray1[4] = "' and (a.deleted is null or a.deleted = 'N') and a.Ref LIKE '";
                            textArray1[5] = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                            textArray1[6] = "%' and a.Do_No = '";
                            textArray1[7] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                            textArray1[8] = "' and (b.uniq is null or (c.uniq is null and b.Require_BC = 'Y'))";
                            sqltext = string.Concat(textArray1);
                        }
                        else
                        {
                            string[] textArray2 = new string[9];
                            textArray2[0] = "select a.uniq from wb_transBC a\r\n                left join wb_contract b\r\n                on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.STO = b.STO and a.STO_Item = b.STO_Item\r\n                left join wb_contract_detail_BC c\r\n                on a.Coy = c.Coy and a.Location_Code = c.Location_Code and a.BC_No = c.BC_No and a.BC_Item = c.BC_Item and a.BC_Type = c.BC_Type and a.BC_Date = c.BC_Date and b.Do_No = c.Do_No\r\n                where a.Coy = '";
                            textArray2[1] = WBData.sCoyCode;
                            textArray2[2] = "' and a.Location_Code = '";
                            textArray2[3] = WBData.sLocCode;
                            textArray2[4] = "' and (a.deleted is null or a.deleted = 'N') and a.Ref LIKE '";
                            textArray2[5] = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                            textArray2[6] = "%' and a.Do_No = '";
                            textArray2[7] = this.dataGridView1.CurrentRow.Cells["Do_No"].Value.ToString();
                            textArray2[8] = "' and (b.uniq is null or (c.uniq is null and b.Require_BC = 'Y'))";
                            sqltext = string.Concat(textArray2);
                        }
                        sqltext = "Select * from wb_transBC where uniq IN (" + sqltext + ")";
                        table3.OpenTable("WB_LOCATION", sqltext, WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            if (MessageBox.Show("This Transaction contains Invalid Sparepart Quantity due to WB DO Re-Adopt.\nDo you want to remove all of the invalid data?", "W A R N I N G", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                            {
                                return;
                            }
                            else
                            {
                                foreach (DataRow row in table3.DT.Rows)
                                {
                                    row.BeginEdit();
                                    row["deleted"] = "Y";
                                    row.EndEdit();
                                    table3.Save();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Mark Delete due to contains Invalid BC / STO Information (Re-Adopted WB DO)." };
                                    Program.updateLogHeader("wb_transBC", row["uniq"].ToString(), logField, logValue);
                                }
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Main Transaction Reference to Entry Sparepart Qty", "Warning...");
                    return;
                }
            }
            else
            {
                return;
            }
            table3.Dispose();
            this.Trans.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), true);
            FormSparepartInfo info = new FormSparepartInfo {
                txtRefNo = { Text = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim() },
                textRef_Date = { Text = Convert.ToDateTime(this.dataGridView1.CurrentRow.Cells["Ref_date"].Value.ToString().Trim()).ToShortDateString() }
            };
            info.ShowDialog();
            info.Dispose();
            this.Trans.RLock(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), false);
            this.DataReset();
        }

        private void SPB_Report_Menu_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("MN_PRINT_SPB", "V"))
            {
                string str2 = "";
                str2 = this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString();
                if (string.IsNullOrEmpty(this.dataGridView1.CurrentRow.Cells["date2"].Value.ToString()))
                {
                    MessageBox.Show(Resource.Mainform_052, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    if (!string.IsNullOrEmpty(str2))
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_gatepass", "SELECT TOP 1 submit_gatepass, wx FROM  wb_gatepass with (nolock)\r\n                                                        WHERE gatepass_number = '" + str2 + "'", WBData.conn);
                        if (table.DT.Rows[0]["submit_gatepass"].ToString() != "Y")
                        {
                            MessageBox.Show(Resource.Mainform_095, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            table.Dispose();
                            return;
                        }
                        else
                        {
                            table.Dispose();
                            table.Dispose();
                        }
                    }
                    try
                    {
                        DataRow row2;
                        int num;
                        WBTable table3;
                        WBCondition condition;
                        FormRpt rpt = new FormRpt();
                        ReportDocument cryRpt = new ReportDocument();
                        string str3 = "";
                        WBTable table2 = new WBTable();
                        table2.OpenTable("tbl_spb", "SELECT comm.comm_name, trx.gross, trx.tare, trx.net as netto, trdo.loading_qty, trdo.do_base_uom, trx.ref as spb_no, gp.truck_number,\r\n                                trx.do_no, trx.relation_code, rel.relation_name, rel.address as relation_address, trptr.transporter_name, trx.date2, gp.submit_date, trx.no_ticket_spb,\r\n                                contract.so, trx.seal as seal_no, company.coy_name, comm.bulkpack, comm.unit, gp.submit_time\r\n                                FROM wb_transaction AS trx WITH (NOLOCK)\r\n                                LEFT JOIN wb_transdo AS trdo WITH (NOLOCK) ON trx.Ref = trdo.ref\r\n                                LEFT JOIN wb_commodity AS comm WITH (NOLOCK) ON comm.comm_code = trx.comm_code AND comm.coy = trx.coy AND comm.location_code = trx.location_code\r\n                                LEFT JOIN wb_gatepass AS gp WITH (NOLOCK) on gp.gatepass_number = trx.gatepass_number\r\n                                LEFT JOIN wb_transporter as trptr WITH (NOLOCK) ON trptr.transporter_code = trx.transporter_code AND trptr.coy = trx.coy AND trptr.location_code = trx.location_code\r\n                                LEFT JOIN wb_relation AS rel WITH (NOLOCK) ON rel.relation_code = trx.relation_code AND rel.coy = trx.coy AND rel.location_code = trx.location_code\r\n                                LEFT JOIN wb_contract AS contract WITH (NOLOCK) ON contract.do_no = trx.do_no\r\n                                LEFT JOIN wb_company AS company WITH (NOLOCK) ON company.coy_code = trx.coy\r\n                                WHERE TRX.REF = '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "'", WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0002;
                        }
                        else
                        {
                            row2 = table2.DT.Rows[0];
                            num = Convert.ToInt32(string.IsNullOrEmpty(row2["no_ticket_spb"].ToString()) ? "0" : row2["no_ticket_spb"]);
                            if (WBSetting.Field("GM") != "Y")
                            {
                                goto TR_000D;
                            }
                            else
                            {
                                condition = new WBCondition();
                                bool flag7 = condition.getSettingCondition("TOKEN_REPRINT");
                                if (num == 0)
                                {
                                    goto TR_000F;
                                }
                                else
                                {
                                    this.hasil = this.Trans.tokenOrApp(row2["spb_no"].ToString(), "", "REPRINT", "TOKEN_REPRINT", "REPRINT", "V", "", null);
                                    if (this.hasil[0] == "completed")
                                    {
                                        goto TR_000F;
                                    }
                                }
                            }
                        }
                        return;
                    TR_0002:
                        table2.Dispose();
                        rpt.Dispose();
                        cryRpt.Dispose();
                        return;
                    TR_000D:
                        table3 = new WBTable();
                        table3.OpenTable("wb_transcontainer", "SELECT Container FROM WB_TRANSCONTAINER WITH (NOLOCK) WHERE REF LIKE '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "%'", WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            List<string> values = new List<string>();
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= table3.DT.Rows.Count)
                                {
                                    str3 = string.Join(", ", values);
                                    break;
                                }
                                DataRow row5 = table3.DT.Rows[num3];
                                values.Add(row5["Container"].ToString());
                                num3++;
                            }
                        }
                        table3.Dispose();
                        DataSetTicketSPB tspb = new DataSetTicketSPB();
                        DataTable table4 = new DataTable();
                        table4 = tspb.Tables["HeaderGama"];
                        DataRow row = table4.NewRow();
                        row["spb_no"] = string.IsNullOrEmpty(row2["spb_no"].ToString()) ? "-" : row2["spb_no"].ToString();
                        row["truck_number"] = string.IsNullOrEmpty(row2["truck_number"].ToString()) ? "-" : row2["truck_number"].ToString();
                        row["do_no"] = string.IsNullOrEmpty(row2["do_no"].ToString()) ? "-" : row2["do_no"].ToString();
                        row["relation_name"] = string.IsNullOrEmpty(row2["relation_name"].ToString()) ? "-" : row2["relation_name"].ToString();
                        row["relation_address"] = string.IsNullOrEmpty(row2["relation_address"].ToString()) ? "-" : row2["relation_address"].ToString();
                        row["transporter_name"] = string.IsNullOrEmpty(row2["transporter_name"].ToString()) ? "-" : row2["transporter_name"].ToString();
                        row["date2"] = string.IsNullOrEmpty(row2["date2"].ToString()) ? "-" : row2["date2"].ToString();
                        "submit_date"[(string) row] = (string.IsNullOrEmpty(row2["submit_date"].ToString()) || string.IsNullOrEmpty(row2["submit_time"].ToString())) ? "-" : (row2["submit_time"].ToString() + " " + Convert.ToDateTime(row2["submit_date"]).ToShortDateString().ToString());
                        row["no_ticket_spb"] = num;
                        row["SO"] = string.IsNullOrEmpty(row2["SO"].ToString()) ? "-" : row2["SO"].ToString();
                        row["container_no"] = string.IsNullOrEmpty(str3) ? "-" : str3;
                        row["seal_no"] = string.IsNullOrEmpty(row2["seal_no"].ToString()) ? "-" : row2["seal_no"].ToString();
                        row["coy_name"] = string.IsNullOrEmpty(row2["coy_name"].ToString()) ? "-" : row2["coy_name"].ToString();
                        row["bulkpack"] = string.IsNullOrEmpty(row2["bulkpack"].ToString()) ? "-" : row2["bulkpack"].ToString();
                        row["unit"] = string.IsNullOrEmpty(row2["unit"].ToString()) ? "-" : row2["unit"].ToString();
                        table4.Rows.Add(row);
                        int num2 = 1;
                        DataTable table5 = new DataTable();
                        table5 = tspb.Tables["DetailGama"];
                        DataRow row4 = table5.NewRow();
                        row4["no"] = num2;
                        row4["comm_name"] = string.IsNullOrEmpty(row2["comm_name"].ToString()) ? "-" : row2["comm_name"].ToString();
                        row4["gross"] = string.IsNullOrEmpty(row2["gross"].ToString()) ? "-" : row2["gross"].ToString();
                        row4["tare"] = string.IsNullOrEmpty(row2["tare"].ToString()) ? "-" : row2["tare"].ToString();
                        row4["netto"] = string.IsNullOrEmpty(row2["netto"].ToString()) ? "-" : row2["netto"].ToString();
                        row4["loading_qty"] = string.IsNullOrEmpty(row2["loading_qty"].ToString()) ? "-" : row2["loading_qty"].ToString();
                        row4["do_base_uom"] = string.IsNullOrEmpty(row2["do_base_uom"].ToString()) ? "-" : row2["do_base_uom"].ToString();
                        table5.Rows.Add(row4);
                        cryRpt.Load(Application.StartupPath.ToString() + @"\Report\TicketSPBGama.rpt");
                        cryRpt = Program.rptLogon(cryRpt);
                        cryRpt.Refresh();
                        rpt.setReport(cryRpt);
                        cryRpt.DataSourceConnections.Clear();
                        cryRpt.SetDataSource((DataSet) tspb);
                        rpt.crystalReportViewer1.ShowPrintButton = false;
                        rpt.crystalReportViewer1.DisplayToolbar = true;
                        rpt.setDoPrint(false);
                        rpt.ShowDialog();
                        if (rpt.doPrint)
                        {
                            cryRpt.PrintToPrinter(1, true, 0, 0);
                            WBTable table6 = new WBTable();
                            table6.OpenTable("tbl_spb", "SELECT no_ticket_spb, uniq\r\n                                FROM wb_transaction\r\n                                WHERE REF = '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "'", WBData.conn);
                            table6.DR = table6.DT.Rows[0];
                            table6.DR.BeginEdit();
                            table6.DR["no_ticket_spb"] = (num + 1).ToString();
                            string keyField = table6.DR["uniq"].ToString();
                            table6.DR.EndEdit();
                            table6.Save();
                            table6.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "REPRINT", WBUser.UserID, "Print SPB" };
                            Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                        }
                        tspb.Dispose();
                        goto TR_0002;
                    TR_000F:
                        condition.Dispose();
                        goto TR_000D;
                    }
                    catch (Exception exception1)
                    {
                        MessageBox.Show(exception1.ToString());
                    }
                }
            }
        }

        private void SPBtoolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSPBv2 bv = new FormSPBv2();
            bv.ShowDialog();
            bv.Dispose();
        }

        private void splitReferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.checkCompleteTrans("split"))
            {
                string str = "";
                str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mainform_060, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    str = "";
                    if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X")
                    {
                        MessageBox.Show(Resource.Mainform_061, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if (!this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                    {
                        if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "Y")
                        {
                            MessageBox.Show(Resource.Mainform_062, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else if (this.Trans.BeforeEdit(this.dataGridView1, "SPLIT"))
                        {
                            this.Timbang("SPLIT");
                            this.Trans.UnLock();
                        }
                    }
                }
            }
        }

        public int squared(int i) => 
            i * i;

        private void startWeighingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool flag3;
            if (this.isRegistrationKeyValid())
            {
                if ((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || WBSetting.gatepassWithoutCard)
                {
                    goto TR_0002;
                }
                else
                {
                    flag3 = false;
                    WBTable table = new WBTable();
                    table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE token_code = 'BYPASS_MANNED_WEIGHING'  AND key_1 = '" + WBData.sWBCode + "'  AND completed = 'Y'", WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        flag3 = false;
                    }
                    else
                    {
                        foreach (DataRow row in table.DT.Rows)
                        {
                            double num = Convert.ToInt16(row["key_2"].ToString()) * 0xe10;
                            TimeSpan span = (TimeSpan) (DateTime.Now - Convert.ToDateTime(row["Datetime1"].ToString()));
                            if (span.TotalSeconds < num)
                            {
                                flag3 = true;
                                break;
                            }
                            flag3 = false;
                        }
                    }
                }
            }
            else
            {
                return;
            }
            if (!flag3 && !WBSetting.unlockWeighingMenu)
            {
                MessageBox.Show(Resource.Mainform_093, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        TR_0002:
            this.Timbang("1ST");
        }

        private void stWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || ((this.dataGridView1.RowCount != 0) && ((this.dataGridView1.RowCount <= 0) || (this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString() == ""))))
            {
                if (WBSetting.wb_filling_location)
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction", " select * from wb_transaction where " + WBData.CompanyLocation(" and wx <> '' and wbcode1 = '" + WBData.sWBCode + "' and wbcode2 is null and (deleted <> 'Y' or deleted is null)"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        string[] textArray1 = new string[9];
                        textArray1[0] = Resource.Mainform_019;
                        textArray1[1] = " ";
                        textArray1[2] = table.DT.Rows[0]["truck_number"].ToString();
                        textArray1[3] = " ";
                        textArray1[4] = Resource.Mainform_020;
                        textArray1[5] = " ";
                        textArray1[6] = table.DT.Rows[0]["ref"].ToString();
                        textArray1[7] = " ";
                        textArray1[8] = Resource.Mainform_021;
                        MessageBox.Show(string.Concat(textArray1), Resource.Mainform_022, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                this.Timbang("1ST");
            }
        }

        private void subRP1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA pffbla = new RepFFBLA();
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void tankerLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepTankerLog log = new RepTankerLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void templateSAPLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Template " + this.sapIDSYS + " Log Report",
                labelHeader = { Text = "Log of Template " + this.sapIDSYS },
                labelMasterData = { Text = "Log for: " },
                flag = "TEMPLATE " + this.sapIDSYS
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void templateSAPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTemplateSAP esap = new FormTemplateSAP();
            esap.ShowDialog();
            esap.Dispose();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void thPrint()
        {
            string[] strArray = new string[2];
            string[] strArray2 = new string[] { "", "" };
            strArray[0] = "ref";
            strArray[1] = "DO_No";
        }

        private void thWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || ((this.dataGridView1.RowCount != 0) && ((this.dataGridView1.RowCount <= 0) || (this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString() == "")))) && this.checkWeightValid("4TH"))
            {
                this.check_final_weigh("4TH");
            }
        }

        private void Timbang(string pMode)
        {
            WBCondition condition;
            WBTable table4;
            string wX = "";
            string str2 = "";
            this.nCurrRow = 0;
            this.no_gatepass = "";
            this.uniq_gatepass = "";
            this.no_card = "";
            if (this.dataGridView1.Rows.Count > 0)
            {
                str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                this.buttonFilter.PerformClick();
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { str2 };
                this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
            }
            if ((WBSetting.checkISCC != "Y") || (((WBSetting.validDateISCC - DateTime.Now).Days + 1) > 0))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE (deleted<>'Y' or deleted is null) AND WBCode = '" + WBData.sWBCode + "' ORDER BY valid_date DESC", WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (table.DT.Rows[0]["lock_weighing"].ToString() != "Y"))
                {
                    table.Dispose();
                    if ((((pMode != "CANCEL") && ((pMode != "2ND") && ((pMode != "COPY") && ((pMode != "EDIT") && ((pMode != "QTY") && ((pMode != "DEDUCTION") && (pMode != "EDIT_SPB"))))))) && (pMode != "EDIT_REPORTDATE")) || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X"))
                    {
                        if ((((pMode != "EDIT") && ((pMode != "CANCEL") && ((pMode != "2ND") && ((pMode != "COPY") && ((pMode != "EDIT_OPW") && ((pMode != "ADD_RETUR") && ((pMode != "DEDUCTION") && (pMode != "EDIT_SPB")))))))) && (pMode != "EDIT_REPORTDATE")) || (this.dataGridView1.CurrentRow.Cells["mark_accident"].Value.ToString() != "X"))
                        {
                            if ((pMode != "QTY") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != ""))
                            {
                                if ((pMode != "DEDUCTION") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != ""))
                                {
                                    if ((pMode != "EDIT_SPB") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != ""))
                                    {
                                        if (((pMode == "COPY") && WBSetting.activeTCS) && (this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString() != ""))
                                        {
                                            WBTable table2 = new WBTable();
                                            string[] textArray5 = new string[] { "SELECT Ref FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND Gatepass_Number = '", this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString(), "' AND report_date IS NULL  AND (Deleted IS NULL OR Deleted <> 'Y')" };
                                            table2.OpenTable("wb_transaction", string.Concat(textArray5), WBData.conn);
                                            if (table2.DT.Rows.Count <= 0)
                                            {
                                                table2.Dispose();
                                            }
                                            else
                                            {
                                                string[] textArray6 = new string[] { Resource.Mainform_041, " ", table2.DT.Rows[0]["Ref"].ToString(), " ", Resource.Mainform_042 };
                                                MessageBox.Show(string.Concat(textArray6), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                return;
                                            }
                                        }
                                        if (((pMode == "1ST") || (pMode == "MANUAL")) || (this.dataGridView1.Rows.Count > 0))
                                        {
                                            if (pMode == "GRADING")
                                            {
                                                if (this.dataGridView1.CurrentRow.Cells["Report_Date"].Value.ToString() != "")
                                                {
                                                    WBTable table3 = new WBTable();
                                                    table3.OpenTable("wb_commodity", "SELECT Type FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.dataGridView1.CurrentRow.Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                                                    if ((table3.DT.Rows.Count <= 0) || (table3.DT.Rows[0]["Type"].ToString() == "F"))
                                                    {
                                                        table3.Dispose();
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show(Resource.Mainform_044, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                        table3.Dispose();
                                                        return;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show(Resource.Mainform_043, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    return;
                                                }
                                            }
                                            if (!(WBSetting.adopt_zdotrx && (this.dataGridView1.Rows.Count > 0)))
                                            {
                                                goto TR_006F;
                                            }
                                            else
                                            {
                                                condition = new WBCondition();
                                                string[] aField = new string[] { "ref" };
                                                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString() };
                                                this.Trans.DR = this.Trans.GetData(aField, aFind);
                                                if (this.Trans.DR == null)
                                                {
                                                    goto TR_0070;
                                                }
                                                else
                                                {
                                                    table4 = new WBTable();
                                                    table4.OpenTable("wb_Commodity", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.Trans.DR["comm_code"].ToString() + "'"), WBData.conn);
                                                    string[] textArray9 = new string[] { "comm_code" };
                                                    string[] textArray10 = new string[] { this.Trans.DR["comm_code"].ToString() };
                                                    table4.DR = table4.GetData(textArray9, textArray10);
                                                    DataRow[] dgRows = new DataRow[] { this.Trans.DR, table4.DR };
                                                    condition.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                                                    if (!condition.getResult() || ((pMode != "EDIT") || (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString() != "")))
                                                    {
                                                        goto TR_0071;
                                                    }
                                                    else
                                                    {
                                                        WBTable table5 = new WBTable();
                                                        table5.OpenTable("wb_gatepass", "select WX from wb_gatepass as g inner join wb_transdo as d on d.gatepass_number = g.gatepass_number where d.ref = '" + this.Trans.DR["Ref"].ToString() + "'", WBData.conn);
                                                        if ((table5.DT.Rows.Count <= 0) || (table5.DT.Rows[0]["WX"].ToString() == "1"))
                                                        {
                                                            table5.Dispose();
                                                            goto TR_0071;
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show(Resource.Mainform_043, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                        }
                                                    }
                                                }
                                            }
                                            return;
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Can't edit report date for transaction which has not been weighed before!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Can't edit deduction for transaction which has not been weighed before!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mainform_040, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }
                        }
                        else
                        {
                            string str4 = "";
                            str4 = (pMode == "CANCEL") ? Resource.Mainform_031 : ((pMode == "2ND") ? Resource.Mainform_032 : ((pMode == "COPY") ? "copy" : ((pMode == "EDIT") ? Resource.Mainform_033 : ((pMode == "EDIT_OPW") ? Resource.Mainform_037 : ((pMode == "ADD_RETUR") ? Resource.Mainform_038 : ((pMode == "DEDUCTION") ? "EDIT DEDUCTION" : ((pMode == "EDIT_SPB") ? "EDIT DELIVERY NOTE" : ((pMode == "EDIT_REPORTDATE") ? "EDIT REPORT DATE" : ""))))))));
                            string[] textArray4 = new string[] { Resource.Mainform_035, " ", str4, " ", Resource.Mainform_039 };
                            MessageBox.Show(string.Concat(textArray4), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }
                    else
                    {
                        string str3 = "";
                        str3 = (pMode == "CANCEL") ? Resource.Mainform_031 : ((pMode == "2ND") ? Resource.Mainform_032 : ((pMode == "COPY") ? "copy" : ((pMode == "EDIT") ? Resource.Mainform_033 : ((pMode == "QTY") ? Resource.Mainform_034 : ((pMode == "DEDUCTION") ? "EDIT DEDUCTION" : ((pMode == "EDIT_SPB") ? "EDIT DELIVERY NOTE" : ((pMode == "EDIT_REPORTDATE") ? "EDIT REPORT DATE" : "")))))));
                        string[] textArray3 = new string[] { Resource.Mainform_035, " ", str3, " ", Resource.Mainform_036 };
                        MessageBox.Show(string.Concat(textArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mainform_030, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mainform_007, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            goto TR_0071;
        TR_006F:
            if (((pMode != "2ND") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "2X")) ? ((pMode == "4TH") && (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() == "4X")) : true)
            {
                WBTable table6 = new WBTable();
                if (string.IsNullOrEmpty(table6.CekTokenCompleted(this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString(), "", "OVER_BC_QTY", false)))
                {
                    table6.Dispose();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_617, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            if ((pMode == "1ST") || (pMode == "MANUAL"))
            {
                if (!((pMode == "1ST") && WBSetting.activeTCS))
                {
                    FormTransRegis regis = new FormTransRegis();
                    if (pMode == "MANUAL")
                    {
                        regis.Regis = true;
                        regis.buttonRegis.Enabled = false;
                    }
                    else
                    {
                        regis.buttonRegis.Enabled = true;
                        regis.Regis = (this.dataGridView1.Rows.Count > 0) ? (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "") : true;
                    }
                    regis.ShowDialog();
                    if (regis.pSave)
                    {
                        wX = regis.WX;
                        this.tambahRecord = regis.Regis;
                        regis.Dispose();
                    }
                    else
                    {
                        return;
                    }
                }
                if (!ReferenceEquals(this.dataGridView1.CurrentRow, null))
                {
                    WBTable table7 = new WBTable();
                    string[] textArray11 = new string[] { "select do.do_sap, do.do_sap_item from wb_transaction as ts inner join wb_transDO as do on ts.Ref = do.Ref and ts.Coy = do.Coy and ts.Location_Code = do.Location_Code inner join wb_token as token on token.key_1 = do.do_sap and token.key_2 = do.do_sap_item where token.Token_Code = 'DO_SAP_FAIL_VALID' and token.completed = 'N'  and ts.Ref = '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "' and ts.coy = '", WBData.sCoyCode, "' and ts.location_code = '", WBData.sLocCode, "'" };
                    table7.OpenTable("wb_token", string.Concat(textArray11), WBData.conn);
                    if (table7.DT.Rows.Count <= 0)
                    {
                        string[] textArray12 = new string[] { "select do.internal_number, do.internal_number_item from wb_transaction as ts inner join wb_transDO as do on ts.Ref = do.Ref and ts.Coy = do.Coy and ts.Location_Code = do.Location_Code inner join wb_token as token on token.key_1 = do.internal_number and token.key_2 = do.internal_number_item where token.Token_Code = 'DO_SAP_FAIL_VALID' and token.completed = 'N'  and ts.Ref = '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "' and ts.coy = '", WBData.sCoyCode, "' and ts.location_code = '", WBData.sLocCode, "'" };
                        table7.OpenTable("wb_token", string.Concat(textArray12), WBData.conn);
                        if (table7.DT.Rows.Count > 0)
                        {
                            this.hasil = this.tbl_Loc.tokenOrApp(table7.DT.Rows[0]["internal_number"].ToString(), table7.DT.Rows[0]["internal_number_item"].ToString(), "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "", "", "", null);
                            if (this.hasil[0] != "completed")
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        this.hasil = this.tbl_Loc.tokenOrApp(table7.DT.Rows[0]["do_sap"].ToString(), table7.DT.Rows[0]["do_sap_item"].ToString(), "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "", "", "", null);
                        if (this.hasil[0] != "completed")
                        {
                            return;
                        }
                    }
                }
                if (WBSetting.gatepass_registration & (pMode != "MANUAL"))
                {
                    FormTransGatepass gatepass = new FormTransGatepass {
                        ticketRpt = this.ticketRpt,
                        rpt_advise = this.rpt_advise,
                        ticket2Rpt = this.ticket2Rpt,
                        fRpt = this.fRpt
                    };
                    gatepass.ShowDialog();
                    if (!gatepass.saved)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        this.Trans.ReOpen();
                        this.DataReset();
                        this.ShowStatus();
                        this.SetDisplayOrder();
                        Cursor.Current = Cursors.Default;
                        return;
                    }
                    else
                    {
                        this.uniq_gatepass = gatepass.uniq;
                        this.no_gatepass = gatepass.no;
                        this.no_card = gatepass.noCard;
                        if (WBSetting.region != "2")
                        {
                            wX = gatepass.wx;
                        }
                        gatepass.Dispose();
                        this.tambahRecord = (this.dataGridView1.Rows.Count > 0) ? (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "") : true;
                    }
                }
            }
            if ((this.dataGridView1.Rows.Count > 0) && (((pMode != "1ST") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "")) ? ((pMode != "1ST") && (pMode != "MANUAL")) : true))
            {
                string str5 = "";
                str5 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
                {
                    if ((((pMode == "VIEW") || (pMode == "COPY")) || (pMode == "1ST")) || !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                    {
                        if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "")
                        {
                            wX = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString();
                        }
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                        this.nCurrRow = this.Trans.GetRecNo(aField, aFind);
                        str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Cannot " + pMode + " Automated DO For Titip Timbun...", "WARNING");
                    return;
                }
            }
            if ((((wX != "") & (((pMode == "1ST") || ((pMode == "2ND") || ((pMode == "3RD") || (pMode == "4TH")))) || (pMode == "COPY"))) && (((WBSetting.WB_Type == "1") || (WBSetting.WB_Type == "2")) && (Convert.ToInt16(WBUser.UserLevel) > 2))) && (WBSetting.CheckZero() != 0))
            {
                MessageBox.Show(Resource.Mainform_045, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if ((pMode != "EDIT") || (WBSetting.Field("GM").ToString() != "Y"))
                {
                    if ((pMode != "QTY") || (WBSetting.Field("GM").ToString() != "Y"))
                    {
                        if (!(((pMode == "EDIT_SPB") || ((pMode == "EDIT_REPORTDATE") || (pMode == "DEDUCTION"))) ? (WBSetting.Field("GM").ToString() == "Y") : false))
                        {
                            if ((pMode == "MANUAL") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                            {
                                WBTable table8 = new WBTable();
                                table8.OpenTable("wb_loc", "select * from wb_location", WBData.conn);
                                if (table8.DT.Rows[0]["tokenExpiredDate"].ToString() != "")
                                {
                                    string str6 = Program.shoot(table8.DT.Rows[0]["tokenExpiredDate"].ToString(), false);
                                    if (DateTime.Today.ToString("dd/MM/yyyy") != str6)
                                    {
                                        MessageBox.Show(Resource.Mainform_048, "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        table8.DT.Rows[0]["tokenManual"] = "";
                                        table8.DT.Rows[0]["maxEntry"] = "";
                                        table8.DT.Rows[0]["currEntry"] = "";
                                        table8.DT.Rows[0]["tokenExpiredDate"] = DBNull.Value;
                                        table8.DT.Rows[0]["StartRef"] = "";
                                        table8.DT.Rows[0]["checksum"] = table8.Checksum(table8.DT.Rows[0]);
                                        table8.Save();
                                    }
                                }
                            }
                        }
                        else if ((this.dataGridView1.CurrentRow.Cells["edit_data"].Value.ToString() == "5") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                        {
                            MessageBox.Show(Resource.Mainform_046, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["edit_qty"].Value.ToString() == "5") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                    {
                        MessageBox.Show(Resource.Mainform_047, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else if ((this.dataGridView1.CurrentRow.Cells["edit_data"].Value.ToString() == "5") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                {
                    MessageBox.Show(Resource.Mainform_046, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (this.Trans.BeforeEdit(this.dataGridView1, pMode))
                {
                    if (WBSetting.region == "2")
                    {
                        FormTransactionMsia msia = new FormTransactionMsia {
                            nCurrRow = this.nCurrRow,
                            sUniq = str2,
                            gatepass_uniq = this.uniq_gatepass,
                            gatepass_no = this.no_gatepass,
                            card_no = this.no_card
                        };
                        WBTable table9 = new WBTable();
                        if (this.Trans.DT.Rows.Count == 0)
                        {
                            table9.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                        }
                        else
                        {
                            DataRow row = this.Trans.DT.Rows[this.nCurrRow];
                            string sqltext = "select * from wb_transaction where uniq = '" + row["uniq"].ToString() + "'";
                            table9.OpenTable("wb_transaction", sqltext, WBData.conn);
                        }
                        msia.tblTrans = table9;
                        msia.pMode = pMode;
                        msia.dgvTrans = this.dataGridView1;
                        msia.WX = wX;
                        msia.tambahRecord = (pMode != "COPY") ? this.tambahRecord : true;
                        msia.ticketRpt = this.ticketRpt;
                        msia.rpt_advise = this.rpt_advise;
                        msia.ticket2Rpt = this.ticket2Rpt;
                        msia.fRpt = this.fRpt;
                        msia.ShowDialog();
                        if (msia.Saved)
                        {
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(pMode);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { msia.textRefNo.Text };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        this.Trans.UnLock();
                        msia.Dispose();
                    }
                    else if ((pMode == "EDIT_SPB") || (pMode == "EDIT_REPORTDATE"))
                    {
                        FormEditTransaction transaction = new FormEditTransaction {
                            nCurrRow = this.nCurrRow,
                            sUniq = str2,
                            gatepass_uniq = this.uniq_gatepass,
                            gatepass_no = this.no_gatepass,
                            card_no = this.no_card,
                            noRef = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString()
                        };
                        WBTable table10 = new WBTable();
                        if (this.Trans.DT.Rows.Count == 0)
                        {
                            table10.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                        }
                        else
                        {
                            DataRow row2 = this.Trans.DT.Rows[this.nCurrRow];
                            string sqltext = "select * from wb_transaction where uniq = '" + row2["uniq"].ToString() + "'";
                            table10.OpenTable("wb_transaction", sqltext, WBData.conn);
                            if (table10.DT.Rows[0]["gatepass_number"].ToString() != "")
                            {
                                WBTable table11 = new WBTable();
                                string[] textArray17 = new string[] { " SELECT uniq, card_no,change_by, change_date, reason, delivery_note,scanespb FROM wb_gatepass WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", table10.DT.Rows[0]["gatepass_number"].ToString(), "'" };
                                table11.OpenTable("wb_gatepass", string.Concat(textArray17), WBData.conn);
                                if (table11.DT.Rows.Count > 0)
                                {
                                    this.uniq_gatepass = table11.DT.Rows[0]["uniq"].ToString();
                                    this.no_card = table11.DT.Rows[0]["card_no"].ToString();
                                    this.no_gatepass = table10.DT.Rows[0]["gatepass_number"].ToString();
                                    transaction.gatepass_uniq = this.uniq_gatepass;
                                    transaction.gatepass_no = this.no_gatepass;
                                    transaction.card_no = this.no_card;
                                    transaction.tblGP = table11;
                                }
                            }
                        }
                        transaction.pMode = pMode;
                        transaction.dgvTrans = this.dataGridView1;
                        transaction.tblTrans = table10;
                        transaction.ShowDialog();
                        if (transaction.Saved)
                        {
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(pMode);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { transaction.txtBoxRef.Text };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        this.Trans.UnLock();
                        transaction.Dispose();
                    }
                    else
                    {
                        FormTransaction transaction2 = new FormTransaction {
                            nCurrRow = this.nCurrRow,
                            sUniq = str2,
                            gatepass_uniq = this.uniq_gatepass,
                            gatepass_no = this.no_gatepass,
                            card_no = this.no_card
                        };
                        WBTable table12 = new WBTable();
                        if (this.Trans.DT.Rows.Count == 0)
                        {
                            table12.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                        }
                        else
                        {
                            DataRow row3 = this.Trans.DT.Rows[this.nCurrRow];
                            string sqltext = "select * from wb_transaction where uniq = '" + row3["uniq"].ToString() + "'";
                            table12.OpenTable("wb_transaction", sqltext, WBData.conn);
                            if (table12.DT.Rows[0]["gatepass_number"].ToString() != "")
                            {
                                WBTable table13 = new WBTable();
                                string[] textArray20 = new string[] { " SELECT uniq, card_no FROM wb_gatepass WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", table12.DT.Rows[0]["gatepass_number"].ToString(), "'" };
                                table13.OpenTable("wb_gatepass", string.Concat(textArray20), WBData.conn);
                                if (table13.DT.Rows.Count > 0)
                                {
                                    this.uniq_gatepass = table13.DT.Rows[0]["uniq"].ToString();
                                    this.no_card = table13.DT.Rows[0]["card_no"].ToString();
                                    this.no_gatepass = table12.DT.Rows[0]["gatepass_number"].ToString();
                                }
                                table13.Dispose();
                            }
                            transaction2.gatepass_uniq = this.uniq_gatepass;
                            transaction2.gatepass_no = this.no_gatepass;
                            transaction2.card_no = this.no_card;
                        }
                        transaction2.tblTrans = table12;
                        transaction2.pMode = pMode;
                        transaction2.dgvTrans = this.dataGridView1;
                        transaction2.tblDeduc = this.tblDeduc;
                        transaction2.WX = wX;
                        if (pMode != "COPY")
                        {
                            transaction2.tambahRecord = this.tambahRecord;
                        }
                        else
                        {
                            transaction2.tambahRecord = true;
                            transaction2.manualCopyfromMainForm = true;
                        }
                        transaction2.ticketRpt = this.ticketRpt;
                        transaction2.rpt_advise = this.rpt_advise;
                        transaction2.ticket2Rpt = this.ticket2Rpt;
                        transaction2.ticket_multi1 = this.ticket_multi1;
                        transaction2.ticket_multi2 = this.ticket_multi2;
                        transaction2.fRpt = this.fRpt;
                        transaction2.ShowDialog();
                        if (transaction2.Saved)
                        {
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(pMode);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { transaction2.textRefNo.Text };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        this.Trans.UnLock();
                        transaction2.Dispose();
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
            return;
        TR_0070:
            condition.Dispose();
            goto TR_006F;
        TR_0071:
            table4.Dispose();
            goto TR_0070;
        }

        private void Timbang_CollectiveToken(string pMode)
        {
            string str = "";
            string pUniq = "";
            this.nCurrRow = 0;
            if ((((pMode != "CANCEL") && ((pMode != "2ND") && ((pMode != "COPY") && (pMode != "EDIT")))) && (pMode != "QTY")) || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X"))
            {
                if ((((pMode != "EDIT") && ((pMode != "CANCEL") && ((pMode != "2ND") && ((pMode != "COPY") && (pMode != "EDIT_OPW"))))) && (pMode != "ADD_RETUR")) || (this.dataGridView1.CurrentRow.Cells["mark_accident"].Value.ToString() != "X"))
                {
                    if (((pMode == "1ST") || (pMode == "MANUAL")) || (this.dataGridView1.Rows.Count > 0))
                    {
                        if ((this.dataGridView1.Rows.Count > 0) && (((pMode != "1ST") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "")) ? ((pMode != "1ST") && (pMode != "MANUAL")) : true))
                        {
                            string str6 = "";
                            str6 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                            if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
                            {
                                if ((((pMode == "VIEW") || (pMode == "COPY")) || (pMode == "1ST")) || !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                                {
                                    if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "")
                                    {
                                        str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString();
                                    }
                                    string[] aField = new string[] { "uniq" };
                                    string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                                    this.nCurrRow = this.Trans.GetRecNo(aField, aFind);
                                    pUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot " + pMode + " Automated DO For Titip Timbun...", "WARNING");
                                return;
                            }
                        }
                        this.Trans.RLock(pUniq, true);
                        string str3 = this.dataGridView1.SortedColumn.Name.ToString();
                        ListSortDirection direction = (this.dataGridView1.SortOrder.ToString() == "Ascending") ? ListSortDirection.Ascending : ListSortDirection.Descending;
                        if (WBSetting.region == "2")
                        {
                            FormTransactionMsia msia = new FormTransactionMsia {
                                nCurrRow = this.nCurrRow,
                                sUniq = pUniq,
                                gatepass_uniq = this.uniq_gatepass,
                                gatepass_no = this.no_gatepass,
                                card_no = this.no_card
                            };
                            WBTable table = new WBTable();
                            if (this.Trans.DT.Rows.Count == 0)
                            {
                                table.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                            }
                            else
                            {
                                DataRow row = this.Trans.DT.Rows[this.nCurrRow];
                                string sqltext = "select * from wb_transaction where uniq = '" + row["uniq"].ToString() + "'";
                                table.OpenTable("wb_transaction", sqltext, WBData.conn);
                            }
                            msia.tblTrans = table;
                            msia.pMode = pMode;
                            msia.dgvTrans = this.dataGridView1;
                            msia.WX = str;
                            msia.tambahRecord = (pMode != "COPY") ? this.tambahRecord : true;
                            msia.ticketRpt = this.ticketRpt;
                            msia.rpt_advise = this.rpt_advise;
                            msia.ticket2Rpt = this.ticket2Rpt;
                            msia.fRpt = this.fRpt;
                            msia.ShowDialog();
                            if (msia.Saved)
                            {
                                this.Trans.ReOpen();
                                this.dataGridView1.DataSource = this.Trans.DT;
                                this.dataGridView1.Sort(this.dataGridView1.Columns[str3], direction);
                                string[] aField = new string[] { "Ref" };
                                string[] aFind = new string[] { msia.textRefNo.Text };
                                this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            this.Trans.UnLock();
                            msia.Dispose();
                        }
                        else
                        {
                            FormTransaction transaction = new FormTransaction {
                                nCurrRow = this.nCurrRow,
                                sUniq = pUniq,
                                gatepass_uniq = this.uniq_gatepass,
                                gatepass_no = this.no_gatepass,
                                card_no = this.no_card
                            };
                            WBTable table2 = new WBTable();
                            if (this.Trans.DT.Rows.Count == 0)
                            {
                                table2.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                            }
                            else
                            {
                                DataRow row2 = this.Trans.DT.Rows[this.nCurrRow];
                                string sqltext = "select * from wb_transaction where uniq = '" + row2["uniq"].ToString() + "'";
                                table2.OpenTable("wb_transaction", sqltext, WBData.conn);
                            }
                            transaction.tblTrans = table2;
                            transaction.pMode = pMode;
                            transaction.dgvTrans = this.dataGridView1;
                            transaction.tblDeduc = this.tblDeduc;
                            transaction.WX = str;
                            transaction.tambahRecord = (pMode != "COPY") ? this.tambahRecord : true;
                            transaction.ticketRpt = this.ticketRpt;
                            transaction.rpt_advise = this.rpt_advise;
                            transaction.ticket2Rpt = this.ticket2Rpt;
                            transaction.ticket_multi1 = this.ticket_multi1;
                            transaction.ticket_multi2 = this.ticket_multi2;
                            transaction.fRpt = this.fRpt;
                            transaction.ShowDialog();
                            if (transaction.Saved)
                            {
                                this.Trans.ReOpen();
                                this.dataGridView1.DataSource = this.Trans.DT;
                                this.dataGridView1.Sort(this.dataGridView1.Columns[str3], direction);
                                string[] aField = new string[] { "Ref" };
                                string[] aFind = new string[] { transaction.textRefNo.Text };
                                this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                            }
                            this.Trans.UnLock();
                            transaction.Dispose();
                        }
                        Cursor.Current = Cursors.Default;
                    }
                }
                else
                {
                    string str5 = "";
                    str5 = (pMode == "CANCEL") ? Resource.Mainform_031 : ((pMode == "2ND") ? Resource.Mainform_032 : ((pMode == "COPY") ? "copy" : ((pMode == "EDIT") ? Resource.Mainform_033 : ((pMode == "EDIT_OPW") ? Resource.Mainform_037 : ((pMode == "ADD_RETUR") ? Resource.Mainform_038 : "")))));
                    string[] textArray2 = new string[] { Resource.Mainform_035, " ", str5, " ", Resource.Mainform_039 };
                    MessageBox.Show(string.Concat(textArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                string str4 = "";
                str4 = (pMode == "CANCEL") ? Resource.Mainform_031 : ((pMode == "2ND") ? Resource.Mainform_032 : ((pMode == "COPY") ? "copy" : ((pMode == "EDIT") ? Resource.Mainform_033 : ((pMode == "QTY") ? Resource.Mainform_034 : ""))));
                string[] textArray1 = new string[] { Resource.Mainform_035, " ", str4, " ", Resource.Mainform_036 };
                MessageBox.Show(string.Concat(textArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("!!!");
        }

        private void timerSAPUpd_Tick(object sender, EventArgs e)
        {
            this.lblNow.Text = DateTime.Now.ToString("HH:mm");
            if (WBSetting.zwb != "Y")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_SAPDest", "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation(" AND automaticUpload = 'Y'"), WBData.conn);
                bool flag9 = false;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table.DT.Rows.Count)
                    {
                        if (flag9 && !this.backgroundWorkerSAP.IsBusy)
                        {
                            this.backgroundWorkerSAP.RunWorkerAsync();
                        }
                        table.Dispose();
                        break;
                    }
                    if (Convert.ToDateTime(this.lblNow.Text) >= Convert.ToDateTime(table.DT.Rows[num2]["automaticTime"].ToString()))
                    {
                        double num3 = Program.StrToDouble(table.DT.Rows[num2]["automaticInterval"].ToString(), 3) * 60.0;
                        this.sapD[num2, 0] = table.DT.Rows[num2]["SAPDest"].ToString();
                        if (((Convert.ToDateTime(this.lblNow.Text) - Convert.ToDateTime(table.DT.Rows[num2]["automaticTime"].ToString())).TotalMinutes % num3) >= 2.0)
                        {
                            this.sapD[num2, 1] = "N";
                        }
                        else
                        {
                            this.sapD[num2, 1] = "Y";
                            flag9 = true;
                        }
                    }
                    num2++;
                }
            }
            else if (WBSetting.SAPsch == "Y")
            {
                if (Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") == Convert.ToDateTime(WBSetting.SAPTime).ToString("HH:mm"))
                {
                    if (!this.isUpload && !this.backgroundWorkerSAP.IsBusy)
                    {
                        this.backgroundWorkerSAP.RunWorkerAsync();
                        this.updSuccess = false;
                    }
                }
                else if (Program.StrToDouble(WBSetting.SAPInterval, 3) <= 0.0)
                {
                    this.updSuccess = true;
                }
                else
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.sapJamKirim.Length)
                        {
                            break;
                        }
                        DateTime time = Convert.ToDateTime(this.sapJamKirim[index]);
                        if (Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") != time.ToString("HH:mm"))
                        {
                            this.updSuccess = true;
                        }
                        else if (!this.isUpload && !this.backgroundWorkerSAP.IsBusy)
                        {
                            this.backgroundWorkerSAP.RunWorkerAsync();
                            this.updSuccess = false;
                        }
                        index++;
                    }
                }
            }
        }

        private void timerTokenEmail_Tick(object sender, EventArgs e)
        {
            string startTime = WBSetting.startTime;
            TimeSpan span = Convert.ToDateTime(DateTime.Now.ToString("HH:mm")).Subtract(Convert.ToDateTime(Convert.ToDateTime(WBSetting.startTime).ToString("HH:mm")));
            if (((span.Hours <= 2) && (span.Hours >= 0)) && !this.isSendEmail)
            {
                this.backgroundWorkerEmail.RunWorkerAsync();
            }
        }

        private void tokenToAllowMannedWeighingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_setting", "SELECT usedForWeighing FROM wb_setting WHERE wbcode = '" + WBData.sWBCode + "' and usedForWeighing = 'Y'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("This computer is not used for weighing! Please request token from weighbridge computer!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                table.Dispose();
            }
            else
            {
                table.Dispose();
                if ((!WBSetting.activeTCS || !WBSetting.gatepass_registration) || WBSetting.gatepassWithoutCard)
                {
                    MessageBox.Show("This can't be requested because Unmanned system is not activated!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    FormTokenMannedWeighing weighing = new FormTokenMannedWeighing();
                    weighing.ShowDialog();
                    weighing.Dispose();
                }
            }
        }

        private void toleranceProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepTolerance tolerance = new RepTolerance();
            tolerance.ShowDialog();
            tolerance.Dispose();
        }

        private void toolsToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            this.refreshQCFromTCSToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_REFRESH_QC", "V");
            this.mappingTruckDestinationPerCompanyLocationToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_MAPPING_DESTINATION", "V");
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            string str = this.dataGridView1.CurrentRow.Cells["Gatepass_Number"].Value.ToString().Trim();
            if (str != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND gatepass_number = '" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    if (table.DR["Submit_Gatepass"].ToString() != "Y")
                    {
                        if (table.DR["WX"].ToString() != "1")
                        {
                            MessageBox.Show("Can't copy transaction since selected transaction used non interim weighing registration!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Can't copy transaction since truck registration has been registered out!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        return;
                    }
                }
            }
            this.Timbang("COPY");
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            this.Timbang("MANUAL");
        }

        private void toolStripMenuItem12_Click_1(object sender, EventArgs e)
        {
            RepFFBGrading grading = new RepFFBGrading {
                Text = "FFB Porla Report",
                label5 = { Text = "FFB Porla Report" },
                tableDeduction = "wb_transactionPorla"
            };
            grading.ShowDialog();
            grading.Dispose();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            this.Timbang("VIEW");
        }

        private void toolStripMenuRekapHarian_Click(object sender, EventArgs e)
        {
            RepFFBDaily daily = new RepFFBDaily();
            daily.ShowDialog();
            daily.Dispose();
        }

        private void transactionLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepTransLog log = new RepTransLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void transactionLogToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RepTransLog_New new2 = new RepTransLog_New();
            new2.ShowDialog();
            new2.Dispose();
        }

        private void transactionTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType();
            type.ShowDialog();
            type.Dispose();
        }

        private void translate()
        {
            this.registrationToolStripMenuItem.Text = Resource.Main_105;
            this.WeighingMenuItem.Text = Resource.Main_002;
            this.toolsToolStripMenuItem.Text = Resource.Main_106;
            this.masterDataToolStripMenuItem1.Text = Resource.Main_003;
            this.configurationToolStripMenuItem.Text = Resource.Main_004;
            this.ReportToolStripMenuItem.Text = Resource.Main_005;
            this.uploadSAPToolStripMenuItem.Text = Resource.Main_006 + this.sapIDSYS;
            this.logOffToolStripMenuItem.Text = Resource.Main_007;
            this.exitToolStripMenuItem.Text = Resource.Main_008;
            this.changeProfileToolStripMenuItem.Text = Resource.Main_104;
            this.schDataToolStripMenuItem.Text = Resource.Main_009;
            this.startWeighingToolStripMenuItem.Text = Resource.Main_107;
            this.stWeightToolStripMenuItem.Text = Resource.Menu_003;
            this.ndWeightToolStripMenuItem.Text = Resource.Menu_004;
            this.rdWeightToolStripMenuItem.Text = Resource._3rdWeight;
            this.thWeightToolStripMenuItem.Text = Resource._4thWeight;
            this.splitReferenceToolStripMenuItem.Text = Resource.Menu_005;
            this.mergeDOToolStripMenuItem.Text = Resource.Menu_006;
            this.toolStripMenuItem11.Text = Resource.Menu_008;
            this.ManualEntryMenuItem.Text = Resource.Menu_009;
            this.qcStripMenuItem.Text = Resource.Menu_010;
            this.DLAdoptMenuItem.Text = Resource.Menu_011;
            this.loadingQtyToolStripMenuItem.Text = Resource.Menu_063;
            this.sparePartQtyToolStripMenuItem.Text = Resource.MENU_ENTRY_SPAREPART_QTY;
            this.entryOtherPartyWeightToolStripMenuItem.Text = Resource.Menu_064;
            this.entryFFBGradingToolStripMenuItem.Text = Resource.Menu_065;
            this.entryReturToolStripMenuItem.Text = Resource.Menu_066;
            this.entryDeliveryNoteToolStripMenuItem.Text = Resource.Menu_114;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_012;
            this.editQuantityToolStripMenuItem.Text = Resource.Menu_013;
            this.cancelRecordToolStripMenuItem.Text = Resource.Menu_014;
            this.toolStripMenuItem9.Text = Resource.Menu_015;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.printLoadingUnloadingAdviseToolStripMenuItem.Text = Resource.Menu_067;
            this.repairChecksumToolStripMenuItem.Text = Resource.Menu_018;
            this.repairAllChecksumToolStripMenuItem.Text = Resource.Menu_019;
            this.viewDOToolStripMenuItem.Text = Resource.Menu_068;
            this.view4XTransactionForContainerOutToolStripMenuItem.Text = Resource.Menu_069;
            this.markAccidentToolStripMenuItem.Text = Resource.Menu_070;
            this.autoSplitDOVesselToolStripMenuItem1.Text = Resource.Menu_071;
            this.mergeAutoSplitDOVesselToolStripMenuItem1.Text = Resource.Menu_119;
            this.allowCaptureIfWeighbridgeIsNotStableToolStripMenuItem.Text = Resource.Menu_072;
            this.disableFeaturesToolStripMenuItem.Text = Resource.Menu_115;
            this.changeFlagUploadToolStripMenuItem.Text = Resource.Menu_116;
            this.flagPostedToolStripMenuItem.Text = Resource.Menu_117;
            this.flagRepostedToolStripMenuItem.Text = Resource.Menu_118;
            this.DOToolStripMenuItem.Text = Resource.Menu_020;
            this.commodityToolStripMenuItem.Text = Resource.Menu_021;
            this.relationToolStripMenuItem.Text = Resource.Menu_022;
            this.truckToolStripMenuItem.Text = Resource.Menu_023;
            this.driverToolStripMenuItem.Text = Resource.Menu_024;
            this.transpoterToolStripMenuItem.Text = Resource.Menu_025;
            this.tankerToolStripMenuItem.Text = Resource.Menu_040;
            this.coytoolStripMenuItem.Text = Resource.Menu_026;
            this.locationToolStripMenuItem.Text = Resource.Menu_027;
            this.estateToolStripMenuItem.Text = Resource.Menu_028;
            this.divisionToolStripMenuItemPOM.Text = Resource.Menu_029;
            this.blockStripMenuItemPOM.Text = Resource.Menu_030;
            this.UploadTypeToolStripMenuItem.Text = Resource.Menu_034;
            this.sAPDestinationToolStripMenuItem.Text = this.sapIDSYS + Resource.Menu_073;
            this.storageToolStripMenuItem.Text = Resource.Menu_035;
            this.gradingToolStripMenuItemPOM.Text = Resource.Menu_036;
            this.qualityToolStripMenuItem.Text = Resource.Menu_037;
            this.qCItemToolStripMenuItem.Text = Resource.Menu_038;
            this.compositToolStripMenuItem.Text = Resource.Menu_039;
            this.transactionTypeToolStripMenuItem.Text = Resource.Menu_041;
            this.templateSAPToolStripMenuItem.Text = Resource.Menu_042 + this.sapIDSYS;
            this.formulaRendemenToolStripMenuItemPOM.Text = Resource.Menu_043;
            this.mapCommTrxTypeToolStripMenuItem.Text = Resource.Menu_044;
            this.incotermToolStripMenuItem.Text = Resource.Menu_074;
            this.emailRecipientReportToolStripMenuItem.Text = Resource.Menu_109;
            this.cameraListToolStripMenuItem.Text = Resource.Menu_110;
            this.ReasonToolStripMenuItem.Text = Resource.Menu_111;
            this.wBCalibrationToolStripMenuItem.Text = Resource.Menu_112;
            this.databaseConnectionToolStripMenuItem.Text = Resource.Menu_045;
            this.weighBridgeSettingToolStripMenuItem.Text = Resource.Menu_046;
            this.weighBridgeControlToolStripMenuItem.Text = Resource.Menu_075;
            this.hardwareConfigurationToolStripMenuItem.Text = Resource.Menu_076;
            this.userListToolStripMenuItem.Text = Resource.Menu_047;
            this.userGroupToolStripMenuItem.Text = Resource.Menu_048;
            this.copyToNewCompanyToolStripMenuItem.Text = Resource.Menu_049;
            this.compareDatabaseToolStripMenuItem.Text = Resource.Menu_050;
            this.saveColumnPositionToolStripMenuItem.Text = Resource.Menu_077;
            this.loadColumnPositionToolStripMenuItem.Text = Resource.Menu_078;
            this.FFBReportToolStripMenuItemPOM.Text = Resource.Menu_051;
            this.toolStripMenuRekapHarian.Text = Resource.Menu_079;
            this.subRP1ToolStripMenuItem.Text = Resource.Menu_080;
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Text = Resource.Menu_081;
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Text = Resource.Menu_082;
            this.fFBGradingReportToolStripMenuItem.Text = Resource.Menu_083;
            this.toolStripMenuItem12.Text = Resource.Menu_084;
            this.vendorDetailToolStripMenuItem.Text = Resource.Menu_085;
            this.divisionReportToolStripMenuItem.Text = Resource.Menu_086;
            this.listOfWeighningToolStripMenuItem1.Text = Resource.Menu_052;
            this.copraReportToolStripMenuItem.Text = Resource.Menu_053;
            this.dailyReceiptSupplierToolStripMenuItem.Text = Resource.Menu_054;
            this.reportOutstandingDOToolStripMenuItem.Text = Resource.Menu_055;
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Text = Resource.Menu_056;
            this.doDetailToolStripMenuItem.Text = Resource.Menu_057;
            this.nonContractTransactionToolStripMenuItem.Text = Resource.Menu_058;
            this.qCReportToolStripMenuItem.Text = Resource.Menu_059;
            this.vendorSummaryToolStripMenuItem.Text = Resource.Menu_060;
            this.vendorDetailToolStripMenuItem.Text = Resource.Menu_087;
            this.outstandingDOPerVendorToolStripMenuItem.Text = Resource.Menu_088;
            this.failSynchronizeReportToolStripMenuItem.Text = Resource.Menu_089;
            this.toleranceProductToolStripMenuItem.Text = Resource.Menu_090;
            this.vesselReportToolStripMenuItem.Text = Resource.Menu_091;
            this.wBOwnerToolStripMenuItem.Text = Resource.Menu_092;
            this.tankerLogToolStripMenuItem.Text = Resource.Menu_093;
            this.logReportToolStripMenuItem.Text = Resource.Menu_094;
            this.transactionLogToolStripMenuItem.Text = Resource.Menu_061;
            this.masterDataLogToolStripMenuItem.Text = Resource.Menu_095;
            this.settingLogReportToolStripMenuItem.Text = Resource.Menu_096;
            this.locationLogReportToolStripMenuItem.Text = Resource.Menu_097;
            this.userListLogToolStripMenuItem.Text = Resource.Menu_098;
            this.userLoginLogoutLogToolStripMenuItem.Text = Resource.Menu_099;
            this.authorizationLogToolStripMenuItem.Text = Resource.Menu_100;
            this.templateSAPLogToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.Menu_101_IDSYS : Resource.Menu_101;
            this.commodityToleranceReportToolStripMenuItem.Text = Resource.Menu_102;
            this.tsCCTC.Text = Resource.Menu_103;
            this.indicatorStabilityReportToolStripMenuItem.Text = Resource.Menu_104;
            this.userManagementReportToolStripMenuItem.Text = Resource.Menu_105;
            this.accessRightReportToolStripMenuItem.Text = Resource.Menu_107;
            this.emailRecipientReportToolStripMenuItem.Text = Resource.Menu_108;
            this.reportOutstandingDONonTradeStoreToolStripMenuItem.Text = Resource.Menu_113;
            this.label1.Text = Resource.Main_010;
            this.buttonFind.Text = Resource.Main_026;
            this.buttonFilter.Text = Resource.Main_027;
            this.label4.Text = Resource.Main_028;
            this.label3.Text = Resource.Main_029;
            this.checkBox1.Text = Resource.Main_030;
            this.checkShowCheckSum.Text = Resource.Main_031;
            this.checkPartial.Text = Resource.Main_032;
            this.checkWBCode.Text = Resource.Main_033;
            if (WBSetting.integrationIDSYS)
            {
            }
            this.linkLabelSupport.Text = Resource.Support_01;
        }

        private void TransToLog(string pUniq, string result)
        {
            WBTable table = new WBTable();
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_trans_log", "Select * From wb_trans_log where 1=2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    foreach (DataColumn column in table2.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    table2.DR["log_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table2.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    table2.DR["Printed_By"] = WBUser.UserID.Trim();
                    table2.DR["ChangeReason"] = result;
                    table2.DR["Edit_By"] = "";
                    table2.DR["Printed_Date"] = DateTime.Now;
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }

        private void tsCCTC_Click(object sender, EventArgs e)
        {
            RepCommTol tol = new RepCommTol();
            tol.ShowDialog();
            tol.Dispose();
        }

        private void update_all_split()
        {
            string str = "";
            string str2 = "";
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString() + "'"), WBData.conn);
            this.tbl_temp.ReOpen();
            int num = 0;
            while (true)
            {
                if (num >= this.tbl_temp.DT.Rows.Count)
                {
                    this.tbl_temp.Dispose();
                    this.tbl_rlock.Dispose();
                    this.dataGridView1 = this.Trans.AfterEdit("CANCEL");
                    this.DataReset();
                    if ((WBSetting.Field("Check_Email").Trim() == "Y") & flag)
                    {
                        string[] textArray17 = new string[] { ("Dear All,<br><br>This email is to notify you that the following transaction has been cancelled :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                        string[] textArray18 = new string[] { ((string.Concat(textArray17) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + str) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + str2) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.reason, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                        WBMail mail = new WBMail();
                        mail.SendMail_Cancel((string.Concat(textArray18) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br>Thank you.");
                        mail.Dispose();
                        WBTable table5 = new WBTable();
                        table5.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                        if (table5.DT.Rows.Count <= 0)
                        {
                            table5.DR = table5.DT.NewRow();
                            table5.DR["COY"] = WBData.sCoyCode;
                            table5.DR["LOCATION_CODE"] = WBData.sLocCode;
                            table5.DR["Email_code"] = "TRANSLOG";
                            table5.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                            table5.DR["Status"] = "N";
                            table5.DT.Rows.Add(table5.DR);
                            table5.Save();
                        }
                        else if (table5.DT.Rows[0]["Status"].ToString() == "Y")
                        {
                            table5.DR = table5.DT.Rows[0];
                            table5.DR.BeginEdit();
                            table5.DR["Status"] = "N";
                            table5.DR.EndEdit();
                            table5.Save();
                        }
                        table5.Dispose();
                    }
                    return;
                }
                if (num == 0)
                {
                    str = this.tbl_temp.DT.Rows[num]["ref"].ToString();
                    str2 = this.tbl_temp.DT.Rows[num]["truck_number"].ToString();
                }
                this.tbl_temp.DT.Rows[num].BeginEdit();
                if (WBSetting.Field("GM") != "Y")
                {
                    this.tbl_temp.DT.Rows[num]["deleted"] = "Y";
                    this.tbl_temp.DT.Rows[num]["posted"] = "N";
                    this.tbl_temp.DT.Rows[num]["cancel_type"] = "C";
                    this.tbl_temp.DT.Rows[num]["cancel_reason"] = this.reason;
                    this.tbl_temp.DT.Rows[num]["Delete_By"] = WBUser.UserID.Trim();
                    this.tbl_temp.DT.Rows[num]["Delete_Date"] = Program.DTOC(DateTime.Now);
                    this.tbl_temp.DT.Rows[num]["ChangeReason"] = this.reason;
                    this.tbl_temp.DT.Rows[num]["checksum"] = this.tbl_temp.Checksum_Main(this.tbl_temp.DT.Rows[num]);
                    this.tbl_temp.DT.Rows[num].EndEdit();
                    this.tbl_temp.Save();
                    flag = true;
                }
                else if (this.tbl_temp.DT.Rows[num]["ref"].ToString().Trim() == this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim())
                {
                    if ((this.token_in_progress != "Y") && (this.reason != ""))
                    {
                        this.tbl_temp.DT.Rows[num]["deleted"] = "Y";
                        this.tbl_temp.DT.Rows[num]["posted"] = "N";
                        this.tbl_temp.DT.Rows[num]["cancel_type"] = "C";
                        this.tbl_temp.DT.Rows[num]["cancel_reason"] = this.reason;
                        this.tbl_temp.DT.Rows[num]["ChangeReason"] = this.reason;
                        this.tbl_temp.DT.Rows[num]["Delete_By"] = WBUser.UserID.Trim();
                        this.tbl_temp.DT.Rows[num]["Delete_Date"] = Program.DTOC(DateTime.Now);
                        this.tbl_temp.DT.Rows[num]["checksum"] = this.tbl_temp.Checksum_Main(this.tbl_temp.DT.Rows[num]);
                        this.tbl_temp.DT.Rows[num].EndEdit();
                        this.tbl_temp.Save();
                        flag = true;
                    }
                }
                else
                {
                    this.tbl_temp.DT.Rows[num]["token"] = table.DT.Rows[0]["token"].ToString().Trim();
                    this.tbl_temp.DT.Rows[num]["completed"] = table.DT.Rows[0]["completed"].ToString().Trim();
                    if ((this.token_in_progress != "Y") && (this.reason != ""))
                    {
                        this.tbl_temp.DT.Rows[num]["deleted"] = "Y";
                        this.tbl_temp.DT.Rows[num]["cancel_type"] = "C";
                        this.tbl_temp.DT.Rows[num]["cancel_reason"] = this.reason;
                        this.tbl_temp.DT.Rows[num]["posted"] = "N";
                        this.tbl_temp.DT.Rows[num]["ChangeReason"] = this.reason;
                        this.tbl_temp.DT.Rows[num]["Delete_By"] = WBUser.UserID.Trim();
                        this.tbl_temp.DT.Rows[num]["Delete_Date"] = Program.DTOC(DateTime.Now);
                        flag = true;
                    }
                    this.tbl_temp.DT.Rows[num]["checksum"] = this.tbl_temp.Checksum_Main(this.tbl_temp.DT.Rows[num]);
                    this.tbl_temp.DT.Rows[num].EndEdit();
                    this.tbl_temp.Save();
                }
                this.tbl_temp.RLock(this.tbl_temp.DT.Rows[num]["Uniq"].ToString().Trim(), false);
                if (!flag)
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Cancel transaction is cancelled" };
                    Program.updateLogHeader("wb_transaction", this.tbl_temp.DT.Rows[num]["uniq"].ToString(), logField, logValue);
                }
                else
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "CANCEL", WBUser.UserID, this.reason };
                    Program.updateLogHeader("wb_transaction", this.tbl_temp.DT.Rows[num]["uniq"].ToString(), logField, logValue);
                    if (WBSetting.gatepass_registration)
                    {
                        string keyField = "";
                        WBTable table3 = new WBTable();
                        string[] textArray3 = new string[] { "SELECT * FROM wb_gatepass WHERE gatepass_number = '", this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString(), "' AND ref = '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "'" };
                        table3.OpenTable("WB_COMPANY", string.Concat(textArray3), WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            table3.DR = table3.DT.Rows[0];
                            keyField = table3.DR["uniq"].ToString();
                            if (!WBSetting.activeTCS)
                            {
                                table3.DR = table3.DT.Rows[0];
                                keyField = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                table3.DR["ref"] = "";
                                table3.DR["Change_By"] = WBUser.UserID;
                                table3.DR["Change_Date"] = DateTime.Now;
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray12 = new string[] { "EDIT", WBUser.UserID, "Delete reference no because it's been cancelled" };
                                Program.updateLogHeader("wb_gatepass", keyField, textArray11, textArray12);
                            }
                            else if (table3.DR["WX"].ToString() != "1")
                            {
                                table3.DR.BeginEdit();
                                table3.DR["ref"] = "";
                                table3.DR["Change_By"] = WBUser.UserID;
                                table3.DR["Change_Date"] = DateTime.Now;
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] textArray9 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray10 = new string[] { "EDIT", WBUser.UserID, "Delete reference no because it's been cancelled" };
                                Program.updateLogHeader("wb_gatepass", keyField, textArray9, textArray10);
                            }
                            else
                            {
                                WBTable table4 = new WBTable();
                                string[] textArray4 = new string[] { "SELECT ref FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString(), "'  AND ref != '", this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString(), "' AND (deleted != 'Y' OR deleted IS NULL)" };
                                table4.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
                                if (table4.DT.Rows.Count > 0)
                                {
                                    table3.DR.BeginEdit();
                                    table3.DR["ref"] = table4.DT.Rows[0]["ref"].ToString();
                                    table3.DR["Change_By"] = WBUser.UserID;
                                    table3.DR["Change_Date"] = DateTime.Now;
                                    table3.DR.EndEdit();
                                    table3.Save();
                                    string[] textArray5 = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] textArray6 = new string[] { "EDIT", WBUser.UserID, "Change reference no because old one has been cancelled" };
                                    Program.updateLogHeader("wb_gatepass", keyField, textArray5, textArray6);
                                }
                                else
                                {
                                    table3.DR.BeginEdit();
                                    table3.DR["ref"] = "";
                                    table3.DR["Change_By"] = WBUser.UserID;
                                    table3.DR["Change_Date"] = DateTime.Now;
                                    table3.DR.EndEdit();
                                    table3.Save();
                                    string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] textArray8 = new string[] { "EDIT", WBUser.UserID, "Delete reference no because it's been cancelled" };
                                    Program.updateLogHeader("wb_gatepass", keyField, textArray7, textArray8);
                                }
                                table4.Dispose();
                            }
                        }
                        table3.Dispose();
                    }
                    Program.unblock_os_bc(this.tbl_temp.DT.Rows[num]["do_no"].ToString().Trim(), this.tbl_temp.DT.Rows[num]["ref"].ToString().Trim());
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND linked = '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        string keyField = "";
                        table2.DR = table2.DT.Rows[0];
                        keyField = table2.DR["uniq"].ToString();
                        table2.DR.BeginEdit();
                        table2.DR["linked"] = "";
                        table2.DR["checksum"] = table2.Checksum(table2.DR);
                        table2.DR.EndEdit();
                        table2.Save();
                        string[] textArray13 = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] textArray14 = new string[] { "EDIT", WBUser.UserID, "Delete linked reference no because it's been cancelled" };
                        Program.updateLogHeader("wb_transaction", keyField, textArray13, textArray14);
                    }
                    table2.Dispose();
                }
                num++;
            }
        }

        private void updatePrinted(bool cek)
        {
            int num = 0;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " select * from wb_transaction where  coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' and uniq = ", this.pUnq.Trim() };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            table.DR = table.DT.Rows[0];
            num = (table.DR["printed"].ToString().Trim() == "") ? 0 : Convert.ToInt32(table.DR["printed"].ToString());
            table.DR.BeginEdit();
            if (cek)
            {
                num++;
            }
            table.DR["printed"] = num;
            table.DR["Printed_By"] = WBUser.UserID.Trim();
            table.DR["Printed_Date"] = DateTime.Now;
            table.DR["checksum"] = table.Checksum_Main(table.DR);
            table.DR.EndEdit();
            table.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "REPRINT", WBUser.UserID, this._result };
            Program.updateLogHeader("wb_transaction", table.DR["uniq"].ToString(), logField, logValue);
            table.Dispose();
        }

        private void updatePrintingLogHeader(DataRow rTemp)
        {
            string keyField = rTemp["uniq"].ToString();
            rTemp.BeginEdit();
            rTemp["printed"] = Program.StrToDouble(rTemp["printed"].ToString(), 0);
            rTemp["Printed_By"] = WBUser.UserID.Trim();
            rTemp["Printed_Date"] = DateTime.Now;
            rTemp.EndEdit();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "REPRINT", WBUser.UserID, "Print Gatepass" };
            Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
        }

        private void uploadSAP()
        {
            this.isUpload = true;
            string str = "1";
            string str2 = "MM";
            if (WBSetting.zwb == "Y")
            {
                str2 = "ZWB";
                str = "1";
            }
            FormUploadZWB dzwb = new FormUploadZWB {
                module = str2,
                type = str
            };
            if (WBSetting.zwb == "Y")
            {
                dzwb.sapDest = "ZWB";
            }
            dzwb.auto = 'Y';
            dzwb.initTransFlag();
            dzwb.initTable();
            dzwb.selectAll();
            dzwb.btnUpload();
            this.autoUpd = false;
            this.updSuccess = true;
            this.isUpload = false;
            dzwb.Dispose();
        }

        private void uploadSAPExceptZWB()
        {
            for (int i = 0; i < this.sapD.GetLength(0); i++)
            {
                if (this.sapD[i, 1] == "Y")
                {
                    FormUploadSAP dsap = new FormUploadSAP {
                        module = this.sapD[i, 0],
                        sapDest = this.sapD[i, 0],
                        auto = 'Y'
                    };
                    if ((this.sapD[i, 0] == "ZPOM") || (this.sapD[i, 0] == "ZMY_UPLOADFFB"))
                    {
                        dsap.tipeTrans = "I";
                    }
                    if (((this.sapD[i, 0] == "ZMM_UPLOAD") || (this.sapD[i, 0] == "ZMM_UPLOADSTM")) || (this.sapD[i, 0] == "ZMM_UPLOADSTM_RCV"))
                    {
                        dsap.tipeTrans = "O";
                    }
                    dsap.initTransFlag();
                    dsap.initTable();
                    dsap.cField = (WBData.sRegion != "1") ? WBTable.cFieldTrans : WBTable.cFieldTransAfrica;
                    dsap.selectAll();
                    dsap.btnUpload();
                    dsap.exitToolStripMenuItem.PerformClick();
                    dsap.Dispose();
                }
            }
        }

        private void uploadSAPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUpload upload = new FormUpload();
            upload.ShowDialog();
            upload.Dispose();
        }

        private void UploadTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUploadType type = new FormUploadType {
                Text = "List of Upload Type"
            };
            type.ShowDialog();
            type.Dispose();
        }

        private void userGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormUserGroup().ShowDialog();
        }

        private void userListLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "User List Log Report",
                labelHeader = { Text = "Log of User List" },
                labelMasterData = { Text = "Log for: " },
                flag = "USER LIST"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void userListReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RepUserList().generateRep();
        }

        private void userListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormUser().ShowDialog();
        }

        private void userLoginLogoutLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepLoginLogout logout = new RepLoginLogout();
            logout.ShowDialog();
            logout.Dispose();
        }

        private void userManagementReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void vendorDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepVendorDetail detail = new RepVendorDetail();
            detail.ShowDialog();
            detail.Dispose();
        }

        private void vendorSummaryTBSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBVendorSummary summary = new RepFFBVendorSummary();
            summary.ShowDialog();
            summary.Dispose();
        }

        private void vendorSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepVendorSummary summary = new RepVendorSummary();
            summary.ShowDialog();
            summary.Dispose();
        }

        private void vesselReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepVessel vessel = new RepVessel();
            vessel.ShowDialog();
            vessel.Dispose();
        }

        private void view4XTransactionForContainerOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTransactionContainerOut @out = new FormTransactionContainerOut();
            @out.ShowDialog();
            @out.Dispose();
        }

        private void viewDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTransDO_View view = new FormTransDO_View {
                textDO = { Text = this.doviewDO_No },
                textRefNo = { Text = this.doviewRefNo },
                textRelation = { Text = this.doviewRelation },
                textCommodity = { Text = this.doviewComm },
                textPI_No = { Text = this.doviewPI_No },
                doviewFirsttime = this.doviewFirsttime
            };
            view.ShowDialog();
            this.doviewDO_No = view.textDO.Text;
            this.doviewRefNo = view.textRefNo.Text;
            this.doviewRelation = view.textRelation.Text;
            this.doviewComm = view.textCommodity.Text;
            this.doviewPI_No = view.textPI_No.Text;
            this.doviewFirsttime = view.doviewFirsttime;
            if (view.fMode == "FIND")
            {
                try
                {
                    string[] aField = new string[] { "Ref" };
                    string[] aFind = new string[] { view.fNoRef };
                    this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                catch
                {
                }
            }
            view.Dispose();
        }

        private void ViewSparepartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.TblReportdate.OpenTable("wb_transaction", "SELECT report_date FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref like '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "%'"), WBData.conn);
            WBTable table = new WBTable();
            if (this.TblReportdate.DT.Rows[0]["report_date"].ToString() != "")
            {
                table.OpenTable("vw_reportbc", "SELECT * FROM vw_reportbc WHERE " + WBData.CompanyLocation(" AND ref = '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "'"), WBData.conn);
            }
            else
            {
                table.OpenTable("vw_reportbc", "SELECT * FROM vw_reportbc WHERE " + WBData.CompanyLocation(" AND ref like '" + this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString() + "%'"), WBData.conn);
            }
            if (table.DT.Rows.Count != 0.0)
            {
                HTML rep = new HTML();
                rep.File = rep.File + @"\" + WBUser.UserID + "_RecIssue.htm";
                rep.Title = "";
                rep.Open();
                rep.Write(rep.Style());
                rep.Write("<br>");
                rep.Write("<br><br><font size=5><b>View SPAREPART</b></font><br>");
                string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                rep.Write(string.Concat(textArray1));
                string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                rep.Write(string.Concat(textArray2));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
                rep.Write("<br><br>");
                List<string> list = new List<string>();
                rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                foreach (DataRow row in table.DT.Rows)
                {
                    if (!list.Contains(row["STO"].ToString() + "/" + row["STO_Item"].ToString()))
                    {
                        list.Add(row["STO"].ToString() + "/" + row["STO_Item"].ToString());
                        int jumlahbaris = 1;
                        foreach (DataRow row2 in table.DT.Rows)
                        {
                            if ((row["STO"].ToString() == row2["STO"].ToString()) && (row["STO_Item"].ToString() == row2["STO_Item"].ToString()))
                            {
                                this.fillTable(rep, row2, jumlahbaris);
                            }
                            jumlahbaris++;
                        }
                    }
                }
                rep.Write("</table>");
                rep.Write("<br><br><br>");
                rep.Close();
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                };
                report.ShowDialog();
                rep.Dispose();
                report.Dispose();
            }
            else
            {
                MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void wBCalibrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormWBCalibration calibration = new FormWBCalibration();
            calibration.ShowDialog();
            calibration.Dispose();
        }

        private void wBOwnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.tbl_Loc2.OpenTable("wb_Location", "select distinct loc.coy, loc.Location_Code, sett.Coy_Name, loc.Location_Name, loc.wbowner from wb_location as loc left outer join wb_setting as sett on sett.coy = loc.coy and sett.location_code = loc.location_code where sett.Coy_Name <> ''", WBData.conn);
            HTML html = new HTML();
            html = this.generateRep(this.tbl_Loc2);
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + html.File) }
            };
            report.ShowDialog();
            html.Dispose();
            report.Dispose();
        }

        private void weighBridgeControlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!(WBUser.CheckTrustee("MD_CONTROL", "E") || WBUser.CheckTrustee("MD_CONTROL", "V")))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDeepSetting setting = new FormDeepSetting();
                setting.ShowDialog();
                setting.Dispose();
            }
        }

        private void weighBridgeSettingToolStripMenuItem_CheckStateChanged(object sender, EventArgs e)
        {
        }

        private void weighBridgeSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSetting setting = new FormSetting();
            setting.ShowDialog();
            WBSetting.ReOpen();
            int num = 0;
            if (Program.StrToDouble(WBSetting.SAPInterval, 3) > 0.0)
            {
                num = Convert.ToInt16((double) (24.0 / Program.StrToDouble(WBSetting.SAPInterval, 3)));
                string[] strArray = new string[num];
                int index = 0;
                while (true)
                {
                    if (index >= num)
                    {
                        this.sapJamKirim = strArray;
                        this.timerSAPUpd.Enabled = true;
                        this.timerSAPUpd.Interval = 0xea60;
                        break;
                    }
                    DateTime time = Convert.ToDateTime(WBSetting.startTime).AddHours(index * Program.StrToDouble(WBSetting.SAPInterval, 3));
                    strArray[index] = Convert.ToString(time);
                    index++;
                }
            }
            if (setting.saved)
            {
                WBSetting.ReOpen();
                this.f_load();
                if (setting.reloadTicket)
                {
                    FormMessage message = new FormMessage {
                        label1 = { Text = "Preparing . . . . . . ." }
                    };
                    this.ticketRpt.Load(WBSetting.ticket);
                    this.rpt_advise.Load(WBSetting.loading_advise);
                    if (File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine1.rpt") && File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine2.rpt"))
                    {
                        this.ticket_multi1.Load(WBSetting.ticket_MultiLine1);
                        this.ticket_multi1 = Program.rptLogon(this.ticket_multi1);
                        this.ticket_multi2.Load(WBSetting.ticket_MultiLine2);
                        this.ticket_multi2 = Program.rptLogon(this.ticket_multi2);
                    }
                    this.ticketLangsir.Load(WBSetting.ticketLangsir);
                    this.ticketLangsir = Program.rptLogon(this.ticketLangsir);
                    this.ticketLangsir2.Load(WBSetting.ticketLangsir2);
                    this.ticketLangsir2 = Program.rptLogon(this.ticketLangsir2);
                    message.Show();
                    this.ticketRpt = Program.rptLogon(this.ticketRpt);
                    this.rpt_advise = Program.rptLogon(this.rpt_advise);
                    message.label1.Text = "Application is Ready";
                    message.Close();
                    message.Dispose();
                }
            }
        }

        private void WeighingMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            this._weighMenuActivate();
            this.editDeductionToolStripMenuItem.Text = (WBSetting.locType == "0") ? Resource.Menu_013a : Resource.Menu_013b;
        }
    }
}

