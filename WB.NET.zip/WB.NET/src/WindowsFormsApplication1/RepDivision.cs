﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepDivision : Form
    {
        public Button button1;
        public Button button2;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public Button buttonDoNo;
        public Label labelDoNo;
        public TextBox textDoNo;
        public Button buttonRelation;
        public Label label1;
        public TextBox textRelation;
        public Button buttonEstate;
        public Label label2;
        public TextBox textEstate;
        public DateTimePicker monthCalendar2;
        private WBTable tbl_Do;
        private WBTable tbl_Relation;
        private WBTable tbl_Estate;
        public Label labelRecNo;
        public Label labelProcess;
        public Label label3;
        public Button buttonDivision;
        public Label label4;
        public TextBox textDivision;
        private CheckBox checkBox1;
        public Label label7;
        private ComboBox comboCom;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;
        private int no;

        public RepDivision()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.comboCom.Text.Trim() == "")
            {
                MessageBox.Show("Please choose commodity!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboCom.Focus();
            }
            else
            {
                string str;
                string str2;
                string str3;
                string str4;
                string str5;
                string str6;
                int index = 0;
                string[] source = new string[5];
                foreach (Control control in this.groupFType.Controls)
                {
                    CheckBox box = control as CheckBox;
                    if ((box != null) && box.Checked)
                    {
                        source[index] = box.Text;
                        index++;
                    }
                }
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                HTML html = new HTML();
                ViewReport report = new ViewReport();
                if (!this.checkBox1.Checked)
                {
                    str2 = " Ref, report_date, ref_date, Estate, Do_No, Relation_code, delivery_note, Truck_Number, netto ";
                    string[] textArray6 = new string[] { " and (report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and  report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                    str = (("Select " + str2 + " from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray6))) + " and (Comm_Code = '" + this.comboCom.Text.Trim() + "') ") + " and (deleted is null or deleted = 'N' or deleted = '') ";
                    if (this.rboGI.Checked)
                    {
                        str = str + " and vw_trans.IO = 'O' ";
                    }
                    else if (this.rboGR.Checked)
                    {
                        str = str + " and vw_trans.IO = 'I' ";
                    }
                    if (this.textRelation.Text.Trim() != "")
                    {
                        str = str + " and (relation_code = '" + this.textRelation.Text.Trim() + "') ";
                    }
                    if (this.textDoNo.Text.Trim() != "")
                    {
                        str = str + " and (Do_No = '" + this.textDoNo.Text.Trim() + "') ";
                    }
                    if (this.textEstate.Text.Trim() != "")
                    {
                        str = str + " and (Estate = '" + this.textEstate.Text.Trim() + "') ";
                    }
                    if (index <= 0)
                    {
                        str = str + " and (Fruits_type = '' or Fruits_type is null) ";
                    }
                    else
                    {
                        int num9 = 0;
                        while (true)
                        {
                            if (num9 >= source.Count<string>())
                            {
                                str = str + " ) ";
                                break;
                            }
                            if (source[num9] != "")
                            {
                                str = (num9 != 0) ? (str + " or Fruits_type = '" + source[num9] + "' ") : (str + " and ( Fruits_type = '" + source[num9] + "' ");
                            }
                            num9++;
                        }
                    }
                    str = str + " Order by Ref  ";
                    table.OpenTable("vw_trans", str, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        this.labelRecNo.Visible = true;
                        this.labelProcess.Visible = true;
                        int count = table.DT.Rows.Count;
                        this.labelRecNo.Text = "0/" + count.ToString();
                        this.labelRecNo.Refresh();
                        this.labelProcess.Refresh();
                        html.File = html.File + @"\" + WBUser.UserID + "_Division.htm";
                        html.Title = "Division Report";
                        html.Open();
                        html.Write(html.Style());
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_commodity", "SELECT comm_name FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.comboCom.Text.Trim() + "'"), WBData.conn);
                        table3.DR = table3.DT.Rows[0];
                        html.Write("<br><font size=5><b>DIVISION REPORT FOR " + table3.DR["comm_name"].ToString().ToUpper() + "</b></font><br>");
                        string[] textArray7 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                        html.Write(string.Concat(textArray7));
                        string[] textArray8 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                        html.Write(string.Concat(textArray8));
                        if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                        }
                        html.Write("<br><br>");
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        string[] textArray9 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                        html.Write(string.Concat(textArray9));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Commodity</td>");
                        html.Write("<td>: <b>" + this.comboCom.Text + "</b></td>");
                        html.Write("</tr>");
                        if (this.textRelation.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Relation Code</td>");
                            html.Write("<td>: <b>" + this.textRelation.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textDoNo.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>DO/SO No</td>");
                            html.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textEstate.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Estate Code</td>");
                            html.Write("<td>: <b>" + this.textEstate.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap align=center><b>No</b></td>");
                        html.Write("<td nowrap align=center><b>Date</b></td>");
                        html.Write("<td nowrap align=center><b>Estate</b></td>");
                        html.Write("<td nowrap align=center><b>Division</b></td>");
                        html.Write("<td nowrap align=center><b>Block</b></td>");
                        html.Write("<td nowrap align=center><b>Year Of Planting</b></td>");
                        html.Write("<td nowrap align=center><b>Delivery Note</b></td>");
                        html.Write("<td nowrap align=center><b>WB Ref</b></td>");
                        html.Write("<td nowrap align=center><b>Vehicle Number</b></td>");
                        html.Write("<td nowrap align=center><b>Netto</b></td>");
                        html.Write("</tr>");
                        this.no = 0;
                        foreach (DataRow row2 in table.DT.Rows)
                        {
                            str4 = "";
                            str5 = "";
                            str6 = "";
                            this.no++;
                            str3 = row2["Ref"].ToString();
                            table2.OpenTable("wb_transDiv", "Select * from wb_transDivision where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                            foreach (DataRow row3 in table2.DT.Rows)
                            {
                                str4 = str4 + row3["Division_code"].ToString() + " , ";
                                str6 = str6 + row3["Block_code"].ToString() + " , ";
                                str5 = str5 + row3["YearPlanting"].ToString() + " , ";
                            }
                            if (table2.DT.Rows.Count > 0)
                            {
                                str4 = str4.Substring(0, str4.Length - 3);
                                str6 = str6.Substring(0, str6.Length - 3);
                                str5 = str5.Substring(0, str5.Length - 3);
                            }
                            this.labelRecNo.Text = this.no.ToString() + "/" + table.DT.Rows.Count.ToString();
                            this.labelRecNo.Refresh();
                            html.Write("<tr class='bd'>");
                            html.Write("<td nowrap >" + this.no.ToString() + "</td>");
                            html.Write("<td nowrap >" + row2["Report_date"].ToString().Substring(0, 10) + "</td>");
                            html.Write("<td nowrap >" + html.strq(row2["Estate"].ToString()) + "</td>");
                            html.Write("<td align = center >" + html.strq(str4) + "</td>");
                            html.Write("<td align = center >" + html.strq(str6) + "</td>");
                            html.Write("<td align = center >" + html.strq(str5) + "</td>");
                            html.Write("<td nowrap >" + html.strq(row2["Delivery_note"].ToString()) + "</td>");
                            html.Write("<td nowrap >" + row2["Ref"].ToString() + "</td>");
                            html.Write("<td nowrap align = center >" + row2["Truck_number"].ToString() + "</td>");
                            html.Write("<td nowrap align = right >" + $"{Convert.ToDouble(row2["Netto"].ToString()):N0}" + "</td>");
                            html.Write("</tr>");
                        }
                        html.Write("</table> <br> <br> <br>");
                        html.writeSign();
                        html.Close();
                        table3.Dispose();
                        report.webBrowser1.Url = new Uri("file:///" + html.File);
                        report.ShowDialog();
                        html.Dispose();
                        report.Dispose();
                    }
                }
                else
                {
                    str2 = " vw_trans.Ref, vw_trans.report_date, vw_trans.ref_date, vw_trans.Estate, wb_transDivision.Division_Code, wb_transDivision.Block_Code, wb_transDivision.YearPlanting, wb_transDivision.Weight, vw_trans.Do_No, vw_trans.Relation_code, vw_trans.delivery_note, vw_trans.Truck_Number, vw_trans.netto ";
                    string[] textArray1 = new string[11];
                    textArray1[0] = "Select ";
                    textArray1[1] = str2;
                    textArray1[2] = " from vw_trans, wb_transDivision where (vw_trans.Coy='";
                    textArray1[3] = WBData.sCoyCode;
                    textArray1[4] = "' and vw_trans.Location_Code='";
                    textArray1[5] = WBData.sLocCode;
                    textArray1[6] = "') and (vw_trans.report_date >= '";
                    textArray1[7] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
                    textArray1[8] = " 00:00:00' and  vw_trans.report_date <= '";
                    textArray1[9] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
                    textArray1[10] = " 00:00:00')";
                    str = (string.Concat(textArray1) + " and (vw_trans.comm_code = '" + this.comboCom.Text.Trim() + "')") + " and (vw_trans.deleted is null or vw_trans.deleted = 'N' or vw_trans.deleted = '') " + " AND vw_trans.Ref = wb_transDivision.Ref ";
                    if (this.rboGI.Checked)
                    {
                        str = str + " and vw_trans.IO = 'O' ";
                    }
                    else if (this.rboGR.Checked)
                    {
                        str = str + " and vw_trans.IO = 'I' ";
                    }
                    if (this.textRelation.Text.Trim() != "")
                    {
                        str = str + " and (vw_trans.relation_code = '" + this.textRelation.Text.Trim() + "') ";
                    }
                    if (this.textDoNo.Text.Trim() != "")
                    {
                        str = str + " and (vw_trans.Do_No = '" + this.textDoNo.Text.Trim() + "') ";
                    }
                    if (this.textEstate.Text.Trim() != "")
                    {
                        str = str + " and (vw_trans.Estate = '" + this.textEstate.Text.Trim() + "') ";
                    }
                    if (this.textDivision.Text.Trim() != "")
                    {
                        str = str + " and (vw_trans.Division_Code = '" + this.textDivision.Text.Trim() + "') ";
                    }
                    if (index <= 0)
                    {
                        str = str + " and (Fruits_type = '' or Fruits_type is null) ";
                    }
                    else
                    {
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= source.Count<string>())
                            {
                                str = str + " ) ";
                                break;
                            }
                            if (source[num6] != "")
                            {
                                str = (num6 != 0) ? (str + " or Fruits_type = '" + source[num6] + "' ") : (str + " and ( Fruits_type = '" + source[num6] + "' ");
                            }
                            num6++;
                        }
                    }
                    str = str + "Order by vw_trans.Estate, wb_transDivision.Division_Code, wb_transDivision.Block_Code, vw_trans.Ref  ";
                    table.OpenTable("vw_trans", str, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        this.labelRecNo.Visible = true;
                        this.labelProcess.Visible = true;
                        this.labelRecNo.Text = "0/" + table.DT.Rows.Count.ToString();
                        this.labelRecNo.Refresh();
                        this.labelProcess.Refresh();
                        html.File = html.File + WBUser.UserID + "_Division.htm";
                        html.Title = "Division Report";
                        html.Open();
                        html.Write(html.Style());
                        html.Write("<br><font size=5><b>DIVISION REPORT</b></font><br>");
                        string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                        html.Write(string.Concat(textArray2));
                        string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                        html.Write(string.Concat(textArray3));
                        if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                        }
                        html.Write("<br><br>");
                        string str7 = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.comboCom.Text);
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Commodity</td>");
                        string[] textArray4 = new string[] { "<td>: <b>", this.comboCom.Text, " - ", str7, "</b></td>" };
                        html.Write(string.Concat(textArray4));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        string[] textArray5 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                        html.Write(string.Concat(textArray5));
                        html.Write("</tr>");
                        if (this.textRelation.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Relation Code</td>");
                            html.Write("<td>: <b>" + this.textRelation.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textDoNo.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>DO/SO No</td>");
                            html.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textEstate.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Estate Code</td>");
                            html.Write("<td>: <b>" + this.textEstate.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textDivision.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Division Code</td>");
                            html.Write("<td>: <b>" + this.textDivision.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap align=center><b>No</b></td>");
                        html.Write("<td nowrap align=center><b>Date</b></td>");
                        html.Write("<td nowrap align=center><b>Estate</b></td>");
                        html.Write("<td nowrap align=center><b>Division</b></td>");
                        html.Write("<td nowrap align=center><b>Block</b></td>");
                        html.Write("<td nowrap align=center><b>Year Of Planting</b></td>");
                        html.Write("<td nowrap align=center><b>Delivery Note</b></td>");
                        html.Write("<td nowrap align=center><b>WB Ref</b></td>");
                        html.Write("<td nowrap align=center><b>Vehicle Number</b></td>");
                        html.Write("<td nowrap align=center><b>Netto in Block</b></td>");
                        html.Write("</tr>");
                        this.no = 0;
                        double num3 = 0.0;
                        double num4 = 0.0;
                        double num5 = 0.0;
                        string str8 = "";
                        string str9 = "";
                        foreach (DataRow row in table.DT.Rows)
                        {
                            str4 = "";
                            this.no++;
                            str3 = row["Ref"].ToString();
                            table2.OpenTable("wb_transDiv", "Select * from wb_transDivision where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                            str4 = str4 + row["Division_code"].ToString();
                            str6 = "" + row["Block_code"].ToString();
                            str5 = "" + row["YearPlanting"].ToString();
                            if ((str8 != "") && (str8 != str6))
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td colspan = 9 nowrap align = left ><b>TOTAL BLOCK</b></td>");
                                html.Write("<td nowrap align = right ><b>" + $"{Convert.ToDouble(num3.ToString()):N0}" + "</b></td>");
                                html.Write("</tr>");
                                num3 = 0.0;
                            }
                            str8 = str6;
                            if ((str9 != "") && (str9 != str4))
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td colspan = 9 nowrap align = left ><b>TOTAL DIVISION</b></td>");
                                html.Write("<td nowrap align = right ><b>" + $"{Convert.ToDouble(num4.ToString()):N0}" + "</b></td>");
                                html.Write("</tr>");
                                html.Write("</table> <br>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td nowrap align=center><b>No</b></td>");
                                html.Write("<td nowrap align=center><b>Date</b></td>");
                                html.Write("<td nowrap align=center><b>Estate</b></td>");
                                html.Write("<td nowrap align=center><b>Division</b></td>");
                                html.Write("<td nowrap align=center><b>Block</b></td>");
                                html.Write("<td nowrap align=center><b>Year Of Planting</b></td>");
                                html.Write("<td nowrap align=center><b>Delivery Note</b></td>");
                                html.Write("<td nowrap align=center><b>WB Ref</b></td>");
                                html.Write("<td nowrap align=center><b>Vehicle Number</b></td>");
                                html.Write("<td nowrap align=center><b>Netto in Block</b></td>");
                                html.Write("</tr>");
                                this.no = 1;
                                num4 = 0.0;
                                num3 = 0.0;
                            }
                            str9 = str4;
                            this.labelRecNo.Text = this.no.ToString() + "/" + table.DT.Rows.Count.ToString();
                            this.labelRecNo.Refresh();
                            html.Write("<tr class='bd'>");
                            html.Write("<td nowrap >" + this.no.ToString() + "</td>");
                            html.Write("<td nowrap >" + row["Report_date"].ToString().Substring(0, 10) + "</td>");
                            html.Write("<td nowrap >" + html.strq(row["Estate"].ToString()) + "</td>");
                            html.Write("<td align = center >" + html.strq(str4) + "</td>");
                            html.Write("<td align = center >" + html.strq(str6) + "</td>");
                            html.Write("<td align = center >" + html.strq(str5) + "</td>");
                            html.Write("<td nowrap >" + html.strq(row["Delivery_note"].ToString()) + "</td>");
                            html.Write("<td nowrap >" + row["Ref"].ToString() + "</td>");
                            html.Write("<td nowrap align = center >" + row["Truck_number"].ToString() + "</td>");
                            double num8 = (Convert.ToDouble(row["Weight"].ToString()) == 0.0) ? Convert.ToDouble(row["netto"].ToString()) : Convert.ToDouble(row["Weight"].ToString());
                            html.Write("<td nowrap align = right >" + $"{num8:N0}" + "</td>");
                            html.Write("</tr>");
                            num5 += num8;
                            num4 += num8;
                            num3 += num8;
                        }
                        if (table.DT.Rows.Count > 0)
                        {
                            html.Write("<tr class='bd'>");
                            html.Write("<td colspan = 9 nowrap align = left ><b>TOTAL BLOCK</b></td>");
                            html.Write("<td nowrap align = right ><b>" + $"{Convert.ToDouble(num3.ToString()):N0}" + "</b></td>");
                            html.Write("</tr>");
                            html.Write("<tr class='bd'>");
                            html.Write("<td colspan = 9 nowrap align = left ><b>TOTAL DIVISION</b></td>");
                            html.Write("<td nowrap align = right ><b>" + $"{Convert.ToDouble(num4.ToString()):N0}" + "</b></td>");
                            html.Write("</tr>");
                            html.Write("<tr class='bd'>");
                            html.Write("<td colspan = 9 nowrap align = left ><b>GRAND TOTAL</b></td>");
                            html.Write("<td nowrap align = right ><b>" + $"{Convert.ToDouble(num5.ToString()):N0}" + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("</table> <br> <br> <br>");
                        html.writeSign();
                        html.Close();
                        report.webBrowser1.Url = new Uri("file:///" + html.File);
                        report.ShowDialog();
                        html.Dispose();
                        report.Dispose();
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["estate_code"].ToString();
            }
            estate.Dispose();
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.button2 = new Button();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.buttonDoNo = new Button();
            this.labelDoNo = new Label();
            this.textDoNo = new TextBox();
            this.buttonRelation = new Button();
            this.label1 = new Label();
            this.textRelation = new TextBox();
            this.buttonEstate = new Button();
            this.label2 = new Label();
            this.textEstate = new TextBox();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.label3 = new Label();
            this.buttonDivision = new Button();
            this.label4 = new Label();
            this.textDivision = new TextBox();
            this.checkBox1 = new CheckBox();
            this.label7 = new Label();
            this.comboCom = new ComboBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            base.SuspendLayout();
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x131, 0x13c);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1a7, 0x13d);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(0x13, 0x6c);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x15b, 0x30);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x3d, 0x12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x15, 0x15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x21, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "From:";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xb8, 0x15);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x17, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "To:";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd5, 0x12);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.buttonDoNo.Location = new Point(0x11b, 0xe0);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x17, 0x17);
            this.buttonDoNo.TabIndex = 14;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(20, 0xe4);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x3a, 13);
            this.labelDoNo.TabIndex = 11;
            this.labelDoNo.Text = "DO/SO no";
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x59, 0xe1);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xc0, 20);
            this.textDoNo.TabIndex = 2;
            this.textDoNo.Leave += new EventHandler(this.textDoNo_Leave);
            this.buttonRelation.Location = new Point(0x11b, 0xfb);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 15;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x1f, 0xff);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2e, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Relation";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x59, 0xfc);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xc0, 20);
            this.textRelation.TabIndex = 3;
            this.textRelation.Leave += new EventHandler(this.textRelation_Leave);
            this.buttonEstate.Location = new Point(0x11b, 0xc6);
            this.buttonEstate.Margin = new Padding(0);
            this.buttonEstate.Name = "buttonEstate";
            this.buttonEstate.Size = new Size(0x17, 0x17);
            this.buttonEstate.TabIndex = 13;
            this.buttonEstate.Text = "...";
            this.buttonEstate.UseVisualStyleBackColor = true;
            this.buttonEstate.Click += new EventHandler(this.buttonEstate_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(40, 0xca);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x25, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Estate";
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x59, 0xc7);
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0xc0, 20);
            this.textEstate.TabIndex = 1;
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1d0, 20);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 9;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x138, 20);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 8;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(15, 15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xc5, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Division Report for FFB";
            this.buttonDivision.Location = new Point(0x11b, 0x115);
            this.buttonDivision.Margin = new Padding(0);
            this.buttonDivision.Name = "buttonDivision";
            this.buttonDivision.Size = new Size(0x17, 0x17);
            this.buttonDivision.TabIndex = 0x15;
            this.buttonDivision.Text = "...";
            this.buttonDivision.UseVisualStyleBackColor = true;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x21, 0x119);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2c, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Division";
            this.textDivision.CharacterCasing = CharacterCasing.Upper;
            this.textDivision.Location = new Point(0x59, 0x116);
            this.textDivision.Name = "textDivision";
            this.textDivision.Size = new Size(0xc0, 20);
            this.textDivision.TabIndex = 0x13;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x146, 0xae);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(100, 0x11);
            this.checkBox1.TabIndex = 0x16;
            this.checkBox1.Text = "Group By Block";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x13, 0xaf);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x3a, 13);
            this.label7.TabIndex = 0x17;
            this.label7.Text = "Commodity";
            this.comboCom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new Point(0x59, 0xac);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new Size(0xc0, 0x15);
            this.comboCom.TabIndex = 0x18;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x139, 0x39);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0x19;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x39);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0x1a;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            base.ClientSize = new Size(560, 0x177);
            base.ControlBox = false;
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.comboCom);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.buttonDivision);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textDivision);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.buttonEstate);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.groupBox1);
            base.Name = "RepDivision";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Division";
            base.Load += new EventHandler(this.RepDivision_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepDivision_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lineShape2_Click(object sender, EventArgs e)
        {
        }

        private void RepDivision_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepDivision_Load(object sender, EventArgs e)
        {
            this.tbl_Do = new WBTable();
            this.tbl_Estate = new WBTable();
            this.tbl_Relation = new WBTable();
            this.tbl_Do.OpenTable("wb_contract", "Select Do_No from wb_contract", WBData.conn);
            this.tbl_Relation.OpenTable("wb_contract", "Select Relation_code from wb_Relation", WBData.conn);
            this.tbl_Estate.OpenTable("wb_Estate", "Select Estate_code from wb_Estate", WBData.conn);
            Program.AutoComp(this.tbl_Do, "Do_No", this.textDoNo);
            Program.AutoComp(this.tbl_Relation, "Relation_code", this.textRelation);
            Program.AutoComp(this.tbl_Estate, "Estate_code", this.textEstate);
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" AND type='F'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboCom.Items.Add(row["Comm_Code"].ToString());
            }
            table.Dispose();
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
            if (this.textDoNo.Text.Trim() != "")
            {
                this.tbl_Do.ReOpen();
                string[] aField = new string[] { "Do_NO" };
                string[] aFind = new string[] { this.textDoNo.Text.Trim() };
                if (this.tbl_Do.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonDoNo.PerformClick();
                    this.textDoNo.Focus();
                }
            }
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (this.textEstate.Text.Trim() != "")
            {
                this.tbl_Estate.ReOpen();
                string[] aField = new string[] { "Estate_Code" };
                string[] aFind = new string[] { this.textEstate.Text.Trim() };
                if (this.tbl_Estate.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonEstate.PerformClick();
                    this.textEstate.Focus();
                }
            }
        }

        private void textRelation_Leave(object sender, EventArgs e)
        {
            if (this.textRelation.Text.Trim() != "")
            {
                this.tbl_Relation.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textRelation.Text.Trim() };
                if (this.tbl_Relation.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonRelation.PerformClick();
                    this.textRelation.Focus();
                }
            }
        }
    }
}

