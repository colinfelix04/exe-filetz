﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMessageEntry : Form
    {
        public string reason;
        private IContainer components;
        private Button button1;
        private Button button2;
        public Label lblHeader;
        public Label lblDetail;
        private TextBox textBox1;

        public FormMessageEntry()
        {
            this.reason = "";
            this.components = null;
            this.InitializeComponent();
        }

        public FormMessageEntry(string pMode)
        {
            this.reason = "";
            this.components = null;
            this.InitializeComponent();
            if (pMode == "BLACKLIST")
            {
                this.button2.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("This Field is not allowed to be empty");
                this.textBox1.Focus();
            }
            else
            {
                this.reason = this.textBox1.Text;
                base.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.button2 = new Button();
            this.lblHeader = new Label();
            this.lblDetail = new Label();
            this.textBox1 = new TextBox();
            base.SuspendLayout();
            this.button1.Location = new Point(0x8f, 0x79);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x21);
            this.button1.TabIndex = 0;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0xca, 0x79);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x56, 0x21);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.lblHeader.AutoSize = true;
            this.lblHeader.Location = new Point(12, 9);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new Size(0x2a, 13);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Header";
            this.lblDetail.AutoSize = true;
            this.lblDetail.Location = new Point(12, 0x27);
            this.lblDetail.Name = "lblDetail";
            this.lblDetail.Size = new Size(0x22, 13);
            this.lblDetail.TabIndex = 3;
            this.lblDetail.Text = "Detail";
            this.textBox1.Location = new Point(15, 0x53);
            this.textBox1.MaxLength = 50;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x13e, 20);
            this.textBox1.TabIndex = 4;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x16c, 0xa6);
            base.ControlBox = false;
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.lblDetail);
            base.Controls.Add(this.lblHeader);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Name = "FormMessageEntry";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

