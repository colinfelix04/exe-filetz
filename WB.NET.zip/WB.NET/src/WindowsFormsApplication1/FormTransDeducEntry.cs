﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDeducEntry : Form
    {
        public string pMode;
        public bool saved = false;
        public DataGridView dataGridView1;
        public WBTable tblTransD;
        public string textNET2;
        public string textBunchDeduc;
        public string oldDeducCode;
        private IContainer components = null;
        public Label labelKgUnit;
        public Label label1;
        public ComboBox comboDeducBy;
        public Label label2;
        public Label label3;
        public Label label4;
        public Button button1;
        public Button button2;
        public Label label5;
        public TextBox textDeducCode;
        public Button button11;
        public TextBox textDeducName;
        public TextBox textFormula;
        public Label label7;
        public Label label8;
        public Label label6;
        public TextBox textDeducPercent;
        public Label label9;
        public TextBox textDeducQtyUnit;
        public Label label10;
        public TextBox textDeducKG;
        public Label label11;
        public Label label12;
        public CheckBox checkDeducReturn;
        public TextBox textDeducVar;
        public Label label13;
        public Label label14;
        public CheckBox checkDeduct;
        public TextBox textTarget;
        public Label label15;

        public FormTransDeducEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textDeducCode.Text.Trim() != "")
            {
                using (IEnumerator enumerator = ((IEnumerable) this.dataGridView1.Rows).GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                        if (((this.pMode != "ADD") || (current.Cells["Code"].Value.ToString().Trim() != this.textDeducCode.Text.Trim())) ? ((this.pMode == "EDIT") && ((current.Cells["Code"].Value.ToString().Trim() == this.textDeducCode.Text.Trim()) && (current.Cells["Code"].Value.ToString().Trim() != this.oldDeducCode.Trim()))) : true)
                        {
                            MessageBox.Show(Resource.Mes_341, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.textDeducCode.Focus();
                            return;
                        }
                    }
                }
            }
            this.CalcDeduc();
            this.saved = true;
            base.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormGrading grading = new FormGrading(this.comboDeducBy.Text) {
                pMode = "CHOOSE"
            };
            grading.ShowDialog();
            if (grading.ReturnRow != null)
            {
                this.textDeducCode.Text = grading.ReturnRow["Grading_Code"].ToString();
                this.textDeducName.Text = grading.ReturnRow["Grading_Name"].ToString();
                this.textFormula.Text = grading.ReturnRow["Formula"].ToString();
                this.textDeducVar.Text = grading.ReturnRow["Variable"].ToString();
                this.textDeducCode.Focus();
            }
            grading.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        public void CalcDeduc()
        {
            double num = 0.0;
            if (this.comboDeducBy.Text == "2")
            {
                num = Math.Round((double) (Convert.ToDouble(this.textNET2) * (Convert.ToDouble(this.textDeducPercent.Text) / 100.0)), 0);
                this.textDeducKG.Text = num.ToString();
            }
            else if (this.comboDeducBy.Text == "3")
            {
                num = Math.Round((double) ((Convert.ToDouble(this.textBunchDeduc) * Convert.ToDouble(this.textDeducPercent.Text)) / 100.0), 0);
                this.textDeducQtyUnit.Text = num.ToString();
                this.HitPercent();
            }
            else if (this.comboDeducBy.Text == "4")
            {
                if (!(Convert.ToDouble(this.textBunchDeduc) == 0.0))
                {
                    num = Math.Round((double) ((Convert.ToDouble(this.textDeducQtyUnit.Text) / Convert.ToDouble(this.textBunchDeduc)) * 100.0), 2);
                }
                this.textDeducPercent.Text = num.ToString();
                this.HitPercent();
            }
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void comboDeducBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboDeducBy.Text == "1")
            {
                this.textDeducPercent.ReadOnly = true;
                this.textDeducPercent.Text = "0";
                this.textDeducQtyUnit.ReadOnly = true;
                this.textDeducQtyUnit.Text = "0";
                this.textDeducKG.ReadOnly = false;
            }
            else if (this.comboDeducBy.Text == "2")
            {
                this.textDeducPercent.ReadOnly = false;
                this.textDeducQtyUnit.ReadOnly = true;
                this.textDeducQtyUnit.Text = "0";
                this.textDeducKG.ReadOnly = true;
            }
            else if (this.comboDeducBy.Text == "3")
            {
                this.textDeducPercent.ReadOnly = false;
                this.textDeducQtyUnit.ReadOnly = true;
                this.textDeducKG.ReadOnly = true;
            }
            else if (this.comboDeducBy.Text == "4")
            {
                this.textDeducPercent.ReadOnly = true;
                this.textDeducQtyUnit.ReadOnly = false;
                this.textDeducKG.ReadOnly = true;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransDeducEntry_Load(object sender, EventArgs e)
        {
            WBSetting.ReOpen();
        }

        private void HitPercent()
        {
            TextBox[] aText = new TextBox[] { this.textDeducCode };
            if (!Program.CheckEmpty(aText))
            {
                ExpressionVariabel owner = new ExpressionVariabel {
                    NET = Convert.ToDouble(this.textNET2)
                };
                string pStr = this.textFormula.Text.Replace(this.textDeducVar.Text.Trim(), this.textDeducPercent.Text.Trim());
                this.textDeducKG.Text = ((WBSetting.Field("Round") != "Y") ? (Program.eval(pStr, owner) / 100.0) : Math.Round((double) (Program.eval(pStr, owner) / 100.0), 0)).ToString();
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.comboDeducBy = new ComboBox();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.button1 = new Button();
            this.button2 = new Button();
            this.label5 = new Label();
            this.textDeducCode = new TextBox();
            this.button11 = new Button();
            this.textDeducName = new TextBox();
            this.textFormula = new TextBox();
            this.label7 = new Label();
            this.label8 = new Label();
            this.label6 = new Label();
            this.textDeducPercent = new TextBox();
            this.label9 = new Label();
            this.textDeducQtyUnit = new TextBox();
            this.label10 = new Label();
            this.textDeducKG = new TextBox();
            this.label11 = new Label();
            this.label12 = new Label();
            this.labelKgUnit = new Label();
            this.checkDeducReturn = new CheckBox();
            this.textDeducVar = new TextBox();
            this.label13 = new Label();
            this.label14 = new Label();
            this.checkDeduct = new CheckBox();
            this.textTarget = new TextBox();
            this.label15 = new Label();
            base.SuspendLayout();
            this.label1.Location = new Point(13, 0x15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Deduction by";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.comboDeducBy.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.comboDeducBy.FormattingEnabled = true;
            object[] items = new object[] { "1", "2", "3", "4" };
            this.comboDeducBy.Items.AddRange(items);
            this.comboDeducBy.Location = new Point(0x63, 13);
            this.comboDeducBy.Name = "comboDeducBy";
            this.comboDeducBy.Size = new Size(0x2a, 0x1c);
            this.comboDeducBy.TabIndex = 0;
            this.comboDeducBy.Text = "1";
            this.comboDeducBy.SelectedIndexChanged += new EventHandler(this.comboDeducBy_SelectedIndexChanged);
            this.comboDeducBy.KeyPress += new KeyPressEventHandler(this.comboBox1_KeyPress);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x93, 13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(190, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "1. Deduction by Quantity of Commodity";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x93, 0x1d);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xd1, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "2. Deduction by Percentage of Net Weight";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x93, 0x2d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0xfd, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "3. Deduction by Percentage ( Calculate by Formula )";
            this.button1.Location = new Point(0x16b, 0xfc);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 5;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x1c9, 0xfc);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.label5.Location = new Point(12, 0x5e);
            this.label5.Name = "label5";
            this.label5.Size = new Size(80, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Deduction Code";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.textDeducCode.Location = new Point(0x63, 0x5b);
            this.textDeducCode.Name = "textDeducCode";
            this.textDeducCode.ReadOnly = true;
            this.textDeducCode.Size = new Size(100, 20);
            this.textDeducCode.TabIndex = 1;
            this.button11.Location = new Point(0xc7, 0x59);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 1;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textDeducName.Location = new Point(0x63, 0x75);
            this.textDeducName.MaxLength = 100;
            this.textDeducName.Name = "textDeducName";
            this.textDeducName.ReadOnly = true;
            this.textDeducName.Size = new Size(0x1db, 20);
            this.textDeducName.TabIndex = 1;
            this.textFormula.Location = new Point(0x63, 0x8f);
            this.textFormula.Name = "textFormula";
            this.textFormula.ReadOnly = true;
            this.textFormula.Size = new Size(0x1db, 20);
            this.textFormula.TabIndex = 2;
            this.label7.Location = new Point(13, 0x92);
            this.label7.Name = "label7";
            this.label7.Size = new Size(80, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Formula";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x93, 0x3d);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x112, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "4. Deduction by Quantity of Unit  ( Calculate by Formula )";
            this.label6.Location = new Point(13, 0xc3);
            this.label6.Name = "label6";
            this.label6.Size = new Size(80, 13);
            this.label6.TabIndex = 0x10;
            this.label6.Text = "Percentage";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.textDeducPercent.Location = new Point(0x63, 0xc0);
            this.textDeducPercent.Name = "textDeducPercent";
            this.textDeducPercent.ReadOnly = true;
            this.textDeducPercent.Size = new Size(0x2a, 20);
            this.textDeducPercent.TabIndex = 2;
            this.textDeducPercent.Text = "0";
            this.textDeducPercent.TextAlign = HorizontalAlignment.Right;
            this.textDeducPercent.Leave += new EventHandler(this.textDeducPercent_Leave);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x8d, 0xc3);
            this.label9.Name = "label9";
            this.label9.Size = new Size(15, 13);
            this.label9.TabIndex = 0x12;
            this.label9.Text = "%";
            this.textDeducQtyUnit.Location = new Point(0x63, 0xda);
            this.textDeducQtyUnit.Name = "textDeducQtyUnit";
            this.textDeducQtyUnit.ReadOnly = true;
            this.textDeducQtyUnit.Size = new Size(0x4c, 20);
            this.textDeducQtyUnit.TabIndex = 3;
            this.textDeducQtyUnit.Text = "0";
            this.textDeducQtyUnit.TextAlign = HorizontalAlignment.Right;
            this.textDeducQtyUnit.Leave += new EventHandler(this.textDeducQtyUnit_Leave);
            this.label10.Location = new Point(13, 0xdd);
            this.label10.Name = "label10";
            this.label10.Size = new Size(80, 13);
            this.label10.TabIndex = 0x13;
            this.label10.Text = "Quantity of Unit";
            this.label10.TextAlign = ContentAlignment.MiddleRight;
            this.textDeducKG.Location = new Point(0x63, 0xf4);
            this.textDeducKG.Name = "textDeducKG";
            this.textDeducKG.Size = new Size(0x4c, 20);
            this.textDeducKG.TabIndex = 4;
            this.textDeducKG.Text = "0";
            this.textDeducKG.TextAlign = HorizontalAlignment.Right;
            this.textDeducKG.Leave += new EventHandler(this.textDeducQTY_Leave);
            this.label11.Location = new Point(12, 0xf8);
            this.label11.Name = "label11";
            this.label11.Size = new Size(80, 13);
            this.label11.TabIndex = 0x15;
            this.label11.Text = "Deduction";
            this.label11.TextAlign = ContentAlignment.MiddleRight;
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0xaf, 0xf7);
            this.label12.Name = "label12";
            this.label12.Size = new Size(20, 13);
            this.label12.TabIndex = 0x17;
            this.label12.Text = "Kg";
            this.labelKgUnit.AutoSize = true;
            this.labelKgUnit.Location = new Point(0xaf, 0xdd);
            this.labelKgUnit.Name = "labelKgUnit";
            this.labelKgUnit.Size = new Size(0x26, 13);
            this.labelKgUnit.TabIndex = 0x18;
            this.labelKgUnit.Text = "Bunch";
            this.checkDeducReturn.AutoSize = true;
            this.checkDeducReturn.Location = new Point(0xde, 0xf7);
            this.checkDeducReturn.Name = "checkDeducReturn";
            this.checkDeducReturn.Size = new Size(0x3a, 0x11);
            this.checkDeducReturn.TabIndex = 0x19;
            this.checkDeducReturn.Text = "Return";
            this.checkDeducReturn.UseVisualStyleBackColor = true;
            this.textDeducVar.Location = new Point(0x1e4, 170);
            this.textDeducVar.Name = "textDeducVar";
            this.textDeducVar.ReadOnly = true;
            this.textDeducVar.Size = new Size(90, 20);
            this.textDeducVar.TabIndex = 0x1a;
            this.label13.Location = new Point(0x18e, 0xad);
            this.label13.Name = "label13";
            this.label13.Size = new Size(80, 13);
            this.label13.TabIndex = 0x1b;
            this.label13.Text = "As Variable";
            this.label13.TextAlign = ContentAlignment.MiddleRight;
            this.label14.Location = new Point(13, 120);
            this.label14.Name = "label14";
            this.label14.Size = new Size(80, 13);
            this.label14.TabIndex = 0x1c;
            this.label14.Text = "Description";
            this.label14.TextAlign = ContentAlignment.MiddleRight;
            this.checkDeduct.AutoSize = true;
            this.checkDeduct.Location = new Point(0xf3, 0x5d);
            this.checkDeduct.Name = "checkDeduct";
            this.checkDeduct.Size = new Size(130, 0x11);
            this.checkDeduct.TabIndex = 30;
            this.checkDeduct.Text = "Deduct From Receive";
            this.checkDeduct.UseVisualStyleBackColor = true;
            this.textTarget.Location = new Point(0x62, 0xa9);
            this.textTarget.Name = "textTarget";
            this.textTarget.Size = new Size(0x4c, 20);
            this.textTarget.TabIndex = 0x21;
            this.textTarget.TextAlign = HorizontalAlignment.Right;
            this.label15.Location = new Point(12, 0xac);
            this.label15.Name = "label15";
            this.label15.Size = new Size(80, 13);
            this.label15.TabIndex = 0x20;
            this.label15.Text = "Target";
            this.label15.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(590, 0x11d);
            base.ControlBox = false;
            base.Controls.Add(this.textTarget);
            base.Controls.Add(this.label15);
            base.Controls.Add(this.checkDeduct);
            base.Controls.Add(this.label14);
            base.Controls.Add(this.textDeducVar);
            base.Controls.Add(this.label13);
            base.Controls.Add(this.checkDeducReturn);
            base.Controls.Add(this.labelKgUnit);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.textDeducKG);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.textDeducQtyUnit);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.textDeducPercent);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.textFormula);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textDeducName);
            base.Controls.Add(this.button11);
            base.Controls.Add(this.textDeducCode);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.comboDeducBy);
            base.Controls.Add(this.label1);
            base.MaximizeBox = false;
            base.Name = "FormTransDeducEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Deduction Entry";
            base.Load += new EventHandler(this.FormTransDeducEntry_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textDeducPercent_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textDeducPercent))
            {
                this.CalcDeduc();
            }
        }

        private void textDeducQTY_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textDeducKG);
        }

        private void textDeducQtyUnit_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textDeducQtyUnit))
            {
                this.CalcDeduc();
            }
        }

        private void translate()
        {
            this.label1.Text = Resource.Lbl_Deduction_By;
            this.label2.Text = Resource.Lbl_Deduction_Description;
            this.label3.Text = Resource.Ttp_Deduc_By_2;
            this.label4.Text = Resource.Lbl_Deduction_Description_3;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.label5.Text = Resource.Lbl_Deduction_Code;
            this.label7.Text = Resource.Grade_004;
            this.label8.Text = Resource.Lbl_Deduction_Description_4;
            this.label6.Text = Resource.Lbl_Percentage;
            this.label10.Text = Resource.Lbl_Unit_Quantity;
            this.label11.Text = Resource.Main_022;
            this.labelKgUnit.Text = Resource.Txt_Unit_Name_Bunch;
            this.checkDeducReturn.Text = Resource.Trans_101;
            this.label13.Text = Resource.Grade_003;
            this.label14.Text = Resource.Composite_007;
            this.checkDeduct.Text = Resource.Chk_Deduct_Receive;
            this.label15.Text = Resource.Lbl_Target;
            this.Text = Resource.Title_Deduction_Entry;
        }
    }
}

