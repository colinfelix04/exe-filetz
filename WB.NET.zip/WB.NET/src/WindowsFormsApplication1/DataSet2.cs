﻿namespace WindowsFormsApplication1
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.ComponentModel;
    using System.ComponentModel.Design;
    using System.Data;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;

    [Serializable, DesignerCategory("code"), ToolboxItem(true), XmlSchemaProvider("GetTypedDataSetSchema"), XmlRoot("DataSet2"), HelpKeyword("vs.data.DataSet")]
    public class DataSet2 : DataSet
    {
        private DataTable1DataTable tableDataTable1;
        private DataTable3DataTable tableDataTable3;
        private DataTable2DataTable tableDataTable2;
        private DataTable4DataTable tableDataTable4;
        private System.Data.SchemaSerializationMode _schemaSerializationMode;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public DataSet2()
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            base.BeginInit();
            this.InitClass();
            CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
            base.Tables.CollectionChanged += handler;
            base.Relations.CollectionChanged += handler;
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected DataSet2(SerializationInfo info, StreamingContext context) : base(info, context, false)
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            if (base.IsBinarySerialized(info, context))
            {
                this.InitVars(false);
                CollectionChangeEventHandler handler2 = new CollectionChangeEventHandler(this.SchemaChanged);
                this.Tables.CollectionChanged += handler2;
                this.Relations.CollectionChanged += handler2;
            }
            else
            {
                string s = (string) info.GetValue("XmlSchema", typeof(string));
                if (base.DetermineSchemaSerializationMode(info, context) != System.Data.SchemaSerializationMode.IncludeSchema)
                {
                    base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                }
                else
                {
                    DataSet dataSet = new DataSet();
                    dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                    if (dataSet.Tables["DataTable1"] != null)
                    {
                        base.Tables.Add(new DataTable1DataTable(dataSet.Tables["DataTable1"]));
                    }
                    if (dataSet.Tables["DataTable3"] != null)
                    {
                        base.Tables.Add(new DataTable3DataTable(dataSet.Tables["DataTable3"]));
                    }
                    if (dataSet.Tables["DataTable2"] != null)
                    {
                        base.Tables.Add(new DataTable2DataTable(dataSet.Tables["DataTable2"]));
                    }
                    if (dataSet.Tables["DataTable4"] != null)
                    {
                        base.Tables.Add(new DataTable4DataTable(dataSet.Tables["DataTable4"]));
                    }
                    base.DataSetName = dataSet.DataSetName;
                    base.Prefix = dataSet.Prefix;
                    base.Namespace = dataSet.Namespace;
                    base.Locale = dataSet.Locale;
                    base.CaseSensitive = dataSet.CaseSensitive;
                    base.EnforceConstraints = dataSet.EnforceConstraints;
                    base.Merge(dataSet, false, MissingSchemaAction.Add);
                    this.InitVars();
                }
                base.GetSerializationData(info, context);
                CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
                base.Tables.CollectionChanged += handler;
                this.Relations.CollectionChanged += handler;
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public override DataSet Clone()
        {
            DataSet2 set = (DataSet2) base.Clone();
            set.InitVars();
            set.SchemaSerializationMode = this.SchemaSerializationMode;
            return set;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override XmlSchema GetSchemaSerializable()
        {
            MemoryStream w = new MemoryStream();
            base.WriteXmlSchema(new XmlTextWriter(w, null));
            w.Position = 0L;
            return XmlSchema.Read(new XmlTextReader(w), null);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
        {
            DataSet2 set = new DataSet2();
            XmlSchemaComplexType type = new XmlSchemaComplexType();
            XmlSchemaSequence sequence = new XmlSchemaSequence();
            XmlSchemaAny item = new XmlSchemaAny {
                Namespace = set.Namespace
            };
            sequence.Items.Add(item);
            type.Particle = sequence;
            XmlSchema schemaSerializable = set.GetSchemaSerializable();
            if (xs.Contains(schemaSerializable.TargetNamespace))
            {
                MemoryStream stream = new MemoryStream();
                MemoryStream stream2 = new MemoryStream();
                try
                {
                    XmlSchema current = null;
                    schemaSerializable.Write(stream);
                    IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        current = (XmlSchema) enumerator.Current;
                        stream2.SetLength(0L);
                        current.Write(stream2);
                        if (stream.Length == stream2.Length)
                        {
                            stream.Position = 0L;
                            stream2.Position = 0L;
                            while (true)
                            {
                                if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                {
                                    continue;
                                }
                                if (stream.Position != stream.Length)
                                {
                                    break;
                                }
                                return type;
                            }
                        }
                    }
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                    }
                    if (stream2 != null)
                    {
                        stream2.Close();
                    }
                }
            }
            xs.Add(schemaSerializable);
            return type;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void InitClass()
        {
            base.DataSetName = "DataSet2";
            base.Prefix = "";
            base.Namespace = "http://tempuri.org/DataSet2.xsd";
            base.EnforceConstraints = true;
            this.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            this.tableDataTable1 = new DataTable1DataTable();
            base.Tables.Add(this.tableDataTable1);
            this.tableDataTable3 = new DataTable3DataTable();
            base.Tables.Add(this.tableDataTable3);
            this.tableDataTable2 = new DataTable2DataTable();
            base.Tables.Add(this.tableDataTable2);
            this.tableDataTable4 = new DataTable4DataTable();
            base.Tables.Add(this.tableDataTable4);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void InitializeDerivedDataSet()
        {
            base.BeginInit();
            this.InitClass();
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars()
        {
            this.InitVars(true);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars(bool initTable)
        {
            this.tableDataTable1 = (DataTable1DataTable) base.Tables["DataTable1"];
            if (initTable && (this.tableDataTable1 != null))
            {
                this.tableDataTable1.InitVars();
            }
            this.tableDataTable3 = (DataTable3DataTable) base.Tables["DataTable3"];
            if (initTable && (this.tableDataTable3 != null))
            {
                this.tableDataTable3.InitVars();
            }
            this.tableDataTable2 = (DataTable2DataTable) base.Tables["DataTable2"];
            if (initTable && (this.tableDataTable2 != null))
            {
                this.tableDataTable2.InitVars();
            }
            this.tableDataTable4 = (DataTable4DataTable) base.Tables["DataTable4"];
            if (initTable && (this.tableDataTable4 != null))
            {
                this.tableDataTable4.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void ReadXmlSerializable(XmlReader reader)
        {
            if (base.DetermineSchemaSerializationMode(reader) != System.Data.SchemaSerializationMode.IncludeSchema)
            {
                base.ReadXml(reader);
                this.InitVars();
            }
            else
            {
                this.Reset();
                DataSet dataSet = new DataSet();
                dataSet.ReadXml(reader);
                if (dataSet.Tables["DataTable1"] != null)
                {
                    base.Tables.Add(new DataTable1DataTable(dataSet.Tables["DataTable1"]));
                }
                if (dataSet.Tables["DataTable3"] != null)
                {
                    base.Tables.Add(new DataTable3DataTable(dataSet.Tables["DataTable3"]));
                }
                if (dataSet.Tables["DataTable2"] != null)
                {
                    base.Tables.Add(new DataTable2DataTable(dataSet.Tables["DataTable2"]));
                }
                if (dataSet.Tables["DataTable4"] != null)
                {
                    base.Tables.Add(new DataTable4DataTable(dataSet.Tables["DataTable4"]));
                }
                base.DataSetName = dataSet.DataSetName;
                base.Prefix = dataSet.Prefix;
                base.Namespace = dataSet.Namespace;
                base.Locale = dataSet.Locale;
                base.CaseSensitive = dataSet.CaseSensitive;
                base.EnforceConstraints = dataSet.EnforceConstraints;
                base.Merge(dataSet, false, MissingSchemaAction.Add);
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void SchemaChanged(object sender, CollectionChangeEventArgs e)
        {
            if (e.Action == CollectionChangeAction.Remove)
            {
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeDataTable1() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeDataTable2() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeDataTable3() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeDataTable4() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeRelations() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeTables() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DataTable1DataTable DataTable1 =>
            this.tableDataTable1;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DataTable3DataTable DataTable3 =>
            this.tableDataTable3;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DataTable2DataTable DataTable2 =>
            this.tableDataTable2;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DataTable4DataTable DataTable4 =>
            this.tableDataTable4;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public override System.Data.SchemaSerializationMode SchemaSerializationMode
        {
            get => 
                this._schemaSerializationMode;
            set => 
                this._schemaSerializationMode = value;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataTableCollection Tables =>
            base.Tables;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataRelationCollection Relations =>
            base.Relations;

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class DataTable1DataTable : TypedTableBase<DataSet2.DataTable1Row>
        {
            private DataColumn columnTRANSPORTER;
            private DataColumn columnTRUCK;
            private DataColumn columnDRIVER;
            private DataColumn columnNO;
            private DataColumn columnREF;
            private DataColumn columnIN_DATETIME;
            private DataColumn columnOUT_DATETIME;
            private DataColumn columnGROSS;
            private DataColumn columnTARE;
            private DataColumn columnRECEIVED;
            private DataColumn columnDEDUCTION;
            private DataColumn columnNET;
            private DataColumn columnDELIVERYNOTE;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable1RowChangeEventHandler DataTable1RowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable1RowChangeEventHandler DataTable1RowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable1RowChangeEventHandler DataTable1RowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable1RowChangeEventHandler DataTable1RowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable1DataTable()
            {
                base.TableName = "DataTable1";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable1DataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected DataTable1DataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddDataTable1Row(DataSet2.DataTable1Row row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable1Row AddDataTable1Row(string TRANSPORTER, string TRUCK, string DRIVER, short NO, string REF, DateTime IN_DATETIME, DateTime OUT_DATETIME, int GROSS, int TARE, int RECEIVED, int DEDUCTION, int NET, string DELIVERYNOTE)
            {
                DataSet2.DataTable1Row row = (DataSet2.DataTable1Row) base.NewRow();
                object[] objArray1 = new object[13];
                objArray1[0] = TRANSPORTER;
                objArray1[1] = TRUCK;
                objArray1[2] = DRIVER;
                objArray1[3] = NO;
                objArray1[4] = REF;
                objArray1[5] = IN_DATETIME;
                objArray1[6] = OUT_DATETIME;
                objArray1[7] = GROSS;
                objArray1[8] = TARE;
                objArray1[9] = RECEIVED;
                objArray1[10] = DEDUCTION;
                objArray1[11] = NET;
                objArray1[12] = DELIVERYNOTE;
                row.ItemArray = objArray1;
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSet2.DataTable1DataTable table = (DataSet2.DataTable1DataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSet2.DataTable1DataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSet2.DataTable1Row);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSet2 set = new DataSet2();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = set.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "DataTable1DataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = set.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnTRANSPORTER = new DataColumn("TRANSPORTER", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTRANSPORTER);
                this.columnTRUCK = new DataColumn("TRUCK", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTRUCK);
                this.columnDRIVER = new DataColumn("DRIVER", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnDRIVER);
                this.columnNO = new DataColumn("NO", typeof(short), null, MappingType.Element);
                base.Columns.Add(this.columnNO);
                this.columnREF = new DataColumn("REF", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnREF);
                this.columnIN_DATETIME = new DataColumn("IN DATETIME", typeof(DateTime), null, MappingType.Element);
                base.Columns.Add(this.columnIN_DATETIME);
                this.columnOUT_DATETIME = new DataColumn("OUT DATETIME", typeof(DateTime), null, MappingType.Element);
                base.Columns.Add(this.columnOUT_DATETIME);
                this.columnGROSS = new DataColumn("GROSS", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnGROSS);
                this.columnTARE = new DataColumn("TARE", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnTARE);
                this.columnRECEIVED = new DataColumn("RECEIVED", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnRECEIVED);
                this.columnDEDUCTION = new DataColumn("DEDUCTION", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnDEDUCTION);
                this.columnNET = new DataColumn("NET", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnNET);
                this.columnDELIVERYNOTE = new DataColumn("DELIVERYNOTE", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnDELIVERYNOTE);
                this.columnNO.AutoIncrementSeed = 1L;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnTRANSPORTER = base.Columns["TRANSPORTER"];
                this.columnTRUCK = base.Columns["TRUCK"];
                this.columnDRIVER = base.Columns["DRIVER"];
                this.columnNO = base.Columns["NO"];
                this.columnREF = base.Columns["REF"];
                this.columnIN_DATETIME = base.Columns["IN DATETIME"];
                this.columnOUT_DATETIME = base.Columns["OUT DATETIME"];
                this.columnGROSS = base.Columns["GROSS"];
                this.columnTARE = base.Columns["TARE"];
                this.columnRECEIVED = base.Columns["RECEIVED"];
                this.columnDEDUCTION = base.Columns["DEDUCTION"];
                this.columnNET = base.Columns["NET"];
                this.columnDELIVERYNOTE = base.Columns["DELIVERYNOTE"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable1Row NewDataTable1Row() => 
                (DataSet2.DataTable1Row) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSet2.DataTable1Row(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.DataTable1RowChanged != null)
                {
                    this.DataTable1RowChanged(this, new DataSet2.DataTable1RowChangeEvent((DataSet2.DataTable1Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.DataTable1RowChanging != null)
                {
                    this.DataTable1RowChanging(this, new DataSet2.DataTable1RowChangeEvent((DataSet2.DataTable1Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.DataTable1RowDeleted != null)
                {
                    this.DataTable1RowDeleted(this, new DataSet2.DataTable1RowChangeEvent((DataSet2.DataTable1Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.DataTable1RowDeleting != null)
                {
                    this.DataTable1RowDeleting(this, new DataSet2.DataTable1RowChangeEvent((DataSet2.DataTable1Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveDataTable1Row(DataSet2.DataTable1Row row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn TRANSPORTERColumn =>
                this.columnTRANSPORTER;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn TRUCKColumn =>
                this.columnTRUCK;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn DRIVERColumn =>
                this.columnDRIVER;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn NOColumn =>
                this.columnNO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn REFColumn =>
                this.columnREF;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn IN_DATETIMEColumn =>
                this.columnIN_DATETIME;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn OUT_DATETIMEColumn =>
                this.columnOUT_DATETIME;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn GROSSColumn =>
                this.columnGROSS;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn TAREColumn =>
                this.columnTARE;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn RECEIVEDColumn =>
                this.columnRECEIVED;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn DEDUCTIONColumn =>
                this.columnDEDUCTION;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn NETColumn =>
                this.columnNET;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn DELIVERYNOTEColumn =>
                this.columnDELIVERYNOTE;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable1Row this[int index] =>
                (DataSet2.DataTable1Row) base.Rows[index];
        }

        public class DataTable1Row : DataRow
        {
            private DataSet2.DataTable1DataTable tableDataTable1;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable1Row(DataRowBuilder rb) : base(rb)
            {
                this.tableDataTable1 = (DataSet2.DataTable1DataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsDEDUCTIONNull() => 
                base.IsNull(this.tableDataTable1.DEDUCTIONColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsDELIVERYNOTENull() => 
                base.IsNull(this.tableDataTable1.DELIVERYNOTEColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsDRIVERNull() => 
                base.IsNull(this.tableDataTable1.DRIVERColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsGROSSNull() => 
                base.IsNull(this.tableDataTable1.GROSSColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsIN_DATETIMENull() => 
                base.IsNull(this.tableDataTable1.IN_DATETIMEColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsNETNull() => 
                base.IsNull(this.tableDataTable1.NETColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsNONull() => 
                base.IsNull(this.tableDataTable1.NOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsOUT_DATETIMENull() => 
                base.IsNull(this.tableDataTable1.OUT_DATETIMEColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsRECEIVEDNull() => 
                base.IsNull(this.tableDataTable1.RECEIVEDColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsREFNull() => 
                base.IsNull(this.tableDataTable1.REFColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTARENull() => 
                base.IsNull(this.tableDataTable1.TAREColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTRANSPORTERNull() => 
                base.IsNull(this.tableDataTable1.TRANSPORTERColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTRUCKNull() => 
                base.IsNull(this.tableDataTable1.TRUCKColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetDEDUCTIONNull()
            {
                base[this.tableDataTable1.DEDUCTIONColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetDELIVERYNOTENull()
            {
                base[this.tableDataTable1.DELIVERYNOTEColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetDRIVERNull()
            {
                base[this.tableDataTable1.DRIVERColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetGROSSNull()
            {
                base[this.tableDataTable1.GROSSColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetIN_DATETIMENull()
            {
                base[this.tableDataTable1.IN_DATETIMEColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetNETNull()
            {
                base[this.tableDataTable1.NETColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetNONull()
            {
                base[this.tableDataTable1.NOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetOUT_DATETIMENull()
            {
                base[this.tableDataTable1.OUT_DATETIMEColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetRECEIVEDNull()
            {
                base[this.tableDataTable1.RECEIVEDColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetREFNull()
            {
                base[this.tableDataTable1.REFColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTARENull()
            {
                base[this.tableDataTable1.TAREColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTRANSPORTERNull()
            {
                base[this.tableDataTable1.TRANSPORTERColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTRUCKNull()
            {
                base[this.tableDataTable1.TRUCKColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string TRANSPORTER
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable1.TRANSPORTERColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'TRANSPORTER' in table 'DataTable1' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable1.TRANSPORTERColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string TRUCK
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable1.TRUCKColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'TRUCK' in table 'DataTable1' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable1.TRUCKColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string DRIVER
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable1.DRIVERColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'DRIVER' in table 'DataTable1' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable1.DRIVERColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public short NO
            {
                get
                {
                    short num;
                    try
                    {
                        num = (short) base[this.tableDataTable1.NOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'NO' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.NOColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string REF
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable1.REFColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'REF' in table 'DataTable1' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable1.REFColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DateTime IN_DATETIME
            {
                get
                {
                    DateTime time;
                    try
                    {
                        time = (DateTime) base[this.tableDataTable1.IN_DATETIMEColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'IN DATETIME' in table 'DataTable1' is DBNull.", exception);
                    }
                    return time;
                }
                set => 
                    base[this.tableDataTable1.IN_DATETIMEColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DateTime OUT_DATETIME
            {
                get
                {
                    DateTime time;
                    try
                    {
                        time = (DateTime) base[this.tableDataTable1.OUT_DATETIMEColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'OUT DATETIME' in table 'DataTable1' is DBNull.", exception);
                    }
                    return time;
                }
                set => 
                    base[this.tableDataTable1.OUT_DATETIMEColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int GROSS
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDataTable1.GROSSColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'GROSS' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.GROSSColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int TARE
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDataTable1.TAREColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'TARE' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.TAREColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int RECEIVED
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDataTable1.RECEIVEDColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'RECEIVED' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.RECEIVEDColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int DEDUCTION
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDataTable1.DEDUCTIONColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'DEDUCTION' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.DEDUCTIONColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int NET
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDataTable1.NETColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'NET' in table 'DataTable1' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDataTable1.NETColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string DELIVERYNOTE
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable1.DELIVERYNOTEColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'DELIVERYNOTE' in table 'DataTable1' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable1.DELIVERYNOTEColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class DataTable1RowChangeEvent : EventArgs
        {
            private DataSet2.DataTable1Row eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable1RowChangeEvent(DataSet2.DataTable1Row row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable1Row Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void DataTable1RowChangeEventHandler(object sender, DataSet2.DataTable1RowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class DataTable2DataTable : TypedTableBase<DataSet2.DataTable2Row>
        {
            private DataColumn columnNO;
            private DataColumn columnWB_DO;
            private DataColumn columnTRANSACTION_TYPE;
            private DataColumn columnCOMMODITY;
            private DataColumn columnRELATION;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable2RowChangeEventHandler DataTable2RowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable2RowChangeEventHandler DataTable2RowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable2RowChangeEventHandler DataTable2RowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable2RowChangeEventHandler DataTable2RowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable2DataTable()
            {
                base.TableName = "DataTable2";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable2DataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected DataTable2DataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddDataTable2Row(DataSet2.DataTable2Row row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable2Row AddDataTable2Row(short NO, string WB_DO, string TRANSACTION_TYPE, string COMMODITY, string RELATION)
            {
                DataSet2.DataTable2Row row = (DataSet2.DataTable2Row) base.NewRow();
                row.ItemArray = new object[] { NO, WB_DO, TRANSACTION_TYPE, COMMODITY, RELATION };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSet2.DataTable2DataTable table = (DataSet2.DataTable2DataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSet2.DataTable2DataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable2Row FindByNO(short NO)
            {
                object[] keys = new object[] { NO };
                return (DataSet2.DataTable2Row) base.Rows.Find(keys);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSet2.DataTable2Row);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSet2 set = new DataSet2();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = set.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "DataTable2DataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = set.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnNO = new DataColumn("NO", typeof(short), null, MappingType.Element);
                base.Columns.Add(this.columnNO);
                this.columnWB_DO = new DataColumn("WB DO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnWB_DO);
                this.columnTRANSACTION_TYPE = new DataColumn("TRANSACTION TYPE", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTRANSACTION_TYPE);
                this.columnCOMMODITY = new DataColumn("COMMODITY", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCOMMODITY);
                this.columnRELATION = new DataColumn("RELATION", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnRELATION);
                DataColumn[] columns = new DataColumn[] { this.columnNO };
                base.Constraints.Add(new UniqueConstraint("Constraint1", columns, true));
                this.columnNO.AllowDBNull = false;
                this.columnNO.Unique = true;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnNO = base.Columns["NO"];
                this.columnWB_DO = base.Columns["WB DO"];
                this.columnTRANSACTION_TYPE = base.Columns["TRANSACTION TYPE"];
                this.columnCOMMODITY = base.Columns["COMMODITY"];
                this.columnRELATION = base.Columns["RELATION"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable2Row NewDataTable2Row() => 
                (DataSet2.DataTable2Row) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSet2.DataTable2Row(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.DataTable2RowChanged != null)
                {
                    this.DataTable2RowChanged(this, new DataSet2.DataTable2RowChangeEvent((DataSet2.DataTable2Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.DataTable2RowChanging != null)
                {
                    this.DataTable2RowChanging(this, new DataSet2.DataTable2RowChangeEvent((DataSet2.DataTable2Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.DataTable2RowDeleted != null)
                {
                    this.DataTable2RowDeleted(this, new DataSet2.DataTable2RowChangeEvent((DataSet2.DataTable2Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.DataTable2RowDeleting != null)
                {
                    this.DataTable2RowDeleting(this, new DataSet2.DataTable2RowChangeEvent((DataSet2.DataTable2Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveDataTable2Row(DataSet2.DataTable2Row row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn NOColumn =>
                this.columnNO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn WB_DOColumn =>
                this.columnWB_DO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn TRANSACTION_TYPEColumn =>
                this.columnTRANSACTION_TYPE;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn COMMODITYColumn =>
                this.columnCOMMODITY;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn RELATIONColumn =>
                this.columnRELATION;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable2Row this[int index] =>
                (DataSet2.DataTable2Row) base.Rows[index];
        }

        public class DataTable2Row : DataRow
        {
            private DataSet2.DataTable2DataTable tableDataTable2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable2Row(DataRowBuilder rb) : base(rb)
            {
                this.tableDataTable2 = (DataSet2.DataTable2DataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCOMMODITYNull() => 
                base.IsNull(this.tableDataTable2.COMMODITYColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsRELATIONNull() => 
                base.IsNull(this.tableDataTable2.RELATIONColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTRANSACTION_TYPENull() => 
                base.IsNull(this.tableDataTable2.TRANSACTION_TYPEColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsWB_DONull() => 
                base.IsNull(this.tableDataTable2.WB_DOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCOMMODITYNull()
            {
                base[this.tableDataTable2.COMMODITYColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetRELATIONNull()
            {
                base[this.tableDataTable2.RELATIONColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTRANSACTION_TYPENull()
            {
                base[this.tableDataTable2.TRANSACTION_TYPEColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetWB_DONull()
            {
                base[this.tableDataTable2.WB_DOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public short NO
            {
                get => 
                    (short) base[this.tableDataTable2.NOColumn];
                set => 
                    base[this.tableDataTable2.NOColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string WB_DO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable2.WB_DOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'WB DO' in table 'DataTable2' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable2.WB_DOColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string TRANSACTION_TYPE
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable2.TRANSACTION_TYPEColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'TRANSACTION TYPE' in table 'DataTable2' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable2.TRANSACTION_TYPEColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string COMMODITY
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable2.COMMODITYColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'COMMODITY' in table 'DataTable2' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable2.COMMODITYColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string RELATION
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable2.RELATIONColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'RELATION' in table 'DataTable2' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable2.RELATIONColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class DataTable2RowChangeEvent : EventArgs
        {
            private DataSet2.DataTable2Row eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable2RowChangeEvent(DataSet2.DataTable2Row row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable2Row Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void DataTable2RowChangeEventHandler(object sender, DataSet2.DataTable2RowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class DataTable3DataTable : TypedTableBase<DataSet2.DataTable3Row>
        {
            private DataColumn columnCOY1;
            private DataColumn columnCOY2;
            private DataColumn columnCOY3;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable3RowChangeEventHandler DataTable3RowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable3RowChangeEventHandler DataTable3RowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable3RowChangeEventHandler DataTable3RowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable3RowChangeEventHandler DataTable3RowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable3DataTable()
            {
                base.TableName = "DataTable3";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable3DataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected DataTable3DataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddDataTable3Row(DataSet2.DataTable3Row row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable3Row AddDataTable3Row(string COY1, string COY2, string COY3)
            {
                DataSet2.DataTable3Row row = (DataSet2.DataTable3Row) base.NewRow();
                row.ItemArray = new object[] { COY1, COY2, COY3 };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSet2.DataTable3DataTable table = (DataSet2.DataTable3DataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSet2.DataTable3DataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSet2.DataTable3Row);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSet2 set = new DataSet2();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = set.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "DataTable3DataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = set.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnCOY1 = new DataColumn("COY1", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCOY1);
                this.columnCOY2 = new DataColumn("COY2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCOY2);
                this.columnCOY3 = new DataColumn("COY3", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCOY3);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnCOY1 = base.Columns["COY1"];
                this.columnCOY2 = base.Columns["COY2"];
                this.columnCOY3 = base.Columns["COY3"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable3Row NewDataTable3Row() => 
                (DataSet2.DataTable3Row) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSet2.DataTable3Row(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.DataTable3RowChanged != null)
                {
                    this.DataTable3RowChanged(this, new DataSet2.DataTable3RowChangeEvent((DataSet2.DataTable3Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.DataTable3RowChanging != null)
                {
                    this.DataTable3RowChanging(this, new DataSet2.DataTable3RowChangeEvent((DataSet2.DataTable3Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.DataTable3RowDeleted != null)
                {
                    this.DataTable3RowDeleted(this, new DataSet2.DataTable3RowChangeEvent((DataSet2.DataTable3Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.DataTable3RowDeleting != null)
                {
                    this.DataTable3RowDeleting(this, new DataSet2.DataTable3RowChangeEvent((DataSet2.DataTable3Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveDataTable3Row(DataSet2.DataTable3Row row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn COY1Column =>
                this.columnCOY1;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn COY2Column =>
                this.columnCOY2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn COY3Column =>
                this.columnCOY3;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable3Row this[int index] =>
                (DataSet2.DataTable3Row) base.Rows[index];
        }

        public class DataTable3Row : DataRow
        {
            private DataSet2.DataTable3DataTable tableDataTable3;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable3Row(DataRowBuilder rb) : base(rb)
            {
                this.tableDataTable3 = (DataSet2.DataTable3DataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCOY1Null() => 
                base.IsNull(this.tableDataTable3.COY1Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCOY2Null() => 
                base.IsNull(this.tableDataTable3.COY2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCOY3Null() => 
                base.IsNull(this.tableDataTable3.COY3Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCOY1Null()
            {
                base[this.tableDataTable3.COY1Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCOY2Null()
            {
                base[this.tableDataTable3.COY2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCOY3Null()
            {
                base[this.tableDataTable3.COY3Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string COY1
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable3.COY1Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'COY1' in table 'DataTable3' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable3.COY1Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string COY2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable3.COY2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'COY2' in table 'DataTable3' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable3.COY2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string COY3
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable3.COY3Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'COY3' in table 'DataTable3' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable3.COY3Column] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class DataTable3RowChangeEvent : EventArgs
        {
            private DataSet2.DataTable3Row eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable3RowChangeEvent(DataSet2.DataTable3Row row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable3Row Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void DataTable3RowChangeEventHandler(object sender, DataSet2.DataTable3RowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class DataTable4DataTable : TypedTableBase<DataSet2.DataTable4Row>
        {
            private DataColumn columnUSER;
            private DataColumn columnAPPROVED;
            private DataColumn columnTRANSPORTED;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable4RowChangeEventHandler DataTable4RowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable4RowChangeEventHandler DataTable4RowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable4RowChangeEventHandler DataTable4RowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSet2.DataTable4RowChangeEventHandler DataTable4RowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable4DataTable()
            {
                base.TableName = "DataTable4";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable4DataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected DataTable4DataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddDataTable4Row(DataSet2.DataTable4Row row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable4Row AddDataTable4Row(string USER, string APPROVED, string TRANSPORTED)
            {
                DataSet2.DataTable4Row row = (DataSet2.DataTable4Row) base.NewRow();
                row.ItemArray = new object[] { USER, APPROVED, TRANSPORTED };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSet2.DataTable4DataTable table = (DataSet2.DataTable4DataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSet2.DataTable4DataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSet2.DataTable4Row);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSet2 set = new DataSet2();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = set.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "DataTable4DataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = set.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnUSER = new DataColumn("USER", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnUSER);
                this.columnAPPROVED = new DataColumn("APPROVED", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnAPPROVED);
                this.columnTRANSPORTED = new DataColumn("TRANSPORTED", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTRANSPORTED);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnUSER = base.Columns["USER"];
                this.columnAPPROVED = base.Columns["APPROVED"];
                this.columnTRANSPORTED = base.Columns["TRANSPORTED"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable4Row NewDataTable4Row() => 
                (DataSet2.DataTable4Row) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSet2.DataTable4Row(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.DataTable4RowChanged != null)
                {
                    this.DataTable4RowChanged(this, new DataSet2.DataTable4RowChangeEvent((DataSet2.DataTable4Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.DataTable4RowChanging != null)
                {
                    this.DataTable4RowChanging(this, new DataSet2.DataTable4RowChangeEvent((DataSet2.DataTable4Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.DataTable4RowDeleted != null)
                {
                    this.DataTable4RowDeleted(this, new DataSet2.DataTable4RowChangeEvent((DataSet2.DataTable4Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.DataTable4RowDeleting != null)
                {
                    this.DataTable4RowDeleting(this, new DataSet2.DataTable4RowChangeEvent((DataSet2.DataTable4Row) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveDataTable4Row(DataSet2.DataTable4Row row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn USERColumn =>
                this.columnUSER;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn APPROVEDColumn =>
                this.columnAPPROVED;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn TRANSPORTEDColumn =>
                this.columnTRANSPORTED;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable4Row this[int index] =>
                (DataSet2.DataTable4Row) base.Rows[index];
        }

        public class DataTable4Row : DataRow
        {
            private DataSet2.DataTable4DataTable tableDataTable4;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DataTable4Row(DataRowBuilder rb) : base(rb)
            {
                this.tableDataTable4 = (DataSet2.DataTable4DataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsAPPROVEDNull() => 
                base.IsNull(this.tableDataTable4.APPROVEDColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTRANSPORTEDNull() => 
                base.IsNull(this.tableDataTable4.TRANSPORTEDColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsUSERNull() => 
                base.IsNull(this.tableDataTable4.USERColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetAPPROVEDNull()
            {
                base[this.tableDataTable4.APPROVEDColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTRANSPORTEDNull()
            {
                base[this.tableDataTable4.TRANSPORTEDColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetUSERNull()
            {
                base[this.tableDataTable4.USERColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string USER
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable4.USERColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'USER' in table 'DataTable4' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable4.USERColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string APPROVED
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable4.APPROVEDColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'APPROVED' in table 'DataTable4' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable4.APPROVEDColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string TRANSPORTED
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDataTable4.TRANSPORTEDColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'TRANSPORTED' in table 'DataTable4' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDataTable4.TRANSPORTEDColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class DataTable4RowChangeEvent : EventArgs
        {
            private DataSet2.DataTable4Row eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataTable4RowChangeEvent(DataSet2.DataTable4Row row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSet2.DataTable4Row Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void DataTable4RowChangeEventHandler(object sender, DataSet2.DataTable4RowChangeEvent e);
    }
}

