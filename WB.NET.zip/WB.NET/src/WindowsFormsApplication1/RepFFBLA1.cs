﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBLA1 : Form
    {
        private WBTable tbl_Comm;
        private WBTable tbl_Supp;
        private WBTable tbl_Trans;
        private string sqlTrans;
        private int No = 0;
        private int jlhkol = 0;
        private int jlhRecord = 0;
        private int _colspanWeight = 0;
        private double received;
        private double treceived;
        private double deduc;
        private double tdeduc;
        private double net;
        private double tnet;
        private double rSdhi;
        private double nSdhi;
        private double bunch;
        private double tbunch;
        private double gross;
        private double tgross;
        private double tare;
        private double ttare;
        private double colly;
        private double tcolly;
        private string topLine = "";
        private string bottomLine = "";
        private string borderStyle = "";
        public bool ffb;
        private IContainer components = null;
        public Button button2;
        public Button button1;
        public DateTimePicker monthCalendar2;
        public Label labelRecNo;
        public Label labelProcess;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Button buttonSupp;
        public Label labelSupp;
        public TextBox textSupp;
        public Label label4;
        private CheckBox checkPlat;
        public Label label3;
        private TextBox textBox1;
        public CheckBox checkColly;
        public CheckBox checkBunch;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        private GroupBox groupColumn;
        private CheckBox checkGrossTare;
        private CheckBox checkTransporter;
        private CheckBox checkDO;
        private CheckBox checkTime;
        private CheckBox checkURec;
        private CheckBox checkUNet;
        public CheckBox checkLine;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public GroupBox groupBox1;
        public DateTimePicker dateTimePicker1;
        public Label label6;
        public Label label7;
        public DateTimePicker dateTimePicker2;
        public GroupBox groupBox2;
        public Label label8;
        public Label label9;

        public RepFFBLA1()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days <= 31.0)
            {
                if (this.textCommodity.Text.Trim() != "")
                {
                    if (this.textCommodity.Text.Trim() != "")
                    {
                        if (!this.ffb)
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE type!='F' AND comm_code='" + this.textCommodity.Text.Trim() + "'", WBData.conn);
                            if (table2.DT.Rows.Count < 1)
                            {
                                MessageBox.Show("Please Choose Commodity which Type is not F (FFB)!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textCommodity.Focus();
                                return;
                            }
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE type='F' AND comm_code='" + this.textCommodity.Text.Trim() + "'", WBData.conn);
                            if (table.DT.Rows.Count < 1)
                            {
                                MessageBox.Show("Please Choose Commodity which Type is F (FFB)!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textCommodity.Focus();
                                return;
                            }
                        }
                    }
                    if (this.textSupp.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Fill in Supplier.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else if (Convert.ToDateTime(this.monthCalendar2.Value.ToShortDateString()) < Convert.ToDateTime(this.monthCalendar1.Value.ToShortDateString()))
                    {
                        MessageBox.Show("Invalid Date Selected, Date To is Smaller than Date From.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        int index = 0;
                        string[] source = new string[5];
                        foreach (Control control in this.groupFType.Controls)
                        {
                            CheckBox box = control as CheckBox;
                            if ((box != null) && box.Checked)
                            {
                                source[index] = box.Text;
                                index++;
                            }
                        }
                        string[] textArray1 = new string[] { " and relation_code = '", this.textSupp.Text, "' and comm_code ='", this.textCommodity.Text, "'" };
                        this.sqlTrans = "select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1));
                        this.sqlTrans = this.sqlTrans + " and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'";
                        this.sqlTrans = this.sqlTrans + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00'))";
                        if (this.rboGI.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                        }
                        else if (this.rboGR.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                        }
                        if (this.ffb)
                        {
                            this.sqlTrans = this.sqlTrans + " and Type = 'F' ";
                        }
                        this.sqlTrans = this.sqlTrans + " and comm_code = '" + this.textCommodity.Text.Trim() + "'";
                        this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N') and ( report_Date is not null or report_date <> '') ";
                        if (this.ffb)
                        {
                            if (index <= 0)
                            {
                                this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                            }
                            else
                            {
                                int num3 = 0;
                                while (true)
                                {
                                    if (num3 >= source.Count<string>())
                                    {
                                        this.sqlTrans = this.sqlTrans + " ) ";
                                        break;
                                    }
                                    if (source[num3] != "")
                                    {
                                        this.sqlTrans = (num3 != 0) ? (this.sqlTrans + " or Fruits_type = '" + source[num3] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + source[num3] + "' ");
                                    }
                                    num3++;
                                }
                            }
                        }
                        this.sqlTrans = this.sqlTrans + " order by report_date,ref";
                        this.tbl_Trans = new WBTable();
                        this.tbl_Trans.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                        if (this.tbl_Trans.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("No Records Found", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            this.labelProcess.Visible = true;
                            this.labelRecNo.Visible = true;
                            this.labelProcess.Refresh();
                            this.labelRecNo.Refresh();
                            this.jlhRecord = this.tbl_Trans.DT.Rows.Count;
                            this.printReport();
                            this.labelProcess.Visible = false;
                            this.labelRecNo.Visible = false;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Fill in Commodity.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonSupp_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textSupp.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelSupp.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textSupp.Focus();
            }
            vendor.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            this.jlhkol = 0;
            this._colspanWeight = 3;
            if (this.checkLine.Checked)
            {
                this.borderStyle = "border = 0 style='border-collapse: collapse;'";
                this.topLine = "border-top: 1px solid #004080;";
                this.bottomLine = "border-bottom: 1px solid #004080;";
            }
            else
            {
                this.borderStyle = "border = 1";
                this.topLine = "";
                this.bottomLine = "";
            }
            rep.Write("<table " + this.borderStyle + " rules=all cellpadding=0 cellspacing=0>");
            rep.Write("<tr class='bd'>");
            string[] textArray1 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>No.</b></td>" };
            rep.Write(string.Concat(textArray1));
            this.jlhkol++;
            string[] textArray2 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Date</b></td>" };
            rep.Write(string.Concat(textArray2));
            this.jlhkol++;
            string[] textArray3 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Reference No.</b></td>" };
            rep.Write(string.Concat(textArray3));
            this.jlhkol++;
            if (this.checkPlat.Checked)
            {
                string[] textArray4 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Truck No.</b></td>" };
                rep.Write(string.Concat(textArray4));
                this.jlhkol++;
            }
            if (this.checkTime.Checked)
            {
                rep.Write("<td nowrap align=center colspan=2 style='" + this.topLine + "'><b>Time</b></td>");
            }
            if (this.checkDO.Checked)
            {
                string[] textArray5 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>DO No.</b></td>" };
                rep.Write(string.Concat(textArray5));
                this.jlhkol++;
            }
            if (this.checkTransporter.Checked)
            {
                string[] textArray6 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Transporter Name</b></td>" };
                rep.Write(string.Concat(textArray6));
                this.jlhkol++;
            }
            if (this.checkBunch.Checked)
            {
                string[] textArray7 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Bunch</b></td>" };
                rep.Write(string.Concat(textArray7));
            }
            if (this.checkColly.Checked)
            {
                string[] textArray8 = new string[] { "<td nowrap align=center rowspan=2 style='", this.topLine, " ", this.bottomLine, "'><b>Colly</b></td>" };
                rep.Write(string.Concat(textArray8));
            }
            if (this.checkGrossTare.Checked)
            {
                this._colspanWeight += 2;
            }
            if (this.checkURec.Checked)
            {
                this._colspanWeight++;
            }
            if (this.checkUNet.Checked)
            {
                this._colspanWeight++;
            }
            string[] textArray9 = new string[] { "<td nowrap align=center colspan=", this._colspanWeight.ToString(), " style='", this.topLine, "'><b>Weight</b></td>" };
            rep.Write(string.Concat(textArray9));
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            if (this.checkTime.Checked)
            {
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>In</b></td>");
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Out</b></td>");
                this.jlhkol += 2;
            }
            if (this.checkGrossTare.Checked)
            {
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Gross</b></td>");
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Tare</b></td>");
            }
            rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Received</b></td>");
            if (this.checkURec.Checked)
            {
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>U/Today</b></td>");
            }
            rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Deduction</b></td>");
            rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>Net</b></td>");
            if (this.checkUNet.Checked)
            {
                rep.Write("<td nowrap align=center style='" + this.bottomLine + "'><b>U/Today</b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.monthCalendar2 = new DateTimePicker();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.buttonSupp = new Button();
            this.labelSupp = new Label();
            this.textSupp = new TextBox();
            this.label4 = new Label();
            this.checkPlat = new CheckBox();
            this.label3 = new Label();
            this.textBox1 = new TextBox();
            this.checkColly = new CheckBox();
            this.checkBunch = new CheckBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.groupColumn = new GroupBox();
            this.checkGrossTare = new CheckBox();
            this.checkTransporter = new CheckBox();
            this.checkDO = new CheckBox();
            this.checkTime = new CheckBox();
            this.checkURec = new CheckBox();
            this.checkUNet = new CheckBox();
            this.checkLine = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupBox1 = new GroupBox();
            this.dateTimePicker1 = new DateTimePicker();
            this.label6 = new Label();
            this.label7 = new Label();
            this.dateTimePicker2 = new DateTimePicker();
            this.groupBox2 = new GroupBox();
            this.label8 = new Label();
            this.label9 = new Label();
            this.groupFType.SuspendLayout();
            this.groupColumn.SuspendLayout();
            this.grType.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1b7, 0x160);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 0x79;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x155, 0x15f);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x58, 0x21);
            this.button1.TabIndex = 4;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd5, 0x11);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 3;
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1df, 0x15);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x75;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x14c, 0x15);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x74;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x3d, 0x11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 2;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x12b, 20);
            this.label5.TabIndex = 0x71;
            this.label5.Text = "Receiving Per Supplier Report (LA1)";
            this.buttonComm.Location = new Point(0x10d, 0xad);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x7c;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x127, 0xb2);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x7e;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x5f, 0xae);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(170, 20);
            this.textCommodity.TabIndex = 0;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x15, 0xb1);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x44, 13);
            this.labelcommodity.TabIndex = 0x7d;
            this.labelcommodity.Text = "Commodity * ";
            this.buttonSupp.Location = new Point(0x10d, 0xc7);
            this.buttonSupp.Margin = new Padding(0);
            this.buttonSupp.Name = "buttonSupp";
            this.buttonSupp.Size = new Size(0x17, 0x17);
            this.buttonSupp.TabIndex = 0x80;
            this.buttonSupp.Text = "...";
            this.buttonSupp.UseVisualStyleBackColor = true;
            this.buttonSupp.Click += new EventHandler(this.buttonSupp_Click);
            this.labelSupp.AutoSize = true;
            this.labelSupp.Location = new Point(0x127, 0xcc);
            this.labelSupp.Name = "labelSupp";
            this.labelSupp.Size = new Size(0x2d, 13);
            this.labelSupp.TabIndex = 130;
            this.labelSupp.Text = "Supplier";
            this.textSupp.CharacterCasing = CharacterCasing.Upper;
            this.textSupp.Location = new Point(0x5f, 200);
            this.textSupp.Name = "textSupp";
            this.textSupp.Size = new Size(170, 20);
            this.textSupp.TabIndex = 1;
            this.textSupp.Leave += new EventHandler(this.textSupp_Leave);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x15, 0xcb);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x37, 13);
            this.label4.TabIndex = 0x81;
            this.label4.Text = "Supplier * ";
            this.checkPlat.AutoSize = true;
            this.checkPlat.Checked = true;
            this.checkPlat.CheckState = CheckState.Checked;
            this.checkPlat.Location = new Point(10, 15);
            this.checkPlat.Name = "checkPlat";
            this.checkPlat.Size = new Size(0x5e, 0x11);
            this.checkPlat.TabIndex = 0x83;
            this.checkPlat.Text = "Truck Number";
            this.checkPlat.UseVisualStyleBackColor = true;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x15, 0x159);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x34, 13);
            this.label3.TabIndex = 0x84;
            this.label3.Text = "Max Row";
            this.label3.Visible = false;
            this.textBox1.Location = new Point(0x4f, 0x156);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x31, 20);
            this.textBox1.TabIndex = 0x85;
            this.textBox1.Text = "60";
            this.textBox1.TextAlign = HorizontalAlignment.Right;
            this.textBox1.Visible = false;
            this.textBox1.Leave += new EventHandler(this.textBox1_Leave);
            this.checkColly.AutoSize = true;
            this.checkColly.Location = new Point(0x128, 0x3d);
            this.checkColly.Name = "checkColly";
            this.checkColly.Size = new Size(0x4f, 0x11);
            this.checkColly.TabIndex = 0x86;
            this.checkColly.Text = "Colly Copra";
            this.checkColly.UseVisualStyleBackColor = true;
            this.checkBunch.AutoSize = true;
            this.checkBunch.Location = new Point(0x128, 0x26);
            this.checkBunch.Name = "checkBunch";
            this.checkBunch.Size = new Size(0x39, 0x11);
            this.checkBunch.TabIndex = 0x87;
            this.checkBunch.Text = "Bunch";
            this.checkBunch.UseVisualStyleBackColor = true;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x138, 0x3a);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0x88;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.groupColumn.Controls.Add(this.checkBunch);
            this.groupColumn.Controls.Add(this.checkColly);
            this.groupColumn.Controls.Add(this.checkGrossTare);
            this.groupColumn.Controls.Add(this.checkTransporter);
            this.groupColumn.Controls.Add(this.checkDO);
            this.groupColumn.Controls.Add(this.checkTime);
            this.groupColumn.Controls.Add(this.checkURec);
            this.groupColumn.Controls.Add(this.checkUNet);
            this.groupColumn.Controls.Add(this.checkPlat);
            this.groupColumn.Location = new Point(0x13, 0xeb);
            this.groupColumn.Name = "groupColumn";
            this.groupColumn.Size = new Size(0x1ab, 0x5b);
            this.groupColumn.TabIndex = 0x89;
            this.groupColumn.TabStop = false;
            this.checkGrossTare.AutoSize = true;
            this.checkGrossTare.Checked = true;
            this.checkGrossTare.CheckState = CheckState.Checked;
            this.checkGrossTare.Location = new Point(0x128, 15);
            this.checkGrossTare.Name = "checkGrossTare";
            this.checkGrossTare.Size = new Size(0x56, 0x11);
            this.checkGrossTare.TabIndex = 0x8d;
            this.checkGrossTare.Text = "Gross / Tare";
            this.checkGrossTare.UseVisualStyleBackColor = true;
            this.checkTransporter.AutoSize = true;
            this.checkTransporter.Checked = true;
            this.checkTransporter.CheckState = CheckState.Checked;
            this.checkTransporter.Location = new Point(10, 0x26);
            this.checkTransporter.Name = "checkTransporter";
            this.checkTransporter.Size = new Size(0x6f, 0x11);
            this.checkTransporter.TabIndex = 140;
            this.checkTransporter.Text = "Transporter Name";
            this.checkTransporter.UseVisualStyleBackColor = true;
            this.checkDO.AutoSize = true;
            this.checkDO.Checked = true;
            this.checkDO.CheckState = CheckState.Checked;
            this.checkDO.Location = new Point(0x92, 15);
            this.checkDO.Name = "checkDO";
            this.checkDO.Size = new Size(0x3b, 0x11);
            this.checkDO.TabIndex = 0x8b;
            this.checkDO.Text = "DO No";
            this.checkDO.UseVisualStyleBackColor = true;
            this.checkTime.AutoSize = true;
            this.checkTime.Checked = true;
            this.checkTime.CheckState = CheckState.Checked;
            this.checkTime.Location = new Point(10, 0x3d);
            this.checkTime.Name = "checkTime";
            this.checkTime.Size = new Size(0x61, 0x11);
            this.checkTime.TabIndex = 0x8a;
            this.checkTime.Text = "Weighing Time";
            this.checkTime.UseVisualStyleBackColor = true;
            this.checkURec.AutoSize = true;
            this.checkURec.Location = new Point(0x92, 0x3d);
            this.checkURec.Name = "checkURec";
            this.checkURec.Size = new Size(0x79, 0x11);
            this.checkURec.TabIndex = 0x89;
            this.checkURec.Text = "Received U/ Today";
            this.checkURec.UseVisualStyleBackColor = true;
            this.checkUNet.AutoSize = true;
            this.checkUNet.Location = new Point(0x92, 0x26);
            this.checkUNet.Name = "checkUNet";
            this.checkUNet.Size = new Size(0x5c, 0x11);
            this.checkUNet.TabIndex = 0x88;
            this.checkUNet.Text = "Net U/ Today";
            this.checkUNet.UseVisualStyleBackColor = true;
            this.checkLine.AutoSize = true;
            this.checkLine.Location = new Point(0x18, 0x16f);
            this.checkLine.Name = "checkLine";
            this.checkLine.Size = new Size(0x65, 0x11);
            this.checkLine.TabIndex = 0x8f;
            this.checkLine.Text = "Hide Table Line";
            this.checkLine.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x3a);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0xa5;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Location = new Point(0x15, 0x60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x15b, 0x30);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date";
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x3d, 0x12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x69, 20);
            this.dateTimePicker1.TabIndex = 0;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x15, 0x15);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x21, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "From:";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0xb8, 0x15);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x17, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "To:";
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(0xd5, 0x12);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x69, 20);
            this.dateTimePicker2.TabIndex = 1;
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.monthCalendar1);
            this.groupBox2.Controls.Add(this.monthCalendar2);
            this.groupBox2.Location = new Point(0x13, 0x6d);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x15b, 0x30);
            this.groupBox2.TabIndex = 0xa6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Date";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x15, 0x15);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x21, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "From:";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xb8, 0x15);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x17, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "To:";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x22f, 0x196);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.checkLine);
            base.Controls.Add(this.groupColumn);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.buttonSupp);
            base.Controls.Add(this.labelSupp);
            base.Controls.Add(this.textSupp);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBLA1";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Per Supplier (LA1)";
            base.Load += new EventHandler(this.RepFFBLA1_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBLA1_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.groupColumn.ResumeLayout(false);
            this.groupColumn.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printReport()
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_LA1.htm";
            rep.Title = "Receiving per Supplier Report(LA1)";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<style type='text/css'>");
            rep.Write("td { padding: 4px 7px; }");
            rep.Write(".no { padding: 0px; }");
            rep.Write("</style>");
            rep.Write("<br><font size=5><b>RECEIVING PER SUPPLIER REPORT (LA1)</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            string str = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.textCommodity.Text);
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td class=no>Commodity</td>");
            string[] textArray3 = new string[] { "<td class=no>: <b>", this.textCommodity.Text.Trim(), " - ", str, "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td class=no>Relation</td>");
            rep.Write("<td class=no>: <b>" + this.labelSupp.Text + "</b></td>");
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td class=no>Selected Date</td>");
            string[] textArray4 = new string[] { "<td class=no>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray4));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td class=no>Report Date</td>");
            rep.Write("<td class=no>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            this.initHeader(rep);
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            this.received = 0.0;
            this.treceived = 0.0;
            this.deduc = 0.0;
            this.tdeduc = 0.0;
            this.net = 0.0;
            this.tnet = 0.0;
            this.rSdhi = 0.0;
            this.nSdhi = 0.0;
            this.gross = 0.0;
            this.tgross = 0.0;
            this.tare = 0.0;
            this.ttare = 0.0;
            this.No = 0;
            this.bunch = 0.0;
            this.tbunch = 0.0;
            this.colly = 0.0;
            this.tcolly = 0.0;
            foreach (DataRow row in this.tbl_Trans.DT.Rows)
            {
                this.No++;
                this.labelRecNo.Text = num3.ToString() + " / " + this.jlhRecord.ToString();
                this.labelRecNo.Refresh();
                num2++;
                num3++;
                if ((num2 == 1) && (num > 0))
                {
                    rep.Write("</table>");
                    rep.Write("<br>");
                    rep.Write("<br>");
                    this.initHeader(rep);
                }
                rep.Write("<tr class='bd'>");
                rep.Write("<td nowrap align=right>" + $"{this.No:N0}" + "</td>");
                rep.Write("<td nowrap>" + rep.strq(row["Report_date"].ToString().Substring(0, 10)) + "</td>");
                rep.Write("<td nowrap>" + rep.strq(row["Ref"].ToString()) + "</td>");
                this.bunch = Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                this.tbunch += this.bunch;
                this.received = Program.StrToDouble(row["Received"].ToString(), 0);
                this.treceived += this.received;
                this.rSdhi += this.received;
                this.colly = Program.StrToDouble(row["JlhColly"].ToString(), 0);
                this.tcolly += this.colly;
                this.deduc = Program.StrToDouble(row["Deduction"].ToString(), 0);
                this.tdeduc += this.deduc;
                this.gross = Program.StrToDouble(row["Gross"].ToString(), 0);
                this.tgross += this.gross;
                this.tare = Program.StrToDouble(row["Tare"].ToString(), 0);
                this.ttare += this.tare;
                this.net = Program.StrToDouble(row["Netto"].ToString(), 0);
                this.tnet += this.net;
                this.nSdhi += this.net;
                if (this.checkPlat.Checked)
                {
                    rep.Write("<td nowrap>" + rep.strq(row["Truck_Number"].ToString()) + "</td>");
                }
                if (this.checkTime.Checked)
                {
                    rep.Write("<td nowrap align=center>" + rep.strq(row["Time1"].ToString().Substring(0, 5)) + "</td>");
                    rep.Write("<td nowrap align=center>" + rep.strq(row["Time2"].ToString().Substring(0, 5)) + "</td>");
                }
                if (this.checkDO.Checked)
                {
                    rep.Write("<td nowrap align=center>" + rep.strq(row["Do_No"].ToString()) + "</td>");
                }
                if (this.checkTransporter.Checked)
                {
                    rep.Write("<td nowrap align=center>" + rep.strq(row["Transporter_Name"].ToString()) + "</td>");
                }
                if (this.checkBunch.Checked)
                {
                    rep.Write("<td nowrap align=right>" + $"{this.bunch:N0}" + "</td>");
                }
                if (this.checkColly.Checked)
                {
                    rep.Write("<td nowrap align=right>" + $"{this.colly:N0}" + "</td>");
                }
                if (this.checkGrossTare.Checked)
                {
                    rep.Write("<td nowrap align=right>" + $"{this.gross:N0}" + "</td>");
                    rep.Write("<td nowrap align=right>" + $"{this.tare:N0}" + "</td>");
                }
                rep.Write("<td nowrap align=right>" + $"{this.received:N0}" + "</td>");
                if (this.checkURec.Checked)
                {
                    rep.Write("<td nowrap align=right>" + $"{this.rSdhi:N0}" + "</td>");
                }
                rep.Write("<td nowrap align=right>" + $"{this.deduc:N0}" + "</td>");
                rep.Write("<td nowrap align=right>" + $"{this.net:N0}" + "</td>");
                if (this.checkUNet.Checked)
                {
                    rep.Write("<td nowrap align=right>" + $"{this.nSdhi:N0}" + "</td>");
                }
                rep.Write("</tr>");
            }
            rep.Write("<tr class='bd'>");
            object[] objArray1 = new object[] { "<td colspan=", this.jlhkol, " nowrap style='", this.topLine, " ", this.bottomLine, "'><b>TOTAL</b></td>" };
            rep.Write(string.Concat(objArray1));
            if (this.checkBunch.Checked)
            {
                string[] textArray5 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.tbunch:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray5));
            }
            if (this.checkColly.Checked)
            {
                string[] textArray6 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.tcolly:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray6));
            }
            if (this.checkGrossTare.Checked)
            {
                string[] textArray7 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.tgross:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray7));
                string[] textArray8 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.ttare:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray8));
            }
            string[] textArray9 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.treceived:N0}", "</b></td>" };
            rep.Write(string.Concat(textArray9));
            if (this.checkURec.Checked)
            {
                string[] textArray10 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.rSdhi:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray10));
            }
            string[] textArray11 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.tdeduc:N0}", "</b></td>" };
            rep.Write(string.Concat(textArray11));
            string[] textArray12 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.tnet:N0}", "</b></td>" };
            rep.Write(string.Concat(textArray12));
            if (this.checkUNet.Checked)
            {
                string[] textArray13 = new string[] { "<td nowrap align=right style='", this.topLine, " ", this.bottomLine, "'><b>", $"{this.nSdhi:N0}", "</b></td>" };
                rep.Write(string.Concat(textArray13));
            }
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.writeSign();
            rep.Close();
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + rep.File) }
            };
            report.ShowDialog();
            rep.Dispose();
            report.Dispose();
        }

        private void RepFFBLA1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepFFBLA1_Load(object sender, EventArgs e)
        {
            this.groupFType.Visible = this.ffb;
            this.tbl_Comm = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select comm_code, comm_name from wb_commodity", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Supp = new WBTable();
            this.tbl_Supp.OpenTable("wb_relation", "Select relation_code,relation_name from wb_relation", WBData.conn);
            Program.AutoComp(this.tbl_Supp, "Relation_Code", this.textSupp);
            this.labelSupp.Text = "";
            this.labelCommName.Text = "";
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBox1);
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }

        private void textSupp_Leave(object sender, EventArgs e)
        {
            this.labelSupp.Text = "";
            if (this.textSupp.Text.Trim() != "")
            {
                this.tbl_Supp.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textSupp.Text.Trim() };
                int recNo = this.tbl_Supp.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelSupp.Text = this.tbl_Supp.DT.Rows[recNo]["Relation_name"].ToString().Trim();
                }
                else
                {
                    this.buttonSupp.PerformClick();
                    this.textSupp.Focus();
                }
            }
        }
    }
}

