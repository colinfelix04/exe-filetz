﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTankerEntry : Form
    {
        public WBTable zTable;
        private WBTable tblTruck = new WBTable();
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        private Label label3;
        public TextBox textBox1;
        private Panel pCheckTanker;
        private RadioButton rbNotCheck;
        private TextBox tTankerTolKG;
        private TextBox tTankerTolPersen;
        private RadioButton rbTankerKG;
        private RadioButton rbTankerPersen;
        private Label lblCheckTanker;

        public FormTankerEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            if (this.textBox2.Text.Trim() == "")
            {
                this.textBox2.Text = "0";
            }
            TextBox[] aText = new TextBox[] { this.textBox1 };
            if (!Program.CheckEmpty(aText))
            {
                if ((Convert.ToInt32(this.textBox2.Text) > 0) || this.rbNotCheck.Checked)
                {
                    if ((this.rbNotCheck.Checked || this.rbTankerPersen.Checked) || this.rbTankerKG.Checked)
                    {
                        if (!(this.rbTankerPersen.Checked && ((this.tTankerTolPersen.Text.Trim() == "") || (this.tTankerTolPersen.Text.Trim() == "0"))))
                        {
                            if (!(this.rbTankerKG.Checked && ((this.tTankerTolKG.Text.Trim() == "") || (this.tTankerTolKG.Text.Trim() == "0"))))
                            {
                                WBTable table = new WBTable();
                                table.OpenTable("wb_tanker", "Select Uniq From wb_tanker Where " + WBData.CompanyLocation(" and ( Tanker_No='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                                {
                                    table.Dispose();
                                    Cursor.Current = Cursors.WaitCursor;
                                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                                    {
                                        goto TR_0020;
                                    }
                                    else
                                    {
                                        table2 = new WBTable();
                                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.CompanyLocation(" and ( Tanker='" + this.zTable.DT.Rows[this.nCurrRow]["Tanker_No"].ToString() + "')"), WBData.conn);
                                        Cursor.Current = Cursors.Default;
                                        if (table2.DT.Rows.Count <= 0)
                                        {
                                            goto TR_0021;
                                        }
                                        else
                                        {
                                            string[] textArray1 = new string[13];
                                            textArray1[0] = Resource.Mes_243;
                                            textArray1[1] = " ";
                                            textArray1[2] = this.OldCode;
                                            textArray1[3] = " -> ";
                                            textArray1[4] = this.textBox1.Text;
                                            textArray1[5] = "\n\n";
                                            textArray1[6] = Resource.Mes_Confirm_Replace_Tanker;
                                            textArray1[7] = "\n  ( ";
                                            textArray1[8] = table2.DT.Rows.Count.ToString();
                                            textArray1[9] = " ";
                                            textArray1[10] = Resource.Mes_Records_In_Transaction;
                                            textArray1[11] = " )\n\n";
                                            textArray1[12] = Resource.Msg_Continue;
                                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                            {
                                                this.ReplaceAll = true;
                                                goto TR_0021;
                                            }
                                            else
                                            {
                                                this.ReplaceAll = false;
                                                this.textBox1.Focus();
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    table.Dispose();
                                    MessageBox.Show(Resource.Mes_244);
                                    this.textBox1.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Fill_Tolerance_KG);
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Fill_Tolerance_Percent);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Check_Tanker_Empty);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Max_Capacity_Zero);
                    this.textBox2.Focus();
                }
            }
            return;
        TR_0020:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Tanker_002 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Tanker_No"] = this.textBox1.Text;
            this.zTable.DR["Capacity"] = Math.Round((double) ((float) Convert.ToDecimal((this.textBox2.Text == "") ? "0" : this.textBox2.Text)), 2);
            if (this.rbNotCheck.Checked)
            {
                this.zTable.DR["Check_Tanker"] = "N";
                this.zTable.DR["CheckTankerTol"] = 0;
                this.zTable.DR["CheckTankerKG"] = 0;
            }
            else if (this.rbTankerPersen.Checked)
            {
                this.zTable.DR["Check_Tanker"] = "P";
                this.zTable.DR["CheckTankerTol"] = this.tTankerTolPersen.Text;
                this.zTable.DR["CheckTankerKG"] = 0;
            }
            else if (this.rbTankerKG.Checked)
            {
                this.zTable.DR["Check_Tanker"] = "K";
                this.zTable.DR["CheckTankerKG"] = this.tTankerTolKG.Text;
                this.zTable.DR["CheckTankerTol"] = 0;
            }
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_tanker", "SELECT uniq FROM wb_tanker WHERE " + WBData.CompanyLocation(" AND tanker_no = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_tanker", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Tanker" };
                string[] aNewValue = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Tanker='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit tanker master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0021:
            table2.Dispose();
            goto TR_0020;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTankerEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTankerEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Tanker_no"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Capacity"].Value.ToString();
                this.tTankerTolPersen.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["CheckTankerTol"].Value.ToString().Trim();
                this.tTankerTolKG.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["CheckTankerKG"].Value.ToString().Trim();
                this.radioCheckTanker(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Check_Tanker"].Value.ToString().Trim());
            }
            else if (this.pMode == "ADD")
            {
                WBSetting.ReOpen();
                this.tTankerTolPersen.Text = WBSetting.Field("CheckTankerTol").ToString().Trim();
                this.tTankerTolKG.Text = WBSetting.Field("CheckTankerKG").ToString().Trim();
                this.radioCheckTanker(WBSetting.Field("Check_Tanker"));
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
            if ((((WBSetting.Field("Check_Tanker") == "P") && (WBSetting.Field("CheckTankerTol").ToString().Trim() != "0")) || ((WBSetting.Field("Check_Tanker") == "K") && (WBSetting.Field("CheckTankerKG").ToString().Trim() != "0"))) ? (Convert.ToInt16(WBUser.UserLevel) > 1) : false)
            {
                this.tTankerTolKG.Enabled = false;
                this.tTankerTolPersen.Enabled = false;
                this.rbTankerKG.Enabled = false;
                this.rbTankerPersen.Enabled = false;
                this.rbNotCheck.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label3 = new Label();
            this.pCheckTanker = new Panel();
            this.rbNotCheck = new RadioButton();
            this.tTankerTolKG = new TextBox();
            this.tTankerTolPersen = new TextBox();
            this.rbTankerKG = new RadioButton();
            this.rbTankerPersen = new RadioButton();
            this.lblCheckTanker = new Label();
            this.pCheckTanker.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(0xcb, 230);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 40);
            this.button2.TabIndex = 70;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x68, 230);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 40);
            this.button1.TabIndex = 0x45;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x69, 0x2b);
            this.textBox2.MaxLength = 15;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x4d, 20);
            this.textBox2.TabIndex = 0x44;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = HorizontalAlignment.Right;
            this.textBox2.Leave += new EventHandler(this.textBox2_Leave);
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x69, 0x11);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 0x43;
            this.textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.label2.Location = new Point(14, 0x2e);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x55, 13);
            this.label2.TabIndex = 0x48;
            this.label2.Text = "Max. Capacity";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(14, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x55, 13);
            this.label1.TabIndex = 0x47;
            this.label1.Text = "Tanker No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(190, 0x2e);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x16, 13);
            this.label3.TabIndex = 0x49;
            this.label3.Text = "KG";
            this.pCheckTanker.BorderStyle = BorderStyle.FixedSingle;
            this.pCheckTanker.Controls.Add(this.rbNotCheck);
            this.pCheckTanker.Controls.Add(this.tTankerTolKG);
            this.pCheckTanker.Controls.Add(this.tTankerTolPersen);
            this.pCheckTanker.Controls.Add(this.rbTankerKG);
            this.pCheckTanker.Controls.Add(this.rbTankerPersen);
            this.pCheckTanker.Location = new Point(90, 0x6b);
            this.pCheckTanker.Name = "pCheckTanker";
            this.pCheckTanker.Size = new Size(0xbc, 0x55);
            this.pCheckTanker.TabIndex = 0x69;
            this.rbNotCheck.AutoSize = true;
            this.rbNotCheck.Checked = true;
            this.rbNotCheck.Location = new Point(8, 0x38);
            this.rbNotCheck.Name = "rbNotCheck";
            this.rbNotCheck.Size = new Size(0x4c, 0x11);
            this.rbNotCheck.TabIndex = 0x6b;
            this.rbNotCheck.TabStop = true;
            this.rbNotCheck.Text = "Not Check";
            this.rbNotCheck.UseVisualStyleBackColor = true;
            this.rbNotCheck.CheckedChanged += new EventHandler(this.rbNotCheck_CheckedChanged);
            this.tTankerTolKG.Location = new Point(0x7b, 0x1f);
            this.tTankerTolKG.MaxLength = 5;
            this.tTankerTolKG.Name = "tTankerTolKG";
            this.tTankerTolKG.Size = new Size(0x31, 20);
            this.tTankerTolKG.TabIndex = 0x6a;
            this.tTankerTolKG.Text = "0";
            this.tTankerTolKG.TextAlign = HorizontalAlignment.Right;
            this.tTankerTolKG.Leave += new EventHandler(this.tTankerTolKG_Leave);
            this.tTankerTolPersen.Location = new Point(0x7b, 5);
            this.tTankerTolPersen.MaxLength = 5;
            this.tTankerTolPersen.Name = "tTankerTolPersen";
            this.tTankerTolPersen.Size = new Size(0x31, 20);
            this.tTankerTolPersen.TabIndex = 0x69;
            this.tTankerTolPersen.Text = "0";
            this.tTankerTolPersen.TextAlign = HorizontalAlignment.Right;
            this.tTankerTolPersen.Leave += new EventHandler(this.tTankerTolPersen_Leave);
            this.rbTankerKG.AutoSize = true;
            this.rbTankerKG.Location = new Point(8, 0x1f);
            this.rbTankerKG.Name = "rbTankerKG";
            this.rbTankerKG.Size = new Size(0x66, 0x11);
            this.rbTankerKG.TabIndex = 0x6a;
            this.rbTankerKG.Text = "Tolerance in KG";
            this.rbTankerKG.UseVisualStyleBackColor = true;
            this.rbTankerKG.CheckedChanged += new EventHandler(this.rbTankerKG_CheckedChanged);
            this.rbTankerPersen.AutoSize = true;
            this.rbTankerPersen.Location = new Point(8, 5);
            this.rbTankerPersen.Name = "rbTankerPersen";
            this.rbTankerPersen.Size = new Size(0x5f, 0x11);
            this.rbTankerPersen.TabIndex = 0x69;
            this.rbTankerPersen.Text = "Tolerance in %";
            this.rbTankerPersen.UseVisualStyleBackColor = true;
            this.rbTankerPersen.CheckedChanged += new EventHandler(this.rbTankerPersen_CheckedChanged);
            this.lblCheckTanker.AutoSize = true;
            this.lblCheckTanker.Location = new Point(0x60, 0x5b);
            this.lblCheckTanker.Name = "lblCheckTanker";
            this.lblCheckTanker.Size = new Size(0x4b, 13);
            this.lblCheckTanker.TabIndex = 0x6a;
            this.lblCheckTanker.Text = "Check Tanker";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x126, 0x11a);
            base.ControlBox = false;
            base.Controls.Add(this.lblCheckTanker);
            base.Controls.Add(this.pCheckTanker);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormTankerEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTankerEntry";
            base.Load += new EventHandler(this.FormTankerEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTankerEntry_KeyPress);
            this.pCheckTanker.ResumeLayout(false);
            this.pCheckTanker.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioCheckTanker(string checkMode)
        {
            string str = checkMode;
            if (str == "K")
            {
                this.rbTankerKG.Checked = true;
                this.rbTankerPersen.Checked = false;
                this.rbNotCheck.Checked = false;
                this.tTankerTolPersen.Enabled = false;
                this.tTankerTolPersen.Text = "0";
                this.tTankerTolKG.Enabled = true;
            }
            else if (str == "P")
            {
                this.rbTankerKG.Checked = false;
                this.rbTankerPersen.Checked = true;
                this.rbNotCheck.Checked = false;
                this.tTankerTolPersen.Enabled = true;
                this.tTankerTolKG.Text = "0";
                this.tTankerTolKG.Enabled = false;
            }
            else if (str == "N")
            {
                this.rbTankerKG.Checked = false;
                this.rbTankerPersen.Checked = false;
                this.rbNotCheck.Checked = true;
                this.tTankerTolPersen.Text = "0";
                this.tTankerTolPersen.Enabled = false;
                this.tTankerTolKG.Text = "0";
                this.tTankerTolKG.Enabled = false;
            }
            else if ((str != null) && (str.Length == 0))
            {
                this.rbTankerKG.Checked = false;
                this.rbTankerPersen.Checked = false;
                this.rbNotCheck.Checked = true;
                this.tTankerTolPersen.Text = "0";
                this.tTankerTolPersen.Enabled = false;
                this.tTankerTolKG.Text = "0";
                this.tTankerTolKG.Enabled = false;
            }
        }

        private void rbNotCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbTankerKG.Checked)
            {
                this.radioCheckTanker("K");
            }
            else if (this.rbTankerPersen.Checked)
            {
                this.radioCheckTanker("P");
            }
            else if (this.rbNotCheck.Checked)
            {
                this.radioCheckTanker("N");
            }
        }

        private void rbTankerKG_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbTankerKG.Checked)
            {
                this.radioCheckTanker("K");
            }
            else if (this.rbTankerPersen.Checked)
            {
                this.radioCheckTanker("P");
            }
            else if (this.rbNotCheck.Checked)
            {
                this.radioCheckTanker("N");
            }
        }

        private void rbTankerPersen_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbTankerKG.Checked)
            {
                this.radioCheckTanker("K");
            }
            else if (this.rbTankerPersen.Checked)
            {
                this.radioCheckTanker("P");
            }
            else if (this.rbNotCheck.Checked)
            {
                this.radioCheckTanker("N");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBox2);
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label1.Text = Resource.Tanker_002;
            this.label2.Text = Resource.Tanker_003;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.rbNotCheck.Text = Resource.Rdb_Not_Check;
            this.rbTankerKG.Text = Resource.Rdb_Tolerance_Kg;
            this.rbTankerPersen.Text = Resource.Rdb_Tolerance_Percent;
            this.lblCheckTanker.Text = Resource.Lbl_Check_Tanker;
        }

        private void tTankerTolKG_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.tTankerTolKG);
        }

        private void tTankerTolPersen_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.tTankerTolPersen);
        }
    }
}

