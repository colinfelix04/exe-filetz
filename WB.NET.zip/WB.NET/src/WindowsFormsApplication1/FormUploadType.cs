﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUploadType : Form
    {
        private int idxFind = 0;
        private int nCurrRow;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dgvUploadType;
        public Panel panel1;
        private ProgressBar progressBar1;
        public TextBox TextFind;
        public Button buttonFind;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormUploadType()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dgvUploadType, "ADD"))
            {
                FormUploadTypeEntry entry = new FormUploadTypeEntry {
                    pMode = "ADD",
                    Text = Resource.Title_Add_Upload,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvUploadType = this.ztable.AfterEdit("ADD");
                    string[] aField = new string[] { "upload_type" };
                    string[] aFind = new string[] { entry.textUploadCode.Text };
                    this.ztable.SetCursor(this.dgvUploadType, this.ztable.GetCurrentRow(this.dgvUploadType, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
                if (this.dgvUploadType.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                    this.chooseToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dgvUploadType, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dgvUploadType.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvUploadType.Rows.Count > 0) && (MessageBox.Show(Resource.Mes_452, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Menu_034 },
                    textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString() },
                    Text = Resource.Form_Delete_Reason,
                    label2 = { Text = Resource.Lbl_Delete_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    if (this.ztable.BeforeEdit(this.dgvUploadType, "DELETE"))
                    {
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { this.dgvUploadType.CurrentRow.Cells["uniq"].Value.ToString() };
                        int recNo = this.ztable.GetRecNo(aField, aFind);
                        this.logKey = this.ztable.DT.Rows[recNo]["uniq"].ToString();
                        this.ztable.DT.Rows[recNo].Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_upload_type", this.logKey, logField, logValue);
                        this.ztable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            if (this.dgvUploadType.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.chooseToolStripMenuItem.Enabled = false;
            }
        }

        private void dgvUploadType_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dgvUploadType_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvUploadType.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvUploadType, "EDIT"))
            {
                FormUploadTypeEntry entry = new FormUploadTypeEntry {
                    pMode = "EDIT",
                    nCurrRow = this.ztable.GetPosRec(this.dgvUploadType.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = Resource.Title_Edit_Upload,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvUploadType = this.ztable.AfterEdit("EDIT");
                    string[] aField = new string[] { "upload_type" };
                    string[] aFind = new string[] { entry.textUploadCode.Text };
                    this.ztable.SetCursor(this.dgvUploadType, this.ztable.GetCurrentRow(this.dgvUploadType, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormUploadType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormUploadType_Load(object sender, EventArgs e)
        {
            this.progressBar1.Visible = false;
            this.addNewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_UPLOAD_TYPE_LIST", "A");
            this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_UPLOAD_TYPE_LIST", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_UPLOAD_TYPE_LIST", "D");
            this.ztable.OpenTable("wb_upload_type", "SELECT * FROM wb_upload_type" + " WHERE " + WBData.CompanyLocation(this.pFilter), WBData.conn);
            this.dgvUploadType.DataSource = this.ztable.DT;
            this.dgvUploadType.Sort(this.dgvUploadType.Columns["Upload_Type"], ListSortDirection.Ascending);
            this.dgvUploadType.Columns["Coy"].Visible = false;
            this.dgvUploadType.Columns["Location_Code"].Visible = false;
            this.dgvUploadType.Columns["Uniq"].Visible = false;
            this.dgvUploadType.Columns["Delete_By"].Visible = false;
            this.dgvUploadType.Columns["Delete_Date"].Visible = false;
            this.dgvUploadType.Columns["Deleted"].Visible = false;
            this.dgvUploadType.Columns["Digit"].HeaderText = Resource.UploadType_001;
            this.dgvUploadType.Columns["Digit_Value"].HeaderText = Resource.UploadType_002;
            this.dgvUploadType.Columns["Upload_Type"].HeaderText = Resource.UploadType_003;
            this.dgvUploadType.Columns["Description"].HeaderText = Resource.UploadType_004;
            this.dgvUploadType.Columns["Create_By"].HeaderText = Resource.Gatepass_063;
            this.dgvUploadType.Columns["Create_Date"].HeaderText = Resource.Gatepass_064;
            this.dgvUploadType.Columns["Change_By"].HeaderText = Resource.Gatepass_065;
            this.dgvUploadType.Columns["Change_Date"].HeaderText = Resource.Gatepass_066;
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            this.chooseToolStripMenuItem.Visible = this.pMode != "";
            if (this.dgvUploadType.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.chooseToolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dgvUploadType = new DataGridView();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgvUploadType).BeginInit();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x222, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dgvUploadType.AllowUserToAddRows = false;
            this.dgvUploadType.AllowUserToDeleteRows = false;
            this.dgvUploadType.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUploadType.Dock = DockStyle.Fill;
            this.dgvUploadType.Location = new Point(0, 0x18);
            this.dgvUploadType.MultiSelect = false;
            this.dgvUploadType.Name = "dgvUploadType";
            this.dgvUploadType.ReadOnly = true;
            this.dgvUploadType.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvUploadType.Size = new Size(0x222, 0xdd);
            this.dgvUploadType.TabIndex = 1;
            this.dgvUploadType.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvUploadType_CellDoubleClick);
            this.dgvUploadType.KeyDown += new KeyEventHandler(this.dgvUploadType_KeyDown);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0xf5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x222, 0x21);
            this.panel1.TabIndex = 15;
            this.progressBar1.Anchor = AnchorStyles.Right | AnchorStyles.Left;
            this.progressBar1.Location = new Point(0x12a, 8);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xec, 0x10);
            this.progressBar1.TabIndex = 0x10;
            this.TextFind.Location = new Point(5, 6);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 5);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x222, 0x116);
            base.ControlBox = false;
            base.Controls.Add(this.dgvUploadType);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormUploadType";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Upload Type";
            base.Load += new EventHandler(this.FormUploadType_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUploadType_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgvUploadType).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.Text = Resource.Title_Upload_Type;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvUploadType.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvUploadType, "ADD"))
            {
                FormUploadTypeEntry entry = new FormUploadTypeEntry {
                    pMode = "VIEW",
                    Text = Resource.Title_View_Upload_Type,
                    nCurrRow = this.ztable.GetPosRec(this.dgvUploadType.CurrentRow.Cells["uniq"].Value.ToString()),
                    zTable = this.ztable
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

