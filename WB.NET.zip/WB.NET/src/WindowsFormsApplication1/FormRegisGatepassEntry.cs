﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;

    public class FormRegisGatepassEntry : Form
    {
        private string MODE = "";
        private WBTable t_truck = new WBTable();
        private WBTable t_tanker = new WBTable();
        private WBTable t_driver = new WBTable();
        private WBTable t_transporter = new WBTable();
        private WBTable t_gatepass = new WBTable();
        private IContainer components = null;
        private Label label1;
        private TextBox txt_truck;
        private Button sh_truck;
        private TextBox txt_tanker;
        private Button sh_tanker;
        private TextBox txt_transporter_code;
        private Button sh_transporter;
        private Label label3;
        private Label label2;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label5;
        private TextBox txt_driver_name;
        private TextBox txt_driver_ic;
        private Label label4;
        private Button sh_driver;
        private GroupBox groupBox3;
        private TextBox txt_deli_note;
        private Label label6;
        private TextBox txt_seal;
        private Label label7;
        private GroupBox groupBox4;
        private TextBox txt_remark;
        private Label label9;
        private Button btn_save;
        private Button btn_cancel;
        private Label lbl_transporter_name;
        private TextBox txt_gp_no;
        private Label lbl_gp_no;
        private GroupBox groupBox5;
        private TextBox txt_loc;
        private Label label10;
        private TextBox txt_coy;
        private Label label8;
        private Label lbl_loc;
        private Label lbl_coy;

        public FormRegisGatepassEntry(string mode, string uniq)
        {
            this.InitializeComponent();
            this.MODE = mode;
            this.t_truck.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.t_transporter.OpenTable("wb_transporter", "SELECT * FROM wb_transporter WHERE " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.t_tanker.OpenTable("wb_tanker", "SELECT * FROM wb_tanker", WBData.conn);
            this.t_driver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL) and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
            Program.AutoComp(this.t_truck, "truck_number", this.txt_truck);
            Program.AutoComp(this.t_transporter, "transporter_code", this.txt_transporter_code);
            Program.AutoComp(this.t_tanker, "tanker_no", this.txt_tanker);
            Program.AutoComp(this.t_driver, "license_no", this.txt_driver_ic);
            Program.AutoComp(this.t_driver, "name", this.txt_driver_name);
            this.txt_coy.Text = WBData.sCoyCode;
            this.lbl_coy.Text = WBData.sCoyName;
            this.txt_loc.Text = WBData.sLocCode;
            this.lbl_loc.Text = WBSetting.sLocName;
            if (this.MODE == "NEW")
            {
                this.t_gatepass.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND 1 = 0"), WBData.conn);
                this.lbl_gp_no.Visible = false;
                this.txt_gp_no.Visible = false;
            }
            else
            {
                this.t_gatepass.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND uniq = " + uniq), WBData.conn);
                if (this.t_gatepass.DT.Rows.Count == 1)
                {
                    DataRow row = this.t_gatepass.DT.Rows[0];
                    this.txt_gp_no.Text = row["gatepass_number"].ToString();
                    this.txt_truck.Text = row["truck_number"].ToString();
                    this.txt_tanker.Text = row["tanker_no"].ToString();
                    this.txt_driver_ic.Text = row["License_No"].ToString();
                    this.txt_transporter_code.Text = row["Transporter_Code"].ToString();
                    this.txt_remark.Text = row["GatePass_Remark"].ToString();
                    this.txt_deli_note.Text = row["delivery_note"].ToString();
                    this.txt_seal.Text = row["seal"].ToString();
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.txt_transporter_code.Text };
                    DataRow data = this.t_transporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.lbl_transporter_name.Text = data["Transporter_Name"].ToString();
                    }
                    string[] textArray3 = new string[] { "License_No" };
                    string[] textArray4 = new string[] { this.txt_driver_ic.Text.Trim() };
                    int recNo = this.t_driver.GetRecNo(textArray3, textArray4);
                    if (recNo > -1)
                    {
                        this.txt_driver_name.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    }
                }
                if (this.MODE == "VIEW")
                {
                    this.btn_save.Enabled = false;
                }
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (this.can_save())
            {
                if (this.MODE == "NEW")
                {
                    this.t_gatepass.DR = this.t_gatepass.DT.NewRow();
                    this.t_gatepass.DR["Gatepass_Number"] = this.generate_gatepass_no();
                }
                else
                {
                    this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                    this.t_gatepass.DR.BeginEdit();
                }
                this.t_gatepass.DR["Coy"] = WBData.sCoyCode;
                this.t_gatepass.DR["Location_Code"] = WBData.sLocCode;
                this.t_gatepass.DR["Truck_Number"] = this.txt_truck.Text;
                this.t_gatepass.DR["tanker_no"] = this.txt_tanker.Text;
                this.t_gatepass.DR["Transporter_Code"] = this.txt_transporter_code.Text;
                this.t_gatepass.DR["License_No"] = this.txt_driver_ic.Text;
                this.t_gatepass.DR["GatePass_Remark"] = this.txt_remark.Text;
                this.t_gatepass.DR["delivery_note"] = this.txt_deli_note.Text;
                this.t_gatepass.DR["seal"] = this.txt_seal.Text;
                this.t_gatepass.DR["In_Date"] = DateTime.Now;
                this.t_gatepass.DR["In_Time"] = DateTime.Now.ToString("HH:mm");
                if (this.MODE == "NEW")
                {
                    this.t_gatepass.DR["Create_By"] = WBUser.UserID;
                    this.t_gatepass.DR["Create_Date"] = DateTime.Now;
                    this.t_gatepass.DT.Rows.Add(this.t_gatepass.DR);
                }
                else
                {
                    this.t_gatepass.DR["Change_By"] = WBUser.UserID;
                    this.t_gatepass.DR["Change_Date"] = DateTime.Now;
                    this.t_gatepass.DR.EndEdit();
                }
                this.t_gatepass.Save();
                base.Close();
            }
        }

        private bool can_save()
        {
            bool flag2;
            if (this.txt_truck.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in Truck No", "Warning...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.txt_truck.Focus();
                flag2 = false;
            }
            else if (this.txt_driver_ic.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in Driver IC", "Warning...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.txt_driver_ic.Focus();
                flag2 = false;
            }
            else if (this.txt_transporter_code.Text.Trim() != "")
            {
                flag2 = true;
            }
            else
            {
                MessageBox.Show("Please fill in Transporter Code", "Warning...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.txt_transporter_code.Focus();
                flag2 = false;
            }
            return flag2;
        }

        private bool check_truck_inyard(string truck_no)
        {
            bool flag = false;
            string sqltext = "";
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select * from wb_gatepass where ", WBData.CompanyLocation(""), " and truck_number = '", this.txt_truck.Text.Trim(), "' and (deleted is null OR deleted = 'N' OR deleted = '') and (submit_gatepass is null or Submit_gatepass = 'N')" };
            sqltext = string.Concat(textArray1);
            table.OpenTable("wb_truck", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                flag = false;
            }
            else if (this.MODE == "NEW")
            {
                flag = true;
                MessageBox.Show("Truck is registered with Gatepass No " + table.DT.Rows[0]["gatepass_number"].ToString() + " !! \nPlease Check Truck Number...", "Warning...");
            }
            else
            {
                string[] textArray2 = new string[] { "Select * from wb_gatepass where ", WBData.CompanyLocation(""), " and truck_number = '", this.txt_truck.Text.Trim(), "' and (deleted is null OR deleted = 'N' OR deleted = '') \r\n                        and submit_date is null\r\n                        and gatepass_number <> '", this.txt_gp_no.Text, "'" };
                sqltext = string.Concat(textArray2);
                table.OpenTable("wb_truck", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    flag = true;
                    MessageBox.Show("Truck is registered with Gatepass No " + table.DT.Rows[0]["gatepass_number"].ToString() + " !! \nPlease Check Truck Number...", "Warning...");
                }
            }
            table.Dispose();
            return flag;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string generate_gatepass_no()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_ref", "SELECT ref_no FROM wb_ref WHERE " + WBData.CompanyLocation(" and ref_code ='GATEPASS'"), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                string[] textArray1 = new string[] { "INSERT INTO [wb_ref]([Coy],[Location_Code],[Ref_Code],[Ref_No])\r\n                    VALUES('", WBData.sCoyCode, "','", WBData.sLocCode, "','GATEPASS',0) " };
                string sqltext = string.Concat(textArray1);
                table.OpenTable("WB_COMPANY", sqltext, WBData.conn);
                table.OpenTable("wb_ref", "SELECT ref_no FROM wb_ref WHERE " + WBData.CompanyLocation(" and ref_code ='GATEPASS'"), WBData.conn);
            }
            table.OpenTable("wb_ref", "UPDATE wb_ref SET ref_no = ref_no + 1 WHERE " + WBData.CompanyLocation(" and ref_code ='GATEPASS'"), WBData.conn);
            table.OpenTable("wb_ref", "SELECT ref_no FROM wb_ref WHERE " + WBData.CompanyLocation(" and ref_code ='GATEPASS'"), WBData.conn);
            int result = 0;
            int.TryParse(table.DT.Rows[0]["ref_no"].ToString(), out result);
            return (WBSetting.sGatepassCode + WBData.sCoyCode + WBData.sLocCode + result.ToString().PadLeft(7, '0'));
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.txt_truck = new TextBox();
            this.sh_truck = new Button();
            this.txt_tanker = new TextBox();
            this.sh_tanker = new Button();
            this.txt_transporter_code = new TextBox();
            this.sh_transporter = new Button();
            this.label3 = new Label();
            this.label2 = new Label();
            this.groupBox1 = new GroupBox();
            this.lbl_transporter_name = new Label();
            this.groupBox2 = new GroupBox();
            this.label5 = new Label();
            this.txt_driver_name = new TextBox();
            this.txt_driver_ic = new TextBox();
            this.label4 = new Label();
            this.sh_driver = new Button();
            this.groupBox3 = new GroupBox();
            this.txt_seal = new TextBox();
            this.label7 = new Label();
            this.txt_deli_note = new TextBox();
            this.label6 = new Label();
            this.groupBox4 = new GroupBox();
            this.txt_remark = new TextBox();
            this.label9 = new Label();
            this.btn_cancel = new Button();
            this.btn_save = new Button();
            this.txt_gp_no = new TextBox();
            this.lbl_gp_no = new Label();
            this.groupBox5 = new GroupBox();
            this.lbl_loc = new Label();
            this.lbl_coy = new Label();
            this.txt_loc = new TextBox();
            this.label10 = new Label();
            this.txt_coy = new TextBox();
            this.label8 = new Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x34, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Truck No";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.txt_truck.CharacterCasing = CharacterCasing.Upper;
            this.txt_truck.Location = new Point(110, 0x13);
            this.txt_truck.MaxLength = 50;
            this.txt_truck.Name = "txt_truck";
            this.txt_truck.Size = new Size(0x7b, 20);
            this.txt_truck.TabIndex = 6;
            this.txt_truck.Leave += new EventHandler(this.txt_truck_Leave);
            this.sh_truck.Location = new Point(0xed, 0x11);
            this.sh_truck.Margin = new Padding(0);
            this.sh_truck.Name = "sh_truck";
            this.sh_truck.Size = new Size(0x17, 0x17);
            this.sh_truck.TabIndex = 7;
            this.sh_truck.Text = "...";
            this.sh_truck.UseVisualStyleBackColor = true;
            this.sh_truck.Click += new EventHandler(this.sh_truck_Click);
            this.txt_tanker.CharacterCasing = CharacterCasing.Upper;
            this.txt_tanker.Location = new Point(110, 0x2d);
            this.txt_tanker.MaxLength = 50;
            this.txt_tanker.Name = "txt_tanker";
            this.txt_tanker.Size = new Size(0x7b, 20);
            this.txt_tanker.TabIndex = 8;
            this.txt_tanker.Leave += new EventHandler(this.txt_tanker_Leave);
            this.sh_tanker.Location = new Point(0xed, 0x2b);
            this.sh_tanker.Margin = new Padding(0);
            this.sh_tanker.Name = "sh_tanker";
            this.sh_tanker.Size = new Size(0x17, 0x17);
            this.sh_tanker.TabIndex = 9;
            this.sh_tanker.Text = "...";
            this.sh_tanker.UseVisualStyleBackColor = true;
            this.sh_tanker.Click += new EventHandler(this.sh_tanker_Click);
            this.txt_transporter_code.CharacterCasing = CharacterCasing.Upper;
            this.txt_transporter_code.Location = new Point(110, 0x47);
            this.txt_transporter_code.MaxLength = 50;
            this.txt_transporter_code.Name = "txt_transporter_code";
            this.txt_transporter_code.Size = new Size(0x7b, 20);
            this.txt_transporter_code.TabIndex = 10;
            this.txt_transporter_code.Leave += new EventHandler(this.txt_transporter_code_Leave);
            this.sh_transporter.Location = new Point(0xed, 0x45);
            this.sh_transporter.Margin = new Padding(0);
            this.sh_transporter.Name = "sh_transporter";
            this.sh_transporter.Size = new Size(0x17, 0x17);
            this.sh_transporter.TabIndex = 11;
            this.sh_transporter.Text = "...";
            this.sh_transporter.UseVisualStyleBackColor = true;
            this.sh_transporter.Click += new EventHandler(this.sh_transporter_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x2e, 0x30);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3a, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Tanker No";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(15, 0x4a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x59, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Transporter Code";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.groupBox1.Controls.Add(this.lbl_transporter_name);
            this.groupBox1.Controls.Add(this.txt_truck);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.sh_truck);
            this.groupBox1.Controls.Add(this.txt_transporter_code);
            this.groupBox1.Controls.Add(this.sh_tanker);
            this.groupBox1.Controls.Add(this.sh_transporter);
            this.groupBox1.Controls.Add(this.txt_tanker);
            this.groupBox1.Location = new Point(12, 0x5f);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1c9, 0x67);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Truck Information";
            this.lbl_transporter_name.AutoSize = true;
            this.lbl_transporter_name.Location = new Point(0x107, 0x4a);
            this.lbl_transporter_name.Name = "lbl_transporter_name";
            this.lbl_transporter_name.Size = new Size(0x16, 13);
            this.lbl_transporter_name.TabIndex = 14;
            this.lbl_transporter_name.Text = "     ";
            this.lbl_transporter_name.TextAlign = ContentAlignment.TopRight;
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txt_driver_name);
            this.groupBox2.Controls.Add(this.txt_driver_ic);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.sh_driver);
            this.groupBox2.Location = new Point(12, 0xcc);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x1c9, 0x51);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Driver Information";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x26, 0x30);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x42, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Driver Name";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.txt_driver_name.CharacterCasing = CharacterCasing.Upper;
            this.txt_driver_name.Location = new Point(110, 0x2d);
            this.txt_driver_name.MaxLength = 50;
            this.txt_driver_name.Name = "txt_driver_name";
            this.txt_driver_name.Size = new Size(0xde, 20);
            this.txt_driver_name.TabIndex = 11;
            this.txt_driver_name.Leave += new EventHandler(this.txt_driver_name_Leave);
            this.txt_driver_ic.CharacterCasing = CharacterCasing.Upper;
            this.txt_driver_ic.Location = new Point(110, 0x13);
            this.txt_driver_ic.MaxLength = 50;
            this.txt_driver_ic.Name = "txt_driver_ic";
            this.txt_driver_ic.Size = new Size(0x7b, 20);
            this.txt_driver_ic.TabIndex = 9;
            this.txt_driver_ic.Leave += new EventHandler(this.txt_driver_ic_Leave);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x38, 0x16);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x30, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Driver IC";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.sh_driver.Location = new Point(0xed, 0x11);
            this.sh_driver.Margin = new Padding(0);
            this.sh_driver.Name = "sh_driver";
            this.sh_driver.Size = new Size(0x17, 0x17);
            this.sh_driver.TabIndex = 10;
            this.sh_driver.Text = "...";
            this.sh_driver.UseVisualStyleBackColor = true;
            this.sh_driver.Click += new EventHandler(this.sh_driver_Click);
            this.groupBox3.Controls.Add(this.txt_seal);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txt_deli_note);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new Point(12, 0x123);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1c9, 0x4c);
            this.groupBox3.TabIndex = 0x10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Delivery Information";
            this.txt_seal.CharacterCasing = CharacterCasing.Upper;
            this.txt_seal.Location = new Point(110, 0x2d);
            this.txt_seal.MaxLength = 50;
            this.txt_seal.Name = "txt_seal";
            this.txt_seal.Size = new Size(0x142, 20);
            this.txt_seal.TabIndex = 14;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x3b, 0x30);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x2d, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Seal No";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.txt_deli_note.CharacterCasing = CharacterCasing.Upper;
            this.txt_deli_note.Location = new Point(110, 0x13);
            this.txt_deli_note.MaxLength = 50;
            this.txt_deli_note.Name = "txt_deli_note";
            this.txt_deli_note.Size = new Size(0x142, 20);
            this.txt_deli_note.TabIndex = 12;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x21, 0x16);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x47, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Delivery Note";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.groupBox4.Controls.Add(this.txt_remark);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new Point(12, 0x175);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x1c9, 0x36);
            this.groupBox4.TabIndex = 0x11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Additional Information";
            this.txt_remark.CharacterCasing = CharacterCasing.Upper;
            this.txt_remark.Location = new Point(110, 0x13);
            this.txt_remark.MaxLength = 100;
            this.txt_remark.Name = "txt_remark";
            this.txt_remark.Size = new Size(0x142, 20);
            this.txt_remark.TabIndex = 12;
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x21, 0x16);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x2c, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Remark";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.btn_cancel.Image = Resources.cancel_24px1;
            this.btn_cancel.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new Point(350, 0x1b1);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x5e, 0x23);
            this.btn_cancel.TabIndex = 0x13;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_save.Image = Resources.Save;
            this.btn_save.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_save.Location = new Point(250, 0x1b1);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new Size(0x5e, 0x23);
            this.btn_save.TabIndex = 0x12;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.txt_gp_no.CharacterCasing = CharacterCasing.Upper;
            this.txt_gp_no.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_gp_no.Location = new Point(290, 0x39);
            this.txt_gp_no.MaxLength = 50;
            this.txt_gp_no.Name = "txt_gp_no";
            this.txt_gp_no.ReadOnly = true;
            this.txt_gp_no.Size = new Size(0xb3, 30);
            this.txt_gp_no.TabIndex = 15;
            this.lbl_gp_no.AutoSize = true;
            this.lbl_gp_no.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_gp_no.Location = new Point(0x11d, 0x1a);
            this.lbl_gp_no.Name = "lbl_gp_no";
            this.lbl_gp_no.Size = new Size(0x7e, 0x19);
            this.lbl_gp_no.TabIndex = 20;
            this.lbl_gp_no.Text = "Gatepass No";
            this.lbl_gp_no.TextAlign = ContentAlignment.TopRight;
            this.groupBox5.Controls.Add(this.lbl_loc);
            this.groupBox5.Controls.Add(this.lbl_coy);
            this.groupBox5.Controls.Add(this.txt_loc);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.txt_coy);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Location = new Point(12, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new Size(0x10b, 0x4d);
            this.groupBox5.TabIndex = 0x15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Company Details";
            this.lbl_loc.AutoSize = true;
            this.lbl_loc.Location = new Point(110, 0x31);
            this.lbl_loc.Name = "lbl_loc";
            this.lbl_loc.Size = new Size(0x33, 13);
            this.lbl_loc.TabIndex = 30;
            this.lbl_loc.Text = "Company";
            this.lbl_loc.TextAlign = ContentAlignment.TopRight;
            this.lbl_coy.AutoSize = true;
            this.lbl_coy.Location = new Point(110, 0x18);
            this.lbl_coy.Name = "lbl_coy";
            this.lbl_coy.Size = new Size(0x33, 13);
            this.lbl_coy.TabIndex = 0x1d;
            this.lbl_coy.Text = "Company";
            this.lbl_coy.TextAlign = ContentAlignment.TopRight;
            this.txt_loc.CharacterCasing = CharacterCasing.Upper;
            this.txt_loc.Location = new Point(0x47, 0x2e);
            this.txt_loc.MaxLength = 50;
            this.txt_loc.Name = "txt_loc";
            this.txt_loc.ReadOnly = true;
            this.txt_loc.Size = new Size(0x21, 20);
            this.txt_loc.TabIndex = 0x1c;
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x11, 50);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x30, 13);
            this.label10.TabIndex = 0x1b;
            this.label10.Text = "Location";
            this.label10.TextAlign = ContentAlignment.TopRight;
            this.txt_coy.CharacterCasing = CharacterCasing.Upper;
            this.txt_coy.Location = new Point(0x47, 20);
            this.txt_coy.MaxLength = 50;
            this.txt_coy.Name = "txt_coy";
            this.txt_coy.ReadOnly = true;
            this.txt_coy.Size = new Size(0x21, 20);
            this.txt_coy.TabIndex = 0x1a;
            this.txt_coy.Text = "XX";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(14, 0x17);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x33, 13);
            this.label8.TabIndex = 0x19;
            this.label8.Text = "Company";
            this.label8.TextAlign = ContentAlignment.TopRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e1, 0x203);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox5);
            base.Controls.Add(this.lbl_gp_no);
            base.Controls.Add(this.txt_gp_no);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_save);
            base.Controls.Add(this.groupBox4);
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupBox1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormRegisGatepassEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gatepass Registration";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void sh_driver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.txt_driver_ic.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.txt_driver_ic.Text = driver.ReturnRow["License_No"].ToString();
                this.txt_driver_name.Text = driver.ReturnRow["Name"].ToString();
                if (this.txt_truck.Text.Trim() == "")
                {
                    this.txt_truck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.txt_truck.Focus();
                }
            }
            driver.Dispose();
            this.txt_driver_ic.Focus();
        }

        private void sh_tanker_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.txt_tanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.txt_tanker.Focus();
            }
            tanker.Dispose();
            this.txt_tanker.Focus();
        }

        private void sh_transporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.txt_transporter_code.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.lbl_transporter_name.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.txt_transporter_code.Focus();
            }
            transporter.Dispose();
            this.txt_transporter_code.Focus();
        }

        private void sh_truck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.txt_truck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.txt_truck.Text = truck.ReturnRow["Truck_Number"].ToString();
                this.txt_tanker.Text = truck.ReturnRow["Tanker_no"].ToString().Trim();
                if (this.txt_transporter_code.Text.Trim() == "")
                {
                    this.txt_transporter_code.Text = truck.ReturnRow["Transporter_Code"].ToString();
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.txt_transporter_code.Text };
                    DataRow data = this.t_transporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.lbl_transporter_name.Text = data["Transporter_Name"].ToString();
                    }
                }
            }
            truck.Dispose();
            this.txt_truck.Focus();
        }

        private void txt_driver_ic_Leave(object sender, EventArgs e)
        {
            if (this.txt_driver_ic.Text.Trim() != "")
            {
                this.t_driver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.txt_driver_ic.Text.Trim() };
                int recNo = this.t_driver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.sh_driver.PerformClick();
                    this.txt_driver_ic.Focus();
                }
                else
                {
                    this.txt_driver_name.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    if (this.txt_truck.Text.Trim() == "")
                    {
                        this.txt_truck.Text = this.t_driver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.txt_truck.Focus();
                    }
                }
            }
        }

        private void txt_driver_name_Leave(object sender, EventArgs e)
        {
            if (this.txt_driver_name.Text.Trim() != "")
            {
                this.t_driver.ReOpen();
                string[] aField = new string[] { "Name" };
                string[] aFind = new string[] { this.txt_driver_name.Text.Trim() };
                int recNo = this.t_driver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.sh_driver.PerformClick();
                    this.txt_driver_name.Focus();
                }
                else
                {
                    this.txt_driver_name.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    this.txt_driver_ic.Text = this.t_driver.DT.Rows[recNo]["License_No"].ToString();
                    if (this.txt_truck.Text.Trim() == "")
                    {
                        this.txt_truck.Text = this.t_driver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.txt_truck.Focus();
                    }
                }
            }
        }

        private void txt_tanker_Leave(object sender, EventArgs e)
        {
            if (this.txt_tanker.Text.Trim() != "")
            {
                this.t_tanker.ReOpen();
                string[] aField = new string[] { "Tanker_No" };
                string[] aFind = new string[] { this.txt_tanker.Text.Trim() };
                int recNo = this.t_tanker.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.txt_tanker.Text = this.t_tanker.DT.Rows[recNo]["Tanker_No"].ToString().Trim();
                }
                else
                {
                    this.sh_tanker.PerformClick();
                    this.txt_tanker.Focus();
                }
            }
        }

        private void txt_transporter_code_Leave(object sender, EventArgs e)
        {
            if (this.txt_transporter_code.Text.Trim() != "")
            {
                this.t_transporter.ReOpen();
                string[] aField = new string[] { "transporter_code" };
                string[] aFind = new string[] { this.txt_transporter_code.Text.Trim() };
                int recNo = this.t_transporter.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.txt_transporter_code.Text = this.t_transporter.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                    this.lbl_transporter_name.Text = this.t_transporter.DT.Rows[recNo]["Transporter_Name"].ToString().Trim();
                }
                else
                {
                    this.sh_tanker.PerformClick();
                    this.txt_tanker.Focus();
                }
            }
        }

        private void txt_truck_Leave(object sender, EventArgs e)
        {
            if (this.txt_truck.Text.Trim() != "")
            {
                this.t_truck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.txt_truck.Text.Trim() };
                int recNo = this.t_truck.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.sh_truck.PerformClick();
                    this.txt_truck.Focus();
                }
                else
                {
                    this.txt_truck.Text = this.t_truck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                    if (this.txt_tanker.Text.Trim() == "")
                    {
                        this.txt_tanker.Text = this.t_truck.DT.Rows[recNo]["Tanker_no"].ToString().Trim();
                    }
                    if (this.txt_transporter_code.Text == "")
                    {
                        this.txt_transporter_code.Text = this.t_truck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                        string[] textArray3 = new string[] { "Transporter_Code" };
                        string[] textArray4 = new string[] { this.txt_transporter_code.Text };
                        DataRow data = this.t_transporter.GetData(textArray3, textArray4);
                        if (data != null)
                        {
                            this.lbl_transporter_name.Text = data["Transporter_Name"].ToString().Trim();
                        }
                    }
                }
                if (this.check_truck_inyard(this.txt_truck.Text))
                {
                    this.txt_truck.SelectAll();
                    this.txt_truck.Focus();
                }
            }
        }
    }
}

