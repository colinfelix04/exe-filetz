﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Africa;

    public class RepQualityControl : Form
    {
        public string tipe = "I";
        public bool zAuto = false;
        public bool outspec = false;
        private WBTable tbl_Comm;
        private WBTable tbl_Estate;
        private WBTable tbl_Relation;
        private WBTable tbl_Contract;
        private WBTable vQC;
        private string[] strRef;
        private IContainer components = null;
        public Label label3;
        public Label labelProses1;
        public Label labelProses2;
        public GroupBox grType;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public Button buttonRelation;
        public Label label4;
        public TextBox textRelation;
        public Button buttonEstate;
        public Label labelDoNo;
        public CheckBox checkDate;
        public TextBox textEstate;
        public GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label2;
        public DateTimePicker monthCalendar2;
        public Button button2;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Button button1;
        public Label label7;
        public Label label8;
        public Label label5;
        public TextBox textDO;
        public Button buttonDO;
        public Label label6;
        public CheckBox checkDO;
        private CachedTicketPOMAfrica cachedTicketPOMAfrica1;
        public CheckBox checkOutSpec;
        public CheckBox cb_mill;

        public RepQualityControl()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable vQC = new WBTable();
                vQC = this.initTable(this.checkOutSpec.Checked, this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, WBData.sCoyCode, WBData.sLocCode);
                this.outspec = this.checkOutSpec.Checked;
                if (vQC.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML html = new HTML();
                    html = this.generateRep(vQC, this.monthCalendar1.Value, WBData.sCoyCode, WBData.sLocCode);
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    this.labelProses1.Text = "";
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = "";
                    this.labelProses2.Refresh();
                    html.Dispose();
                    report.Dispose();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["DO_No"].ToString();
                this.label6.Text = contract.ReturnRow["DO_No"].ToString();
                this.textDO.Focus();
            }
            contract.Dispose();
        }

        private void buttonEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.label7.Text = estate.ReturnRow["Estate_Name"].ToString();
                this.textEstate.Focus();
            }
            estate.Dispose();
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.label8.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textRelation.Focus();
            }
            vendor.Dispose();
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.monthCalendar1.Enabled = this.checkDate.Checked;
            this.monthCalendar2.Enabled = this.checkDate.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(WBTable vQC, DateTime dt, string coy, string loc)
        {
            StringBuilder builder;
            int num3;
            int num4;
            this.labelProses1.Text = "0/" + vQC.DT.Rows.Count;
            HTML html = new HTML();
            string path = html.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            HTML html2 = html;
            string[] textArray1 = new string[] { html2.File, @"\LogReport\", coy, loc, "REP_QC_", dt.ToString("ddMMyyyy"), ".htm" };
            html2.File = string.Concat(textArray1);
            html.Title = "List of Quality Control";
            html.Open();
            html.Write(html.Style());
            if (this.rboGR.Checked)
            {
                html.Write("<br><font size=5><b>QUALITY CONTROL LIST OF GOODS RECEIVE</b></font><br>");
            }
            else
            {
                html.Write("<br><font size=5><b>QUALITY CONTROL LIST OF GOODS ISSUE</b></font><br>");
            }
            WBTable table = new WBTable();
            string[] textArray2 = new string[] { "Select * from wb_setting where Coy = '", coy, "' AND Location_Code='", loc, "'" };
            table.OpenTable("wb_setting", string.Concat(textArray2), WBData.conn);
            DataRow row = table.DT.Rows[0];
            WBTable table2 = new WBTable();
            string[] textArray3 = new string[] { "Select * from wb_location where Coy = '", coy, "' AND Location_Code='", loc, "'" };
            table2.OpenTable("wb_location", string.Concat(textArray3), WBData.conn);
            DataRow row2 = table2.DT.Rows[0];
            string[] textArray4 = new string[] { "<br><font size=4>", row["Coy_Name"].ToString(), " (", row["Coy"].ToString(), ")</font>" };
            html.Write(string.Concat(textArray4));
            string[] textArray5 = new string[] { "<br><font size=4>", row2["Location_Name"].ToString(), " (", row["Location_Code"].ToString(), ")</font><br>" };
            html.Write(string.Concat(textArray5));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            html.Write("<br><br>");
            html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            if (this.textCommodity.Text.Trim() != "")
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Commodity</td>");
                html.Write("<td>: <b>" + this.textCommodity.Text + "</b></td>");
                html.Write("</tr>");
            }
            if (this.textEstate.Text.Trim() != "")
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Estate Code</td>");
                html.Write("<td>: <b>" + this.textEstate.Text + "</b></td>");
                html.Write("</tr>");
            }
            if (this.textRelation.Text.Trim() != "")
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Relation Code</td>");
                html.Write("<td>: <b>" + this.textRelation.Text + "</b></td>");
                html.Write("</tr>");
            }
            if (this.textDO.Text.Trim() != "")
            {
                html.Write("<tr class=bd>");
                html.Write("<td>DO No</td>");
                html.Write("<td>: <b>" + this.textDO.Text + "</b></td>");
                html.Write("</tr>");
            }
            if (this.checkDate.Checked)
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Selected Date</td>");
                string[] textArray6 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                html.Write(string.Concat(textArray6));
                html.Write("</tr>");
            }
            html.Write("<tr class=bd>");
            html.Write("<td>Report Date</td>");
            html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            html.Write("</tr>");
            html.Write("</table>");
            html.Write("<br/><br/><br/>");
            html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
            html.Write("<tr class='bd'> ");
            html.Write("<th nowrap rowspan=2>" + Resource.DoE_005 + "</th> ");
            if (this.cb_mill.Checked)
            {
                html.Write("<th nowrap rowspan=2>Mill Name</th> ");
            }
            html.Write("<th nowrap rowspan=2>" + Resource.Trans_005 + "</th> ");
            if (this.checkDO.Checked)
            {
                html.Write("<th nowrap rowspan=2>" + Resource.Trans_025 + "</th> ");
            }
            html.Write("<th nowrap rowspan=2>" + Resource.DriverE_003 + "</th> ");
            WBTable table3 = new WBTable();
            vQC.DR = vQC.DT.Rows[0];
            string[] textArray7 = new string[] { "SELECT QCode FROM wb_Commodity_Detail WHERE ", WBData.CompanyLocation(""), " AND comm_code='", vQC.DR["comm_code"].ToString(), "' ORDER BY QCode ASC" };
            table3.OpenTable("QDetail", string.Concat(textArray7), WBData.conn);
            string[] source = new string[table3.DT.Rows.Count];
            int num = 0;
            foreach (DataRow row3 in table3.DT.Rows)
            {
                int num5 = 0;
                bool outspec = this.outspec;
                num5 = !outspec ? 2 : 3;
                object[] objArray1 = new object[] { "<th nowrap colspan=", num5, " align=center>", row3["QCode"].ToString(), "</td> " };
                html.Write(string.Concat(objArray1));
                source[num++] = row3["QCode"].ToString();
            }
            html.Write("</tr>");
            html.Write("<tr class='bd'> ");
            int num6 = 0;
            while (true)
            {
                if (num6 >= table3.DT.Rows.Count)
                {
                    string str2 = "";
                    string str3 = "";
                    int num2 = 1;
                    builder = new StringBuilder("");
                    num3 = 0;
                    num4 = 0;
                    foreach (DataRow row4 in vQC.DT.Rows)
                    {
                        if ((str3 != row4["ref"].ToString()) && (str3 != ""))
                        {
                            while (true)
                            {
                                if (num4 >= source.Length)
                                {
                                    break;
                                }
                                if (this.outspec)
                                {
                                    builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                }
                                builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                num4++;
                            }
                        }
                        num4 = (num4 >= source.Length) ? 0 : num4;
                        this.labelProses1.Text = num2++ + "/" + vQC.DT.Rows.Count;
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = row4["comm_code"].ToString() + " - " + row4["ref"].ToString();
                        this.labelProses2.Refresh();
                        if (str2 != row4["comm_code"].ToString())
                        {
                            html.Write("</tr>");
                            builder.Replace("?x?x?rowz", num3);
                            html.Write(builder.ToString());
                            builder.Clear();
                            num3 = 0;
                            if (str2 != "")
                            {
                                builder.Append("<tr class='bd'> ");
                                builder.Append("<td colspan=" + table3.DT.Rows.Count + " height=10px></td> ");
                                builder.Append("</tr> ");
                                string[] textArray8 = new string[] { "SELECT QCode FROM wb_Commodity_Detail WHERE ", WBData.CompanyLocation(""), " AND comm_code='", row4["comm_code"].ToString(), "' ORDER BY QCode ASC" };
                                table3.OpenTable("QDetail", string.Concat(textArray8), WBData.conn);
                                builder.Append("<tr class='bd'> ");
                                builder.Append("<th nowrap rowspan=2>" + Resource.Composite_004 + "</th> ");
                                if (this.cb_mill.Checked)
                                {
                                    builder.Append("<th nowrap rowspan=2>Mill Name</th> ");
                                }
                                builder.Append("<th nowrap rowspan=2>" + Resource.Trans_005 + "</th> ");
                                if (this.checkDO.Checked)
                                {
                                    builder.Append("<th nowrap rowspan=2>" + Resource.Trans_025 + "</th> ");
                                }
                                builder.Append("<th nowrap rowspan=2>" + Resource.DriverE_003 + "</th> ");
                                source = new string[table3.DT.Rows.Count];
                                num = 0;
                                foreach (DataRow row5 in table3.DT.Rows)
                                {
                                    int num7 = 0;
                                    bool outspec = this.outspec;
                                    num7 = !outspec ? 2 : 3;
                                    object[] objArray2 = new object[] { "<th nowrap colspan=", num7, " align=center>", html.strq(row5["QCode"].ToString()), "</th> " };
                                    builder.Append(string.Concat(objArray2));
                                    source[num++] = row5["QCode"].ToString();
                                }
                                builder.Append("</tr>");
                                builder.Append("<tr class='bd'> ");
                                int num8 = 0;
                                while (true)
                                {
                                    if (num8 >= table3.DT.Rows.Count)
                                    {
                                        num4 = 0;
                                        builder.Append("</tr>");
                                        break;
                                    }
                                    if (this.outspec)
                                    {
                                        builder.Append("<th nowrap>Contract Spec</th> ");
                                    }
                                    builder.Append("<th nowrap>" + Resource.Block_001 + "</td> ");
                                    builder.Append("<th nowrap>" + Resource.ContractE_038 + "</td> ");
                                    num8++;
                                }
                            }
                            builder.Append("<tr class='bd'> ");
                            builder.Append("<td nowrap valign=top align=center rowspan=?x?x?rowz><b>" + html.strq(row4["comm_code"].ToString()) + "</b></td>");
                            if (this.cb_mill.Checked)
                            {
                                builder.Append("<td nowrap>" + html.strq(row4["mill"].ToString()) + "</td>");
                            }
                            builder.Append("<td nowrap>" + html.strq(row4["ref"].ToString()) + "</td>");
                            if (this.checkDO.Checked)
                            {
                                builder.Append("<td nowrap>" + html.strq(row4["Do_No"].ToString()) + "</td>");
                            }
                            builder.Append("<td nowrap>" + html.strq(row4["Truck_Number"].ToString()) + "</td>");
                            str3 = row4["ref"].ToString();
                            str2 = row4["comm_code"].ToString();
                            num3++;
                        }
                        if ((str2 == row4["comm_code"].ToString()) && (str3 != row4["ref"].ToString()))
                        {
                            builder.Append("</tr>");
                            builder.Append("<tr class='bd'> ");
                            if (this.cb_mill.Checked)
                            {
                                builder.Append("<td nowrap>" + html.strq(row4["mill"].ToString()) + "</td>");
                            }
                            builder.Append("<td nowrap>" + html.strq(row4["ref"].ToString()) + "</td>");
                            if (this.checkDO.Checked)
                            {
                                builder.Append("<td nowrap>" + html.strq(row4["Do_No"].ToString()) + "</td>");
                            }
                            builder.Append("<td nowrap>" + html.strq(row4["truck_Number"].ToString()) + "</td>");
                            str3 = row4["ref"].ToString();
                            num3++;
                        }
                        if ((str2 == row4["comm_code"].ToString()) && (str3 == row4["ref"].ToString()))
                        {
                            while (true)
                            {
                                if ((num4 < source.Length) && source.Contains<string>(row4["QCode"].ToString()))
                                {
                                    if (source[num4] != row4["QCode"].ToString())
                                    {
                                        if (this.outspec)
                                        {
                                            builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                        }
                                        builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                        builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                                        num4++;
                                        continue;
                                    }
                                    if (this.outspec)
                                    {
                                        builder.Append("<td nowrap align=right>" + html.strq($"{row4["contractSpec"]:N0}") + "</td>");
                                    }
                                    builder.Append("<td nowrap align=right>" + html.strq($"{row4["Estate"]:N0}") + "</td>");
                                    builder.Append("<td nowrap align=right>" + html.strq($"{row4["Factory"]:N0}") + "</td>");
                                    num4++;
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
                if (this.outspec)
                {
                    html.Write("<th nowrap>Contract Spec</th> ");
                }
                html.Write("<th nowrap>" + Resource.Block_001 + "</th> ");
                html.Write("<th nowrap>" + Resource.ContractE_038 + "</th> ");
                num6++;
            }
            while (true)
            {
                if (num4 >= source.Length)
                {
                    builder.Replace("?x?x?rowz", num3);
                    html.Write(builder.ToString());
                    builder.Clear();
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br>");
                    html.Write("<br>");
                    html.writeSign();
                    html.Close();
                    return html;
                }
                if (this.outspec)
                {
                    builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                }
                builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                builder.Append("<td nowrap align=right>" + html.strq($"{"0":N0}") + "</td>");
                num4++;
            }
        }

        private void initAutoComplete()
        {
            this.tbl_Comm = new WBTable();
            this.tbl_Estate = new WBTable();
            this.tbl_Relation = new WBTable();
            this.tbl_Contract = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            this.tbl_Estate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            this.tbl_Relation.OpenTable("wb_relation", "Select * from wb_relation", WBData.conn);
            this.tbl_Contract.OpenTable("wb_contract", "select * from wb_contract", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            Program.AutoComp(this.tbl_Estate, "Estate_Code", this.textEstate);
            Program.AutoComp(this.tbl_Relation, "Relation_Code", this.textRelation);
            Program.AutoComp(this.tbl_Contract, "Do_No", this.textDO);
        }

        private void initComponent()
        {
            base.KeyPreview = true;
            this.rboGR.Checked = true;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }

        private void InitializeComponent()
        {
            this.label3 = new Label();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.grType = new GroupBox();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.buttonRelation = new Button();
            this.label4 = new Label();
            this.textRelation = new TextBox();
            this.buttonEstate = new Button();
            this.labelDoNo = new Label();
            this.checkDate = new CheckBox();
            this.textEstate = new TextBox();
            this.groupDate = new GroupBox();
            this.label1 = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.button2 = new Button();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.button1 = new Button();
            this.label7 = new Label();
            this.label8 = new Label();
            this.label5 = new Label();
            this.textDO = new TextBox();
            this.buttonDO = new Button();
            this.label6 = new Label();
            this.checkDO = new CheckBox();
            this.cachedTicketPOMAfrica1 = new CachedTicketPOMAfrica();
            this.checkOutSpec = new CheckBox();
            this.cb_mill = new CheckBox();
            this.grType.SuspendLayout();
            this.groupDate.SuspendLayout();
            base.SuspendLayout();
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x10, 14);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xb6, 20);
            this.label3.TabIndex = 0x44;
            this.label3.Text = "List of Quality Control";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x144, 9);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd0, 13);
            this.labelProses1.TabIndex = 0x43;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x141, 0x16);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd7, 13);
            this.labelProses2.TabIndex = 0x42;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x10, 0x35);
            this.grType.Name = "grType";
            this.grType.Size = new Size(260, 0x2d);
            this.grType.TabIndex = 50;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0x94, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Checked = true;
            this.rboGR.Location = new Point(0x10, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.buttonRelation.Location = new Point(0x11a, 0xf6);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 60;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x19, 0xfb);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2e, 13);
            this.label4.TabIndex = 0x41;
            this.label4.Text = "Relation";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x55, 0xf8);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xbf, 20);
            this.textRelation.TabIndex = 0x37;
            this.textRelation.Leave += new EventHandler(this.textRelation_Leave);
            this.buttonEstate.Location = new Point(0x11a, 0xdb);
            this.buttonEstate.Margin = new Padding(0);
            this.buttonEstate.Name = "buttonEstate";
            this.buttonEstate.Size = new Size(0x17, 0x17);
            this.buttonEstate.TabIndex = 0x3b;
            this.buttonEstate.Text = "...";
            this.buttonEstate.UseVisualStyleBackColor = true;
            this.buttonEstate.Click += new EventHandler(this.buttonEstate_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(0x22, 0xe0);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x25, 13);
            this.labelDoNo.TabIndex = 0x40;
            this.labelDoNo.Text = "Estate";
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(20, 0x6f);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x3f;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x55, 0xdd);
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0xbf, 20);
            this.textEstate.TabIndex = 0x36;
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x10, 0x7e);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x176, 0x2d);
            this.groupDate.TabIndex = 0x34;
            this.groupDate.TabStop = false;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x4e, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xc4, 20);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xfe, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1a6, 0x5e);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x39;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonComm.Location = new Point(0x11a, 0xbf);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x3a;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x135, 0xc4);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x3e;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x55, 0xc1);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xbf, 20);
            this.textCommodity.TabIndex = 0x35;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(13, 0xc4);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x3d;
            this.labelcommodity.Text = "Commodity";
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x1a6, 0x36);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x38;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x135, 0xe0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x25, 13);
            this.label7.TabIndex = 0x45;
            this.label7.Text = "Estate";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x135, 0xfb);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2e, 13);
            this.label8.TabIndex = 70;
            this.label8.Text = "Relation";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x19, 0x116);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x2b, 13);
            this.label5.TabIndex = 0x47;
            this.label5.Text = "DO No.";
            this.textDO.CharacterCasing = CharacterCasing.Upper;
            this.textDO.Location = new Point(0x55, 0x113);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xbf, 20);
            this.textDO.TabIndex = 0x48;
            this.buttonDO.Location = new Point(0x11a, 0x111);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 0x49;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x135, 0x116);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x29, 13);
            this.label6.TabIndex = 0x4a;
            this.label6.Text = "Do No.";
            this.checkDO.AutoSize = true;
            this.checkDO.Checked = true;
            this.checkDO.CheckState = CheckState.Checked;
            this.checkDO.Location = new Point(0x10, 0x13a);
            this.checkDO.Name = "checkDO";
            this.checkDO.Size = new Size(0x5c, 0x11);
            this.checkDO.TabIndex = 0x4b;
            this.checkDO.Text = "Show DO No.";
            this.checkDO.UseVisualStyleBackColor = true;
            this.checkOutSpec.AutoSize = true;
            this.checkOutSpec.Location = new Point(0xa4, 0x13a);
            this.checkOutSpec.Name = "checkOutSpec";
            this.checkOutSpec.Size = new Size(160, 0x11);
            this.checkOutSpec.TabIndex = 0x4c;
            this.checkOutSpec.Text = "Show Outspec Material Only";
            this.checkOutSpec.UseVisualStyleBackColor = true;
            this.cb_mill.AutoSize = true;
            this.cb_mill.Location = new Point(0x167, 0x13a);
            this.cb_mill.Name = "cb_mill";
            this.cb_mill.Size = new Size(0x47, 0x11);
            this.cb_mill.TabIndex = 0x4d;
            this.cb_mill.Text = "Show Mill";
            this.cb_mill.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x223, 0x157);
            base.ControlBox = false;
            base.Controls.Add(this.cb_mill);
            base.Controls.Add(this.checkOutSpec);
            base.Controls.Add(this.checkDO);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.buttonDO);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.buttonEstate);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Name = "RepQualityControl";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Report Quality Control";
            base.Load += new EventHandler(this.RepQualityControl_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepQualityControl_KeyPress);
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public WBTable initTable(bool outspec, bool byDate, DateTime dateFrom, DateTime dateTo, string coy, string loc)
        {
            WBTable table = new WBTable();
            string str = "* FROM (SELECT wb_transQC.Comm_Code AS Comm_Code, vw_trans.Mill AS Mill, vw_trans.Ref AS Ref, vw_trans.Truck_Number AS Truck_Number, wb_TransQC.QCode AS QCode, vw_trans.Relation_Code AS Relation_Code, vw_trans.Estate_Code AS Estate_Code, wb_TransQC.Estate AS Estate, wb_TransQC.Factory AS Factory, wb_TransQC.SAP_Value AS contractSpec, vw_trans.IO AS IO, vw_trans.Report_Date AS Report_Date, vw_trans.Location_Code AS Location_Code, vw_trans.Coy AS Coy, vw_trans.DO_No AS Do_No, vw_trans.Deleted AS Deleted FROM vw_Trans INNER JOIN wb_TransQC ON vw_Trans.Coy = wb_TransQC.Coy AND vw_Trans.Location_Code = wb_TransQC.Location_Code AND vw_Trans.Ref = wb_TransQC.Ref ";
            if (outspec)
            {
                str = str + "AND (wb_TransQC.Factory > wb_TransQC.SAP_Value AND wb_TransQC.SAP_Value != '0') ";
            }
            str = str + ") mt_vw_trans ";
            string[] textArray1 = new string[] { "SELECT ", str, " WHERE Coy = '", coy, "' AND Location_Code='", loc, "' " };
            string sqltext = string.Concat(textArray1);
            if (byDate && !this.zAuto)
            {
                sqltext = (sqltext + " AND (report_date>='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND report_date<='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            else if (byDate && this.zAuto)
            {
                sqltext = sqltext + " AND (report_date ='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            sqltext = sqltext + " AND IO ='" + (this.rboGR.Checked ? "I" : "O") + "'";
            if (this.textCommodity.Text != "")
            {
                sqltext = sqltext + " AND Comm_Code='" + this.textCommodity.Text.Trim() + "'";
            }
            if (this.textEstate.Text != "")
            {
                sqltext = sqltext + " AND Estate_Code='" + this.textEstate.Text.Trim() + "'";
            }
            if (this.textRelation.Text != "")
            {
                sqltext = sqltext + " AND Relation_Code='" + this.textRelation.Text.Trim() + "'";
            }
            if (this.textDO.Text != "")
            {
                sqltext = sqltext + " AND Do_No='" + this.textDO.Text.Trim() + "'";
            }
            string str3 = "";
            if (this.cb_mill.Checked)
            {
                str3 = " mill, ";
            }
            sqltext = sqltext + " AND (deleted is null or deleted = 'N') ORDER BY Comm_Code, " + str3 + " Ref, QCode";
            table.OpenTable("viewQC", sqltext, WBData.conn);
            if (outspec && (table.DT.Rows.Count > 0))
            {
                this.strRef = new string[table.DT.Rows.Count];
                int index = 0;
                foreach (DataRow row in table.DT.Rows)
                {
                    if (!this.strRef.Contains<string>(row["ref"].ToString()))
                    {
                        this.strRef[index] = row["ref"].ToString();
                        index++;
                    }
                }
                str = "* FROM (SELECT wb_transQC.Comm_Code AS Comm_Code, vw_trans.Ref AS Ref, vw_trans.Truck_Number AS Truck_Number, wb_TransQC.QCode AS QCode, vw_trans.Relation_Code AS Relation_Code, vw_trans.Estate_Code AS Estate_Code, wb_TransQC.Estate AS Estate, wb_TransQC.Factory AS Factory, wb_TransQC.SAP_Value AS contractSpec, vw_trans.IO AS IO, vw_trans.Report_Date AS Report_Date, vw_trans.Location_Code AS Location_Code, vw_trans.Coy AS Coy, vw_trans.DO_No AS Do_No, vw_trans.Deleted AS Deleted FROM vw_Trans INNER JOIN wb_TransQC ON vw_Trans.Coy = wb_TransQC.Coy AND vw_Trans.Location_Code = wb_TransQC.Location_Code AND vw_Trans.Ref = wb_TransQC.Ref) mt_vw_trans ";
                string[] textArray2 = new string[] { "SELECT ", str, " WHERE Coy = '", coy, "' AND Location_Code='", loc, "' " };
                sqltext = string.Concat(textArray2);
                if (byDate && !this.zAuto)
                {
                    sqltext = (sqltext + " AND (report_date>='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND report_date<='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
                }
                else if (byDate && this.zAuto)
                {
                    sqltext = sqltext + " AND (report_date ='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
                }
                sqltext = sqltext + " AND IO ='" + (this.rboGR.Checked ? "I" : "O") + "'";
                if (this.textCommodity.Text != "")
                {
                    sqltext = sqltext + " AND Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                }
                if (this.textEstate.Text != "")
                {
                    sqltext = sqltext + " AND Estate_Code='" + this.textEstate.Text.Trim() + "'";
                }
                if (this.textRelation.Text != "")
                {
                    sqltext = sqltext + " AND Relation_Code='" + this.textRelation.Text.Trim() + "'";
                }
                if (this.textDO.Text != "")
                {
                    sqltext = sqltext + " AND Do_No='" + this.textDO.Text.Trim() + "'";
                }
                string str4 = "";
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.strRef.Length)
                    {
                        sqltext = (sqltext + str4 + ")") + " AND (deleted is null or deleted = 'N') ORDER BY Comm_Code, Ref, QCode ASC";
                        table.OpenTable("viewQC", sqltext, WBData.conn);
                        break;
                    }
                    if (this.strRef[num2] != null)
                    {
                        str4 = (num2 != 0) ? (str4 + " OR ref='" + this.strRef[num2] + "'") : (str4 + " AND (ref='" + this.strRef[num2] + "'");
                    }
                    num2++;
                }
            }
            return table;
        }

        private void RepQualityControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepQualityControl_Load(object sender, EventArgs e)
        {
            this.translate();
            this.label7.Text = "";
            this.labelCommName.Text = "";
            this.label8.Text = "";
            this.label6.Text = "";
            this.initAutoComplete();
            this.initComponent();
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            if (this.textCommodity.Text.Trim() == "")
            {
                this.labelCommName.Text = "";
            }
            else
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.labelCommName.Text = "";
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (this.textEstate.Text.Trim() == "")
            {
                this.label7.Text = "";
            }
            else
            {
                this.tbl_Estate.ReOpen();
                string[] aField = new string[] { "Estate_Code" };
                string[] aFind = new string[] { this.textEstate.Text.Trim() };
                int recNo = this.tbl_Estate.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.label7.Text = this.tbl_Estate.DT.Rows[recNo]["Estate_name"].ToString().Trim();
                }
                else
                {
                    this.label7.Text = "";
                    this.buttonEstate.PerformClick();
                    this.textEstate.Focus();
                }
            }
        }

        private void textRelation_Leave(object sender, EventArgs e)
        {
            if (this.textRelation.Text.Trim() == "")
            {
                this.label8.Text = "";
            }
            else
            {
                this.tbl_Relation.ReOpen();
                string[] aField = new string[] { "Relation_Code" };
                string[] aFind = new string[] { this.textRelation.Text.Trim() };
                int recNo = this.tbl_Relation.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.label8.Text = this.tbl_Relation.DT.Rows[recNo]["relation_name"].ToString().Trim();
                }
                else
                {
                    this.label8.Text = "";
                    this.buttonRelation.PerformClick();
                    this.textRelation.Focus();
                }
            }
        }

        private void translate()
        {
            this.Text = Resource.Report07_001;
            this.label3.Text = Resource.Report07_002;
            this.grType.Text = Resource.Report07_003;
            this.rboGR.Text = Resource.Report07_004;
            this.rboGI.Text = Resource.Report07_005;
            this.checkDate.Text = Resource.Report07_006;
            this.label1.Text = Resource.Report07_007;
            this.label2.Text = Resource.Report07_008;
            this.labelcommodity.Text = Resource.Report07_009;
            this.labelDoNo.Text = Resource.Report07_010;
            this.label4.Text = Resource.Report07_011;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
        }
    }
}

