﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTemplateSAPEntry : Form
    {
        private WBTable tbl_templateSAP;
        private WBTable tbl_all;
        public int nCurrRow;
        public DataRow templateRow;
        public string pmode;
        public string changeReason;
        public string logKey;
        private string sqlText;
        public bool saved;
        private int cnumbering;
        private string str_conn;
        private SqlConnection conn;
        private string sapIDSYS;
        private IContainer components;
        private GroupBox groupBox1;
        private Label label2;
        private TextBox textSAPFiledName;
        private GroupBox groupBoxFromTable;
        private ComboBox comboBoxKeyField2;
        private ComboBox comboBoxKeyField1;
        private ComboBox comboBoxFieldName;
        private ComboBox comboBoxTableName;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private GroupBox groupBoxFixed;
        private TextBox textBoxValue;
        private Label label7;
        private Label label9;
        public ComboBox comboBoxModuleName;
        public NumericUpDown numericType;
        private Label label8;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public ToolStripMenuItem menuClose;
        private ComboBox comboBoxTypeData;
        private CheckBox checkFixed;
        private Label label1;
        private Button buttonTest;

        public FormTemplateSAPEntry()
        {
            this.tbl_templateSAP = new WBTable();
            this.tbl_all = new WBTable();
            this.changeReason = "";
            this.logKey = "";
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.components = null;
            this.InitializeComponent();
            this.translate();
        }

        public FormTemplateSAPEntry(DataRow aRow)
        {
            this.tbl_templateSAP = new WBTable();
            this.tbl_all = new WBTable();
            this.changeReason = "";
            this.logKey = "";
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.components = null;
            this.InitializeComponent();
            this.templateRow = aRow;
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.simpan();
            this.saved = true;
        }

        private void buttonTest_Click(object sender, EventArgs e)
        {
            ExpressionVariabel owner = new ExpressionVariabel();
            string pStr = (this.textBoxValue.Text.Trim() + " ~").ToUpper().Replace("VAL".Trim(), "1.00").Replace("~", "");
            owner.NET = 1.0;
            if (Program.eval(pStr, owner) == -999999999.0)
            {
                this.textBoxValue.Focus();
            }
            else
            {
                MessageBox.Show(Resource.Mes_170);
            }
        }

        private void cekFixed()
        {
            if (this.checkFixed.Checked)
            {
                this.groupBoxFromTable.Enabled = false;
                this.groupBoxFixed.Enabled = true;
            }
            else
            {
                this.groupBoxFromTable.Enabled = true;
                this.groupBoxFixed.Enabled = false;
            }
        }

        private void checkFixed_CheckedChanged(object sender, EventArgs e)
        {
            this.cekFixed();
        }

        private void checkFixed_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!this.checkFixed.Checked)
            {
                this.groupBoxFromTable.Enabled = true;
                this.groupBoxFixed.Enabled = false;
                this.textBoxValue.Text = "";
            }
            else
            {
                this.groupBoxFromTable.Enabled = false;
                this.groupBoxFixed.Enabled = true;
                this.textBoxValue.Text = "";
            }
        }

        private void clearTextBox()
        {
            this.checkFixed.Checked = false;
            this.cekFixed();
            this.textSAPFiledName.Text = "";
            this.comboBoxTableName.Text = "";
            this.comboBoxFieldName.Text = "";
            this.comboBoxKeyField1.Text = "";
            this.comboBoxKeyField2.Text = "";
            this.textBoxValue.Text = "";
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBoxTypeData.Text == "Formula")
            {
                this.checkFixed.Checked = false;
                this.checkFixed.Visible = false;
                this.groupBoxFixed.Enabled = true;
                this.buttonTest.Visible = true;
            }
        }

        private void comboBoxTableName_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxTypeData_Leave(object sender, EventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTemplateSAPEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.menuClose.PerformClick();
            }
        }

        private void FormTemplateSAPEntry_Load(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = WBData.sServer;
            textArray1[2] = "; database=";
            textArray1[3] = WBData.sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = WBData.sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = WBData.sPassword;
            textArray1[8] = ";";
            this.str_conn = string.Concat(textArray1);
            this.conn = new SqlConnection(this.str_conn);
            SqlCommand command = this.conn.CreateCommand();
            command.CommandText = "SELECT table_name AS Name FROM INFORMATION_SCHEMA.Tables WHERE TABLE_TYPE = 'BASE TABLE' Order By table_name";
            try
            {
                this.conn.Open();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_545 + "\n\n" + exception.Message, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            SqlDataReader reader = command.ExecuteReader();
            while (true)
            {
                if (!reader.Read())
                {
                    this.comboBoxModuleName.Enabled = false;
                    this.numericType.Enabled = false;
                    if (this.pmode == "EDIT")
                    {
                        this.isiTextBox();
                        this.sqlText = "Select * From wb_templateSAP Where " + WBData.CompanyLocation(" and uniq ='" + this.templateRow["uniq"].ToString().Trim() + "'");
                        this.tbl_templateSAP.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
                        this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[0];
                    }
                    else if (this.pmode == "ADD")
                    {
                        this.clearTextBox();
                        string[] textArray2 = new string[] { " and modul = '", this.comboBoxModuleName.Text, "'  and type = '", this.numericType.Value.ToString().Trim(), "' order by column_numbering" };
                        this.sqlText = "Select * From wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray2));
                        this.tbl_templateSAP.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
                        this.getMaxNumbering();
                    }
                    break;
                }
                string item = (string) reader[0];
                if (item.Substring(0, 3) == "wb_")
                {
                    this.comboBoxTableName.Items.Add(item);
                }
            }
        }

        public void getMaxNumbering()
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " and modul = '", this.comboBoxModuleName.Text, "'  and type = '", this.numericType.Value.ToString().Trim(), "'" };
            this.sqlText = "Select max(column_numbering) as maxNumbering From wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray1));
            table.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
            table.DR = table.DT.Rows[0];
            this.cnumbering = (table.DR["maxNumbering"].ToString() == "") ? 1 : (Convert.ToInt16(table.DR["maxNumbering"].ToString()) + 1);
            table.Dispose();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void groupBoxFromTable_Enter(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new GroupBox();
            this.label1 = new Label();
            this.checkFixed = new CheckBox();
            this.comboBoxTypeData = new ComboBox();
            this.groupBoxFixed = new GroupBox();
            this.buttonTest = new Button();
            this.textBoxValue = new TextBox();
            this.label7 = new Label();
            this.groupBoxFromTable = new GroupBox();
            this.comboBoxKeyField2 = new ComboBox();
            this.comboBoxKeyField1 = new ComboBox();
            this.comboBoxFieldName = new ComboBox();
            this.comboBoxTableName = new ComboBox();
            this.label6 = new Label();
            this.label5 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.textSAPFiledName = new TextBox();
            this.label2 = new Label();
            this.label9 = new Label();
            this.comboBoxModuleName = new ComboBox();
            this.numericType = new NumericUpDown();
            this.label8 = new Label();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.menuClose = new ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBoxFixed.SuspendLayout();
            this.groupBoxFromTable.SuspendLayout();
            this.numericType.BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.groupBox1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.checkFixed);
            this.groupBox1.Controls.Add(this.comboBoxTypeData);
            this.groupBox1.Controls.Add(this.groupBoxFixed);
            this.groupBox1.Controls.Add(this.groupBoxFromTable);
            this.groupBox1.Controls.Add(this.textSAPFiledName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new Point(12, 70);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x151, 0x180);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new EventHandler(this.groupBox1_Enter);
            this.label1.Location = new Point(6, 0x34);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x59, 13);
            this.label1.TabIndex = 0x19;
            this.label1.Text = "Data Type";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.checkFixed.AutoSize = true;
            this.checkFixed.Location = new Point(0xc2, 0x4c);
            this.checkFixed.Name = "checkFixed";
            this.checkFixed.Size = new Size(0x51, 0x11);
            this.checkFixed.TabIndex = 0x18;
            this.checkFixed.Text = "Fixed Value";
            this.checkFixed.UseVisualStyleBackColor = true;
            this.checkFixed.CheckedChanged += new EventHandler(this.checkFixed_CheckedChanged_1);
            this.comboBoxTypeData.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxTypeData.FormattingEnabled = true;
            object[] items = new object[] { "String", "Number", "Date", "Time", "Boolean", "Formula" };
            this.comboBoxTypeData.Items.AddRange(items);
            this.comboBoxTypeData.Location = new Point(0x65, 0x31);
            this.comboBoxTypeData.Name = "comboBoxTypeData";
            this.comboBoxTypeData.Size = new Size(0xaf, 0x15);
            this.comboBoxTypeData.TabIndex = 1;
            this.comboBoxTypeData.SelectedIndexChanged += new EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBoxTypeData.Leave += new EventHandler(this.comboBoxTypeData_Leave);
            this.groupBoxFixed.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.groupBoxFixed.Controls.Add(this.buttonTest);
            this.groupBoxFixed.Controls.Add(this.textBoxValue);
            this.groupBoxFixed.Controls.Add(this.label7);
            this.groupBoxFixed.Location = new Point(14, 0x12a);
            this.groupBoxFixed.Name = "groupBoxFixed";
            this.groupBoxFixed.Size = new Size(0x12b, 0x53);
            this.groupBoxFixed.TabIndex = 3;
            this.groupBoxFixed.TabStop = false;
            this.groupBoxFixed.Text = "Fixed Value";
            this.buttonTest.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.buttonTest.Location = new Point(0xba, 0x39);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new Size(0x4b, 0x17);
            this.buttonTest.TabIndex = 0x17;
            this.buttonTest.Text = "Test Forml.";
            this.buttonTest.UseVisualStyleBackColor = true;
            this.buttonTest.Click += new EventHandler(this.buttonTest_Click);
            this.textBoxValue.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.textBoxValue.Location = new Point(0x57, 0x1f);
            this.textBoxValue.MaxLength = 250;
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.Size = new Size(0xaf, 20);
            this.textBoxValue.TabIndex = 0;
            this.label7.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.label7.Location = new Point(6, 0x22);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x4b, 13);
            this.label7.TabIndex = 0x16;
            this.label7.Text = "Value";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.groupBoxFromTable.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.groupBoxFromTable.Controls.Add(this.comboBoxKeyField2);
            this.groupBoxFromTable.Controls.Add(this.comboBoxKeyField1);
            this.groupBoxFromTable.Controls.Add(this.comboBoxFieldName);
            this.groupBoxFromTable.Controls.Add(this.comboBoxTableName);
            this.groupBoxFromTable.Controls.Add(this.label6);
            this.groupBoxFromTable.Controls.Add(this.label5);
            this.groupBoxFromTable.Controls.Add(this.label4);
            this.groupBoxFromTable.Controls.Add(this.label3);
            this.groupBoxFromTable.Location = new Point(14, 0x76);
            this.groupBoxFromTable.Name = "groupBoxFromTable";
            this.groupBoxFromTable.Size = new Size(0x124, 0xae);
            this.groupBoxFromTable.TabIndex = 0x13;
            this.groupBoxFromTable.TabStop = false;
            this.groupBoxFromTable.Text = "From Table Value";
            this.groupBoxFromTable.Enter += new EventHandler(this.groupBoxFromTable_Enter);
            this.comboBoxKeyField2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.comboBoxKeyField2.FormattingEnabled = true;
            this.comboBoxKeyField2.Location = new Point(0x57, 0x8e);
            this.comboBoxKeyField2.Name = "comboBoxKeyField2";
            this.comboBoxKeyField2.Size = new Size(0xaf, 0x15);
            this.comboBoxKeyField2.TabIndex = 3;
            this.comboBoxKeyField1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.comboBoxKeyField1.FormattingEnabled = true;
            this.comboBoxKeyField1.Location = new Point(0x57, 0x66);
            this.comboBoxKeyField1.Name = "comboBoxKeyField1";
            this.comboBoxKeyField1.Size = new Size(0xaf, 0x15);
            this.comboBoxKeyField1.TabIndex = 2;
            this.comboBoxFieldName.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.comboBoxFieldName.FormattingEnabled = true;
            this.comboBoxFieldName.Location = new Point(0x57, 0x3a);
            this.comboBoxFieldName.Name = "comboBoxFieldName";
            this.comboBoxFieldName.Size = new Size(0xaf, 0x15);
            this.comboBoxFieldName.TabIndex = 1;
            this.comboBoxTableName.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.comboBoxTableName.FormattingEnabled = true;
            this.comboBoxTableName.Location = new Point(0x57, 0x13);
            this.comboBoxTableName.Name = "comboBoxTableName";
            this.comboBoxTableName.Size = new Size(0xaf, 0x15);
            this.comboBoxTableName.TabIndex = 0;
            this.comboBoxTableName.SelectedIndexChanged += new EventHandler(this.comboBoxTableName_SelectedIndexChanged);
            this.label6.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.label6.Location = new Point(6, 0x91);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x4b, 13);
            this.label6.TabIndex = 0x13;
            this.label6.Text = "Key Field 2";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.label5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.label5.Location = new Point(6, 0x69);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x4b, 13);
            this.label5.TabIndex = 0x12;
            this.label5.Text = "Key Field 1";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.label4.Location = new Point(6, 0x3d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x4b, 13);
            this.label4.TabIndex = 0x11;
            this.label4.Text = "Field Name";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.label3.Location = new Point(6, 0x16);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x4b, 13);
            this.label3.TabIndex = 0x10;
            this.label3.Text = "Table Name";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textSAPFiledName.Location = new Point(0x65, 0x17);
            this.textSAPFiledName.Name = "textSAPFiledName";
            this.textSAPFiledName.Size = new Size(0xaf, 20);
            this.textSAPFiledName.TabIndex = 0;
            this.label2.Location = new Point(6, 0x1a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x59, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "SAP Field Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x9a, 0x19);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x1f, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Type";
            this.comboBoxModuleName.FormattingEnabled = true;
            object[] objArray2 = new object[] { "MM", "SD" };
            this.comboBoxModuleName.Items.AddRange(objArray2);
            this.comboBoxModuleName.Location = new Point(12, 0x2b);
            this.comboBoxModuleName.Name = "comboBoxModuleName";
            this.comboBoxModuleName.Size = new Size(0x79, 0x15);
            this.comboBoxModuleName.TabIndex = 0;
            this.numericType.Location = new Point(0x9d, 0x2c);
            this.numericType.Name = "numericType";
            this.numericType.Size = new Size(0x37, 20);
            this.numericType.TabIndex = 1;
            int[] bits = new int[4];
            bits[0] = 1;
            this.numericType.Value = new decimal(bits);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(12, 0x19);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2a, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Module";
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.menuClose };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x163, 0x18);
            this.menuStrip1.TabIndex = 0x16;
            this.menuStrip1.Text = "menuStrip1";
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x2d, 20);
            this.activitiesToolStripMenuItem.Text = "&SAVE";
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.menuClose.Name = "menuClose";
            this.menuClose.Size = new Size(0x30, 20);
            this.menuClose.Text = "&Close";
            this.menuClose.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x163, 0x1d2);
            base.ControlBox = false;
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.numericType);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.comboBoxModuleName);
            base.KeyPreview = true;
            base.Name = "FormTemplateSAPEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Template SAP Entry";
            base.Load += new EventHandler(this.FormTemplateSAPEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTemplateSAPEntry_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxFixed.ResumeLayout(false);
            this.groupBoxFixed.PerformLayout();
            this.groupBoxFromTable.ResumeLayout(false);
            this.numericType.EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void isiTextBox()
        {
            this.comboBoxModuleName.Text = this.templateRow["modul"].ToString().Trim().ToUpper();
            this.numericType.Value = Convert.ToInt16(this.templateRow["type"].ToString());
            this.checkFixed.Checked = this.templateRow["fixed"].ToString() != "0";
            this.cekFixed();
            this.textSAPFiledName.Text = this.templateRow["Title_Excel"].ToString();
            this.comboBoxTableName.Text = this.templateRow["Table_name"].ToString();
            this.comboBoxFieldName.Text = this.templateRow["Field_WB"].ToString();
            this.comboBoxKeyField1.Text = this.templateRow["Key_Field"].ToString();
            this.comboBoxKeyField2.Text = this.templateRow["Key_Field2"].ToString();
            this.textBoxValue.Text = this.templateRow["value"].ToString();
            this.comboBoxTypeData.Text = this.templateRow["data_type"].ToString();
        }

        private void simpan()
        {
            if (this.pmode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Lbl_Module },
                    textRefNo = { Text = this.comboBoxModuleName.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            if (this.pmode == "EDIT")
            {
                this.tbl_templateSAP.DR.BeginEdit();
                this.logKey = this.tbl_templateSAP.DR["uniq"].ToString();
            }
            else if (this.pmode == "ADD")
            {
                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.NewRow();
                this.tbl_templateSAP.DR["Coy"] = WBData.sCoyCode;
                this.tbl_templateSAP.DR["location_code"] = WBData.sLocCode;
                this.tbl_templateSAP.DR["column_numbering"] = this.cnumbering;
            }
            this.tbl_templateSAP.DR["modul"] = this.comboBoxModuleName.Text;
            this.tbl_templateSAP.DR["type"] = this.numericType.Value;
            this.tbl_templateSAP.DR["fixed"] = this.checkFixed.Checked ? "1" : "0";
            this.tbl_templateSAP.DR["Title_Excel"] = this.textSAPFiledName.Text;
            this.tbl_templateSAP.DR["Table_name"] = this.comboBoxTableName.Text;
            this.tbl_templateSAP.DR["Field_WB"] = this.comboBoxFieldName.Text;
            this.tbl_templateSAP.DR["Key_Field"] = this.comboBoxKeyField1.Text;
            this.tbl_templateSAP.DR["Key_Field2"] = this.comboBoxKeyField2.Text;
            this.tbl_templateSAP.DR["value"] = this.textBoxValue.Text;
            this.tbl_templateSAP.DR["data_Type"] = this.comboBoxTypeData.Text;
            if (this.pmode == "EDIT")
            {
                this.tbl_templateSAP.DR.EndEdit();
            }
            else if (this.pmode == "ADD")
            {
                this.tbl_templateSAP.DT.Rows.Add(this.tbl_templateSAP.DR);
            }
            this.tbl_templateSAP.Save();
            if ((this.pmode == "ADD") || (this.pmode == "EDIT"))
            {
                if (this.pmode == "ADD")
                {
                    string sqltext = (("SELECT uniq FROM wb_templateSAP WHERE " + WBData.CompanyLocation("")) + " AND modul = '" + this.comboBoxModuleName.Text + "'") + " AND type = '" + this.numericType.Text + "'";
                    WBTable table = new WBTable();
                    table.OpenTable("wb_templateSAP", sqltext, WBData.conn);
                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                    table.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pmode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_templateSAP", this.logKey, logField, logValue);
            }
            Cursor.Current = Cursors.Default;
            base.Close();
        }

        private void translate()
        {
            this.label1.Text = Resource.Lbl_Data_Type;
            this.checkFixed.Text = Resource.Chk_Fixed_Value;
            this.groupBoxFixed.Text = Resource.Chk_Fixed_Value;
            this.label7.Text = Resource.Composite_006;
            this.groupBoxFromTable.Text = Resource.Gbx_From_Value;
            this.label6.Text = Resource.Lbl_Key_Field + " 2";
            this.label5.Text = Resource.Lbl_Key_Field + " 1";
            this.label4.Text = Resource.Lbl_Field_Name;
            this.label3.Text = Resource.Lbl_Table_Name;
            this.label2.Text = Resource.Lbl_SAP_Field + this.sapIDSYS;
            this.label9.Text = Resource.Setting_057;
            this.label8.Text = Resource.Lbl_Module;
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Save;
            this.menuClose.Text = Resource.Btn_Close;
            this.buttonTest.Text = Resource.Btn_Test_Formula;
            this.Text = WBSetting.integrationIDSYS ? Resource.Title_Template_SAP_Entry_IDSYS : Resource.Title_Template_SAP_Entry;
        }
    }
}

