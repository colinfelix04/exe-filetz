﻿namespace JR.Utils.GUI.Forms
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    public class FlexibleMessageBox
    {
        public static double MAX_WIDTH_FACTOR = 0.7;
        public static double MAX_HEIGHT_FACTOR = 0.9;
        public static Font FONT = SystemFonts.MessageBoxFont;

        public static DialogResult Show(string text) => 
            FlexibleMessageBoxForm.Show(null, text, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(string text, string caption) => 
            FlexibleMessageBoxForm.Show(null, text, caption, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(IWin32Window owner, string text) => 
            FlexibleMessageBoxForm.Show(owner, text, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons) => 
            FlexibleMessageBoxForm.Show(null, text, caption, buttons, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(IWin32Window owner, string text, string caption) => 
            FlexibleMessageBoxForm.Show(owner, text, caption, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon) => 
            FlexibleMessageBoxForm.Show(null, text, caption, buttons, icon, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons) => 
            FlexibleMessageBoxForm.Show(owner, text, caption, buttons, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton) => 
            FlexibleMessageBoxForm.Show(null, text, caption, buttons, icon, defaultButton);

        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon) => 
            FlexibleMessageBoxForm.Show(owner, text, caption, buttons, icon, MessageBoxDefaultButton.Button1);

        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton) => 
            FlexibleMessageBoxForm.Show(owner, text, caption, buttons, icon, defaultButton);

        private class FlexibleMessageBoxForm : Form
        {
            private IContainer components = null;
            private Button button1;
            private BindingSource FlexibleMessageBoxFormBindingSource;
            private RichTextBox richTextBoxMessage;
            private Panel panel1;
            private PictureBox pictureBoxForIcon;
            private Button button2;
            private Button button3;
            private static readonly string STANDARD_MESSAGEBOX_SEPARATOR_LINES = "---------------------------\n";
            private static readonly string STANDARD_MESSAGEBOX_SEPARATOR_SPACES = "   ";
            private static readonly string[] BUTTON_TEXTS_ENGLISH_EN = new string[] { "OK", "Cancel", "&Yes", "&No", "&Abort", "&Retry", "&Ignore" };
            private static readonly string[] BUTTON_TEXTS_GERMAN_DE = new string[] { "OK", "Abbrechen", "&Ja", "&Nein", "&Abbrechen", "&Wiederholen", "&Ignorieren" };
            private static readonly string[] BUTTON_TEXTS_SPANISH_ES = new string[] { "Aceptar", "Cancelar", "&S\x00ed", "&No", "&Abortar", "&Reintentar", "&Ignorar" };
            private static readonly string[] BUTTON_TEXTS_ITALIAN_IT = new string[] { "OK", "Annulla", "&S\x00ec", "&No", "&Interrompi", "&Riprova", "&Ignora" };
            private MessageBoxDefaultButton defaultButton;
            private int visibleButtonsCount;
            private TwoLetterISOLanguageID languageID = TwoLetterISOLanguageID.en;

            private FlexibleMessageBoxForm()
            {
                this.InitializeComponent();
                Enum.TryParse<TwoLetterISOLanguageID>(CultureInfo.CurrentUICulture.TwoLetterISOLanguageName, out this.languageID);
                base.KeyPreview = true;
                base.KeyUp += new KeyEventHandler(this.FlexibleMessageBoxForm_KeyUp);
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing && (this.components != null))
                {
                    this.components.Dispose();
                }
                base.Dispose(disposing);
            }

            private void FlexibleMessageBoxForm_KeyUp(object sender, KeyEventArgs e)
            {
                if (e.Control && ((e.KeyCode == Keys.C) || (e.KeyCode == Keys.Insert)))
                {
                    string str = (this.button1.Visible ? (this.button1.Text + STANDARD_MESSAGEBOX_SEPARATOR_SPACES) : string.Empty) + (this.button2.Visible ? (this.button2.Text + STANDARD_MESSAGEBOX_SEPARATOR_SPACES) : string.Empty) + (this.button3.Visible ? (this.button3.Text + STANDARD_MESSAGEBOX_SEPARATOR_SPACES) : string.Empty);
                    string[] textArray1 = new string[10];
                    textArray1[0] = STANDARD_MESSAGEBOX_SEPARATOR_LINES;
                    textArray1[1] = this.Text;
                    textArray1[2] = Environment.NewLine;
                    textArray1[3] = STANDARD_MESSAGEBOX_SEPARATOR_LINES;
                    textArray1[4] = this.richTextBoxMessage.Text;
                    textArray1[5] = Environment.NewLine;
                    textArray1[6] = STANDARD_MESSAGEBOX_SEPARATOR_LINES;
                    textArray1[7] = str.Replace("&", string.Empty);
                    textArray1[8] = Environment.NewLine;
                    textArray1[9] = STANDARD_MESSAGEBOX_SEPARATOR_LINES;
                    Clipboard.SetText(string.Concat(textArray1));
                }
            }

            private void FlexibleMessageBoxForm_Shown(object sender, EventArgs e)
            {
                int visibleButtonsCount = 1;
                MessageBoxDefaultButton defaultButton = this.defaultButton;
                if (defaultButton != MessageBoxDefaultButton.Button1)
                {
                    if (defaultButton == MessageBoxDefaultButton.Button2)
                    {
                        visibleButtonsCount = 2;
                        goto TR_0002;
                    }
                    else if (defaultButton == MessageBoxDefaultButton.Button3)
                    {
                        visibleButtonsCount = 3;
                        goto TR_0002;
                    }
                }
                visibleButtonsCount = 1;
            TR_0002:
                if (visibleButtonsCount > this.visibleButtonsCount)
                {
                    visibleButtonsCount = this.visibleButtonsCount;
                }
                ((visibleButtonsCount != 3) ? ((visibleButtonsCount != 2) ? this.button1 : this.button2) : this.button3).Focus();
            }

            private string GetButtonText(ButtonID buttonID)
            {
                string str;
                int index = Convert.ToInt32(buttonID);
                switch (this.languageID)
                {
                    case TwoLetterISOLanguageID.de:
                        str = BUTTON_TEXTS_GERMAN_DE[index];
                        break;

                    case TwoLetterISOLanguageID.es:
                        str = BUTTON_TEXTS_SPANISH_ES[index];
                        break;

                    case TwoLetterISOLanguageID.it:
                        str = BUTTON_TEXTS_ITALIAN_IT[index];
                        break;

                    default:
                        str = BUTTON_TEXTS_ENGLISH_EN[index];
                        break;
                }
                return str;
            }

            private static double GetCorrectedWorkingAreaFactor(double workingAreaFactor) => 
                (workingAreaFactor >= 0.2) ? ((workingAreaFactor <= 1.0) ? workingAreaFactor : 1.0) : 0.2;

            private static string[] GetStringRows(string message)
            {
                string[] strArray2;
                if (string.IsNullOrEmpty(message))
                {
                    strArray2 = null;
                }
                else
                {
                    char[] separator = new char[] { '\n' };
                    strArray2 = message.Split(separator, StringSplitOptions.None);
                }
                return strArray2;
            }

            private void InitializeComponent()
            {
                this.components = new Container();
                this.button1 = new Button();
                this.richTextBoxMessage = new RichTextBox();
                this.FlexibleMessageBoxFormBindingSource = new BindingSource(this.components);
                this.panel1 = new Panel();
                this.pictureBoxForIcon = new PictureBox();
                this.button2 = new Button();
                this.button3 = new Button();
                ((ISupportInitialize) this.FlexibleMessageBoxFormBindingSource).BeginInit();
                this.panel1.SuspendLayout();
                ((ISupportInitialize) this.pictureBoxForIcon).BeginInit();
                base.SuspendLayout();
                this.button1.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
                this.button1.AutoSize = true;
                this.button1.DialogResult = DialogResult.OK;
                this.button1.Location = new Point(11, 0x43);
                this.button1.MinimumSize = new Size(0, 0x18);
                this.button1.Name = "button1";
                this.button1.Size = new Size(0x4b, 0x18);
                this.button1.TabIndex = 2;
                this.button1.Text = "OK";
                this.button1.UseVisualStyleBackColor = true;
                this.button1.Visible = false;
                this.richTextBoxMessage.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
                this.richTextBoxMessage.BackColor = Color.White;
                this.richTextBoxMessage.BorderStyle = BorderStyle.None;
                this.richTextBoxMessage.DataBindings.Add(new Binding("Text", this.FlexibleMessageBoxFormBindingSource, "MessageText", true, DataSourceUpdateMode.OnPropertyChanged));
                this.richTextBoxMessage.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
                this.richTextBoxMessage.Location = new Point(50, 0x1a);
                this.richTextBoxMessage.Margin = new Padding(0);
                this.richTextBoxMessage.Name = "richTextBoxMessage";
                this.richTextBoxMessage.ReadOnly = true;
                this.richTextBoxMessage.ScrollBars = RichTextBoxScrollBars.Vertical;
                this.richTextBoxMessage.Size = new Size(200, 20);
                this.richTextBoxMessage.TabIndex = 0;
                this.richTextBoxMessage.TabStop = false;
                this.richTextBoxMessage.Text = "<Message>";
                this.richTextBoxMessage.LinkClicked += new LinkClickedEventHandler(this.richTextBoxMessage_LinkClicked);
                this.panel1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
                this.panel1.BackColor = Color.White;
                this.panel1.Controls.Add(this.pictureBoxForIcon);
                this.panel1.Controls.Add(this.richTextBoxMessage);
                this.panel1.Location = new Point(-3, -4);
                this.panel1.Name = "panel1";
                this.panel1.Size = new Size(0x10c, 0x3b);
                this.panel1.TabIndex = 1;
                this.pictureBoxForIcon.BackColor = Color.Transparent;
                this.pictureBoxForIcon.Location = new Point(15, 0x13);
                this.pictureBoxForIcon.Name = "pictureBoxForIcon";
                this.pictureBoxForIcon.Size = new Size(0x20, 0x20);
                this.pictureBoxForIcon.TabIndex = 8;
                this.pictureBoxForIcon.TabStop = false;
                this.button2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
                this.button2.DialogResult = DialogResult.OK;
                this.button2.Location = new Point(0x5c, 0x43);
                this.button2.MinimumSize = new Size(0, 0x18);
                this.button2.Name = "button2";
                this.button2.Size = new Size(0x4b, 0x18);
                this.button2.TabIndex = 3;
                this.button2.Text = "OK";
                this.button2.UseVisualStyleBackColor = true;
                this.button2.Visible = false;
                this.button3.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
                this.button3.AutoSize = true;
                this.button3.DialogResult = DialogResult.OK;
                this.button3.Location = new Point(0xad, 0x43);
                this.button3.MinimumSize = new Size(0, 0x18);
                this.button3.Name = "button3";
                this.button3.Size = new Size(0x4b, 0x18);
                this.button3.TabIndex = 0;
                this.button3.Text = "OK";
                this.button3.UseVisualStyleBackColor = true;
                this.button3.Visible = false;
                base.AutoScaleDimensions = new SizeF(6f, 13f);
                base.AutoScaleMode = AutoScaleMode.Font;
                base.ClientSize = new Size(260, 0x66);
                base.Controls.Add(this.button3);
                base.Controls.Add(this.button2);
                base.Controls.Add(this.panel1);
                base.Controls.Add(this.button1);
                base.DataBindings.Add(new Binding("Text", this.FlexibleMessageBoxFormBindingSource, "CaptionText", true));
                base.MaximizeBox = false;
                base.MinimizeBox = false;
                this.MinimumSize = new Size(0x114, 140);
                base.Name = "FlexibleMessageBoxForm";
                base.ShowIcon = false;
                base.SizeGripStyle = SizeGripStyle.Show;
                base.StartPosition = FormStartPosition.CenterParent;
                this.Text = "<Caption>";
                base.Shown += new EventHandler(this.FlexibleMessageBoxForm_Shown);
                ((ISupportInitialize) this.FlexibleMessageBoxFormBindingSource).EndInit();
                this.panel1.ResumeLayout(false);
                ((ISupportInitialize) this.pictureBoxForIcon).EndInit();
                base.ResumeLayout(false);
                base.PerformLayout();
            }

            private void richTextBoxMessage_LinkClicked(object sender, LinkClickedEventArgs e)
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    Process.Start(e.LinkText);
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    Cursor.Current = Cursors.Default;
                }
            }

            private static void SetDialogButtons(FlexibleMessageBox.FlexibleMessageBoxForm flexibleMessageBoxForm, MessageBoxButtons buttons, MessageBoxDefaultButton defaultButton)
            {
                switch (buttons)
                {
                    case MessageBoxButtons.OKCancel:
                        flexibleMessageBoxForm.visibleButtonsCount = 2;
                        flexibleMessageBoxForm.button2.Visible = true;
                        flexibleMessageBoxForm.button2.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.OK);
                        flexibleMessageBoxForm.button2.DialogResult = DialogResult.OK;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.CANCEL);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.Cancel;
                        flexibleMessageBoxForm.CancelButton = flexibleMessageBoxForm.button3;
                        break;

                    case MessageBoxButtons.AbortRetryIgnore:
                        flexibleMessageBoxForm.visibleButtonsCount = 3;
                        flexibleMessageBoxForm.button1.Visible = true;
                        flexibleMessageBoxForm.button1.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.ABORT);
                        flexibleMessageBoxForm.button1.DialogResult = DialogResult.Abort;
                        flexibleMessageBoxForm.button2.Visible = true;
                        flexibleMessageBoxForm.button2.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.RETRY);
                        flexibleMessageBoxForm.button2.DialogResult = DialogResult.Retry;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.IGNORE);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.Ignore;
                        flexibleMessageBoxForm.ControlBox = false;
                        break;

                    case MessageBoxButtons.YesNoCancel:
                        flexibleMessageBoxForm.visibleButtonsCount = 3;
                        flexibleMessageBoxForm.button1.Visible = true;
                        flexibleMessageBoxForm.button1.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.YES);
                        flexibleMessageBoxForm.button1.DialogResult = DialogResult.Yes;
                        flexibleMessageBoxForm.button2.Visible = true;
                        flexibleMessageBoxForm.button2.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.NO);
                        flexibleMessageBoxForm.button2.DialogResult = DialogResult.No;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.CANCEL);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.Cancel;
                        flexibleMessageBoxForm.CancelButton = flexibleMessageBoxForm.button3;
                        break;

                    case MessageBoxButtons.YesNo:
                        flexibleMessageBoxForm.visibleButtonsCount = 2;
                        flexibleMessageBoxForm.button2.Visible = true;
                        flexibleMessageBoxForm.button2.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.YES);
                        flexibleMessageBoxForm.button2.DialogResult = DialogResult.Yes;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.NO);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.No;
                        flexibleMessageBoxForm.ControlBox = false;
                        break;

                    case MessageBoxButtons.RetryCancel:
                        flexibleMessageBoxForm.visibleButtonsCount = 2;
                        flexibleMessageBoxForm.button2.Visible = true;
                        flexibleMessageBoxForm.button2.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.RETRY);
                        flexibleMessageBoxForm.button2.DialogResult = DialogResult.Retry;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.CANCEL);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.Cancel;
                        flexibleMessageBoxForm.CancelButton = flexibleMessageBoxForm.button3;
                        break;

                    default:
                        flexibleMessageBoxForm.visibleButtonsCount = 1;
                        flexibleMessageBoxForm.button3.Visible = true;
                        flexibleMessageBoxForm.button3.Text = flexibleMessageBoxForm.GetButtonText(ButtonID.OK);
                        flexibleMessageBoxForm.button3.DialogResult = DialogResult.OK;
                        flexibleMessageBoxForm.CancelButton = flexibleMessageBoxForm.button3;
                        break;
                }
                flexibleMessageBoxForm.defaultButton = defaultButton;
            }

            private static void SetDialogIcon(FlexibleMessageBox.FlexibleMessageBoxForm flexibleMessageBoxForm, MessageBoxIcon icon)
            {
                MessageBoxIcon icon2 = icon;
                if (icon2 > MessageBoxIcon.Question)
                {
                    if (icon2 == MessageBoxIcon.Exclamation)
                    {
                        flexibleMessageBoxForm.pictureBoxForIcon.Image = SystemIcons.Warning.ToBitmap();
                        return;
                    }
                    else if (icon2 == MessageBoxIcon.Asterisk)
                    {
                        flexibleMessageBoxForm.pictureBoxForIcon.Image = SystemIcons.Information.ToBitmap();
                        return;
                    }
                }
                else if (icon2 == MessageBoxIcon.Hand)
                {
                    flexibleMessageBoxForm.pictureBoxForIcon.Image = SystemIcons.Error.ToBitmap();
                    return;
                }
                else if (icon2 == MessageBoxIcon.Question)
                {
                    flexibleMessageBoxForm.pictureBoxForIcon.Image = SystemIcons.Question.ToBitmap();
                    return;
                }
                flexibleMessageBoxForm.pictureBoxForIcon.Visible = false;
                flexibleMessageBoxForm.richTextBoxMessage.Left -= flexibleMessageBoxForm.pictureBoxForIcon.Width;
                flexibleMessageBoxForm.richTextBoxMessage.Width += flexibleMessageBoxForm.pictureBoxForIcon.Width;
            }

            private static void SetDialogSizes(FlexibleMessageBox.FlexibleMessageBoxForm flexibleMessageBoxForm, string text, string caption)
            {
                flexibleMessageBoxForm.MaximumSize = new Size(Convert.ToInt32((double) (SystemInformation.WorkingArea.Width * GetCorrectedWorkingAreaFactor(FlexibleMessageBox.MAX_WIDTH_FACTOR))), Convert.ToInt32((double) (SystemInformation.WorkingArea.Height * GetCorrectedWorkingAreaFactor(FlexibleMessageBox.MAX_HEIGHT_FACTOR))));
                string[] stringRows = GetStringRows(text);
                if (stringRows != null)
                {
                    int height = TextRenderer.MeasureText(text, FlexibleMessageBox.FONT).Height;
                    Func<string, int> selector = <>c.<>9__26_0;
                    if (<>c.<>9__26_0 == null)
                    {
                        Func<string, int> local1 = <>c.<>9__26_0;
                        selector = <>c.<>9__26_0 = textForRow => TextRenderer.MeasureText(textForRow, FlexibleMessageBox.FONT).Width;
                    }
                    int width = TextRenderer.MeasureText(caption, SystemFonts.CaptionFont).Width;
                    int num4 = Math.Max(stringRows.Max<string>(selector) + 15, width);
                    flexibleMessageBoxForm.Size = new Size(num4 + (flexibleMessageBoxForm.Width - flexibleMessageBoxForm.richTextBoxMessage.Width), height + (flexibleMessageBoxForm.Height - flexibleMessageBoxForm.richTextBoxMessage.Height));
                }
            }

            private static void SetDialogStartPosition(FlexibleMessageBox.FlexibleMessageBoxForm flexibleMessageBoxForm, IWin32Window owner)
            {
                if (ReferenceEquals(owner, null))
                {
                    Screen screen = Screen.FromPoint(Cursor.Position);
                    flexibleMessageBoxForm.StartPosition = FormStartPosition.Manual;
                    flexibleMessageBoxForm.Left = (screen.Bounds.Left + (screen.Bounds.Width / 2)) - (flexibleMessageBoxForm.Width / 2);
                    flexibleMessageBoxForm.Top = (screen.Bounds.Top + (screen.Bounds.Height / 2)) - (flexibleMessageBoxForm.Height / 2);
                }
            }

            public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
            {
                FlexibleMessageBox.FlexibleMessageBoxForm flexibleMessageBoxForm = new FlexibleMessageBox.FlexibleMessageBoxForm {
                    ShowInTaskbar = false,
                    CaptionText = caption,
                    MessageText = text
                };
                flexibleMessageBoxForm.FlexibleMessageBoxFormBindingSource.DataSource = flexibleMessageBoxForm;
                SetDialogButtons(flexibleMessageBoxForm, buttons, defaultButton);
                SetDialogIcon(flexibleMessageBoxForm, icon);
                flexibleMessageBoxForm.Font = FlexibleMessageBox.FONT;
                flexibleMessageBoxForm.richTextBoxMessage.Font = FlexibleMessageBox.FONT;
                SetDialogSizes(flexibleMessageBoxForm, text, caption);
                SetDialogStartPosition(flexibleMessageBoxForm, owner);
                return flexibleMessageBoxForm.ShowDialog(owner);
            }

            public string CaptionText { get; set; }

            public string MessageText { get; set; }

            [Serializable, CompilerGenerated]
            private sealed class <>c
            {
                public static readonly FlexibleMessageBox.FlexibleMessageBoxForm.<>c <>9 = new FlexibleMessageBox.FlexibleMessageBoxForm.<>c();
                public static Func<string, int> <>9__26_0;

                internal int <SetDialogSizes>b__26_0(string textForRow) => 
                    TextRenderer.MeasureText(textForRow, FlexibleMessageBox.FONT).Width;
            }

            private enum ButtonID
            {
                OK,
                CANCEL,
                YES,
                NO,
                ABORT,
                RETRY,
                IGNORE
            }

            private enum TwoLetterISOLanguageID
            {
                en,
                de,
                es,
                it
            }
        }
    }
}

