﻿namespace Encryption.Utility
{
    using System;
    using System.Security.Cryptography;
    using System.Text;

    public class WBEncryption
    {
        public static string Decrypt(string strEncrypted)
        {
            try
            {
                strEncrypted = strEncrypted.Replace("wilmarKey", "&");
                return Decrypt(strEncrypted, "wilmarKey");
            }
            catch (Exception exception)
            {
                return ("Wrong Input. " + exception.Message);
            }
        }

        public static string Decrypt(string strEncrypted, string strKey)
        {
            string str3;
            try
            {
                if (strEncrypted == "")
                {
                    str3 = "";
                }
                else
                {
                    TripleDESCryptoServiceProvider provider = new TripleDESCryptoServiceProvider();
                    string s = strKey;
                    provider.Key = new MD5CryptoServiceProvider().ComputeHash(Encoding.ASCII.GetBytes(s));
                    provider.Mode = CipherMode.ECB;
                    byte[] inputBuffer = Convert.FromBase64String(strEncrypted);
                    provider = null;
                    str3 = Encoding.ASCII.GetString(provider.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length));
                }
            }
            catch (Exception exception)
            {
                str3 = "Wrong Input. " + exception.Message;
            }
            return str3;
        }

        public static string Encrypt(string strToEncrypt)
        {
            try
            {
                return Encrypt(strToEncrypt, "wilmarKey").Replace("&", "wilmarKey");
            }
            catch (Exception exception)
            {
                return ("Wrong Input. " + exception.Message);
            }
        }

        public static string Encrypt(string strToEncrypt, string strKey)
        {
            string str2;
            try
            {
                if (strToEncrypt == "")
                {
                    str2 = "";
                }
                else
                {
                    TripleDESCryptoServiceProvider provider = new TripleDESCryptoServiceProvider();
                    string s = strKey;
                    provider.Key = new MD5CryptoServiceProvider().ComputeHash(Encoding.ASCII.GetBytes(s));
                    provider.Mode = CipherMode.ECB;
                    byte[] bytes = Encoding.ASCII.GetBytes(strToEncrypt);
                    str2 = Convert.ToBase64String(provider.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length));
                }
            }
            catch (Exception exception)
            {
                str2 = "Wrong Input. " + exception.Message;
            }
            return str2;
        }
    }
}

