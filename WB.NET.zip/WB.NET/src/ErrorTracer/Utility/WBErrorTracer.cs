﻿namespace ErrorTracer.Utility
{
    using System;
    using WindowsFormsApplication1;

    internal class WBErrorTracer
    {
        public static void sendError(string gatepassNo, string ref_, string errorMsg)
        {
            try
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_errorList", "SELECT * FROM wb_errorList WHERE 1 = 2", WBData.conn);
                table.DR = table.DT.NewRow();
                table.DR["coy"] = WBData.sCoyCode;
                table.DR["location_code"] = WBData.sLocCode;
                table.DR["wbcode"] = WBData.sWBCode;
                table.DR["error_date"] = DateTime.Now;
                table.DR["code1"] = "WBSE";
                table.DR["code2"] = gatepassNo;
                table.DR["code3"] = ref_;
                table.DR["error_msg"] = errorMsg;
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.Dispose();
            }
            catch
            {
            }
        }
    }
}

