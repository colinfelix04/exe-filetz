﻿namespace BarrierGate.Utility
{
    using System;

    internal class WBBarrierGate2
    {
        private static int hndSocket = 0;
        private static byte bRet = 0;
        public static string strMsg = "";

        public static bool closeGate(string IP, string Port)
        {
            strMsg = "";
            bool flag = true;
            modDLL.StoreReturnCode();
            bRet = modDLL.SMFAPI_OpenSocket(out hndSocket, IP, Convert.ToUInt32(Port));
            if (bRet != 0)
            {
                strMsg = $"OpenSocket: {modDLL.strReturCode[bRet]:s}!";
                flag = false;
            }
            else
            {
                byte bytStatus = 0;
                bRet = modDLL.SMFAPI_GateStatus(hndSocket, out bytStatus);
                if (bRet != 0)
                {
                    strMsg = $"GateStatus: {modDLL.strReturCode[bRet]:s}!";
                    flag = false;
                }
                else
                {
                    bool flag4 = true;
                    byte num3 = (byte) (bytStatus & 2);
                    if ((((byte) (bytStatus & 1)) == 1) || (num3 == 2))
                    {
                        flag4 = false;
                    }
                    if (!flag4)
                    {
                        strMsg = "Can't close gate due to loop or sensor is still detecting an object!";
                        flag = false;
                    }
                    else
                    {
                        bRet = modDLL.SMFAPI_CloseGate(hndSocket);
                        if (bRet != 0)
                        {
                            strMsg = $"CloseGate: {modDLL.strReturCode[bRet]:s}!";
                            flag = false;
                        }
                    }
                }
                bRet = modDLL.SMFAPI_CloseSocket(hndSocket);
                if (bRet != 0)
                {
                    strMsg = $"CloseSocket: {modDLL.strReturCode[bRet]:s}!";
                    flag = false;
                }
            }
            return flag;
        }

        public static bool getStatus(string IP, string Port)
        {
            bool flag = false;
            bool flag2 = true;
            bRet = modDLL.SMFAPI_OpenSocket(out hndSocket, IP, Convert.ToUInt32(Port));
            if (bRet == 0)
            {
                flag = true;
            }
            if (!flag)
            {
                strMsg = $"OpenSocket: {modDLL.strReturCode[bRet]:s}!";
                flag2 = false;
            }
            else
            {
                byte bytStatus = 0;
                bRet = modDLL.SMFAPI_GateStatus(hndSocket, out bytStatus);
                byte num2 = (byte) (bytStatus & 4);
                byte num3 = (byte) (bytStatus & 2);
                byte num4 = (byte) (bytStatus & 1);
                strMsg = "Status of Barrier Gate\n";
                strMsg = strMsg + "\nBarrier Arm \t: " + ((num2 == 0) ? "Close" : "Open");
                strMsg = strMsg + "\nSensor \t\t: " + ((num3 == 0) ? "Detect no object" : "Detect an object");
                strMsg = strMsg + "\nLoop   \t\t: " + ((num4 == 0) ? "Detect no object" : "Detected an object");
                bRet = modDLL.SMFAPI_CloseSocket(hndSocket);
                if (bRet != 0)
                {
                    strMsg = $"CloseSocket: {modDLL.strReturCode[bRet]:s}!";
                    flag2 = false;
                }
            }
            return flag2;
        }

        public static bool openGate(string IP, string Port)
        {
            bool flag = true;
            bRet = modDLL.SMFAPI_OpenSocket(out hndSocket, IP, Convert.ToUInt32(Port));
            strMsg = $"OpenSocket: {modDLL.strReturCode[bRet]:s}!";
            if (bRet != 0)
            {
                strMsg = $"OpenSocket: {modDLL.strReturCode[bRet]:s}!";
                flag = false;
            }
            else
            {
                byte bytStatus = 0;
                bRet = modDLL.SMFAPI_GateStatus(hndSocket, out bytStatus);
                if (bRet != 0)
                {
                    strMsg = $"GateStatus: {modDLL.strReturCode[bRet]:s}!";
                    flag = false;
                }
                else
                {
                    bool flag4 = true;
                    byte num3 = (byte) (bytStatus & 2);
                    if ((((byte) (bytStatus & 1)) == 1) || (num3 == 2))
                    {
                        flag4 = false;
                    }
                    if (!flag4)
                    {
                        strMsg = "Can't open gate due to loop or sensor is still detecting an object!";
                        flag = false;
                    }
                    else
                    {
                        bRet = modDLL.SMFAPI_OpenGate(hndSocket);
                        if (bRet != 0)
                        {
                            strMsg = $"OpenGate: {modDLL.strReturCode[bRet]:s}!";
                            flag = false;
                        }
                    }
                }
                bRet = modDLL.SMFAPI_CloseSocket(hndSocket);
                if (bRet != 0)
                {
                    strMsg = $"CloseSocket: {modDLL.strReturCode[bRet]:s}!";
                    flag = false;
                }
            }
            return flag;
        }
    }
}

