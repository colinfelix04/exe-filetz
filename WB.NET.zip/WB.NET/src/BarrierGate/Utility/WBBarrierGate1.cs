﻿namespace BarrierGate.Utility
{
    using System;
    using System.Diagnostics;

    internal class WBBarrierGate1
    {
        public static void runGate(string file)
        {
            Process.Start(file);
        }
    }
}

