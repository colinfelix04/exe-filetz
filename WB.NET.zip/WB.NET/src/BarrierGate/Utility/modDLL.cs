﻿namespace BarrierGate.Utility
{
    using System;
    using System.Runtime.InteropServices;

    internal class modDLL
    {
        private const string strDLL = "SMFAPI_510.DLL";
        public static string[] strReturCode = new string[0x100];

        [DllImport("SMFAPI_510.DLL")]
        public static extern byte SMFAPI_CloseGate(int hndSocket);
        [DllImport("SMFAPI_510.DLL")]
        public static extern byte SMFAPI_CloseSocket(int hndSocket);
        [DllImport("SMFAPI_510.DLL")]
        public static extern byte SMFAPI_GateStatus(int hndSocket, out byte bytStatus);
        [DllImport("SMFAPI_510.DLL")]
        public static extern byte SMFAPI_OpenGate(int hndSocket);
        [DllImport("SMFAPI_510.DLL")]
        public static extern byte SMFAPI_OpenSocket(out int hndSocket, string cIPAddress, uint nPort);
        public static void StoreReturnCode()
        {
            uint index = 0;
            while (true)
            {
                if (index > 0xff)
                {
                    strReturCode[0] = "Success";
                    strReturCode[2] = "Unknown error has occured";
                    strReturCode[3] = "Not found";
                    strReturCode[8] = "Unknown command";
                    strReturCode[9] = "Invalid parameter";
                    strReturCode[20] = "User is full";
                    strReturCode[0x15] = "Template is full";
                    strReturCode[0xf6] = "Package error";
                    strReturCode[0xf7] = "BCC Error";
                    strReturCode[0xf9] = "Max handles is reached";
                    strReturCode[250] = "Invalid handle";
                    strReturCode[0xfb] = "No more data received";
                    strReturCode[0xfc] = "Process aborted";
                    strReturCode[0xfd] = "Process timeout";
                    strReturCode[0xfe] = "Closed by remote";
                    strReturCode[0xff] = "Connection failure";
                    return;
                }
                strReturCode[index] = $"[{index:X2}h]";
                index++;
            }
        }

        public enum returnCode : byte
        {
            retSUCCESS = 0,
            retERROR = 2,
            retNEXIST = 3,
            retEXIST = 6,
            retERRCMD = 8,
            retERRPARA = 9,
            retUSERFULL = 20,
            retFVFULL = 0x15,
            retERRPACKAGE = 0xf6,
            retERRBCC = 0xf7,
            retMAXHANDLEREACHED = 0xf9,
            retINVALIDHANDLE = 250,
            retNOMOREDATA = 0xfb,
            retABORTED = 0xfc,
            retTIMEOUT = 0xfd,
            retREMOTECLOSED = 0xfe,
            retCONNECTION_FAILURE = 0xff
        }
    }
}

