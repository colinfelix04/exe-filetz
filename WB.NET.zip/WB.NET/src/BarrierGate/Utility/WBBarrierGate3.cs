﻿namespace BarrierGate.Utility
{
    using Encryption.Utility;
    using System;
    using System.IO;
    using System.Threading;
    using WindowsFormsApplication1.Utility;

    internal class WBBarrierGate3
    {
        public static void openGate(string direction)
        {
            try
            {
                int num;
                if ((direction != "0") && (direction != "1"))
                {
                    return;
                }
                else
                {
                    if (!Directory.Exists(Constant.GATE_DIRECTORY))
                    {
                        Directory.CreateDirectory(Constant.GATE_DIRECTORY);
                    }
                    if (!File.Exists(Constant.GATE_COMMAND_FILE))
                    {
                        File.Create(Constant.GATE_COMMAND_FILE).Dispose();
                    }
                    num = 0;
                }
                while (num < Constant.TOLERANCE_FOR_WRITING_TXT)
                {
                    try
                    {
                        StreamWriter writer = new StreamWriter(Constant.GATE_COMMAND_FILE);
                        writer.Write(WBEncryption.Encrypt(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + direction));
                        writer.Dispose();
                    }
                    catch
                    {
                        num++;
                        Thread.Sleep(100);
                        continue;
                    }
                    break;
                }
            }
            catch
            {
            }
        }
    }
}

