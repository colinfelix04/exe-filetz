﻿namespace Camera.Utility
{
    using AForge.Controls;
    using AForge.Video;
    using AForge.Video.DirectShow;
    using ErrorTracer.Utility;
    using NetworkShare.Utility;
    using System;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.Drawing;
    using System.Drawing.Drawing2D;
    using System.Drawing.Imaging;
    using System.IO;
    using System.Net;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;
    using WindowsFormsApplication1;
    using WindowsFormsApplication1.Properties;

    internal class WBCamera
    {
        public int cam_no;
        public bool camera_online;
        private string code1;
        private string code2;
        public JPEGStream jpegSource;
        private VideoSourcePlayer videoSourcePlayer;
        public FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;

        public WBCamera()
        {
            this.cam_no = 0;
            this.camera_online = true;
            this.code1 = "";
            this.code2 = "";
            this.videoSourcePlayer = new VideoSourcePlayer();
            this.videoSource = null;
        }

        public WBCamera(int _cam_no)
        {
            this.cam_no = 0;
            this.camera_online = true;
            this.code1 = "";
            this.code2 = "";
            this.videoSourcePlayer = new VideoSourcePlayer();
            this.videoSource = null;
            this.cam_no = _cam_no;
        }

        public void CloseCurrentVideoSource()
        {
            if (this.videoSourcePlayer.VideoSource != null)
            {
                this.videoSourcePlayer.SignalToStop();
                int num = 0;
                while (true)
                {
                    if ((num < 30) && this.videoSourcePlayer.IsRunning)
                    {
                        Thread.Sleep(100);
                        num++;
                        continue;
                    }
                    if (this.videoSourcePlayer.IsRunning)
                    {
                        this.videoSourcePlayer.Stop();
                    }
                    this.videoSourcePlayer.VideoSource = null;
                    break;
                }
            }
            if (this.videoSource != null)
            {
                this.videoSource.SignalToStop();
                int num2 = 0;
                while (true)
                {
                    if ((num2 < 30) && this.videoSource.IsRunning)
                    {
                        Thread.Sleep(100);
                        num2++;
                        continue;
                    }
                    if (this.videoSource.IsRunning)
                    {
                        this.videoSource.Stop();
                    }
                    this.videoSource = null;
                    break;
                }
            }
        }

        public bool getHttpRequest(string sourceURL, string username, string password, PictureBox picBox, string cameraName)
        {
            try
            {
                byte[] buffer = new byte[0x4b000];
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(sourceURL);
                request.Credentials = new NetworkCredential(username, password);
                Bitmap bitmap = null;
                using (Bitmap bitmap2 = new Bitmap(request.GetResponse().GetResponseStream()))
                {
                    if (bitmap2 != null)
                    {
                        bitmap = (Bitmap) bitmap2.Clone();
                    }
                }
                picBox.Image = bitmap;
                picBox.SizeMode = PictureBoxSizeMode.StretchImage;
                return true;
            }
            catch (Exception)
            {
                string[] textArray1 = new string[] { Resource.Camera_001, " ", cameraName, " ", Resource.Camera_003, "\n", Resource.Camera_004 };
                MessageBox.Show(string.Concat(textArray1), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
        }

        public void getWebCamList(ComboBox cb)
        {
            bool flag = false;
            try
            {
                this.videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                cb.Items.Clear();
                if (this.videoDevices.Count == 0)
                {
                    throw new ApplicationException();
                }
                flag = true;
                foreach (FilterInfo info in this.videoDevices)
                {
                    cb.Items.Add(info.Name);
                }
                cb.Items.Add("");
            }
            catch (ApplicationException)
            {
                flag = false;
            }
        }

        public static void HttpUploadFile(string url, string file, string paramName, string contentType, NameValueCollection nvc)
        {
            string str = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            byte[] bytes = Encoding.ASCII.GetBytes("\r\n--" + str + "\r\n");
            HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
            request.ContentType = "multipart/form-data; boundary=" + str;
            request.Method = "POST";
            request.KeepAlive = true;
            request.Credentials = CredentialCache.DefaultCredentials;
            Stream requestStream = request.GetRequestStream();
            string format = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";
            foreach (string str5 in nvc.Keys)
            {
                requestStream.Write(bytes, 0, bytes.Length);
                string str6 = string.Format(format, str5, nvc[str5]);
                byte[] buffer5 = Encoding.UTF8.GetBytes(str6);
                requestStream.Write(buffer5, 0, buffer5.Length);
            }
            requestStream.Write(bytes, 0, bytes.Length);
            string s = $"Content-Disposition: form-data; name="{paramName}"; filename="{file}"
Content-Type: {contentType}

";
            byte[] buffer = Encoding.UTF8.GetBytes(s);
            requestStream.Write(buffer, 0, buffer.Length);
            FileStream stream2 = new FileStream(file, FileMode.Open, FileAccess.Read);
            byte[] buffer3 = new byte[0x1000];
            int count = 0;
            while (true)
            {
                count = stream2.Read(buffer3, 0, buffer3.Length);
                if (count == 0)
                {
                    stream2.Close();
                    byte[] buffer4 = Encoding.ASCII.GetBytes("\r\n--" + str + "--\r\n");
                    requestStream.Write(buffer4, 0, buffer4.Length);
                    requestStream.Close();
                    WebResponse response = null;
                    try
                    {
                        StreamReader reader = new StreamReader(request.GetResponse().GetResponseStream());
                    }
                    catch (Exception)
                    {
                        if (response != null)
                        {
                            response.Close();
                            response = null;
                        }
                    }
                    finally
                    {
                        request = null;
                    }
                    break;
                }
                requestStream.Write(buffer3, 0, count);
            }
        }

        public static bool ImageCompareString(Image firstImage, Image secondImage)
        {
            MemoryStream stream = new MemoryStream();
            firstImage.Save(stream, ImageFormat.Png);
            stream.Position = 0L;
            secondImage.Save(stream, ImageFormat.Png);
            return Convert.ToBase64String(stream.ToArray()).Equals(Convert.ToBase64String(stream.ToArray()));
        }

        private void jpegSource_VideoSourceError(object sender, VideoSourceErrorEventArgs eventArgs)
        {
            WBErrorTracer.sendError(this.code1, this.code2, "Camera " + this.cam_no.ToString() + " : " + eventArgs.Description);
            this.jpegSource.Stop();
            int num = 0;
            while (true)
            {
                if ((num < 30) && this.jpegSource.IsRunning)
                {
                    Thread.Sleep(100);
                    num++;
                    continue;
                }
                if (this.jpegSource.IsRunning)
                {
                    this.jpegSource.Stop();
                }
                return;
            }
        }

        public void loadImageFromServer(string gatepassNo, string refNo, PictureBox video_panel, string mode, string cam)
        {
            if (WBSetting.camera_path == "")
            {
                video_panel.Image = Resources.NoImage;
            }
            else
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                if (Directory.Exists(Path.Combine(WBSetting.camera_path, gatepassNo)))
                {
                    try
                    {
                        string[] textArray1 = new string[] { refNo, "_", mode.Substring(0, 1), "_", cam, ".jpg" };
                        video_panel.Image = Image.FromFile(Path.Combine(WBSetting.camera_path, gatepassNo) + @"\" + string.Concat(textArray1));
                        stopwatch.Stop();
                        long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                    }
                    catch
                    {
                        video_panel.Image = Resources.NoImage;
                        stopwatch.Stop();
                        long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                    }
                }
                else
                {
                    stopwatch.Stop();
                    long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                    if (elapsedMilliseconds > 0xbb8L)
                    {
                        WBSetting.folderErrorOccurWhenLoadPhotos = true;
                        object[] objArray1 = new object[] { "Error load photos in WB.Net: Photo from camera ", cam, " for ", mode, " weighing is loaded more than 3000 ms (", elapsedMilliseconds, " ms)" };
                        WBErrorTracer.sendError("", refNo, string.Concat(objArray1));
                        video_panel.Image = Resources.NoImage;
                    }
                    else
                    {
                        char[] separator = new char[] { '\\' };
                        string str2 = WBNetworkShare.Access(WBSetting.camera_path.Split(separator)[2], WBSetting.camera_domain, WBSetting.camera_username, WBSetting.camera_password);
                        if (str2 != "")
                        {
                            WBSetting.folderErrorOccurWhenLoadPhotos = true;
                            WBErrorTracer.sendError("", refNo, "Error load photos in WB.Net: " + str2);
                            video_panel.Image = Resources.NoImage;
                        }
                        else if (!Directory.Exists(Path.Combine(WBSetting.camera_path, gatepassNo)))
                        {
                            WBSetting.folderErrorOccurWhenLoadPhotos = true;
                            WBErrorTracer.sendError("", refNo, "Error load photos in WB.Net: Directory doesn't exist.");
                            video_panel.Image = Resources.NoImage;
                        }
                        else
                        {
                            try
                            {
                                string[] textArray2 = new string[] { refNo, "_", mode.Substring(0, 1), "_", cam, ".jpg" };
                                video_panel.Image = Image.FromFile(Path.Combine(WBSetting.camera_path, gatepassNo) + string.Concat(textArray2));
                            }
                            catch
                            {
                                video_panel.Image = Resources.NoImage;
                            }
                        }
                    }
                }
            }
        }

        public void loadImageV2(string filePath, string fileName, PictureBox video_panel)
        {
            try
            {
                if (filePath != "")
                {
                    if (Directory.Exists(WBSetting.camera_path))
                    {
                        try
                        {
                            video_panel.Image = Image.FromFile(filePath + fileName);
                        }
                        catch
                        {
                            video_panel.Image = Resources.NoImage;
                        }
                    }
                    else
                    {
                        char[] separator = new char[] { '\\' };
                        if (WBNetworkShare.Access(filePath.Split(separator)[2], WBSetting.camera_domain, WBSetting.camera_username, WBSetting.camera_password) != "")
                        {
                            video_panel.Image = Resources.NoImage;
                        }
                        else if (!Directory.Exists(WBSetting.camera_path))
                        {
                            video_panel.Image = Resources.NoImage;
                        }
                        else
                        {
                            try
                            {
                                video_panel.Image = Image.FromFile(filePath + fileName);
                            }
                            catch
                            {
                                video_panel.Image = Resources.NoImage;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                video_panel.Image = Resources.NoImage;
            }
        }

        public void pausePreview(PictureBox panel)
        {
            try
            {
                this.jpegSource.Stop();
                Image image = (Image) this.videoSourcePlayer.GetCurrentVideoFrame().Clone();
                panel.Image = image;
                this.videoSourcePlayer.Stop();
                this.videoSourcePlayer.Parent = null;
            }
            catch (Exception)
            {
                this.camera_online = false;
            }
        }

        public static Bitmap ResizeImage(Image image, int width, int height)
        {
            Rectangle destRect = new Rectangle(0, 0, width, height);
            Bitmap bitmap = new Bitmap(width, height);
            bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                using (ImageAttributes attributes = new ImageAttributes())
                {
                    attributes.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, attributes);
                }
            }
            return bitmap;
        }

        public void saveImageToServer(string filename, Image img)
        {
            img = ResizeImage(img, 600, 450);
            if (Directory.Exists(WBSetting.camera_path))
            {
                img.Save(WBSetting.camera_path + filename);
            }
            else
            {
                char[] separator = new char[] { '\\' };
                if ((WBNetworkShare.Access(WBSetting.camera_path.Split(separator)[2], WBSetting.camera_domain, WBSetting.camera_username, WBSetting.camera_password) == "") && Directory.Exists(WBSetting.camera_path))
                {
                    img.Save(WBSetting.camera_path + filename);
                }
            }
        }

        public bool savePhoto(string filepath, string filename, Image img, string cameraNo = "")
        {
            bool flag3;
            try
            {
                img = ResizeImage(img, 600, 450);
                char[] separator = new char[] { '\\' };
                if (WBNetworkShare.Access(filepath.Split(separator)[2], WBSetting.camera_domain, WBSetting.camera_username, WBSetting.camera_password) != "")
                {
                    flag3 = false;
                }
                else if (!Directory.Exists(filepath))
                {
                    MessageBox.Show(string.Format(Resource.Mes_Fail_to_Save_Photo_02, cameraNo), Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    flag3 = false;
                }
                else
                {
                    img.Save(filepath + filename);
                    MessageBox.Show(string.Format(Resource.Mes_Success_to_Save_Photo, cameraNo), Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    flag3 = true;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(string.Format(Resource.Mes_Fail_to_Save_Photo_01, cameraNo, exception.ToString()), Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                flag3 = false;
            }
            return flag3;
        }

        public void setRemarkforErrorTracing(string code1, string code2)
        {
            this.code1 = code1;
            this.code2 = code2;
        }

        public bool streamIPCamera(PictureBox image_panel, string ip_address, string username, string password, string web_url)
        {
            try
            {
                this.jpegSource = new JPEGStream(web_url);
                this.jpegSource.Login = username;
                this.jpegSource.Password = password;
                this.jpegSource.VideoSourceError += new VideoSourceErrorEventHandler(this.jpegSource_VideoSourceError);
                this.jpegSource.RequestTimeout = 0xbb8;
                this.CloseCurrentVideoSource();
                this.videoSourcePlayer.Parent = image_panel;
                this.videoSourcePlayer.Width = image_panel.Width;
                this.videoSourcePlayer.Height = image_panel.Height;
                this.videoSourcePlayer.VideoSource = this.jpegSource;
                this.videoSourcePlayer.Start();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool streamWebCamera(string name, PictureBox picBox)
        {
            bool flag2;
            int num = this.webcamExist(name);
            if (num < 0)
            {
                flag2 = false;
            }
            else
            {
                this.CloseCurrentVideoSource();
                this.videoSource = new VideoCaptureDevice(this.videoDevices[num].MonikerString);
                this.videoSource.NewFrame += delegate (object sender, NewFrameEventArgs eventArgs) {
                    Image image = (Image) eventArgs.Frame.Clone();
                    picBox.Image = image;
                };
                this.videoSource.DesiredFrameSize = new Size(160, 120);
                this.videoSource.Start();
                flag2 = true;
            }
            return flag2;
        }

        public int webcamExist(string webcam_name)
        {
            bool flag = false;
            int num = 0;
            try
            {
                this.videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (this.videoDevices.Count == 0)
                {
                    throw new ApplicationException();
                }
                foreach (FilterInfo info in this.videoDevices)
                {
                    if (info.Name == webcam_name)
                    {
                        flag = true;
                        break;
                    }
                    num++;
                }
            }
            catch (ApplicationException)
            {
                flag = false;
            }
            return (!flag ? -1 : num);
        }
    }
}

