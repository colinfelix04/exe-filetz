﻿namespace TokenAppHandler.Utility
{
    using System;
    using System.Data;
    using WindowsFormsApplication1;

    internal class WBTokenAppHandler
    {
        public static void addNewErrorList(string coy, string loc, string gatepassNo, string refNo, string tokenCode, string wbCode, string remark, string terminalID)
        {
            string str2;
            WBTable table2;
            string sqltext = "";
            WBTable table = new WBTable();
            sqltext = "SELECT TOP 1 * FROM wb_token WHERE key_1 = '" + gatepassNo + "' AND completed = 'N' ORDER BY uniq DESC";
            table.OpenTable("wb_token", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                return;
            }
            else
            {
                str2 = table.DT.Rows[0]["uniq"].ToString();
                table2 = new WBTable();
                string[] textArray1 = new string[] { "SELECT e.uniq FROM wb_errorList e INNER JOIN wb_token t on t.key_1 = e.code2 AND t.completed = 'N' WHERE e.code2 = '", gatepassNo, "' AND e.token_code = '", tokenCode, "'" };
                sqltext = string.Concat(textArray1);
                table2.OpenTable("wb_errorList", sqltext, WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    string str3 = "";
                    foreach (DataRow row in table2.DT.Rows)
                    {
                        str3 = row["uniq"].ToString();
                        WBTable table4 = new WBTable();
                        sqltext = "SELECT * FROM wb_errorList WHERE uniq = '" + str3 + "'";
                        table4.OpenTable("wb_errorList", sqltext, WBData.conn);
                        bool flag3 = table4.DT.Rows.Count > 0;
                        if (flag3 && (str2 != table4.DT.Rows[0]["token_uniq"].ToString()))
                        {
                            table4.DR = table4.DT.Rows[0];
                            table4.DR.BeginEdit();
                            table4.DR["token_uniq"] = str2;
                            table4.DR.EndEdit();
                            table4.Save();
                        }
                        table4.Dispose();
                    }
                }
            }
            table2.Dispose();
            WBTable table3 = new WBTable();
            table3.OpenTable("wb_errorList", "SELECT * FROM wb_errorList WHERE 1 = 2", WBData.conn);
            table3.DR = table3.DT.NewRow();
            table3.DR["coy"] = coy;
            table3.DR["location_code"] = loc;
            table3.DR["wbcode"] = wbCode;
            table3.DR["code1"] = "WB";
            table3.DR["code2"] = gatepassNo;
            table3.DR["code3"] = (refNo == "REF") ? "" : refNo;
            table3.DR["error_date"] = DateTime.Now;
            table3.DR["error_msg"] = parseNewLine(remark);
            table3.DR["terminal_id"] = terminalID;
            table3.DR["token_code"] = tokenCode;
            table3.DR["token_uniq"] = str2;
            table3.DT.Rows.Add(table3.DR);
            table3.Save();
            table3.Dispose();
        }

        public static bool isTokenAppApproved(string gatepassNo, string refNo, string tokenCode)
        {
            string sqltext = "";
            bool flag = false;
            WBTable table = new WBTable();
            if ((refNo == "REF") || (refNo == ""))
            {
                string[] textArray1 = new string[] { "SELECT token_uniq FROM wb_errorList WHERE code1 = 'WB' AND code2 = '", gatepassNo, "' AND token_code = '", tokenCode, "'" };
                sqltext = string.Concat(textArray1);
            }
            else
            {
                string[] textArray2 = new string[] { "SELECT token_uniq FROM wb_errorList WHERE code1 = 'WB' AND code2 = '", gatepassNo, "' AND code3 = '", refNo, "' AND token_code = '", tokenCode, "'" };
                sqltext = string.Concat(textArray2);
            }
            table.OpenTable("wb_errorList", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                flag = false;
            }
            else if (table.DT.Rows[0]["token_uniq"].ToString() == "")
            {
                flag = false;
            }
            else
            {
                WBTable table2 = new WBTable();
                sqltext = "SELECT completed FROM wb_token WHERE uniq = '" + table.DT.Rows[0]["token_uniq"].ToString() + "'";
                table2.OpenTable("wb_token", sqltext, WBData.conn);
                flag = (table2.DT.Rows.Count > 0) && (table2.DT.Rows[0]["completed"].ToString() == "Y");
                table2.Dispose();
            }
            table.Dispose();
            return flag;
        }

        private static string parseNewLine(string txt)
        {
            string str = "";
            if (txt.Contains(" >> "))
            {
                str = txt.Replace(" >> ", "<br>");
            }
            if (txt.Contains(">> "))
            {
                str = txt.Replace(">> ", "<br>");
            }
            if (txt.Contains(" >>"))
            {
                str = txt.Replace(" >>", "<br>");
            }
            if (txt.Contains(">>"))
            {
                str = txt.Replace(">>", "<br>");
            }
            if (txt.Contains("\n\n") || txt.Contains("\n"))
            {
                str = txt.Replace("\n\n", "<br>");
            }
            return str.Replace("\n", "<br>");
        }
    }
}

