﻿namespace OffLine.Installer
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Configuration.Install;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;

    [RunInstaller(true)]
    public class InstallerClass : Installer
    {
        public InstallerClass()
        {
            base.Committed += new InstallEventHandler(this.MyInstaller_Committed);
            base.Committing += new InstallEventHandler(this.MyInstaller_Committing);
        }

        public override void Commit(IDictionary savedState)
        {
            base.Commit(savedState);
        }

        public override void Install(IDictionary savedState)
        {
            base.Install(savedState);
        }

        private void MyInstaller_Committed(object sender, InstallEventArgs e)
        {
            try
            {
                Directory.SetCurrentDirectory(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                Process.Start(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\VWBIndicator.exe");
            }
            catch
            {
            }
        }

        private void MyInstaller_Committing(object sender, InstallEventArgs e)
        {
        }

        public override void Rollback(IDictionary savedState)
        {
            base.Rollback(savedState);
        }
    }
}

