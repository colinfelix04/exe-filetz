﻿namespace NetworkShare.Utility
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class WBNetworkShare
    {
        private static string _remoteUncName;
        private static string _remoteComputerName;
        private const int RESOURCE_CONNECTED = 1;
        private const int RESOURCE_GLOBALNET = 2;
        private const int RESOURCE_REMEMBERED = 3;
        private const int RESOURCETYPE_ANY = 0;
        private const int RESOURCETYPE_DISK = 1;
        private const int RESOURCETYPE_PRINT = 2;
        private const int RESOURCEDISPLAYTYPE_GENERIC = 0;
        private const int RESOURCEDISPLAYTYPE_DOMAIN = 1;
        private const int RESOURCEDISPLAYTYPE_SERVER = 2;
        private const int RESOURCEDISPLAYTYPE_SHARE = 3;
        private const int RESOURCEDISPLAYTYPE_FILE = 4;
        private const int RESOURCEDISPLAYTYPE_GROUP = 5;
        private const int RESOURCEUSAGE_CONNECTABLE = 1;
        private const int RESOURCEUSAGE_CONTAINER = 2;
        private const int CONNECT_INTERACTIVE = 8;
        private const int CONNECT_PROMPT = 0x10;
        private const int CONNECT_REDIRECT = 0x80;
        private const int CONNECT_UPDATE_PROFILE = 1;
        private const int CONNECT_COMMANDLINE = 0x800;
        private const int CONNECT_CMD_SAVECRED = 0x1000;
        private const int CONNECT_LOCALDRIVE = 0x100;
        private const int NO_ERROR = 0;
        private const int ERROR_ACCESS_DENIED = 5;
        private const int ERROR_ALREADY_ASSIGNED = 0x55;
        private const int ERROR_BAD_DEVICE = 0x4b0;
        private const int ERROR_BAD_NET_NAME = 0x43;
        private const int ERROR_BAD_PROVIDER = 0x4b4;
        private const int ERROR_CANCELLED = 0x4c7;
        private const int ERROR_EXTENDED_ERROR = 0x4b8;
        private const int ERROR_INVALID_ADDRESS = 0x1e7;
        private const int ERROR_INVALID_PARAMETER = 0x57;
        private const int ERROR_INVALID_PASSWORD = 0x4c0;
        private const int ERROR_MORE_DATA = 0xea;
        private const int ERROR_NO_MORE_ITEMS = 0x103;
        private const int ERROR_NO_NET_OR_BAD_PATH = 0x4b3;
        private const int ERROR_NO_NETWORK = 0x4c6;
        private const int ERROR_BAD_PROFILE = 0x4b6;
        private const int ERROR_CANNOT_OPEN_PROFILE = 0x4b5;
        private const int ERROR_DEVICE_IN_USE = 0x964;
        private const int ERROR_NOT_CONNECTED = 0x8ca;
        private const int ERROR_OPEN_FILES = 0x961;
        private static ErrorClass[] ERROR_LIST;

        static WBNetworkShare()
        {
            ErrorClass[] classArray1 = new ErrorClass[20];
            classArray1[0] = new ErrorClass(5, "Error: Access Denied");
            classArray1[1] = new ErrorClass(0x55, "Error: Already Assigned");
            classArray1[2] = new ErrorClass(0x4b0, "Error: Bad Device");
            classArray1[3] = new ErrorClass(0x43, "Error: Bad Net Name");
            classArray1[4] = new ErrorClass(0x4b4, "Error: Bad Provider");
            classArray1[5] = new ErrorClass(0x4c7, "Error: Cancelled");
            classArray1[6] = new ErrorClass(0x4b8, "Error: Extended Error");
            classArray1[7] = new ErrorClass(0x1e7, "Error: Invalid Address");
            classArray1[8] = new ErrorClass(0x57, "Error: Invalid Parameter");
            classArray1[9] = new ErrorClass(0x4c0, "Error: Invalid Password");
            classArray1[10] = new ErrorClass(0xea, "Error: More Data");
            classArray1[11] = new ErrorClass(0x103, "Error: No More Items");
            classArray1[12] = new ErrorClass(0x4b3, "Error: No Net Or Bad Path");
            classArray1[13] = new ErrorClass(0x4c6, "Error: No Network");
            classArray1[14] = new ErrorClass(0x4b6, "Error: Bad Profile");
            classArray1[15] = new ErrorClass(0x4b5, "Error: Cannot Open Profile");
            classArray1[0x10] = new ErrorClass(0x964, "Error: Device In Use");
            classArray1[0x11] = new ErrorClass(0x4b8, "Error: Extended Error");
            classArray1[0x12] = new ErrorClass(0x8ca, "Error: Not Connected");
            classArray1[0x13] = new ErrorClass(0x961, "Error: Open Files");
            ERROR_LIST = classArray1;
        }

        public static string Access(string remoteComputerName, string domainOrComuterName, string userName, string password)
        {
            setVariable(remoteComputerName, domainOrComuterName + @"\" + userName, password);
            return ConnectToShare(_remoteUncName, UserName, Password, false);
        }

        private static string ConnectToShare(string remoteUnc, string username, string password, bool promptUser)
        {
            NETRESOURCE netresource1 = new NETRESOURCE();
            netresource1.dwType = 1;
            netresource1.lpRemoteName = remoteUnc;
            NETRESOURCE lpNetResource = netresource1;
            int errNum = !promptUser ? WNetUseConnection(IntPtr.Zero, lpNetResource, password, username, 0, null, null, null) : WNetUseConnection(IntPtr.Zero, lpNetResource, "", "", 0x18, null, null, null);
            return ((errNum != 0) ? getErrorForNumber(errNum) : "");
        }

        public static string DisconnectFromShare(string remoteUnc)
        {
            int errNum = WNetCancelConnection2(remoteUnc, 1, false);
            return ((errNum != 0) ? getErrorForNumber(errNum) : "");
        }

        private static string getErrorForNumber(int errNum)
        {
            ErrorClass[] classArray = ERROR_LIST;
            int index = 0;
            while (true)
            {
                string message;
                if (index >= classArray.Length)
                {
                    message = "Error: Unknown, " + errNum;
                }
                else
                {
                    ErrorClass class2 = classArray[index];
                    if (class2.num != errNum)
                    {
                        index++;
                        continue;
                    }
                    message = class2.message;
                }
                return message;
            }
        }

        private static void setVariable(string remoteComputerName, string userName, string password)
        {
            RemoteComputerName = remoteComputerName;
            UserName = userName;
            Password = password;
        }

        [DllImport("Mpr.dll")]
        private static extern int WNetCancelConnection2(string lpName, int dwFlags, bool fForce);
        [DllImport("Mpr.dll")]
        private static extern int WNetUseConnection(IntPtr hwndOwner, NETRESOURCE lpNetResource, string lpPassword, string lpUserID, int dwFlags, string lpAccessName, string lpBufferSize, string lpResult);

        public static string RemoteComputerName
        {
            get => 
                _remoteComputerName;
            set
            {
                _remoteComputerName = value;
                _remoteUncName = @"\\" + _remoteComputerName;
            }
        }

        public static string UserName { get; set; }

        public static string Password { get; set; }

        [StructLayout(LayoutKind.Sequential)]
        private struct ErrorClass
        {
            public int num;
            public string message;
            public ErrorClass(int num, string message)
            {
                this.num = num;
                this.message = message;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private class NETRESOURCE
        {
            public int dwScope = 0;
            public int dwType = 0;
            public int dwDisplayType = 0;
            public int dwUsage = 0;
            public string lpLocalName = "";
            public string lpRemoteName = "";
            public string lpComment = "";
            public string lpProvider = "";
        }
    }
}

