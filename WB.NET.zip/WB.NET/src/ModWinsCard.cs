﻿using System;
using System.Runtime.InteropServices;

public class ModWinsCard
{
    public const int SCARD_S_SUCCESS = 0;
    public const int SCARD_ATR_LENGTH = 0x21;
    public const int CT_MCU = 0;
    public const int CT_IIC_Auto = 1;
    public const int CT_IIC_1K = 2;
    public const int CT_IIC_2K = 3;
    public const int CT_IIC_4K = 4;
    public const int CT_IIC_8K = 5;
    public const int CT_IIC_16K = 6;
    public const int CT_IIC_32K = 7;
    public const int CT_IIC_64K = 8;
    public const int CT_IIC_128K = 9;
    public const int CT_IIC_256K = 10;
    public const int CT_IIC_512K = 11;
    public const int CT_IIC_1024K = 12;
    public const int CT_AT88SC153 = 13;
    public const int CT_AT88SC1608 = 14;
    public const int CT_SLE4418 = 15;
    public const int CT_SLE4428 = 0x10;
    public const int CT_SLE4432 = 0x11;
    public const int CT_SLE4442 = 0x12;
    public const int CT_SLE4406 = 0x13;
    public const int CT_SLE4436 = 20;
    public const int CT_SLE5536 = 0x15;
    public const int CT_MCUT0 = 0x16;
    public const int CT_MCUT1 = 0x17;
    public const int CT_MCU_Auto = 0x18;
    public const int SCARD_SCOPE_USER = 0;
    public const int SCARD_SCOPE_TERMINAL = 1;
    public const int SCARD_SCOPE_SYSTEM = 2;
    public const int SCARD_STATE_UNAWARE = 0;
    public const int SCARD_STATE_IGNORE = 1;
    public const int SCARD_STATE_CHANGED = 2;
    public const int SCARD_STATE_UNKNOWN = 4;
    public const int SCARD_STATE_UNAVAILABLE = 8;
    public const int SCARD_STATE_EMPTY = 0x10;
    public const int SCARD_STATE_PRESENT = 0x20;
    public const int SCARD_STATE_ATRMATCH = 0x40;
    public const int SCARD_STATE_EXCLUSIVE = 0x80;
    public const int SCARD_STATE_INUSE = 0x100;
    public const int SCARD_STATE_MUTE = 0x200;
    public const int SCARD_STATE_UNPOWERED = 0x400;
    public const int SCARD_SHARE_EXCLUSIVE = 1;
    public const int SCARD_SHARE_SHARED = 2;
    public const int SCARD_SHARE_DIRECT = 3;
    public const int SCARD_LEAVE_CARD = 0;
    public const int SCARD_RESET_CARD = 1;
    public const int SCARD_UNPOWER_CARD = 2;
    public const int SCARD_EJECT_CARD = 3;
    public const long FILE_DEVICE_SMARTCARD = 0x310000L;
    public const long IOCTL_SMARTCARD_DIRECT = 0x312008L;
    public const long IOCTL_SMARTCARD_SELECT_SLOT = 0x31200cL;
    public const long IOCTL_SMARTCARD_DRAW_LCDBMP = 0x312010L;
    public const long IOCTL_SMARTCARD_DISPLAY_LCD = 0x312014L;
    public const long IOCTL_SMARTCARD_CLR_LCD = 0x312018L;
    public const long IOCTL_SMARTCARD_READ_KEYPAD = 0x31201cL;
    public const long IOCTL_SMARTCARD_READ_RTC = 0x312024L;
    public const long IOCTL_SMARTCARD_SET_RTC = 0x312028L;
    public const long IOCTL_SMARTCARD_SET_OPTION = 0x31202cL;
    public const long IOCTL_SMARTCARD_SET_LED = 0x312030L;
    public const long IOCTL_SMARTCARD_LOAD_KEY = 0x312038L;
    public const long IOCTL_SMARTCARD_READ_EEPROM = 0x312044L;
    public const long IOCTL_SMARTCARD_WRITE_EEPROM = 0x312048L;
    public const long IOCTL_SMARTCARD_GET_VERSION = 0x31204cL;
    public const long IOCTL_SMARTCARD_GET_READER_INFO = 0x31200cL;
    public const long IOCTL_SMARTCARD_SET_CARD_TYPE = 0x312030L;
    public const long IOCTL_SMARTCARD_ACR128_ESCAPE_COMMAND = 0x31207cL;
    public const int SCARD_F_INTERNAL_ERROR = -2146435071;
    public const int SCARD_E_CANCELLED = -2146435070;
    public const int SCARD_E_INVALID_HANDLE = -2146435069;
    public const int SCARD_E_INVALID_PARAMETER = -2146435068;
    public const int SCARD_E_INVALID_TARGET = -2146435067;
    public const int SCARD_E_NO_MEMORY = -2146435066;
    public const int SCARD_F_WAITED_TOO_LONG = -2146435065;
    public const int SCARD_E_INSUFFICIENT_BUFFER = -2146435064;
    public const int SCARD_E_UNKNOWN_READER = -2146435063;
    public const int SCARD_E_TIMEOUT = -2146435062;
    public const int SCARD_E_SHARING_VIOLATION = -2146435061;
    public const int SCARD_E_NO_SMARTCARD = -2146435060;
    public const int SCARD_E_UNKNOWN_CARD = -2146435059;
    public const int SCARD_E_CANT_DISPOSE = -2146435058;
    public const int SCARD_E_PROTO_MISMATCH = -2146435057;
    public const int SCARD_E_NOT_READY = -2146435056;
    public const int SCARD_E_INVALID_VALUE = -2146435055;
    public const int SCARD_E_SYSTEM_CANCELLED = -2146435054;
    public const int SCARD_F_COMM_ERROR = -2146435053;
    public const int SCARD_F_UNKNOWN_ERROR = -2146435052;
    public const int SCARD_E_INVALID_ATR = -2146435051;
    public const int SCARD_E_NOT_TRANSACTED = -2146435050;
    public const int SCARD_E_READER_UNAVAILABLE = -2146435049;
    public const int SCARD_P_SHUTDOWN = -2146435048;
    public const int SCARD_E_PCI_TOO_SMALL = -2146435047;
    public const int SCARD_E_READER_UNSUPPORTED = -2146435046;
    public const int SCARD_E_DUPLICATE_READER = -2146435045;
    public const int SCARD_E_CARD_UNSUPPORTED = -2146435044;
    public const int SCARD_E_NO_SERVICE = -2146435043;
    public const int SCARD_E_SERVICE_STOPPED = -2146435042;
    public const int SCARD_W_UNSUPPORTED_CARD = -2146435041;
    public const int SCARD_W_UNRESPONSIVE_CARD = -2146435040;
    public const int SCARD_W_UNPOWERED_CARD = -2146435039;
    public const int SCARD_W_RESET_CARD = -2146435038;
    public const int SCARD_W_REMOVED_CARD = -2146435037;
    public const int SCARD_PROTOCOL_UNDEFINED = 0;
    public const int SCARD_PROTOCOL_T0 = 1;
    public const int SCARD_PROTOCOL_T1 = 2;
    public const int SCARD_PROTOCOL_RAW = 0x10000;
    public const int SCARD_UNKNOWN = 0;
    public const int SCARD_ABSENT = 1;
    public const int SCARD_PRESENT = 2;
    public const int SCARD_SWALLOWED = 3;
    public const int SCARD_POWERED = 4;
    public const int SCARD_NEGOTIABLE = 5;
    public const int SCARD_SPECIFIC = 6;

    public static string GetScardErrMsg(int ReturnCode)
    {
        int num = ReturnCode;
        switch (num)
        {
            case -2146435071:
                return "An internal consistency check failed.";

            case -2146435070:
                return "The action was canceled by an SCardCancel request.";

            case -2146435069:
                return "The supplied handle was invalid.";

            case -2146435068:
                return "One or more of the supplied parameters could not be properly interpreted.";

            case -2146435067:
                return "Registry startup information is missing or invalid.";

            case -2146435066:
                return "Not enough memory available to complete this command.";

            case -2146435065:
                return "An internal consistency timer has expired.";

            case -2146435064:
                return "The data buffer for returned data is too small for the returned data.";

            case -2146435063:
                return "The specified reader name is not recognized.";

            case -2146435062:
                return "The user-specified timeout value has expired.";

            case -2146435061:
                return "The smart card cannot be accessed because of other outstanding connections.";

            case -2146435060:
                return "The operation requires a smart card, but no smart card is currently in the device.";

            case -2146435059:
                return "The specified smart card name is not recognized.";

            case -2146435058:
                return "The system could not dispose of the media in the requested manner.";

            case -2146435057:
                return "The requested protocols are incompatible with the protocol currently in use with the card.";

            case -2146435056:
                return "The reader or card is not ready to accept commands.";

            case -2146435055:
                return "One or more of the supplied parameter values could not be properly interpreted.";

            case -2146435054:
                return "The action was canceled by the system, presumably to log off or shut down.";

            case -2146435053:
                return "An internal communications error has been detected.";

            case -2146435052:
                return "An internal error has been detected, but the source is unknown.";

            case -2146435051:
                return "An ATR string obtained from the registry is not a valid ATR string.";

            case -2146435050:
                return "An attempt was made to end a non-existent transaction.";

            case -2146435049:
                return "The specified reader is not currently available for use.";

            case -2146435048:
                break;

            case -2146435047:
                return "The PCI receive buffer was too small.";

            case -2146435046:
                return "The reader driver does not meet minimal requirements for support.";

            case -2146435045:
                return "The reader driver didn't produce a unique reader name.";

            case -2146435044:
                return "The smart card does not meet minimal requirements for support.";

            case -2146435043:
                return "The smart card resource manager is not running.";

            case -2146435042:
                return "The smart card resource manager has shut down.";

            case -2146435041:
                return "The reader cannot communicate with the card, due to ATR string configuration conflicts.";

            case -2146435040:
                return "The smart card is not responding to a reset.";

            case -2146435039:
                return "Power has been removed from the smart card, so that further communication is not possible.";

            case -2146435038:
                return "The smart card has been reset, so any shared state information is invalid.";

            case -2146435037:
                return "The smart card has been removed, so that further communication is not possible.";

            default:
                if (num != 0)
                {
                    break;
                }
                return "No error was encountered.";
        }
        return "?";
    }

    [DllImport("winscard.dll")]
    public static extern int SCardBeginTransaction(int hCard);
    [DllImport("winscard.dll")]
    public static extern int SCardConnect(int hContext, string szReaderName, int dwShareMode, int dwPrefProtocol, ref int phCard, ref int ActiveProtocol);
    [DllImport("winscard.dll")]
    public static extern int SCardDisconnect(int hCard, int Disposition);
    [DllImport("winscard.dll")]
    public static extern int SCardEndTransaction(int hCard, int Disposition);
    [DllImport("winscard.dll")]
    public static extern int SCardEstablishContext(int dwScope, int pvReserved1, int pvReserved2, ref int phContext);
    [DllImport("winscard.dll")]
    public static extern int SCardListReaderGroups(int hContext, ref string mzGroups, ref int pcchGroups);
    [DllImport("winscard.DLL", EntryPoint="SCardListReadersA", CharSet=CharSet.Ansi)]
    public static extern int SCardListReaders(int hContext, byte[] Groups, byte[] Readers, ref int pcchReaders);
    [DllImport("winscard.dll")]
    public static extern int SCardReleaseContext(int phContext);
    [DllImport("winscard.dll")]
    public static extern int SCardState(int hCard, ref uint State, ref uint Protocol, ref byte ATR, ref uint ATRLen);
    [DllImport("winscard.dll")]
    public static extern int SCardStatus(int hCard, string szReaderName, ref int pcchReaderLen, ref int State, ref int Protocol, ref byte ATR, ref int ATRLen);
    [DllImport("winscard.dll")]
    public static extern int SCardTransmit(int hCard, ref SCARD_IO_REQUEST pioSendRequest, ref byte SendBuff, int SendBuffLen, ref SCARD_IO_REQUEST pioRecvRequest, ref byte RecvBuff, ref int RecvBuffLen);

    [StructLayout(LayoutKind.Sequential)]
    public struct APDURec
    {
        public byte bCLA;
        public byte bINS;
        public byte bP1;
        public byte bP2;
        public byte bP3;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst=0x100)]
        public byte[] Data;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst=3)]
        public byte[] SW;
        public bool IsSend;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SCARD_IO_REQUEST
    {
        public int dwProtocol;
        public int cbPciLength;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SCARD_READERSTATE
    {
        public string RdrName;
        public int UserData;
        public int RdrCurrState;
        public int RdrEventState;
        public int ATRLength;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst=0x25)]
        public byte ATRValue;
    }
}

